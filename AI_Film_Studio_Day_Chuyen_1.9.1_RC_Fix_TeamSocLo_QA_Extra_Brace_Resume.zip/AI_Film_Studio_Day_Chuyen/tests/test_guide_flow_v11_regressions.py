import json
from pathlib import Path
import pytest
from studio.guide_flow import GuideFlow,guide_sections
from studio.guide_preflight import semantic_candidates
from studio.guide_batch import batch_policy,parse_batch
from studio.contract import ContractError
from studio.api import Generation

class Fake:
    model='test';provider_id='test'
    def __init__(self,values):self.values=list(values);self.calls=[]
    def generate(self,*,system,user,max_output_tokens):
        self.calls.append((system,user))
        if not self.values:raise AssertionError('Extra API call: '+system[:80])
        return Generation(self.values.pop(0),50,60,0)


def setup(tmp_path,guide,files,source='SOURCE'):
    p=tmp_path/'rules';p.mkdir()
    (p/'HUONG_DAN.txt').write_text(guide,encoding='utf8')
    for n,s in files.items():(p/n).write_text(s,encoding='utf8')
    src=tmp_path/'novel.txt';src.write_text(source,encoding='utf8')
    return GuideFlow.create(tmp_path/'project',None,[p],[src])


def test_output_directives_are_not_inputs_even_with_quoted_and_uppercase(tmp_path):
    guide=('1- SCRIPT\nĐọc RULE.txt. XUẤT FILE TÊN "XX.TXT". '
           'Xuất file tên "DONE.txt".\n')
    st=guide_sections(guide,'HUONG_DAN.txt')[0]
    assert st['references']==['RULE.txt']
    assert st['output_references']==['DONE.txt']
    assert st['output_placeholders']==['XX.TXT']
    flow=setup(tmp_path,guide,{'RULE.txt':'Một quy tắc chung.'})
    fake=Fake(['@@FILE:DONE.txt@@\nPASS','{"verdict":"PASS","issues":[]}'])
    flow.run_next(fake)
    assert flow.status()['finished']


def test_current_step_literal_conflict_blocks_before_generate(tmp_path):
    guide='1- SCENE\nĐọc RULE_A.txt và RULE_B.txt. Xuất scene.txt.\n'
    flow=setup(tmp_path,guide,{'RULE_A.txt':'Ngôn ngữ đầu ra: tiếng Việt.',
                               'RULE_B.txt':'Ngôn ngữ đầu ra: tiếng Anh.'})
    conflicts=flow.current_conflicts()
    assert len(conflicts)==1
    fake=Fake([])
    with pytest.raises(ContractError,match='mâu thuẫn'):
        flow.run_next(fake)
    assert not fake.calls
    result=flow.run_next(Fake(['@@FILE:scene.txt@@\nVăn bản','{"verdict":"PASS","issues":[]}']),
                         conflict_choices={conflicts[0]['id']:'left'})
    assert result['conflict_decisions'][conflicts[0]['id']]=='left'


def test_semantic_audit_citations_and_human_decline(tmp_path):
    guide='1- SCRIPT\nĐọc RULE_A.txt và RULE_B.txt. Xuất scene.txt.\n'
    rules={'RULE_A.txt':'Phải giữ nguyên lời thoại trực tiếp của nhân vật.',
           'RULE_B.txt':'Phải đổi mọi lời thoại trực tiếp thành gián tiếp.'}
    flow=setup(tmp_path,guide,rules)
    report={'conflicts':[{'reason':'Cách xử lý toàn bộ lời thoại không thể đồng thời',
            'left':{'source_file':'RULE_A.txt','source_line':1,'source_quote':rules['RULE_A.txt']},
            'right':{'source_file':'RULE_B.txt','source_line':1,'source_quote':rules['RULE_B.txt']}}]}
    with pytest.raises(ContractError,match='chưa rà'):
        flow.run_next(Fake([]),require_semantic_audit=True)
    found=flow.audit_current_conflicts(Fake([json.dumps(report,ensure_ascii=False)]))
    assert len(found)==1 and found[0]['kind']=='review'
    with pytest.raises(ContractError,match='mâu thuẫn'):
        flow.run_next(Fake([]),require_semantic_audit=True)
    response=flow.run_next(Fake(['@@FILE:scene.txt@@\nNội dung','{"verdict":"PASS","issues":[]}']),
                           conflict_choices={found[0]['id']:'not_conflict'},require_semantic_audit=True)
    assert response['qa_verdict']=='PASS'


def test_forged_semantic_citation_never_persisted(tmp_path):
    guide='1- SCRIPT\nĐọc RULE_A.txt và RULE_B.txt.\n'
    flow=setup(tmp_path,guide,{'RULE_A.txt':'Alpha nguyên văn.','RULE_B.txt':'Beta nguyên văn.'})
    forged={'conflicts':[{'reason':'Contradiction','left':{
        'source_file':'RULE_A.txt','source_line':1,'source_quote':'Alpha do model tự viết.'},
        'right':{'source_file':'RULE_B.txt','source_line':1,'source_quote':'Beta nguyên văn.'}}]}
    with pytest.raises(ContractError,match='trích sai'):
        flow.audit_current_conflicts(Fake([json.dumps(forged,ensure_ascii=False)]))
    assert flow.needs_semantic_audit()


def test_no_false_block_when_semantic_audit_returns_empty(tmp_path):
    guide='1- SCRIPT\nĐọc RULE_A.txt và RULE_B.txt. Xuất scene.txt.\n'
    flow=setup(tmp_path,guide,{'RULE_A.txt':'Không thêm thông tin bịa.',
                               'RULE_B.txt':'Bảo toàn tuyến truyện.'})
    found=flow.audit_current_conflicts(Fake(['{"conflicts":[]}']))
    assert found==[] and not flow.needs_semantic_audit()
    output=flow.run_next(Fake(['@@FILE:scene.txt@@\nDữ liệu','{"verdict":"PASS","issues":[]}']),require_semantic_audit=True)
    assert output['state']=='LOCKED'


def test_generic_repair_then_reqa(tmp_path):
    guide='1- SCRIPT\nĐọc RULE.txt. Xuất scene.txt.\n'
    flow=setup(tmp_path,guide,{'RULE.txt':'Viết văn bản.'})
    fake=Fake(['@@FILE:scene.txt@@\nSAI', '{"verdict":"FAIL","issues":["Bị thiếu canon"]}',
               '@@FILE:scene.txt@@\nĐÚNG', '{"verdict":"PASS","issues":[]}'])
    result=flow.run_next(fake,repair_attempts=2)
    assert result['state']=='LOCKED'
    assert 'ĐÚNG' in (flow.folder/'steps'/'STEP_001'/'scene.txt').read_text(encoding='utf8')
    assert len(fake.calls)==4


def test_batch_splits_source_2_and_qa_every_4_then_final(tmp_path):
    guide=('1- PROMPT LINE\nĐọc RULE.txt.\n'
           '1 DÒNG/CÂU NGUỒN = 1 OUTPUT_SLOT_LINE = 1 IMAGE_PROMPT.\n'
           'NGUỒN VĂN BẢN DÙNG ĐỂ TẠO PROMPT ẢNH LÀ "SOURCE_LINES".\n'
           'YÊU CẦU MỖI LẦN CHAT CHỈ PHÂN TÍCH 2 DÒNG/CÂU và tạo đúng 2 prompt.\n'
           'SAU 2 LẦN, TỨC 4 PROMPT, phải QA. Lần cuối QA dù chưa đủ.\n')
    rule_dir=tmp_path/'rules';rule_dir.mkdir()
    (rule_dir/'HUONG_DAN.txt').write_text(guide,encoding='utf8')
    (rule_dir/'RULE.txt').write_text('Không bịa sự kiện.',encoding='utf8')
    src=tmp_path/'SOURCE_LINES.txt';src.write_text('One\nTwo\nThree\nFour\nFive\n',encoding='utf8')
    flow=GuideFlow.create(tmp_path/'project',None,[rule_dir],[src])
    policy=batch_policy(flow.meta['steps'][0])
    assert policy['batch_size']==2 and policy['qa_every']==4
    fake=Fake(['IMAGE_PROMPT_000001 | First\nIMAGE_PROMPT_000002 | Second',
               'IMAGE_PROMPT_000003 | Third\nIMAGE_PROMPT_000004 | Fourth',
               '{"verdict":"PASS","issues":[]}',
               'IMAGE_PROMPT_000005 | Fifth',
               '{"verdict":"PASS","issues":[]}',
               '{"verdict":"PASS","issues":[]}'])
    result=flow.run_next(fake)
    assert result['line_count']==5 and len(fake.calls)==6
    assert len((flow.folder/'steps'/'STEP_001'/'IMAGE_PROMPTS.txt').read_text().splitlines())==5


def test_batch_qa_fail_blocks_and_uses_checkpoint_on_resume(tmp_path):
    guide=('1- PROMPT LINE\nĐọc RULE.txt.\n'
           '1 DÒNG/CÂU NGUỒN = 1 OUTPUT_SLOT_LINE = 1 IMAGE_PROMPT.\n'
           'NGUỒN VĂN BẢN DÙNG ĐỂ TẠO PROMPT ẢNH LÀ "SOURCE_LINES".\n'
           'YÊU CẦU MỖI LẦN CHAT CHỈ PHÂN TÍCH 2 DÒNG/CÂU.\n'
           'SAU 1 LẦN, TỨC 2 PROMPT, phải QA.\n')
    rules=tmp_path/'rules';rules.mkdir()
    (rules/'HUONG_DAN.txt').write_text(guide,encoding='utf8')
    (rules/'RULE.txt').write_text('Không bịa.',encoding='utf8')
    src=tmp_path/'SOURCE_LINES.txt';src.write_text('A\nB\nC\n',encoding='utf8')
    flow=GuideFlow.create(tmp_path/'project',None,[rules],[src])
    failed=Fake(['IMAGE_PROMPT_000001 | A\nIMAGE_PROMPT_000002 | B',
                 '{"verdict":"PASS","issues":[]}',
                 'IMAGE_PROMPT_000003 | C',
                 '{"verdict":"FAIL","issues":["IMAGE_PROMPT_000003 sai"]}'])
    with pytest.raises(ContractError,match='QA batch'):
        flow.run_next(failed)
    assert flow.status()['completed']==0
    resume=Fake(['IMAGE_PROMPT_000003 | C revised',
                 '{"verdict":"PASS","issues":[]}',
                 '{"verdict":"PASS","issues":[]}'])
    result=flow.run_next(resume)
    assert result['line_count']==3
    assert len(resume.calls)==3
    assert 'C revised' in (flow.folder/'steps'/'STEP_001'/'IMAGE_PROMPTS.txt').read_text()


def test_parse_batch_reject_missing_or_duplicate_ids():
    with pytest.raises(ContractError):parse_batch('IMAGE_PROMPT_000001 | A\nIMAGE_PROMPT_000001 | Duplicate',1,2)
    with pytest.raises(ContractError):parse_batch('IMAGE_PROMPT_000001 | A',1,2)


def test_real_guide_data_support_not_misclassified_as_rule():
    p=Path('/mnt/data/QUY_TRINH_HUONG_DAN.txt')
    if not p.is_file():pytest.skip('User rulepack not available')
    steps=guide_sections(p.read_text(encoding='utf8'),'QUY_TRINH_HUONG_DAN.txt')
    assert len(steps)==7
    assert set(x.upper() for x in steps[5]['references'])=={'B5.TXT','B6.TXT'}
    assert steps[5]['auxiliary_references']==['TBN6A.txt']
    assert 'XX.TXT' not in steps[5]['references']
    assert steps[5]['output_placeholders']==['XX.TXT']


def test_later_auxiliary_never_sent_to_earlier_step(tmp_path):
    guide=('1- FIRST\nĐọc RULE_A.txt. Xuất FIRST.txt.\n'
           '2- SECOND\nĐọc RULE_B.txt và file dữ liệu hỗ trợ AUX.txt. Xuất SECOND.txt.\n')
    rules=tmp_path/'rules';rules.mkdir()
    (rules/'HUONG_DAN.txt').write_text(guide,encoding='utf8')
    (rules/'RULE_A.txt').write_text('Alpha.',encoding='utf8')
    (rules/'RULE_B.txt').write_text('Beta.',encoding='utf8')
    main=tmp_path/'story.txt';main.write_text('Story source.',encoding='utf8')
    aux=tmp_path/'AUX.txt';aux.write_text('FUTURE AUX SECRET',encoding='utf8')
    flow=GuideFlow.create(tmp_path/'project',None,[rules],[main,aux])
    fake=Fake(['@@FILE:FIRST.txt@@\nFirst','{"verdict":"PASS","issues":[]}'])
    flow.run_next(fake)
    assert 'FUTURE AUX SECRET' not in '\n'.join(a+b for a,b in fake.calls)
    stage2=Fake(['@@FILE:SECOND.txt@@\nSecond','{"verdict":"PASS","issues":[]}'])
    flow.run_next(stage2)
    assert 'FUTURE AUX SECRET' in stage2.calls[0][1]


def test_switching_model_requires_fresh_semantic_audit(tmp_path):
    guide='1- SCRIPT\nĐọc RULE_A.txt và RULE_B.txt. Xuất scene.txt.\n'
    flow=setup(tmp_path,guide,{'RULE_A.txt':'Không bịa thêm.', 'RULE_B.txt':'Giữ nguồn.'})
    flow.audit_current_conflicts(Fake(['{"conflicts":[]}']))
    assert not flow.needs_semantic_audit('test','test')
    assert flow.needs_semantic_audit('tuansu','another-model')
