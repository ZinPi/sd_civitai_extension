"""Regressions for the repeated TeamSocLo timeout / paid preflight problem."""
from __future__ import annotations
import json
from types import SimpleNamespace as NS
import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.model_preflight import ensure_checked, mark_checked, was_checked
from studio.one_click import BudgetedProvider
from studio.guide_flow import GuideFlow
from tests.test_scene_responsive_v14 import SceneProvider, project


class CountingGateway:
    model='test-model'
    effort='default'
    provider_id='teamsoclo'
    is_live=True
    concurrency_limit=1
    def __init__(self,fail=False):
        self.calls=[]
        self.fail=fail
    def generate(self,*,system,user,max_output_tokens):
        self.calls.append((system,user,max_output_tokens))
        if self.fail:raise ContractError('Simulated unavailable provider')
        return Generation('OK',20,2,0)


def test_successful_preflight_is_cached_and_budgeted(tmp_path,monkeypatch):
    from studio import model_preflight
    monkeypatch.setattr(model_preflight,'_CURRENT',{})
    base=CountingGateway()
    guard=BudgetedProvider(base,tmp_path,max_usd=10,max_calls=12)
    assert ensure_checked(guard,tmp_path,'teamsoclo','test-model','test-key') is True
    assert len(base.calls)==1
    assert (tmp_path/'api_usage_guard.json').exists()
    receipt=(tmp_path/'model_preflight_receipt.json').read_text(encoding='utf-8')
    assert 'test-key' not in receipt and 'teamsoclo' not in receipt
    assert ensure_checked(guard,tmp_path,'teamsoclo','test-model','test-key') is False
    assert len(base.calls)==1
    assert json.loads((tmp_path/'api_usage_guard.json').read_text())['requests_total']==1
    # Restart the process (simulate empty in-memory cache) on the same project.
    model_preflight._CURRENT.clear()
    newer=CountingGateway()
    newer_guard=BudgetedProvider(newer,tmp_path,max_usd=10,max_calls=12)
    assert ensure_checked(newer_guard,tmp_path,'teamsoclo','test-model','test-key') is False
    assert not newer.calls
    # New key and new model MUST trigger a fresh guarded preflight.
    assert ensure_checked(newer_guard,tmp_path,'teamsoclo','test-model','changed-key') is True
    assert ensure_checked(newer_guard,tmp_path,'teamsoclo','changed-model','changed-key') is True
    assert len(newer.calls)==2
    assert json.loads((tmp_path/'api_usage_guard.json').read_text())['requests_total']==3


def test_manual_probe_before_project_avoids_redundant_automatic_test(tmp_path,monkeypatch):
    from studio import model_preflight
    monkeypatch.setattr(model_preflight,'_CURRENT',{})
    mark_checked(None,'teamsoclo','manual-model','manual-key')
    gateway=CountingGateway()
    guard=BudgetedProvider(gateway,tmp_path,max_usd=1,max_calls=5)
    assert ensure_checked(guard,tmp_path,'teamsoclo','manual-model','manual-key') is False
    assert gateway.calls==[]


def test_failed_model_test_not_cached(tmp_path,monkeypatch):
    from studio import model_preflight
    monkeypatch.setattr(model_preflight,'_CURRENT',{})
    base=CountingGateway(fail=True)
    guard=BudgetedProvider(base,tmp_path,max_usd=5,max_calls=4)
    with pytest.raises(ContractError):
        ensure_checked(guard,tmp_path,'teamsoclo','test-model','bad-key')
    assert not was_checked(tmp_path,'teamsoclo','test-model','bad-key')
    assert len(base.calls)==1
    assert json.loads((tmp_path/'api_usage_guard.json').read_text())['requests_total']==1


def test_gateway_does_not_silently_retry_truncated_response(tmp_path):
    class Truncated(CountingGateway):
        def generate(self,*,system,user,max_output_tokens):
            self.calls.append(max_output_tokens)
            raise ContractError('max_output_tokens')
    base=Truncated()
    guard=BudgetedProvider(base,tmp_path,max_usd=10,max_calls=5)
    with pytest.raises(ContractError):
        guard.generate(system='rules',user='story',max_output_tokens=2500)
    assert base.calls==[2500]
    assert json.loads((tmp_path/'api_usage_guard.json').read_text())['requests_total']==1


def test_team_gateway_smaller_windows_and_original_rules_still_present(tmp_path):
    flow=project(tmp_path)
    original_story=tmp_path/'story.txt'
    original_story.write_text(original_story.read_text(encoding='utf-8')*6,encoding='utf-8')
    flow=GuideFlow.create(tmp_path/'large-project',tmp_path/'HUONG_DAN.txt',
                          [tmp_path/'B1.txt',tmp_path/'B2.txt'],[original_story])
    provider=SceneProvider()
    rec=flow.run_next(provider,max_output_tokens=8000)
    assert rec['state']=='LOCKED'
    generates=[(s,u,t) for s,u,t in provider.calls if 'HÃY CHUYỂN THỂ NGUYÊN NỘI DUNG PHẦN' in u and 'CHỈ SỬA ĐÚNG LỖI QA.' not in s]
    assert generates and len(generates)>2
    assert all('Chuyển thể trọn nguồn, không bỏ canon.' in s for s,u,t in generates)
    assert all(2500<=t<=3920 for s,u,t in generates)
    assert all('TỪ TƯƠNG LAI KHÔNG ĐƯỢC ĐỌC TRƯỚC' not in s+' '+u for s,u,t in provider.calls)
    assert all(len(u)<22000 for s,u,t in generates)


def test_qa_timeout_resume_candidate_without_regenerating(tmp_path):
    flow=project(tmp_path)
    class QATimeout(SceneProvider):
        def generate(self,*,system,user,max_output_tokens):
            if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
                raise ContractError('Timeout during QA: possibly billed')
            return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
    first=QATimeout()
    with pytest.raises(ContractError,match='Timeout during QA'):
        flow.run_next(first,max_output_tokens=1600)
    assert flow.status()['completed']==0
    candidate=list((flow.folder/'candidates'/'STEP_001'/'scene_windows').glob('*/window_00001_candidate.txt'))
    assert len(candidate)==1 and candidate[0].with_suffix('.json').exists()
    subsequent=SceneProvider()
    rec=flow.run_next(subsequent,max_output_tokens=1600)
    assert rec['state']=='LOCKED'
    assert not any('PHẦN 1/' in user and 'HÃY CHUYỂN THỂ NGUYÊN NỘI DUNG PHẦN' in user
                   for system,user,tokens in subsequent.calls if 'QA ' not in system)


def test_tampered_candidate_never_reused(tmp_path):
    flow=project(tmp_path)
    class QATimeout(SceneProvider):
        def generate(self,*,system,user,max_output_tokens):
            if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
                raise ContractError('QA timeout')
            return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
    with pytest.raises(ContractError):flow.run_next(QATimeout(),max_output_tokens=1600)
    c=next((flow.folder/'candidates'/'STEP_001'/'scene_windows').glob('*/window_00001_candidate.txt'))
    c.write_text('TAMPERED',encoding='utf-8')
    with pytest.raises(ContractError,match='candidate checkpoint không khớp'):
        flow.run_next(SceneProvider(),max_output_tokens=1600)


def test_medium_gateway_source_uses_windows_even_when_output_cap_large(tmp_path):
    flow=project(tmp_path)
    fake=SceneProvider()
    result=flow.run_next(fake,max_output_tokens=8000)
    assert result['engine']=='scene_windows'
    assert len([1 for s,u,t in fake.calls if 'HÃY CHUYỂN THỂ NGUYÊN NỘI DUNG PHẦN' in u])>=2
