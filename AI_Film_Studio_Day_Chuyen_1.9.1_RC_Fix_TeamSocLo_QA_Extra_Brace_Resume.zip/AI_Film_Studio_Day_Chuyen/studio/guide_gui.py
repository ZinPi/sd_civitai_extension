"""Three-panel GUI for the new guide-first, step-locked engine (not legacy v0.7.x)."""
from __future__ import annotations
from pathlib import Path
import json
import traceback
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,
                               QGroupBox,QLabel,QPushButton,QComboBox,QLineEdit,QFileDialog,
                               QMessageBox,QInputDialog,QPlainTextEdit,QSpinBox,QDoubleSpinBox,QScrollArea,QGridLayout,QSizePolicy)
from .guide_flow import GuideFlow, LazyRuleLibrary
from .api import OpenAIProvider
from .claude_api import ClaudeProvider,fetch_claude_models
from .tuansu_api import TuansuProvider,fetch_tuansu_models,probe_tuansu_model
from .teamsoclo_api import TeamSocLoProvider,fetch_teamsoclo_models,probe_teamsoclo_model
from .api_connection import fetch_account_models,probe_responses_model
from .one_click import BudgetedProvider
from .contract import ContractError
from .model_preflight import ensure_checked, mark_checked

STYLE='''
QWidget {background:#0e1626; color:#edf2ff; font:12px 'Segoe UI';}
QGroupBox {background:#17243a; border:1px solid #2e425f; border-radius:9px; margin-top:13px; padding:13px 9px 9px 9px; font-weight:bold;}
QGroupBox::title {subcontrol-origin:margin; left:13px; padding:0 6px;}
QLineEdit,QComboBox,QPlainTextEdit,QSpinBox,QDoubleSpinBox {background:#0c1729; border:1px solid #354866; border-radius:6px; padding:6px; color:#e9f3ff;}
QPushButton {background:#274368; border:1px solid #426186; padding:8px; border-radius:7px;}
QPushButton:hover {background:#345a8a;}
QPushButton:disabled {background:#19283a; color:#7387a5;}
QPushButton#Next {background:#276aca; font-size:14px; font-weight:bold; padding:11px;}
QLabel#Title {font-size:21px; font-weight:bold;}
QLabel#Help {color:#a8b7d2;}
'''


def make_provider(provider,key,model):
    if provider=='tuansu':return TuansuProvider(key,model)
    if provider=='teamsoclo':return TeamSocLoProvider(key,model)
    if provider=='claude':return ClaudeProvider(key,model)
    return OpenAIProvider(key,model,'default')


class ModelsWorker(QThread):
    done=Signal(list); failed=Signal(str)
    def __init__(self,kind,key):super().__init__();self.kind=kind;self.key=key
    def run(self):
        try:
            result=(fetch_teamsoclo_models(self.key) if self.kind=='teamsoclo' else
                    fetch_tuansu_models(self.key) if self.kind=='tuansu' else
                    fetch_claude_models(self.key) if self.kind=='claude' else fetch_account_models(self.key))
            self.done.emit(result)
        except Exception as exc:self.failed.emit(str(exc)[:400])


class ProbeWorker(QThread):
    """Paid model check, outside the GUI thread."""
    done=Signal(tuple);failed=Signal(str)
    def __init__(self,kind,key,model):
        super().__init__();self.kind=kind;self.key=key;self.model=model
    def run(self):
        try:
            if self.kind=='teamsoclo': result=probe_teamsoclo_model(self.key,self.model)
            elif self.kind=='tuansu': result=probe_tuansu_model(self.key,self.model)
            elif self.kind=='openai': result=probe_responses_model(self.key,self.model,'default')
            else:
                r=ClaudeProvider(self.key,self.model).generate(
                    system='Trả lời ngắn gọn.',user='Trả lời OK.',max_output_tokens=128)
                result=r.input_tokens,r.output_tokens
            self.done.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc).replace(self.key,'[REDACTED]')[:550])


class ConflictAuditWorker(QThread):
    """Never blocks Qt UI while a multi-file semantic audit calls the provider."""
    progress=Signal(str);done=Signal(list);failed=Signal(str)
    def __init__(self,project,kind,key,model,budget,calls):
        super().__init__();self.project=Path(project);self.kind=kind;self.key=key
        self.model=model;self.budget=budget;self.calls=calls
    def run(self):
        try:
            base=make_provider(self.kind,self.key,self.model)
            guarded=BudgetedProvider(base,self.project,max_usd=self.budget,max_calls=self.calls,
                                     notify=self.progress.emit)
            guarded.current_stage='CONFLICT_AUDIT_CURRENT_STEP'
            result=GuideFlow(self.project).audit_current_conflicts(guarded,self.progress.emit)
            self.done.emit(result)
        except Exception as exc:
            self.failed.emit(type(exc).__name__+': '+str(exc).replace(self.key,'[REDACTED]')[:850])


class StepWorker(QThread):
    progress=Signal(str);done=Signal(dict);failed=Signal(str)
    def __init__(self,project,kind,key,model,budget,calls,tokens,decisions,conflict_choices):
        super().__init__();self.project=Path(project);self.kind=kind;self.key=key
        self.model=model;self.budget=budget;self.calls=calls;self.tokens=tokens;self.decisions=decisions
        self.conflict_choices=conflict_choices
    def run(self):
        try:
            base=make_provider(self.kind,self.key,self.model)
            guarded=BudgetedProvider(base,self.project,max_usd=self.budget,max_calls=self.calls,
                                     notify=self.progress.emit)
            guarded.current_stage='MODEL_PREFLIGHT'
            ensure_checked(guarded,self.project,self.kind,self.model,self.key,self.progress.emit)
            guarded.current_stage='HUONG_DAN_LAZY_STEP'
            flow=GuideFlow(self.project)
            result=flow.run_next(guarded,self.progress.emit,max_output_tokens=self.tokens,
                                 user_decisions=self.decisions, conflict_choices=self.conflict_choices,
                                 require_semantic_audit=True,repair_attempts=2)
            self.done.emit(result)
        except Exception as exc:
            self.failed.emit(type(exc).__name__+': '+str(exc).replace(self.key,'[REDACTED]')[:850])


class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('AI FILM STUDIO — DÂY CHUYỀN 1.9.1 RC')
        self.resize(1050,760)
        self.setMinimumSize(380,420)
        self._adaptive_groups=[]
        self._layout_mode=None
        self.sources=[];self.rules=[];self.guide=None;self.project=None
        self.worker=None;self.models_worker=None;self.audit_worker=None;self.probe_worker=None
        window=QWidget();self.setCentralWidget(window)
        root=QVBoxLayout(window);root.setContentsMargins(17,13,17,13)
        title=QLabel('AI FILM STUDIO — DÂY CHUYỀN');title.setObjectName('Title')
        title.setWordWrap(True);title.setMinimumWidth(0)
        self.main_title=title;root.addWidget(title)
        subtitle=QLabel('Hướng dẫn điều phối • Chỉ mở quy tắc của bước hiện tại • QA PASS/LOCK rồi mới chuyển bước')
        subtitle.setObjectName('Help');subtitle.setWordWrap(True);root.addWidget(subtitle)
        area=QScrollArea();area.setWidgetResizable(True);area.setFrameShape(QScrollArea.NoFrame)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        root.addWidget(area,1)
        content=QWidget();content.setMinimumWidth(0)
        content.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        area.setWidget(content)
        lay=QVBoxLayout(content);lay.setSpacing(15)
        api=QGroupBox('1. API XỬ LÝ VĂN BẢN');lay.addWidget(api)
        a=QVBoxLayout(api);row=QHBoxLayout();a.addLayout(row)
        self.provider=QComboBox()
        for name,key in [('TuanSu API','tuansu'),('TeamSocLo API','teamsoclo'),('OpenAI','openai'),('Claude','claude')]:self.provider.addItem(name,key)
        row.addWidget(self.provider)
        self.key=QLineEdit();self.key.setEchoMode(QLineEdit.Password);self.key.setPlaceholderText('API Key chỉ lưu trong phiên; không ghi vào dự án')
        a.addWidget(self.key)
        mr=QGridLayout();a.addLayout(mr)
        self.model=QComboBox();self.model.setEditable(True);self.model.setInsertPolicy(QComboBox.NoInsert)
        self.model.setMinimumWidth(0)
        self.btn_models=QPushButton('Lấy model')
        self.btn_probe=QPushButton('Thử model')
        self._adaptive_groups.append((mr,[[self.model],[self.btn_models],[self.btn_probe]],3))
        self.btn_probe.clicked.connect(self.test_model)
        self.provider.currentIndexChanged.connect(self._clear_models)
        self.btn_models.clicked.connect(self.load_models)
        budgets=QGridLayout();a.addLayout(budgets)
        self.budget_label=QLabel('Giới hạn USD nội bộ (ước tính, không phải giá gateway):')
        self.budget=QDoubleSpinBox();self.budget.setRange(1,1000);self.budget.setValue(20)
        self.calls_label=QLabel('Tối đa lượt API toàn dự án:')
        self.calls=QSpinBox();self.calls.setRange(2,10000);self.calls.setValue(180)
        self.tokens_label=QLabel('Output token/lượt:')
        self.tokens=QSpinBox();self.tokens.setRange(512,50000);self.tokens.setSingleStep(1024);self.tokens.setValue(8000)
        self._adaptive_groups.append((budgets,[[self.budget_label,self.budget],
                                              [self.calls_label,self.calls],[self.tokens_label,self.tokens]],3))

        files=QGroupBox('2. TÀI LIỆU NGUỒN + HƯỚNG DẪN / QUY TẮC');lay.addWidget(files)
        fl=QVBoxLayout(files)
        inputs=QGridLayout();fl.addLayout(inputs)
        btn1=QPushButton('Chọn nguồn TXT/SRT');btn1.clicked.connect(self.choose_sources)
        btn2=QPushButton('Chọn bộ quy tắc ZIP/TXT');btn2.clicked.connect(self.choose_rules)
        btn3=QPushButton('Chọn thư mục quy tắc');btn3.clicked.connect(self.choose_folder)
        self._adaptive_groups.append((inputs,[[btn1],[btn2],[btn3]],3))
        self.source_note=QLabel('Nguồn: chưa chọn');self.source_note.setObjectName('Help');fl.addWidget(self.source_note)
        self.rule_note=QLabel('Quy tắc: chưa chọn');self.rule_note.setObjectName('Help');fl.addWidget(self.rule_note)
        for lbl in (self.source_note,self.rule_note):
            lbl.setWordWrap(True);lbl.setMinimumWidth(0)
            lbl.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        gr=QGridLayout();fl.addLayout(gr)
        guide_btn=QPushButton('Chọn hướng dẫn riêng (tùy chọn)');guide_btn.clicked.connect(self.choose_guide)
        self.guide_note=QLabel('Tự nhận diện hướng dẫn trong ZIP nếu có');self.guide_note.setObjectName('Help')
        self.guide_note.setWordWrap(True);self.guide_note.setMinimumWidth(0)
        self.guide_note.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        self._adaptive_groups.append((gr,[[guide_btn],[self.guide_note]],2))
        pathrow=QGridLayout();fl.addLayout(pathrow)
        self.folder=QLineEdit();self.folder.setPlaceholderText('Thư mục dự án mới (được tạo khi chuẩn bị)')
        self.choose_project_btn=QPushButton('Thư mục lưu');self.choose_project_btn.clicked.connect(self.select_project_root)
        self._adaptive_groups.append((pathrow,[[self.folder],[self.choose_project_btn]],2))
        self.btn_prepare=QPushButton('Đọc hướng dẫn → Tạo kế hoạch bước (KHÔNG gọi API)')
        self.btn_prepare.setMinimumWidth(0);self.btn_prepare.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
        fl.addWidget(self.btn_prepare);self.btn_prepare.clicked.connect(self.prepare)
        openrow=QGridLayout();fl.addLayout(openrow)
        self.btn_open=QPushButton('Mở dự án đã tạo');self.btn_open.clicked.connect(self.open_existing)
        self.btn_new=QPushButton('Đổi sang dự án mới');self.btn_new.clicked.connect(self.reset)
        self._adaptive_groups.append((openrow,[[self.btn_open],[self.btn_new]],2))

        work=QGroupBox('3. BƯỚC HIỆN TẠI — THÀNH QUẢ VÀ QA');lay.addWidget(work)
        wl=QVBoxLayout(work)
        self.state=QLabel('Chưa tạo dự án. Chỉ file hướng dẫn được đọc ở giai đoạn lập kế hoạch.')
        self.state.setWordWrap(True);wl.addWidget(self.state)
        self.btn_next=QPushButton('CHẠY DUY NHẤT BƯỚC HIỆN TẠI → QA → PASS/LOCK');self.btn_next.setObjectName('Next')
        self.btn_next.setEnabled(False)
        self.btn_next.setMinimumWidth(0);self.btn_next.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Fixed)
        wl.addWidget(self.btn_next);self.btn_next.clicked.connect(self.run_next)
        self.logs=QPlainTextEdit();self.logs.setReadOnly(True);self.logs.setMinimumHeight(150);wl.addWidget(self.logs)
        self._clear_models()
        self._reflow()


    def _reflow(self):
        """Adapt grid columns on window resize, preserving all controls and values."""
        if not getattr(self,'_adaptive_groups',None):return
        width=self.width()
        columns=1 if width<650 else 2 if width<1050 else 3
        if columns==self._layout_mode:return
        self._layout_mode=columns
        if hasattr(self,'main_title'):
            self.main_title.setStyleSheet('font-size:16px;' if columns==1 else 'font-size:21px;')
        if hasattr(self,'btn_prepare'):
            self.btn_prepare.setText('Đọc hướng dẫn → Tạo kế hoạch' if columns==1
                                     else 'Đọc hướng dẫn → Tạo kế hoạch bước (KHÔNG gọi API)')
        if hasattr(self,'btn_next'):
            self.btn_next.setText('CHẠY BƯỚC HIỆN TẠI → QA' if columns==1
                                  else 'CHẠY DUY NHẤT BƯỚC HIỆN TẠI → QA → PASS/LOCK')
        for layout,groups,max_columns in self._adaptive_groups:
            # Reposition existing widgets; never rebuild controls or reset state.
            for group in groups:
                for widget in group:layout.removeWidget(widget)
            for col in range(3):layout.setColumnStretch(col,0)
            ncols=min(columns,max_columns)
            for index,group in enumerate(groups):
                row=index//ncols;col=index%ncols
                if len(group)==2:
                    # Label + numeric control, keep vertically stacked as a unit.
                    layout.addWidget(group[0],row*2,col)
                    layout.addWidget(group[1],row*2+1,col)
                else:
                    layout.addWidget(group[0],row,col)
                for widget in group:
                    widget.setMinimumWidth(0)
                    if isinstance(widget,QLabel):
                        widget.setWordWrap(True)
                        widget.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
                    if isinstance(widget,(QLineEdit,QComboBox,QSpinBox,QDoubleSpinBox,QPushButton)):
                        widget.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
            for col in range(ncols):layout.setColumnStretch(col,1)

    def resizeEvent(self,event):
        super().resizeEvent(event)
        self._reflow()

    def log(self,s):self.logs.appendPlainText(str(s))
    def _busy(self):return ((self.worker is not None and self.worker.isRunning()) or
                            (self.audit_worker is not None and self.audit_worker.isRunning()) or
                            (self.probe_worker is not None and self.probe_worker.isRunning()))
    def _clear_models(self,*args):self.model.clear();self.model.setEditText('')
    def choose_sources(self):
        paths,_=QFileDialog.getOpenFileNames(self,'Nguồn văn bản','','Text (*.txt *.md *.srt *.json *.yaml *.yml)')
        if paths:self.sources=[Path(p) for p in paths];self.source_note.setText('Nguồn: '+', '.join(x.name for x in self.sources)[:160])
    def choose_rules(self):
        paths,_=QFileDialog.getOpenFileNames(self,'Quy tắc trong ZIP hoặc TXT','','Rule files (*.zip *.txt *.md *.json *.yaml *.yml)')
        if paths:self.rules=[Path(p) for p in paths];self.rule_note.setText('Quy tắc: '+', '.join(x.name for x in self.rules)[:180])
    def choose_folder(self):
        path=QFileDialog.getExistingDirectory(self,'Thư mục quy tắc')
        if path:self.rules=[Path(path)];self.rule_note.setText('Quy tắc: '+path)
    def choose_guide(self):
        path,_=QFileDialog.getOpenFileName(self,'Hướng dẫn điều phối','','Text (*.txt *.md)')
        if path:self.guide=Path(path);self.guide_note.setText('Hướng dẫn: '+self.guide.name)
    def select_project_root(self):
        path=QFileDialog.getExistingDirectory(self,'Nơi lưu dự án')
        if path:
            from datetime import datetime
            from uuid import uuid4
            self.folder.setText(str(Path(path)/('Du_an_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:6])))
    def prepare(self):
        if self._busy():return
        try:
            if not self.rules:raise ContractError('Chưa chọn ZIP/thư mục quy tắc.')
            if not self.sources:raise ContractError('Chưa có văn bản nguồn. Chỉ nên tạo dự án khi đầu vào đã sẵn sàng.')
            target=Path(self.folder.text().strip()) if self.folder.text().strip() else (Path.home()/'Documents'/'AI_Film_Studio'/'GuideProjects'/('Du_an_'+__import__('uuid').uuid4().hex[:8]))
            flow=GuideFlow.create(target,self.guide,self.rules,self.sources)
            self.project=flow.folder;self.folder.setText(str(self.project))
            self.log('Đọc file hướng dẫn, phân đoạn công việc; chưa mở file quy tắc bước tương lai, chưa gửi API.')
            for step in flow.meta['steps']:
                self.log(f"{step['id']} — {step['title']} | viện dẫn: "+', '.join(step['references']))
            self.refresh()
        except Exception as exc:self.alert(str(exc))
    def open_existing(self):
        path=QFileDialog.getExistingDirectory(self,'Mở dự án đã tạo')
        if not path:return
        try:
            flow=GuideFlow(Path(path));flow.status()
            self.project=Path(path);self.folder.setText(path)
            self.log('Đã mở dự án có LOCK và checkpoint từ trước; không cần phân tích lại toàn bộ.');self.refresh()
        except Exception as exc:self.alert(str(exc))
    def reset(self):
        if self._busy():return
        self.project=None;self.folder.clear();self.btn_next.setEnabled(False)
        self.log('Đã đổi sang chế độ dự án mới; dữ liệu của dự án cũ vẫn trên ổ đĩa.')
    def refresh(self):
        if self.project is None:self.btn_next.setEnabled(False);return
        try:
            state=GuideFlow(self.project).status()
            self.btn_next.setEnabled(not state['finished'] and not self._busy())
            if state['finished']:
                self.state.setText(f"HOÀN THÀNH {state['total']} BƯỚC. Tất cả đều có QA PASS và checkpoint LOCK.")
            else:
                step=state['current']
                self.state.setText(f"Đã khóa {state['completed']}/{state['total']} bước. TIẾP THEO: {step['id']} — {step['title']}\nFile trong hướng dẫn bước: "+', '.join(step['references'])+'\nChưa mở nội dung quy tắc bước sau.')
        except Exception as exc:self.alert(str(exc));self.btn_next.setEnabled(False)
    def run_next(self):
        if not self.project or self._busy():return
        kind=self.provider.currentData();key=self.key.text().strip();model=self.model.currentText().strip()
        if not key or not model:self.alert('Nhập API key và mã model trước khi chạy.');return
        status=GuideFlow(self.project).status()
        step=status['current']
        if not step:return
        answer=QMessageBox.question(self,'Xác nhận bước và chi phí',
            f"Chỉ chạy {step['id']} — {step['title']}\n"
            'Có thể phát sinh phí. Bước kế tiếp CHỈ mở sau khi QA PASS và LOCK. Tiếp tục?',
            QMessageBox.Yes|QMessageBox.No)
        if answer!=QMessageBox.Yes:return
        try:
            flow=GuideFlow(self.project)
            if flow.needs_semantic_audit(kind,model):
                self.log('Các quy tắc bước này gọi nhiều file: cần rà mâu thuẫn có dẫn chứng trước khi sản xuất.')
                self.audit_worker=ConflictAuditWorker(self.project,kind,key,model,self.budget.value(),self.calls.value())
                self.audit_worker.progress.connect(self.log)
                self.audit_worker.done.connect(self.audit_done)
                self.audit_worker.failed.connect(self.audit_failed)
                self.audit_worker.finished.connect(self.audit_finished)
                self.audit_worker.start();self.btn_next.setEnabled(False)
                return
            conflicts=flow.current_conflicts()
            choices={}
            for item in conflicts:
                left,right=item['left'],item['right']
                options=['ƯU TIÊN VẾ TRÁI','ƯU TIÊN VẾ PHẢI']
                if item['kind']=='review':options.append('KHÔNG MÂU THUẪN (giữ cả hai)')
                explanation=item.get('reason','Hai quy tắc cố định có giá trị khác nhau')
                label=(explanation+'\n\nTRÁI: '+str(left['source_file'])+':'+str(left['source_line'])+'\n'+left['source_quote']+
                       '\n\nPHẢI: '+str(right['source_file'])+':'+str(right['source_line'])+'\n'+right['source_quote']+
                       '\n\nChọn cách xử lý cho BƯỚC HIỆN TẠI:')
                result,ok=QInputDialog.getItem(self,'XÁC MINH MÂU THUẪN QUY TẮC',label,options,0,False)
                if not ok:return
                choices[item['id']]={'ƯU TIÊN VẾ TRÁI':'left','ƯU TIÊN VẾ PHẢI':'right',
                                    'KHÔNG MÂU THUẪN (giữ cả hai)':'not_conflict'}[result]
            required=flow.current_requirements()
        except Exception as exc:
            self.alert(str(exc));return
        decisions={}
        for source_quote,line in required.items():
            value,ok=QInputDialog.getMultiLineText(
                self,'Lựa chọn bắt buộc trong quy tắc',
                source_quote+'\n'+line+'\n\nNhập quyết định (không phải lựa chọn sáng tạo của AI):')
            if not ok:return
            if not value.strip():self.alert('Chưa nhập lựa chọn bắt buộc: '+source_quote);return
            decisions[source_quote]=value.strip()
        self.worker=StepWorker(self.project,kind,key,model,self.budget.value(),self.calls.value(),self.tokens.value(),decisions,choices)
        self.worker.progress.connect(self.log)
        self.worker.done.connect(self.step_done)
        self.worker.failed.connect(self.step_failed)
        self.worker.finished.connect(self.worker_finished)
        self.worker.start();self.btn_next.setEnabled(False)
    def audit_done(self,conflicts):
        self.log(f'RÀ QUY TẮC HIỆN TẠI HOÀN TẤT — {len(conflicts)} trường hợp cần xử lý hoặc xác nhận.')
        self.log('Nhấn CHẠY BƯỚC HIỆN TẠI lần nữa để xem dẫn chứng và quyết định (nếu có).')
    def audit_failed(self,error):
        self.log('Không xác minh được xung đột; KHÔNG chạy sản xuất: '+error)
        self.alert(error)
    def audit_finished(self):
        self.audit_worker=None
        self.refresh()
    def step_done(self,rec):
        self.log('ĐÃ LOCK: '+rec['step_id']+' → '+', '.join(rec['outputs']))
    def step_failed(self,error):
        self.log('BƯỚC KHÔNG ĐẠT: '+error)
        self.alert(error)
    def worker_finished(self):
        self.worker=None
        self.refresh()
    def closeEvent(self,event):
        if self._busy():
            QMessageBox.warning(self,'Đang chạy API',
                                'Bước hiện tại đang chạy. Hãy để yêu cầu API kết thúc trước khi đóng ứng dụng.')
            event.ignore()
        else:event.accept()
    def load_models(self):
        key=self.key.text().strip()
        if not key:self.alert('Chưa nhập API key.');return
        if self.models_worker and self.models_worker.isRunning():return
        self.btn_models.setEnabled(False)
        self.models_worker=ModelsWorker(self.provider.currentData(),key)
        self.models_worker.done.connect(self.models_done)
        self.models_worker.failed.connect(self.models_failed)
        self.models_worker.start()
    def test_model(self):
        if self._busy():return
        key=self.key.text().strip();model=self.model.currentText().strip()
        if not key or not model:
            return self.alert('Nhập API Key và mã model trước khi thử.')
        agree=QMessageBox.question(self,'Thử model — có thể tính phí',
            'Gửi một request nhỏ để kiểm tra model/endpoint có hoạt động. Request có thể tính phí. Tiếp tục?',
            QMessageBox.Yes|QMessageBox.No)
        if agree!=QMessageBox.Yes:return
        self.btn_probe.setEnabled(False)
        self.probe_worker=ProbeWorker(self.provider.currentData(),key,model)
        self.probe_worker.done.connect(self.probe_done)
        self.probe_worker.failed.connect(self.probe_failed)
        self.probe_worker.finished.connect(self.probe_finished)
        self.probe_worker.start()

    def probe_done(self,usage):
        # A successful manual test counts as a recent model check. The test can
        # be made before project creation; no secret is saved in its receipt.
        if self.probe_worker is not None:
            mark_checked(self.project,self.probe_worker.kind,self.probe_worker.model,
                         self.probe_worker.key)
        self.log(f'Model đã trả văn bản hoàn chỉnh. Token vào/ra: {usage[0]}/{usage[1]}.')
    def probe_failed(self,error):
        self.log('Không xác minh được model: '+error)
        self.alert(error)
    def probe_finished(self):
        self.btn_probe.setEnabled(True)
        self.probe_worker=None

    def models_done(self,models):
        original=self.model.currentText()
        self.model.clear();self.model.addItems(list(models));
        if original:self.model.setEditText(original)
        self.btn_models.setEnabled(True)
    def models_failed(self,error):
        self.btn_models.setEnabled(True);self.log('Không lấy được model: '+error)
        self.alert(error+'\nCó thể nhập mã model thủ công, nhưng cần quyền truy cập model thật.')
    def alert(self,msg):QMessageBox.warning(self,'AI FILM STUDIO',str(msg)[:1200])


def main():
    import sys
    app=QApplication.instance() or QApplication(sys.argv)
    app.setStyleSheet(STYLE)
    window=Main();window.show()
    return app.exec()
