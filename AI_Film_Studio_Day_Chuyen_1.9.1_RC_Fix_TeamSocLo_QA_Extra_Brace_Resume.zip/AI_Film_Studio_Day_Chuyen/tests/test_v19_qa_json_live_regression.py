"""Windows TeamSocLo incident: JSON-format reviewer failure after REPAIR.

Test recovery without silently inventing a PASS or sending another production
request. These are all offline fakes, not real TeamSocLo compatibility tests.
"""
import json
from types import SimpleNamespace as NS
import pytest

from studio.contract import ContractError
from studio.guide_flow import GuideFlow, parse_review
from tests.test_scene_responsive_v14 import SceneProvider, project
from tests.test_scene_v17_scope_resume import window_folder


@pytest.mark.parametrize('raw,expected', [
    ('```json\n{"verdict":"PASS","issues":[],"continuity":"Nhất quán"}\n```', 'PASS'),
    ('KẾT QUẢ KIỂM TRA:\n```json\n{"verdict":"FAIL","issues":["Thiếu beat 2"]}\n```', 'FAIL'),
    ('{"verdict":"FAIL","issues":["Chưa đủ căn cứ",],}', 'FAIL'),
    ('{"verdict":"PASS","issues":[],"continuity":"Mục có dấu phẩy , và dấu } trong chuỗi"}', 'PASS'),
    ('{"verdict":"PASS","issues":[],"continuity":"Dòng 1\nDòng 2"}', 'PASS'),
])
def test_json_format_noise_recovers_without_changing_verdict(raw,expected):
    assert parse_review(raw)['verdict']==expected


@pytest.mark.parametrize('raw', [
    '{"verdict":"PASS","issues":[]', # interrupted JSON; no fabrication
    '{"verdict":"PASS","issues":[]}\n{"verdict":"FAIL","issues":["error"]}',
    '{"verdict":"FAIL","issues":["err"],"verdict":"PASS"}',
    '{"verdict":"PASS","issues":["Actual missing beat"]}',
    '{"verdict":"FAIL","issues":[]}',
    'JSON: {"verdict":"PASS","issues":[]} and {"verdict":"FAIL","issues":["x"]}',
    'The source is okay, PASS.',
    '{"verdict":"PASS","issues":[10]}',
])
def test_ambiguous_partial_and_conflicting_qa_stay_blocked(raw):
    with pytest.raises(ContractError):parse_review(raw)


class InvalidOnce(SceneProvider):
    def __init__(self, bad='{"verdict":"PASS","issues":[]'):
        super().__init__();self.bad=bad;self.failed=False

    def generate(self,*,system,user,max_output_tokens):
        if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system and not self.failed:
            self.failed=True
            self.calls.append((system,user,max_output_tokens))
            return NS(text=self.bad)
        return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)


def test_malformed_window_qa_keeps_candidate_and_records_raw_no_repair(tmp_path):
    flow=project(tmp_path)
    fake=InvalidOnce()
    with pytest.raises(ContractError,match='Không REPAIR truyện vì lỗi định dạng'):
        flow.run_next(fake,max_output_tokens=1600,repair_attempts=2)
    folder=window_folder(flow)
    diagnostic=folder/'window_00001_qa_invalid.json'
    assert diagnostic.is_file()
    doc=json.loads(diagnostic.read_text(encoding='utf8'))
    assert doc['response_text']==fake.bad
    assert doc['evidence']['candidate_sha']
    assert (folder/'window_00001_candidate.txt').is_file()
    assert (folder/'window_00001_candidate.json').is_file()
    assert not list(folder.glob('window_00001_repair_*.txt'))
    assert not (folder/'window_00001.json').exists()
    assert flow.status()['completed']==0
    assert len(fake.calls)==2 # production + ONE QA, never automatic format retry
    resumed=SceneProvider()
    completed=GuideFlow(flow.folder).run_next(resumed,max_output_tokens=1600)
    assert completed['state']=='LOCKED'
    assert not diagnostic.exists()
    assert any('QA ĐỘC LẬP CHO SOURCE WINDOW' in s for s,_,_ in resumed.calls)
    assert not any('PHẦN 1/' in u and 'QA ĐỘC LẬP CHO SOURCE WINDOW' not in s
                   for s,u,_ in resumed.calls)


class BadAfterRepair(SceneProvider):
    def __init__(self):
        super().__init__();self.review_count=0

    def generate(self,*,system,user,max_output_tokens):
        if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system and 'WINDOW 1.' in user:
            self.calls.append((system,user,max_output_tokens))
            self.review_count+=1
            if self.review_count==1:
                return NS(text=json.dumps({'verdict':'FAIL','issues':['Lỗi thực sự ở đoạn 1']}))
            return NS(text='Có một kết quả JSON chưa hoàn tất {"verdict":"PASS",')
        return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)


def test_invalid_json_after_repair_resume_latest_repair_without_regenerating(tmp_path):
    flow=project(tmp_path)
    first=BadAfterRepair()
    with pytest.raises(ContractError,match='Không REPAIR truyện vì lỗi định dạng'):
        flow.run_next(first,max_output_tokens=1600,repair_attempts=2)
    folder=window_folder(flow)
    revised=folder/'window_00001_repair_1.txt'
    assert revised.exists()
    old_bytes=revised.read_bytes()
    assert (folder/'window_00001_qa_invalid.json').exists()
    assert len([c for c in first.calls if 'CHỈ SỬA ĐÚNG LỖI QA' in c[0]])==1
    resumed=SceneProvider()
    result=GuideFlow(flow.folder).run_next(resumed,max_output_tokens=1600)
    assert result['state']=='LOCKED'
    assert revised.read_bytes()==old_bytes
    assert not (folder/'window_00001_repair_2.txt').exists()
    assert any('QA ĐỘC LẬP CHO SOURCE WINDOW' in s and old_bytes.decode('utf8').strip() in u
               for s,u,_ in resumed.calls)
    assert not any('CHỈ SỬA ĐÚNG LỖI QA' in s for s,_,_ in resumed.calls)
    assert not (folder/'window_00001_qa_invalid.json').exists()


def test_json_qa_with_prefix_fence_completes_one_step_without_extra_retry(tmp_path):
    class Wrapped(SceneProvider):
        def generate(self,*,system,user,max_output_tokens):
            if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
                self.calls.append((system,user,max_output_tokens))
                return NS(text='QA RESULT:\n```json\n{"verdict":"PASS","issues":[],"continuity":"Đã đối chiếu nguồn"}\n```')
            return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
    flow=project(tmp_path)
    p=Wrapped()
    result=flow.run_next(p,max_output_tokens=1600)
    assert result['state']=='LOCKED'
    assert not list(window_folder(flow).glob('*_qa_invalid.json'))


def test_reject_example_object_and_conflicting_prose_even_when_only_one_json_object():
    for raw in (
        'Ví dụ: {"verdict":"PASS","issues":[]} Nhưng QA thực tế FAIL',
        'QA RESULT: {"verdict":"PASS","issues":[]}\nTuy nhiên thực tế FAIL',
    ):
        with pytest.raises(ContractError):parse_review(raw)
