"""Large user rulepacks: full scan, explicit API preflight, recoverable chunks."""
import json
import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.rule_options import (
    MAX_ANALYSIS_CHARS, MAX_ANALYSIS_SEGMENTS, CHUNK_SIZE, chunks,
    analysis_plan, analyze_rules, pending_analysis_chunks,
    validate_answers, rules_digest,
)


def long_document(length=408_570):
    end = '\nNgười dùng phải chọn phong cách: Cổ điển hoặc Hiện đại.'
    return 'A' * (length - len(end)) + end


class RespondingModel:
    def __init__(self, stop_at=None):
        self.calls = 0
        self.stop_at = stop_at
        self.inputs = []
    def generate(self, *, system, user, max_output_tokens):
        self.calls += 1
        self.inputs.append(user)
        if self.stop_at is not None and self.calls == self.stop_at:
            raise RuntimeError('gián đoạn API mô phỏng')
        response = {
            'summary': 'Đã đọc đoạn gốc',
            'steps': [], 'deliverables': [], 'questions': [],
            'warnings': [], 'blockers': [],
        }
        if 'L2: Người dùng phải chọn phong cách: Cổ điển hoặc Hiện đại.' in user:
            response['questions'] = [{
                'question': 'Chọn phong cách?', 'kind': 'single', 'required': True,
                'choices': ['Cổ điển', 'Hiện đại'], 'source_file': 'QUY_TAC.txt',
                'source_line': 2, 'source_quote': 'chọn phong cách: Cổ điển hoặc Hiện đại.',
            }]
        return Generation(json.dumps(response, ensure_ascii=False))


def test_408570_characters_are_fully_analyzed_without_skipping():
    content = long_document()
    files = {'QUY_TAC.txt': content}
    assert analysis_plan(files)['characters'] == 408_570
    parts = list(chunks(files))
    assert len(parts) > 20
    assert all(len(fragment) <= CHUNK_SIZE for _, fragment in parts)
    reassembled = ''.join(line.split(': ', 1)[1] for _, fragment in parts
                          for line in fragment.splitlines() if line.startswith('L1: '))
    assert reassembled == content.splitlines()[0]
    model = RespondingModel()
    report = analyze_rules(files, model)
    assert model.calls == len(parts)
    assert report['segment_count'] == len(parts)
    assert report['analyzed_characters'] == 408_570
    assert report['rules_digest'] == rules_digest(files)
    assert len(report['questions']) == 1
    assert validate_answers(report, {'q001': 'Cổ điển'}) == {'q001': 'Cổ điển'}


def test_failed_middle_chunk_can_resume_without_repeating_paid_calls(tmp_path):
    files = {'QUY_TAC.txt': long_document(85_000)}
    total = analysis_plan(files)['segments']
    first = RespondingModel(stop_at=4)
    with pytest.raises(RuntimeError, match='gián đoạn'):
        analyze_rules(files, first, checkpoint_dir=tmp_path, provider_identity='openai:one')
    assert first.calls == 4
    assert pending_analysis_chunks(files, tmp_path, 'openai:one') == total - 3
    second = RespondingModel()
    report = analyze_rules(files, second, checkpoint_dir=tmp_path,
                           provider_identity='openai:one')
    assert report['cache_hits'] == 3
    assert second.calls == total - 3
    assert len(report['questions']) == 1


def test_model_switch_prevents_wrong_cache_reuse(tmp_path):
    files = {'QUY_TAC.txt': long_document(43_000)}
    a = RespondingModel()
    analyze_rules(files, a, checkpoint_dir=tmp_path, provider_identity='openai:model-A')
    assert pending_analysis_chunks(files, tmp_path, 'claude:model-B') == analysis_plan(files)['segments']
    b = RespondingModel()
    result = analyze_rules(files, b, checkpoint_dir=tmp_path,
                           provider_identity='claude:model-B')
    assert result['cache_hits'] == 0
    assert b.calls == analysis_plan(files)['segments']


def test_source_edit_invalidates_checkpoints(tmp_path):
    files = {'QUY_TAC.txt': long_document(43_000)}
    analyze_rules(files, RespondingModel(), checkpoint_dir=tmp_path, provider_identity='test:one')
    updated = {'QUY_TAC.txt': files['QUY_TAC.txt'].replace('A', 'B', 1)}
    assert pending_analysis_chunks(updated, tmp_path, 'test:one') == 1  # unchanged chunks are reused


def test_broken_cached_chunk_is_reanalyzed(tmp_path):
    files = {'QUY_TAC.txt': long_document(43_000)}
    analyze_rules(files, RespondingModel(), checkpoint_dir=tmp_path, provider_identity='test:one')
    item = next((tmp_path / 'rule_analysis_chunks').glob('*.json'))
    item.write_text('{not json', encoding='utf8')
    assert pending_analysis_chunks(files, tmp_path, 'test:one') == 1
    model = RespondingModel()
    result = analyze_rules(files, model, checkpoint_dir=tmp_path, provider_identity='test:one')
    assert result['cache_hits'] == analysis_plan(files)['segments'] - 1
    assert model.calls == 1


def test_hard_safety_limit_blocks_before_api_payment():
    f = {'QUY_TAC.txt': 'A' * (MAX_ANALYSIS_CHARS + 1)}
    model = RespondingModel()
    with pytest.raises(ContractError, match='không được bỏ sót ngầm'):
        analyze_rules(f, model)
    assert model.calls == 0


def test_too_many_short_files_fail_preflight():
    files = {f'file_{i}.txt': 'ABC' for i in range(MAX_ANALYSIS_SEGMENTS + 1)}
    with pytest.raises(ContractError, match='[Kk]hông bỏ qua phần nào'):
        analysis_plan(files)


def test_rule_options_ui_preflights_and_shows_real_chunk_count():
    from pathlib import Path
    src = (Path(__file__).parents[1] / 'studio' / 'minimal_gui.py').read_text(encoding='utf8')
    assert 'pending_analysis_chunks(files, old_audit, identity,' in src
    assert 'shared_cache_dir=shared_rule_cache_dir()' in src
    assert 'plan["segments"]' in src
    assert 'checkpoint_dir=audit_dir' in src


def test_large_analysis_approved_project_import_is_compatible(tmp_path):
    """Reproduce the user's flow: 408k rule -> analysis -> approval -> V6 project."""
    from studio.project_setup import initialize_approved_project, analysis_budget_dir
    content = long_document()
    source = tmp_path / 'QUY_TAC.txt'
    source.write_text(content, encoding='utf8')
    project_path = tmp_path / 'Du_an_kiem_thu'
    audit = analysis_budget_dir(project_path)
    audit.mkdir(parents=True)
    report = analyze_rules({'QUY_TAC.txt': content}, RespondingModel(),
                           checkpoint_dir=audit, provider_identity='openai:model-A')
    studio = initialize_approved_project(project_path, [source], report,
                                         {'q001': 'Hiện đại'})
    try:
        assert studio.folder == project_path.resolve()
        assert 'Hiện đại' in (project_path / 'user_choices_confirmed.txt').read_text(encoding='utf8')
        assert (project_path / 'PHAN_TICH_QUY_TAC.json').is_file()
        assert (project_path / 'analysis_api_usage' / 'rule_analysis_chunks').is_dir()
        assert len(list((project_path / 'analysis_api_usage' / 'rule_analysis_chunks').glob('*.json'))) == report['segment_count']
    finally:
        studio.close()
