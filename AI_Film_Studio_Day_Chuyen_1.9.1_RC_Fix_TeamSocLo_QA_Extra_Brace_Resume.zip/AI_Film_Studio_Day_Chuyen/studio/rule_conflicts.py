"""Evidence-grounded, cross-file conflicting fixed rules.

Never select a winner automatically. The lexical pass is deliberately narrow:
its purpose is to catch unambiguous settings without requiring AI. The analysis
model may also supply anchored fixed statements for more varied prose. This is
not a proof that ALL semantic contradictions were found.
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections import defaultdict
from decimal import Decimal
from .contract import ContractError

MAX_ASSERTIONS = 1800
MAX_CONFLICTS = 75
CONFLICT_ENGINE_VERSION = 4
# Long, source-anchored rules are valid. Do not silently truncate a clause.
MAX_ASSERTION_VALUE_CHARS = 900
MAX_ASSERTION_QUOTE_CHARS = 4096

KNOWN_TOPICS = {
    'ngôn ngữ': 'ngon_ngu', 'ngôn ngữ đầu ra': 'ngon_ngu', 'ngôn ngữ xuất': 'ngon_ngu',
    'output language': 'ngon_ngu',
    'phong cách': 'phong_cach', 'phong cách đầu ra': 'phong_cach', 'style': 'phong_cach',
    'định dạng': 'dinh_dang', 'định dạng đầu ra': 'dinh_dang', 'định dạng xuất': 'dinh_dang',
    'output format': 'dinh_dang',
    'số cảnh': 'so_canh', 'số lượng cảnh': 'so_canh', 'number of scenes': 'so_canh',
    'số câu': 'so_cau', 'số lượng câu': 'so_cau',
    'số lượng cảnh': 'so_canh', 'scene count': 'so_canh',
    'mô tả youtube': 'mo_ta_youtube', 'youtube description': 'mo_ta_youtube',
    'tỉ lệ khung hình': 'ti_le', 'tỷ lệ khung hình': 'ti_le', 'aspect ratio': 'ti_le',
}
TOPIC_PATTERN = '|'.join(re.escape(x) for x in sorted(KNOWN_TOPICS, key=len, reverse=True))
SETTING_LINE = re.compile(r'^\s*(?:(?:bắt buộc|yêu cầu|quy định)\s+)?'
                          rf'({TOPIC_PATTERN})\s*(?:phải\s+là|bắt\s+buộc\s+là|là|:|=)\s*(.+?)\s*$', re.I)
ACTION_LINE = re.compile(r'^\s*(bắt buộc|phải|không được|cấm|tuyệt đối không được)\s+'
                         r'(tạo|xuất|sinh|ghi|đưa vào)\s+(.+?)\s*[.!]?\s*$', re.I)
CONDITIONAL = re.compile(r'\b(?:nếu|khi|tùy chọn|tùy theo|hoặc|hay|or|either|if|choose|chọn|nhập)\b', re.I)

# Keep original source text for the evidence shown to users. Accent-insensitive
# parsing is used ONLY for recognizing a narrow set of explicit fixed clauses.
def _ascii(value: str) -> str:
    return ''.join(c for c in unicodedata.normalize('NFKD', value.casefold())
                   if not unicodedata.combining(c)).replace('đ', 'd')

# Equivalent names for the SAME required output language must never trigger a
# spurious conflict. Unknown values are kept distinct for human review.
_LANGUAGE_NAMES = {
    'vietnamese': ('tieng viet', 'viet', 'vietnamese', 'vi', 'vi-vn'),
    'english': ('tieng anh', 'anh', 'english', 'en', 'en-us', 'en-gb'),
    'japanese': ('tieng nhat', 'nhat', 'japanese', 'ja'),
    'korean': ('tieng han', 'han', 'korean', 'ko'),
    'chinese': ('tieng trung', 'trung', 'chinese', 'zh'),
    'french': ('tieng phap', 'phap', 'french', 'fr'),
    'german': ('tieng duc', 'duc', 'german', 'de'),
    'spanish': ('tieng tay ban nha', 'tay ban nha', 'spanish', 'es'),
    'italian': ('tieng y', 'italian', 'it'),
    'thai': ('tieng thai', 'thai', 'th'),
    'russian': ('tieng nga', 'nga', 'russian', 'ru'),
    'portuguese': ('tieng bo dao nha', 'portuguese', 'pt'),
    'indonesian': ('tieng indonesia', 'indonesian', 'id'),
    'arabic': ('tieng a rap', 'arabic', 'ar'),
    'hindi': ('tieng hindi', 'hindi', 'hi'),
}
_LANGUAGE_LOOKUP = {word: code for code, names in _LANGUAGE_NAMES.items() for word in names}
_VALUE_ALIASES = {
    'dinh_dang': {'txt': 'plain_text', 'plain text': 'plain_text', 'van ban thuan': 'plain_text',
                  'json': 'json', 'json format': 'json'},
    'phong_cach': {'co dien': 'classic', 'classic': 'classic',
                   'hien dai': 'modern', 'modern': 'modern',
                   'trang trong': 'formal', 'formal': 'formal'},
}

# These forms have global scope: the entire output set, not a specific
# scene/stage. Multiple phrasing variants are used in real Vietnamese rule
# documents. Do NOT treat a single product or a conditional as a global rule.
_LANGUAGE_TOKEN = (r'(?:tieng\s+[a-z\s]+|vietnamese|english|japanese|korean|'
                   r'chinese|french|german|spanish|italian|thai|russian|'
                   r'portuguese|indonesian|arabic|hindi)')
_VI_GLOBAL_TARGET = (r'(?:(?:moi|tat ca|toan bo)(?:\s+(?:cac|nhung))?|'
                     r'(?:cac|nhung))\s+'
                     r'(?:thanh pham|dau ra|tai lieu|van ban|noi dung|ket qua|san pham)')
# A mandatory instruction with a verb, e.g.:
# "Các thành phẩm phải viết bằng tiếng Việt"; "Yêu cầu tất cả tài liệu
# đều phải được viết bằng tiếng Anh".
_VI_GLOBAL_LANGUAGE = re.compile(
    r'^(?:(?:yeu cau|quy dinh|bat buoc)\s+)?'
    + _VI_GLOBAL_TARGET
    + r'\s+(?:deu\s+)?(?:bat buoc\s+)?phai\s+(?:duoc\s+)?'
      r'(?:viet|soan|trinh bay|the hien|su dung|dung)\s+'
      r'(?:(?:hoan toan)\s+)?(?:bang\s+)?'
    + rf'(?P<lang>{_LANGUAGE_TOKEN})\s*[.!。]?$', re.I)
# An explicit "Yêu cầu ... bằng ..." / "Bắt buộc ... dùng ..." directive
# need not contain the word "phải" to be mandatory.
_VI_REQUESTED_LANGUAGE = re.compile(
    r'^(?:yeu cau|bat buoc|quy dinh)\s+'
    + _VI_GLOBAL_TARGET
    + r'\s+(?:deu\s+)?(?:phai\s+)?(?:duoc\s+)?'
      r'(?:bang|la|dung|su dung|viet bang|viet|the hien bang)\s+'
    + rf'(?P<lang>{_LANGUAGE_TOKEN})\s*[.!。]?$', re.I)
_EN_GLOBAL_LANGUAGE = re.compile(
    r'^(?:all|every)\s+(?:final\s+)?(?:outputs?|deliverables?|documents?|texts?|results?)'
    r'\s+(?:must|shall|are required to)\s+(?:be\s+)?(?:written|produced|drafted)'
    r'\s+in\s+(?P<lang>[a-z][a-z\s-]*)\s*[.!]?$', re.I)


def _language_key(value: str) -> str | None:
    plain = _ascii(value).strip(' .:;!。\"\'').strip()
    return _LANGUAGE_LOOKUP.get(' '.join(plain.split()))


def _comparison_key(topic: str, value: str) -> str:
    key = _ascii(_value(value))
    if topic == 'ngon_ngu':
        return _language_key(value) or key
    if topic == 'mo_ta_youtube':
        raw = _ascii(value).strip(' .:;!')
        unit = re.fullmatch(r'(\d+)\s*(tu|words?|ky tu|characters?|chars?)', raw)
        if unit:
            unit_name = 'words' if unit.group(2) in ('tu', 'word', 'words') else 'characters'
            return str(int(unit.group(1))) + ':' + unit_name
    if topic in ('so_canh', 'so_cau'):
        # Fixed counts 10, 010, +10, and 10.0 all denote the same quantity.
        # Only normalize a bare decimal value: never interpret filenames,
        # number identifiers or formatted strings as quantities.
        if re.fullmatch(r'[+-]?[0-9]+(?:\.[0-9]+)?', key):
            return format(Decimal(key).normalize(), 'f')
    return _VALUE_ALIASES.get(topic, {}).get(key, key)


def _natural_language_value(line: str) -> str | None:
    stripped = line.strip()
    if not stripped or CONDITIONAL.search(stripped):
        return None
    plain = _ascii(stripped)
    match = (_VI_GLOBAL_LANGUAGE.fullmatch(plain)
             or _VI_REQUESTED_LANGUAGE.fullmatch(plain)
             or _EN_GLOBAL_LANGUAGE.fullmatch(plain))
    if not match:
        return None
    lang = match.group('lang').strip(' .:;!。')
    if _language_key(lang) is None:
        return None
    # Extract the exact original-language text, not the accent-stripped parser
    # token. All displayed evidence remains traceable to the user's TXT.
    original = re.search(
        r'(tiếng\s+[\w]+(?:\s+[\w]+){0,3}|'
        r'Vietnamese|English|Japanese|Korean|Chinese|French|German|'
        r'Spanish|Italian|Thai|Russian|Portuguese|Indonesian|Arabic|Hindi)'
        r'\s*[.!。]?\s*$', stripped, re.I)
    if original and _language_key(original.group(1)) == _language_key(lang):
        return original.group(1)
    return lang


def _canon(value: str) -> str:
    return ' '.join(unicodedata.normalize('NFC', value).casefold().split())


def _topic(value: str) -> str:
    canonical = _canon(value).strip(' .:;')
    return KNOWN_TOPICS.get(canonical, canonical)


def _value(value: str) -> str:
    return _canon(value).strip(' .:;!')


def _record(topic: str, value: str, fn: str, line: int, quote: str) -> dict:
    return {'topic': _topic(topic), 'value': value.strip(), 'source_file': fn,
            'source_line': line, 'source_quote': quote}


def extract_fixed_rules(files: dict[str, str]) -> list[dict]:
    """Exact fixed parameters, not choice questions or conditional branches."""
    statements = []
    for fn, text in files.items():
        for ln, row in enumerate(text.splitlines(), 1):
            match = SETTING_LINE.match(row)
            if match and not CONDITIONAL.search(match.group(2)):
                val = match.group(2).strip().rstrip('.。')
                if val and len(val) <= 160 and '\\' not in val:
                    statements.append(_record(match.group(1), val, fn, ln, row))
            # A fixed "all outputs must be in language X" statement is a
            # setting even without a colon/key-value delimiter. This previously
            # caused a missed contradiction if the model returned no assertions.
            natural = _natural_language_value(row)
            if natural is not None:
                statements.append(_record('ngôn ngữ đầu ra', natural, fn, ln, row))
            # Additional UNAMBIGUOUS fixed outputs, requiring an explicit global
            # requirement rather than incidental mentions or examples.
            plain = _ascii(row.strip())
            if not CONDITIONAL.search(row) and not re.match(r'^(?:vi du|example|vd)\b', plain):
                count = re.fullmatch(r'(?:phai\s+)?(?:tao|xuat)\s+(\d+)\s+canh\s*[.!]?', plain)
                if count:
                    statements.append(_record('số cảnh', str(int(count.group(1))), fn, ln, row))
                # Strictly scoped to YouTube description, never character/background
                # descriptions. A 300-word description cannot be 300 characters.
                desc = re.search(
                    r'(?:mo ta youtube|youtube description)\b[^\n]{0,105}?'
                    r'\b(\d+)\s*(tu|words?|ky tu|characters?|chars?)\b', plain)
                if desc and not re.search(r'\b(?:vi du|example|minh hoa)\b', plain):
                    statements.append(_record('mô tả YouTube',
                                              row[desc.start(1):desc.end(2)], fn, ln, row))
                # Opposed whole-document dialogue handling. Do not infer from a
                # single character's line or a conditional instruction.
                if re.search(r'\b(?:toan bo|tat ca|100%)\s+loi thoai truc tiep\b', plain):
                    if re.search(r'\b(?:giu nguyen|bao toan)\b', plain) and not re.search(r'\b(?:khong|cam)\s+giu nguyen\b', plain):
                        statements.append(_record('xử lý toàn bộ lời thoại trực tiếp', 'giữ nguyên', fn, ln, row))
                    elif re.search(r'\b(?:chuyen|doi)\b[^\n]{0,70}\b(?:gian tiep|indirect)\b', plain):
                        statements.append(_record('xử lý toàn bộ lời thoại trực tiếp', 'chuyển gián tiếp', fn, ln, row))
            # Literal prohibitions contradict literal requirements for the exact
            # same action/object. Broader semantic oppositions need review.
            action = ACTION_LINE.match(row)
            if action and not CONDITIONAL.search(action.group(3)):
                polar, verb, target = action.groups()
                target = target.strip().rstrip('.。')
                if target and len(target) <= 120:
                    statements.append(_record('thao_tac:' + _canon(verb) + ':' + _canon(target),
                                              'CẤM' if 'không' in _canon(polar) or _canon(polar) == 'cấm'
                                              else 'BẮT BUỘC', fn, ln, row))
    return statements


def validate_assertions(assertions: list, files: dict[str, str], *, scope_file: str | None = None) -> list[dict]:
    """Validate literal source evidence; model statements never confer authority."""
    if not isinstance(assertions, list) or len(assertions) > MAX_ASSERTIONS:
        raise ContractError('Danh sách điều khoản cố định không hợp lệ hoặc quá dài.')
    result = []
    for a in assertions:
        if not isinstance(a, dict):
            raise ContractError('Điều khoản so sánh không phải object.')
        for key in ('topic', 'value', 'source_file', 'source_line', 'source_quote'):
            if key not in a:
                raise ContractError('Thiếu bằng chứng cho điều khoản so sánh: ' + key)
        fn, ln, quote = a['source_file'], a['source_line'], a['source_quote']
        location = f'{fn}:{ln}' if isinstance(fn, str) and type(ln) is int else f'{fn}:dòng không hợp lệ'
        if not isinstance(fn, str) or fn not in files or (scope_file is not None and fn != scope_file):
            raise ContractError(f'{location}: điều khoản so sánh trỏ sai file.')
        lines = files[fn].splitlines()
        if type(ln) is not int or not (1 <= ln <= len(lines)):
            raise ContractError(f'{location}: bằng chứng có số dòng trích dẫn không hợp lệ.')
        if not isinstance(quote, str) or not quote.strip() or quote not in lines[ln-1]:
            raise ContractError(f'{location}: bằng chứng trích dẫn không khớp nguyên văn với TXT gốc.')
        if len(quote) > MAX_ASSERTION_QUOTE_CHARS:
            raise ContractError(f'{location}: trích dẫn dài {len(quote)} ký tự; '
                                'hãy trích nguyên văn một đoạn ngắn hơn ngay trong dòng gốc, '
                                'không sửa hoặc cắt bỏ quy tắc trong file.')
        topic, value = a['topic'], a['value']
        if not isinstance(topic, str) or not (2 <= len(topic.strip()) <= 120):
            raise ContractError(f'{location}: chủ đề điều khoản không hợp lệ (2–120 ký tự).')
        if not isinstance(value, str) or not value.strip():
            raise ContractError(f'{location}: giá trị điều khoản bị trống hoặc không phải văn bản.')
        if len(value.strip()) > MAX_ASSERTION_VALUE_CHARS:
            raise ContractError(f'{location}: giá trị điều khoản dài {len(value.strip())} ký tự, '
                                f'quá giới hạn xác minh {MAX_ASSERTION_VALUE_CHARS}; '
                                'hãy trích đúng giá trị ngắn hơn có trong câu gốc, '
                                'không suy diễn hay làm mất thông tin.')
        # Model-generated values must be substrings of verbatim evidence.
        if _value(value) not in _value(quote):
            raise ContractError(f'{location}: giá trị điều khoản không xuất hiện nguyên văn '
                                'trong trích dẫn nguồn: ' + repr(value[:120]))
        # Conditional clauses are not safe to treat as competing fixed defaults.
        if CONDITIONAL.search(quote):
            continue
        result.append(_record(topic, value, fn, ln, quote))
    return result


def detect_conflicts(files: dict[str, str], assertions: list[dict] | None = None) -> list[dict]:
    facts = extract_fixed_rules(files)
    if assertions:
        facts.extend(validate_assertions(assertions, files))
    unique = {(a['topic'], a['source_file'], a['source_line'], _comparison_key(a['topic'], a['value'])): a for a in facts}
    grouped = defaultdict(list)
    for a in unique.values():
        grouped[a['topic']].append(a)
    conflicts = []
    for topic, group in sorted(grouped.items()):
        group = sorted(group, key=lambda x:(x['source_file'], x['source_line'], _comparison_key(topic, x['value'])))
        for i, a in enumerate(group):
            for b in group[i+1:]:
                if a['source_file'] == b['source_file'] or _comparison_key(topic, a['value']) == _comparison_key(topic, b['value']):
                    continue
                # Contradiction requires same exact subject, different mutually
                # exclusive fixed values. Unknown topics from AI are proposals,
                # shown to user as conflicts requiring human review.
                signature = json.dumps([topic, a, b], ensure_ascii=False, sort_keys=True)
                conflicts.append({'id': 'c' + hashlib.sha256(signature.encode('utf8')).hexdigest()[:12],
                                  'topic': topic, 'left': dict(a), 'right': dict(b)})
                if len(conflicts) > MAX_CONFLICTS:
                    raise ContractError('Có quá nhiều điều khoản khác nhau giữa các file (>75). Hãy tách dự án hoặc sửa bộ quy tắc.')
    return conflicts


def verify_conflicts(report: dict, files: dict[str, str]) -> None:
    if report.get('conflict_engine_version') != CONFLICT_ENGINE_VERSION or not isinstance(report.get('assertions'), list):
        raise ContractError('Bản phân tích cũ chưa có đối chiếu xung đột nhiều file. Hãy phân tích lại.')
    if report.get('conflicts') != detect_conflicts(files, report['assertions']):
        raise ContractError('Báo cáo xung đột không khớp các quy tắc gốc. Hãy phân tích lại.')


def validate_conflict_decisions(report: dict, answers: dict) -> dict[str, str]:
    expected = {item['id'] for item in report.get('conflicts', [])}
    raw = answers.get('__conflicts__', {})
    if not isinstance(raw, dict) or set(raw) != expected:
        missing = expected - (set(raw) if isinstance(raw, dict) else set())
        if missing:
            raise ContractError('Bạn chưa quyết định xung đột quy tắc: ' + ', '.join(sorted(missing)))
        raise ContractError('Có quyết định xung đột không xuất phát từ bộ quy tắc.')
    if any(type(choice) is not str or choice not in ('left', 'right') for choice in raw.values()):
        raise ContractError('Chỉ được chọn một trong hai điều khoản của từng xung đột.')
    # A/B, B/C and C/A cannot all be preferred; this is a contradiction in
    # the user's resolutions. A directed cycle is a clear mistake.
    by_topic = defaultdict(list)
    topic_values = defaultdict(set)
    preferred_values = defaultdict(set)
    for c in report.get('conflicts', []):
        side = raw[c['id']]
        chosen = c[side]
        other = c['right' if side == 'left' else 'left']
        a = (chosen['source_file'], chosen['source_line'], _comparison_key(c['topic'], chosen['value']))
        b = (other['source_file'], other['source_line'], _comparison_key(c['topic'], other['value']))
        by_topic[c['topic']].append((a, b))
        topic_values[c['topic']].update((a[2], b[2]))
        preferred_values[c['topic']].add(a[2])
    for topic, edges in by_topic.items():
        if len(topic_values[topic]) == 2 and len(preferred_values[topic]) > 1:
            raise ContractError('Bạn đã chọn hai giá trị trái nhau cho cùng chủ đề ' + topic +
                                '. Hãy thống nhất một phương án ưu tiên.')
        graph = defaultdict(set)
        for winner, loser in edges:
            graph[winner].add(loser)
        visiting, done = set(), set()
        def dfs(node):
            if node in visiting:
                raise ContractError('Quyết định ưu tiên tạo vòng mâu thuẫn trong chủ đề ' + topic +
                                    '. Hãy chọn thứ tự ưu tiên nhất quán giữa các file.')
            if node in done:
                return
            visiting.add(node)
            for next_node in graph[node]:
                dfs(next_node)
            visiting.remove(node)
            done.add(node)
        for node in tuple(graph):
            dfs(node)
    return {x['id']: raw[x['id']] for x in report.get('conflicts', [])}


def conflict_decisions_text(report: dict, answers: dict) -> str:
    decisions = validate_conflict_decisions(report, answers)
    if not decisions:
        return ''
    lines = ['QUYẾT ĐỊNH ƯU TIÊN KHI HAI FILE QUY TẮC XUNG ĐỘT',
             'Chỉ điều khoản của file được người dùng chọn mới có hiệu lực đối với NỘI DUNG MÂU THUẪN cụ thể.',
             'Điều khoản còn lại không được thực thi cho đúng chủ đề mâu thuẫn này; các quy tắc khác của file đó vẫn có hiệu lực.',
             'Không tự mở rộng quyền ưu tiên này sang chủ đề hoặc điều kiện khác.']
    by_topic = defaultdict(list)
    for c in report['conflicts']:
        side = decisions[c['id']]
        by_topic[c['topic']].append(c[side])
    for topic, winners in by_topic.items():
        tally = defaultdict(int)
        representative = {}
        for rule in winners:
            label = (rule['source_file'], rule['source_line'], _comparison_key(topic, rule['value']))
            tally[label] += 1
            representative[label] = rule
        best = max(tally, key=tally.get)
        chosen = representative[best]
        lines.append(f'\nKẾT LUẬN ƯU TIÊN CHỦ ĐỀ {topic}: '
                     f'{chosen["source_file"]}:{chosen["source_line"]} — {chosen["source_quote"]}')
    for c in report['conflicts']:
        side = decisions[c['id']]
        chosen, rejected = c[side], c['right' if side == 'left' else 'left']
        lines.extend(['', 'XUNG ĐỘT: ' + c['id'], 'CHỦ ĐỀ: ' + c['topic'],
                      f'ƯU TIÊN: {chosen["source_file"]}:{chosen["source_line"]} — {chosen["source_quote"]}',
                      f'KHÔNG ÁP DỤNG ĐIỀU KHOẢN TRÁI NGƯỢC: {rejected["source_file"]}:{rejected["source_line"]} — {rejected["source_quote"]}'])
    return '\n'.join(lines) + '\n'
