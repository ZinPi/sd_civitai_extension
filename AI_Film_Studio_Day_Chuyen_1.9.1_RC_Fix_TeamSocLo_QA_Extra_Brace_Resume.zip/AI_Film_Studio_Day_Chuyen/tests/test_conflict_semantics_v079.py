"""v0.7.9 regression: real-language clashes and translation synonyms across files."""
from __future__ import annotations

import copy
import json

import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.rule_conflicts import detect_conflicts, extract_fixed_rules
from studio.rule_options import (analyze_rules, confirmed_choices_text, read_rules,
                                 validate_answers, verify_report_constraints)
from studio.project_setup import initialize_approved_project


class QuietModel:
    """A model that misses every fixed assertion: the lexical pass still runs."""
    def generate(self, *, system, user, max_output_tokens):
        return Generation(json.dumps({
            'summary': 'Quy tắc đã đọc', 'steps': [], 'deliverables': [],
            'questions': [], 'warnings': [], 'blockers': [], 'assertions': []
        }, ensure_ascii=False))


@pytest.mark.parametrize('left,right', [
    ('Mọi thành phẩm phải viết bằng tiếng Việt.',
     'Mọi thành phẩm phải viết bằng tiếng Anh.'),
    ('Tất cả tài liệu phải được viết bằng tiếng Việt.',
     'All outputs must be written in English.'),
    ('Toàn bộ văn bản phải sử dụng tiếng Việt.',
     'Output language: English.'),
    ('Ngôn ngữ đầu ra: tiếng Việt.',
     'All documents must be written in English.'),
    ('Output language: Vietnamese.',
     'Ngôn ngữ đầu ra: tiếng Anh.'),
])
def test_detects_mandatory_language_conflicts_without_ai_claims(left, right):
    files = {'a.txt': left, 'b.txt': right}
    report = analyze_rules(files, QuietModel())
    assert len(report['conflicts']) == 1
    c = report['conflicts'][0]
    assert c['topic'] == 'ngon_ngu'
    assert c['left']['source_quote'] == left
    assert c['right']['source_quote'] == right
    assert c['left']['source_file'] == 'a.txt'
    assert c['right']['source_file'] == 'b.txt'
    with pytest.raises(ContractError, match='chưa quyết định'):
        validate_answers(report, {})


@pytest.mark.parametrize('left,right', [
    ('Ngôn ngữ đầu ra: tiếng Việt.', 'Output language: Vietnamese.'),
    ('Ngôn ngữ xuất: tiếng Anh', 'Output language: English'),
    ('Mọi thành phẩm phải viết bằng tiếng Việt.',
     'All outputs must be written in Vietnamese.'),
    ('Output language: Japanese', 'Ngôn ngữ đầu ra: tiếng Nhật.'),
    ('Phong cách: cổ điển', 'Style: classic'),
    ('Định dạng: TXT', 'Output format: plain text'),
])
def test_equivalent_meaning_is_not_a_conflict(left, right):
    files = {'a.txt': left, 'b.txt': right}
    report = analyze_rules(files, QuietModel())
    assert report['conflicts'] == []
    verify_report_constraints(report, files)
    assert validate_answers(report, {}) == {}


def test_explicitly_conditional_does_not_create_fixed_conflict():
    files = {'a.txt':'Nếu khách chọn ngôn ngữ tiếng Anh, mọi thành phẩm phải viết bằng tiếng Anh.',
             'b.txt':'Ngôn ngữ đầu ra: tiếng Việt.'}
    assert detect_conflicts(files) == []


def test_same_file_not_categorized_as_cross_file_contradiction():
    assert not detect_conflicts({'rules.txt': 'Mọi thành phẩm phải viết bằng tiếng Việt.\n'
                                                'Mọi thành phẩm phải viết bằng tiếng Anh.'})


def test_language_citations_preserve_original_diacritics():
    facts = extract_fixed_rules({'vi.txt':'Mọi thành phẩm phải viết bằng tiếng Việt.'})
    assert len(facts) == 1
    assert facts[0]['value'] == 'tiếng Việt'
    assert facts[0]['source_quote'] == 'Mọi thành phẩm phải viết bằng tiếng Việt.'


def test_equivalent_ai_assertions_do_not_create_false_positive():
    files = {'a.txt':'Văn bản bắt buộc dùng tiếng Việt.',
             'b.txt':'All text must use Vietnamese.'}
    from studio.rule_conflicts import detect_conflicts
    assertions = [
        {'topic':'ngôn ngữ đầu ra', 'value':'tiếng Việt', 'source_file':'a.txt',
         'source_line':1, 'source_quote':files['a.txt']},
        {'topic':'output language', 'value':'Vietnamese', 'source_file':'b.txt',
         'source_line':1, 'source_quote':files['b.txt']},
    ]
    assert detect_conflicts(files, assertions) == []


def test_new_version_does_not_trust_legacy_conflict_report():
    files = {'a.txt':'Ngôn ngữ đầu ra: tiếng Việt', 'b.txt':'Output language: English'}
    report = analyze_rules(files, QuietModel())
    assert report['conflict_engine_version'] == 4
    old = copy.deepcopy(report)
    old['conflict_engine_version'] = 1
    with pytest.raises(ContractError, match='Bản phân tích cũ'):
        verify_report_constraints(old, files)
    bad = copy.deepcopy(report)
    bad['conflicts'] = []
    with pytest.raises(ContractError, match='không khớp'):
        verify_report_constraints(bad, files)


def test_conflict_decision_reaches_saved_project(tmp_path):
    entries = {'a.txt':'Mọi thành phẩm phải viết bằng tiếng Việt.',
               'b.txt':'Mọi thành phẩm phải viết bằng tiếng Anh.'}
    paths=[]
    for fn, data in entries.items():
        p=tmp_path / fn
        p.write_text(data, encoding='utf8')
        paths.append(p)
    report=analyze_rules(read_rules(paths), QuietModel())
    assert len(report['conflicts']) == 1
    choice = {'__conflicts__': {report['conflicts'][0]['id']: 'left'}}
    text = confirmed_choices_text(report, choice)
    assert 'ƯU TIÊN: a.txt:1' in text
    assert 'KHÔNG ÁP DỤNG ĐIỀU KHOẢN TRÁI NGƯỢC: b.txt:1' in text
    studio=initialize_approved_project(tmp_path/'project', paths, report, choice)
    try:
        stored=(tmp_path/'project'/'user_choices_confirmed.txt').read_text(encoding='utf8')
        assert text == stored
        loaded_report=json.loads((tmp_path/'project'/'PHAN_TICH_QUY_TAC.json').read_text(encoding='utf8'))
        verify_report_constraints(loaded_report, entries)
    finally:
        studio.close()
