"""Low-cost account/model discovery; no text-generation calls without consent."""
from __future__ import annotations

from typing import Iterable


class ConnectionCheckError(ValueError):
    """API connection / model selection problem, safe to show in Vietnamese UI."""


def choose_text_models(model_ids: Iterable[str]) -> list[str]:
    """Filter a live account's /models response for likely Responses API text models.

    Visibility in /models does NOT prove Responses API entitlement or compatibility.
    Actual Responses support must be checked via an explicitly paid smoke request.
    """
    banned = ('audio', 'image', 'realtime', 'tts', 'whisper', 'embedding', 'moderation',
              'transcribe', 'search-preview', 'computer-use', 'deep-research', 'sora',
              'dall-e', 'codex', 'chatgpt', 'instruct')
    good = []
    for mid in model_ids:
        if not isinstance(mid, str):
            continue
        m = mid.strip()
        ml = m.lower()
        if (ml.startswith(('gpt-', 'o1', 'o3', 'o4', 'o5', 'o6'))
                and not any(x in ml for x in banned)):
            good.append(m)
    return sorted(set(good), key=str.casefold, reverse=True)


def fetch_account_models(api_key: str, *, client_factory=None) -> list[str]:
    """GET /models authenticates key and discovers model IDs without generation tokens."""
    if not api_key or not api_key.strip():
        raise ConnectionCheckError('Chưa nhập API key.')
    if client_factory is None:
        from openai import OpenAI
        client_factory = OpenAI
    try:
        client = client_factory(api_key=api_key.strip(), timeout=30, max_retries=0)
        page = client.models.list()
        mids = [getattr(model, 'id', None) for model in page.data]
        models = choose_text_models(mids)
    except Exception as exc:
        # Never show credential/Authorization header potentially present in errors.
        cls = type(exc).__name__
        if cls in ('AuthenticationError',):
            msg = 'API key không hợp lệ hoặc đã hết hiệu lực (401).'
        elif cls in ('PermissionDeniedError',):
            msg = 'API key không có quyền xem danh sách model (403).'
        elif cls in ('RateLimitError',):
            msg = 'API đang giới hạn tần suất; thử lại sau (429).'
        elif cls in ('APIConnectionError','APITimeoutError','ConnectError'):
            msg = 'Không kết nối được OpenAI. Kiểm tra Internet hoặc cấu hình mạng.'
        else:
            msg = f'Không lấy được danh sách model ({cls}).'
        raise ConnectionCheckError(msg) from None
    if not models:
        raise ConnectionCheckError('Kết nối được API nhưng tài khoản chưa trả về model GPT dạng văn bản phù hợp.')
    return models


def probe_responses_model(api_key: str, model: str, effort: str, *, client_factory=None) -> tuple[int,int]:
    """Explicitly billable tiny generation. Returns token usage, never logs key."""
    if not api_key or not model:
        raise ConnectionCheckError('Cần API key và model trước khi thử sinh nội dung.')
    if client_factory is None:
        from openai import OpenAI
        client_factory = OpenAI
    try:
        client = client_factory(api_key=api_key.strip(), timeout=60, max_retries=0)
        kwargs = dict(model=model, input='Chỉ trả lời: OK', max_output_tokens=192, store=False)
        if effort not in ('', 'default'):
            kwargs['reasoning'] = {'effort': effort}
        result = client.responses.create(**kwargs)
        if getattr(result, 'status', None) != 'completed':
            raise ConnectionCheckError('Model trả về trạng thái chưa hoàn tất; hãy đổi model hoặc mức suy luận.')
        usage = getattr(result,'usage',None)
        return (int(getattr(usage,'input_tokens',0) or 0),
                int(getattr(usage,'output_tokens',0) or 0))
    except ConnectionCheckError:
        raise
    except Exception as exc:
        cls=type(exc).__name__
        if cls == 'BadRequestError':
            msg = 'Model hoặc mức suy luận không được hỗ trợ cho Responses API (400).'
        elif cls == 'NotFoundError':
            msg = 'Không tìm thấy model hoặc tài khoản không được phép gọi model này (404).'
        elif cls == 'PermissionDeniedError':
            msg = 'Tài khoản không có quyền sử dụng model (403).'
        elif cls == 'RateLimitError':
            msg = 'Vượt hạn mức/rate limit của API (429).'
        elif cls == 'AuthenticationError':
            msg = 'API key không hợp lệ (401).'
        else:
            msg = f'Thử Responses API không thành công ({cls}).'
        raise ConnectionCheckError(msg) from None
