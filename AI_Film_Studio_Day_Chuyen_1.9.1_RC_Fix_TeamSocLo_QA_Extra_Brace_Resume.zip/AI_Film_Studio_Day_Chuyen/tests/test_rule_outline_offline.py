"""Local navigation never calls a model and never licenses RUN by itself."""
from pathlib import Path
import json
import zipfile
import pytest
from studio.rule_outline import build_outline,outline_for_file,outline_stats,display_span,OutlineSelection,heading
from studio.engine import Studio


def test_heading_levels_and_round_trip_exact_span():
    txt='BƯỚC 07 — ĐÁNH GIÁ\n[PHAM_VI]\nĐầu vào: AUDIO\n[QA]\nKhông được bịa cảnh\n'
    x=outline_for_file('random.txt',txt)
    assert [a.title for a in x[1:]]==['BƯỚC 07 — ĐÁNH GIÁ','[PHAM_VI]','[QA]']
    assert (x[1].start,x[1].end)==(1,5)
    assert (x[2].start,x[2].end)==(2,3)
    assert display_span({'random.txt':txt},x[3])=='[QA]\nKhông được bịa cảnh\n'
    assert all(not v.executable for v in x)


def test_do_not_treat_every_numbered_instruction_as_stage():
    txt='1. Đầu tiên cần làm ABC\n2. Tiếp tục quy trình\n'
    nodes=outline_for_file('x.txt',txt)
    assert len(nodes)==1
    assert heading('BƯỚC 12 — QA') is not None
    assert heading('### ĐIỀU KIỆN') is not None
    assert heading('[QA_LAI]') is not None


def test_no_titles_remain_one_file_node():
    text='Yêu cầu một\nNội dung hai\nKhông được tự bịa\n'
    nodes=outline_for_file('custom.txt',text)
    assert len(nodes)==1
    assert nodes[0].end==3
    assert display_span({'custom.txt':text},nodes[0])==text


def test_selection_is_a_review_only_sidecar(tmp_path):
    rules={'a.txt':'BƯỚC 01 — NHẬN DỮ LIỆU\n[QA]\nĐúng\n'}
    nodes=build_outline(rules)
    selected={nodes[0].key,nodes[1].key}
    helper=OutlineSelection(tmp_path/'selected.json')
    assert helper.read('abc',{n.key for n in nodes})=={n.key for n in nodes}
    helper.write('abc',selected,{n.key for n in nodes})
    assert helper.read('abc',{n.key for n in nodes})==selected
    assert helper.read('newsha',{n.key for n in nodes})=={n.key for n in nodes}
    doc=json.loads((tmp_path/'selected.json').read_text())
    assert doc['purpose']=='SELECTED_RULE_SCOPE_REQUIRES_VALIDATION'
    with pytest.raises(ValueError):helper.write('abc',{'nonexistent'},{n.key for n in nodes})


def test_zip_and_multi_txt_are_accepted_offline(tmp_path):
    p=tmp_path/'work';p.mkdir()
    with zipfile.ZipFile(tmp_path/'rules.zip','w') as z:
        z.writestr('more/one.txt','STEP 01 — INPUT\n[QA]\nCheck\n')
    (tmp_path/'next.txt').write_text('BƯỚC 02 — ĐẦU RA\n[PHAM_VI]\nSOURCE\n',encoding='utf-8')
    studio=Studio(p)
    try:
        studio.import_rule_inputs([tmp_path/'rules.zip',tmp_path/'next.txt'])
        outline=build_outline(studio.rule_files())
        assert outline_stats(outline)['files']==2
        assert outline_stats(outline)['candidate_steps']>=2
        assert not (p/'contract_approved.json').exists()
    finally:studio.close()


def test_outline_does_not_mutate_large_rule_content():
    text=('BƯỚC 09 — PHÂN TÍCH\n[PHAM_VI]\n' + 'Dữ liệu nguồn\n'*28000+'[QA]\nBảo toàn nguồn\n')
    files={'unfamiliar.txt':text}
    outline=build_outline(files)
    assert len(outline)>=4
    assert display_span(files,outline[0],max_chars=1000000)==text
    assert files['unfamiliar.txt']==text


def test_rulepack_bytes_immutable_after_selection(tmp_path):
    import hashlib
    pack=tmp_path/'fresh_rules.zip'
    with zipfile.ZipFile(pack,'w') as z:z.writestr('new_stage.txt','BƯỚC 13 — LẤY NGUỒN\n[QA]\nCấm thêm cảnh\n')
    original=hashlib.sha256(pack.read_bytes()).hexdigest()
    p=tmp_path/'app';p.mkdir()
    studio=Studio(p)
    try:
        studio.import_rule_inputs([pack])
        nodes=build_outline(studio.rule_files())
        OutlineSelection(p/'rule_outline_selection.json').write(studio.rule_hash(),
            {nodes[0].key},set(x.key for x in nodes))
        assert hashlib.sha256(pack.read_bytes()).hexdigest()==original
        assert hashlib.sha256((p/'rules_source.zip').read_bytes()).hexdigest()==original
        assert not (p/'contract_approved.json').exists()
    finally:studio.close()
