"""Fail-closed, contract-driven executor. No hard-coded media types or file names."""
from __future__ import annotations
import json, threading, time, io, zipfile, re
from pathlib import Path
from typing import Callable
from .contract import Contract, ContractError, validate_contract, digest
from .rulepack import inspect_zip
from .store import Store
from .qa import audio_lines, validate_content
from .api import Provider
from .delivery import DEFAULT_ROLES,validate_delivery_policy
from .workflow_plan import prepare_plan, stage_fingerprint

# Budget includes staged evidence, rules and output for semantic QA. No silent
# truncation: use stage-aware rule retrieval for large rule files.
MAX_CONTEXT_CHARS=260000

class RunBlocked(RuntimeError):pass
class SemanticReviewFailure(RunBlocked):
    def __init__(self,stage,issues,repair_scope):
        self.issues=issues
        self.repair_scope=repair_scope
        super().__init__(f'{stage}: QA ngữ nghĩa FAIL ({repair_scope}): '+str(issues)[:400])

class Studio:
    def __init__(self,folder:Path):
        self.folder=Path(folder).resolve()
        sentinel=self.folder/'.ai_film_studio_v6'
        if self.folder.exists() and any(self.folder.iterdir()):
            if not sentinel.exists() or sentinel.read_text(encoding='utf8')!='AI_FILM_STUDIO_V6_CLEAN\n':
                raise ContractError('Thư mục có dữ liệu không phải dự án V6. Hãy chọn thư mục mới, không trộn V5/V6.')
        self.store=Store(self.folder)
        if not sentinel.exists():sentinel.write_text('AI_FILM_STUDIO_V6_CLEAN\n',encoding='utf8')
        self.stop=threading.Event()
        self._run_lock=threading.Lock()
        # Covers the entire one-click lifecycle (compile -> run -> export).
        # Unlike _run_lock, proposal/approval are allowed by the owning worker.
        self._session_lock=threading.Lock()
        self._session_owner_ident=None
        self._rule_cache=None
        self._rule_cache_stamp=None
        policy=self.folder/'delivery_policy.json'
        if not policy.exists():policy.write_text(json.dumps({'required_roles':DEFAULT_ROLES, 'mode':'automatic'},indent=2),encoding='utf8')
    def close(self):
        if self._run_lock.locked() or self._session_lock.locked():raise ContractError('Không được đóng dự án khi RUN đang thực hiện')
        self.store.close()
    def _reject_mutation_during_run(self):
        if self._run_lock.locked() or self._session_lock.locked():
            raise ContractError('Không thể sửa nguồn/quy tắc khi phiên RUN đang hoạt động')
    def _reject_external_control_during_run(self):
        """Compiler/approval inside owner session are permitted; external callers are not."""
        if self._run_lock.locked() or (self._session_lock.locked() and
            threading.get_ident()!=self._session_owner_ident):
            raise ContractError('Không được thay cấu hình khi RUN đang hoạt động')
    def import_sources_atomic(self, entries:dict[str,tuple[str,str]]):
        self._reject_mutation_during_run()
        if any(len(data.encode('utf8'))>20_000_000 for data,_ in entries.values()):
            raise ContractError('Nguồn vượt 20 MB')
        return self.store.sources_atomic(entries)
    def import_pack(self,zip_path:Path):
        # Compatibility with prior projects and acceptance tests.
        return self.import_rule_inputs([zip_path])

    def import_rule_inputs(self, paths):
        """Accept one or more TXT/MD/JSON/YAML files and/or ZIP archives.

        Canonicalize a multi-file selection into one immutable project ruleset.
        A sole ZIP retains its original bytes/hash so existing contracts work.
        Duplicate names are rejected; never silently discard or rename rules.
        """
        self._reject_mutation_during_run()
        from .rulepack import decode_text, MAX_ENTRY, MAX_EXPANDED, MAX_ARCHIVE, ALLOWED
        given=[Path(p) for p in paths]
        if not given:raise ContractError('Chưa chọn file quy tắc')
        members={};total=0
        sole_zip=len(given)==1 and given[0].suffix.lower()=='.zip'
        raw_zip=None
        for path in given:
            if not path.is_file():raise ContractError('Không tồn tại file quy tắc: '+str(path))
            if path.suffix.lower()=='.zip':
                entries,raw=inspect_zip(path)
                if sole_zip:raw_zip=raw
            elif path.suffix.lower() in ALLOWED:
                raw=path.read_bytes()
                if len(raw)>MAX_ENTRY:raise ContractError('File TXT quy tắc vượt 7 MB: '+path.name)
                entries={path.name:decode_text(raw)}
            else:
                raise ContractError('Chỉ nhận ZIP, TXT, MD, JSON hoặc YAML: '+path.name)
            for name,content in entries.items():
                if name.casefold() in {k.casefold() for k in members}:
                    raise ContractError('Trùng tên quy tắc (không thể gộp): '+name)
                total+=len(content.encode('utf-8'))
                if total>MAX_EXPANDED:raise ContractError('Bộ quy tắc vượt 80 MB')
                members[name]=content
        if sole_zip:
            package=raw_zip
        else:
            out=io.BytesIO()
            with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as zf:
                for name in sorted(members):
                    info=zipfile.ZipInfo(name,(1980,1,1,0,0,0))
                    info.compress_type=zipfile.ZIP_DEFLATED
                    zf.writestr(info,members[name].encode('utf-8'))
            package=out.getvalue()
            if len(package)>MAX_ARCHIVE:raise ContractError('Gói ZIP quy tắc hợp nhất vượt 40 MB')
        sha=digest(package)
        pack=self.folder/'rules_source.zip'
        if pack.exists() and digest(pack.read_bytes())!=sha:
            raise ContractError('Dự án đã khóa bộ quy tắc khác. Hãy tạo dự án mới để tránh trộn phiên bản.')
        if not pack.exists():pack.write_bytes(package)
        (self.folder/'rule_files.json').write_text(json.dumps(members,ensure_ascii=False,indent=2),encoding='utf8')
        self._rule_cache=None;self._rule_cache_stamp=None
        return sha,len(members)
    def rule_files(self):
        f=self.folder/'rule_files.json'
        if not f.exists():raise ContractError('Chưa nhập ZIP quy tắc')
        pack=self.folder/'rules_source.zip'
        stamp=(pack.stat().st_size,pack.stat().st_mtime_ns,f.stat().st_size,f.stat().st_mtime_ns)
        if self._rule_cache is not None and stamp==self._rule_cache_stamp:
            return self._rule_cache
        files=json.loads(f.read_text(encoding='utf8'))
        authoritative,_=inspect_zip(pack)
        if files!=authoritative:
            raise ContractError('Bản lập chỉ mục quy tắc khác với ZIP gốc; không được sử dụng')
        self._rule_cache=authoritative;self._rule_cache_stamp=stamp
        return authoritative
    def rule_hash(self):
        f=self.folder/'rules_source.zip'
        if not f.exists():raise ContractError('Chưa có ZIP quy tắc')
        return digest(f.read_bytes())
    def rule_scope(self):
        """Authoritative user selection; independent of any provider/API."""
        from .rule_scope import scope_view
        return scope_view(self.rule_files(), self.rule_hash(),
                          self.folder/'rule_outline_selection.json')

    def contract_rule_files(self):
        return self.rule_scope().files

    def contract_rule_hash(self):
        return self.rule_scope().sha

    def _validate_scope_references(self):
        scoped=self.rule_scope()
        if scoped.missing_references:
            raise ContractError('Thiếu quy tắc được tham chiếu trong phạm vi đã chọn. '
                'Hãy tích thêm các file cần thiết trước khi gọi API:\n- '+
                '\n- '.join(scoped.missing_references[:15]))
        return scoped

    def _check_execution_scope(self, raw):
        scope=self._validate_scope_references()
        expected='FULL' if scope.full else 'PARTIAL'
        if raw.get('execution_scope', 'FULL')!=expected:
            raise ContractError('Hợp đồng không khớp lựa chọn quy tắc hiện tại; cần chuẩn bị lại.')
        return scope

    def import_source_file(self,name:str,path:Path):
        self._reject_mutation_during_run()
        # Binary & encoding guards. Source snapshots are immutable blobs; project index can move to a new version.
        raw=Path(path).read_bytes()
        if len(raw)>20_000_000:raise ContractError('Nguồn vượt 20 MB')
        from .rulepack import decode_text
        return self.store.source(name,decode_text(raw),str(Path(path).resolve()))
    def import_stage_output_file(self, name:str, path:Path):
        """Import externally produced intermediate data as UNVERIFIED.
        A producing stage's validators and semantic reviewer still run before use.
        """
        self._reject_mutation_during_run()
        if name not in self.active_contract().producers:
            raise ContractError('Đây không phải đầu ra công đoạn đã duyệt: '+name)
        raw=Path(path).read_bytes()
        if len(raw)>20_000_000:raise ContractError('Tài liệu ngoài vượt 20 MB')
        from .rulepack import decode_text
        return self.store.supply_external_output(name,decode_text(raw),str(Path(path).resolve()))

    def import_source_text(self,name:str,text:str):
        self._reject_mutation_during_run()
        return self.store.source(name,text,'TẠO BẰNG VĂN BẢN')
    def propose_contract(self,provider=None, *, approve_paid_compilation=False, progress=None):
        """Validate draft with reusable, model-scoped compilation checkpoint.

        Shared cache stores no API credentials and never bypasses the final
        contract, clause-coverage or scope validation. An incomplete checkpoint
        can be resumed only with identical source and model identity.
        """
        self._reject_external_control_during_run()
        from .compiler import draft_contract,save_draft
        if provider is not None and getattr(provider,'is_live',False) and not approve_paid_compilation:
            raise ContractError('Biên dịch quy tắc bằng API trả phí cần xác nhận chi phí riêng')
        scope=self._validate_scope_references()
        local=self.folder/('compiler_checkpoint_'+scope.sha[:18]+'.json')
        import hashlib, json, os, shutil
        from .project_setup import shared_rule_cache_dir
        cache_identity=json.dumps([scope.sha, str(getattr(provider,'provider_id','unknown')),
                                  str(getattr(provider,'model','unknown')),
                                  str(getattr(provider,'effort','default')),
                                  not scope.full, 'v0714-compiler'],ensure_ascii=False)
        key=hashlib.sha256(cache_identity.encode('utf-8')).hexdigest()
        shared=shared_rule_cache_dir()/'compiler_checkpoints'/(key+'.json')
        if not local.exists() and shared.is_file():
            try:
                # Malformed/corrupt cache must not poison a new project.
                stored=json.loads(shared.read_text(encoding='utf-8'))
                if isinstance(stored,dict) and stored.get('raw_contract') is not None:
                    local.write_text(json.dumps(stored,ensure_ascii=False),encoding='utf-8')
            except (OSError,ValueError,TypeError):
                pass
        raw=draft_contract(scope.files,scope.sha,provider,progress=progress,
            checkpoint_path=local,partial=not scope.full,
            max_workers=min(3, getattr(provider,'concurrency_limit',3)))
        # Copy only after a *fully validated* result; never commit unfinished
        # compiler state as a trusted shared cache hit.
        if local.is_file():
            try:
                shared.parent.mkdir(parents=True,exist_ok=True)
                temp=shared.with_name(shared.name+'.tmp-'+str(os.getpid()))
                shutil.copy2(local,temp)
                os.replace(temp,shared)
            finally:
                try: temp.unlink(missing_ok=True)
                except (NameError,OSError): pass
        raw['execution_scope']='FULL' if scope.full else 'PARTIAL'
        return save_draft(raw,self.folder/'workflow_DRAFT_REVIEW.json')

    def policy(self):
        return json.loads((self.folder/'delivery_policy.json').read_text(encoding='utf8'))
    def approve(self,path:Path):
        self._reject_external_control_during_run()
        raw=json.loads(Path(path).read_text(encoding='utf-8'))
        self._check_execution_scope(raw)
        contract=validate_contract(raw,self.contract_rule_files(),self.contract_rule_hash())
        if raw.get('execution_scope','FULL')=='FULL':validate_delivery_policy(self.policy(),contract)
        # Approval validates rules, not document availability. Preflight checks documents
        # for the exact selected execution and refuses any missing inputs before RUN.
        self.store.approve(contract,digest(self.policy()))
        target=self.folder/'contract_approved.json'
        target.write_text(json.dumps(raw,ensure_ascii=False,indent=2),encoding='utf-8')
        return contract
    def active_contract(self):
        target=self.folder/'contract_approved.json'
        if not target.exists():raise ContractError('Chưa phê duyệt hợp đồng quy tắc')
        raw=json.loads(target.read_text(encoding='utf8'))
        self._check_execution_scope(raw)
        c=validate_contract(raw,self.contract_rule_files(),self.contract_rule_hash(),approved_hash=self.store.approved_sha())
        if raw.get('execution_scope','FULL')=='FULL':validate_delivery_policy(self.policy(),c)
        if self.store.approved_policy_sha()!=digest(self.policy()):
            raise ContractError('Chính sách bàn giao đã thay đổi; cần phê duyệt lại trước RUN')
        return c
    def _stage_units(self,st,inputs):
        if st.scope=='whole':return [('ALL', None)]
        source=inputs[st.chunk_source]
        if st.scope=='each_audio_line':
            lines=audio_lines(source)
            return [(line_id,{'line':value,'prev':lines[ix-1][1] if ix>0 else '',
                     'next':lines[ix+1][1] if ix+1<len(lines) else ''}) for ix,(line_id,value) in enumerate(lines)]
        src=source.splitlines(keepends=True)
        # Chunking never splits a line, or silently drops blank lines.
        return [(str(i//st.chunk_lines+1).zfill(4), ''.join(src[i:i+st.chunk_lines]))
                  for i in range(0,len(src),st.chunk_lines)]
    def _confirmed_options(self) -> str:
        # Pinned decisions embedded in rulepack and all production/QA prompts.
        path = self.folder / 'user_choices_confirmed.txt'
        if not path.exists():
            return ''  # Backwards compatible for projects created by earlier GUI versions.
        text = path.read_text(encoding='utf-8')
        # Reject post-approval tampering. Both compiler and execution must see the
        # exact same decisions, as captured in immutable rules_source.zip.
        expected = self.rule_files().get('00_TUY_CHON_NGUOI_DUNG.txt')
        if expected != text:
            raise RunBlocked('Tùy chọn đã bị sửa ngoài quy trình sau khi khóa. '
                             'Hãy tạo dự án mới và phân tích lại.')
        if len(text) > 21_000:
            raise RunBlocked('Tùy chọn đã xác nhận quá dài; không thể đưa đủ vào prompt.')
        return text

    def _make_prompt(self,st,inputs,unit):
        from .rule_context import stage_rules
        ruletext=stage_rules(st,self.active_contract(),self.contract_rule_files())
        parts=[]
        for name,text in inputs.items():
            if st.scope=='each_audio_line' and name==st.chunk_source:
                continue
            if st.scope=='chunks' and name==st.chunk_source:continue
            parts.append('### DỮ LIỆU '+name+'\n'+text)
        if st.scope=='each_audio_line':
            parts.append('### ĐƠN VỊ ĐANG XỬ LÝ\n'+json.dumps(unit,ensure_ascii=False))
        elif st.scope=='chunks':
            parts.append('### ĐOẠN NGUỒN ĐANG XỬ LÝ\n'+unit)
        context='\n\n'.join(parts)
        confirmed = self._confirmed_options()
        if len(context)+len(ruletext)+len(confirmed)>MAX_CONTEXT_CHARS:
            raise RunBlocked(f'{st.id}: context quá lớn; cần chia nguồn/quy tắc hợp lệ, không được cắt ngầm')
        system=('Bạn thực thi chính xác một công đoạn theo hợp đồng đã duyệt. '+
          'Không thêm sự kiện, nhân vật, trạng thái không có bằng chứng. '+
          'Nếu thiếu dữ liệu phải trả ERROR_NEED_EVIDENCE và lý do, không đoán.\n'+
          st.instructions+'\n\n# QUY TẮC ÁP DỤNG\n'+ruletext+
          ('\n\n# TÙY CHỌN DO NGƯỜI DÙNG XÁC NHẬN (BẮT BUỘC TUÂN THỦ)\n'+confirmed if confirmed else ''))
        if st.scope=='each_audio_line':system+='\nTrả về duy nhất nội dung của đúng một LINE_ID, KHÔNG thêm ID ở đầu.'
        return system,context
    def _qa_semantic(self,provider:Provider,st,content:str,inputs:dict[str,str],run_id:int,prices:dict,max_usd:float):
        # Risk-aware reviewer: always supplied with the very same evidence, source and rule clauses.
        from .rule_context import stage_rules
        ruletext=stage_rules(st,self.active_contract(),self.contract_rule_files())
        inp='\n\n'.join(f'### {k}\n{v}' for k,v in inputs.items())
        confirmed = self._confirmed_options()
        if len(ruletext)+len(inp)+len(content)+len(confirmed)>MAX_CONTEXT_CHARS:
            raise RunBlocked(f'{st.id}: QA không có đủ nguồn; không chấp nhận PASS thiếu bằng chứng')
        prompt='DỮ LIỆU NGUỒN:\n'+inp+('\n\nTÙY CHỌN NGƯỜI DÙNG ĐÃ XÁC NHẬN:\n'+confirmed if confirmed else '')+'\n\nKẾT QUẢ CẦN QA:\n'+content
        system=('Bạn là người kiểm tra ĐỘC LẬP, dùng duy nhất bằng chứng dưới đây. '+
           'Hãy trả JSON {"verdict":"PASS" hoặc "FAIL", "issues":[...], '+
           '"repair_scope":"OUTPUT_ONLY" hoặc "UPSTREAM" hoặc "UNKNOWN"}. '+
           'Chỉ ghi OUTPUT_ONLY khi chính văn bản được sinh sai và có thể tạo lại từ đầu vào đã khóa; '+
           'nếu thấy dữ kiện nguồn/Mapping/CHAR/BG mâu thuẫn phải ghi UPSTREAM; không chắc thì UNKNOWN.'+
           ' Chỉ PASS khi không thấy lỗi theo quy tắc, đủ dữ liệu để đối chiếu. '+
           'Nếu thiếu bằng chứng bắt buộc, FAIL.\n'+ruletext)
        resp=self._request(provider,run_id,st.id+':QA',system,prompt,2000,prices,max_usd)
        source_sha=digest(inp);rule_sha=digest(ruletext);content_sha=digest(content)
        try:
            candidate=resp.strip()
            if candidate.startswith('```'):
                candidate=candidate.split('\n',1)[1].rsplit('```',1)[0]
            result=json.loads(candidate)
            if result['verdict'] not in ('PASS','FAIL') or not isinstance(result['issues'],list):raise ValueError()
            if any(not isinstance(issue,(str,dict)) for issue in result['issues']):raise ValueError()
            # PASS with outstanding issues is contradictory. FAIL with no
            # issues cannot drive a grounded, bounded repair. Never promote it.
            if (result['verdict']=='PASS' and result['issues']) or (result['verdict']=='FAIL' and not result['issues']):
                raise ValueError()
        except (ValueError,KeyError,TypeError):
            self.store.record_qa(run_id,st.id,source_sha,rule_sha,content_sha,'INVALID',
                                 ['Reviewer trả JSON không hợp lệ'])
            raise RunBlocked(f'{st.id}: reviewer không trả JSON QA hợp lệ')
        self.store.record_qa(run_id,st.id,source_sha,rule_sha,content_sha,
                             result['verdict'],result['issues'])
        if result['verdict']!='PASS':
            scope=result.get('repair_scope','UNKNOWN')
            if scope not in ('OUTPUT_ONLY','UPSTREAM','UNKNOWN'):scope='UNKNOWN'
            raise SemanticReviewFailure(st.id,result['issues'],scope)
        return 'MODEL_REVIEWED (không phải bảo đảm chân lý tuyệt đối)'

    def _retry_semantic_output(self,provider,run_id,st,content,inputs,unit,issue,prices,max_usd,notify):
        """Only regenerate output with the SAME immutable inputs/rules.

        Never auto-edit source, canon, scene, mapping, or dependent artifacts.
        The reviewer MUST explicitly identify an output-only fault.
        """
        if issue.repair_scope!='OUTPUT_ONLY' or st.adapter!='api_text':
            raise issue
        evidence={name:((json.dumps(unit,ensure_ascii=False) if st.scope=='each_audio_line' else unit)
                        if name==st.chunk_source and st.scope in ('each_audio_line','chunks') else val)
                  for name,val in inputs.items()}
        system,user=self._make_prompt(st,inputs,unit)
        for attempt in range(1,3):
            notify(f'{st.title}: sửa văn bản đầu ra theo QA {attempt}/2; không thay đổi dữ kiện nguồn')
            repair_prompt=(user+'\n\nBẢN ĐẦU RA BỊ QA FAIL:\n'+content[:9000]+
                           '\n\nLỖI ĐƯỢC ĐỐI CHIẾU:\n'+json.dumps(issue.issues,ensure_ascii=False)[:3500]+
                           '\nChỉ viết lại đầu ra hiện tại dựa trên nguồn đã khóa, không sửa dữ kiện upstream.')
            regenerated=self._request(provider,run_id,st.id+':SEMANTIC_OUTPUT_REPAIR',system,repair_prompt,
                                     st.max_output_tokens,prices,max_usd).strip()
            if not regenerated or (st.scope=='each_audio_line' and '\n' in regenerated):
                continue
            if st.scope=='each_audio_line':
                # The initial per-line request is prefixed by the runner.
                # Repair requests return the BODY only. Preserve the exact ID
                # through ALL retries, or line coverage would silently break.
                original_id=content.split('|',1)[0]
                if not original_id or '|' not in content:
                    raise RunBlocked(f'{st.id}: thiếu LINE_ID gốc trong lượt sửa')
                if regenerated.startswith(original_id+'|'):
                    regenerated=regenerated[len(original_id)+1:]
                elif re.match(r'^[A-Za-z0-9_-]+\|',regenerated):
                    raise RunBlocked(f'{st.id}: GPT trả LINE_ID khác trong lượt sửa')
                content=original_id+'|'+regenerated
            else:
                content=regenerated
            if any('ERROR_NEED_EVIDENCE' in line for line in content.splitlines()):
                raise RunBlocked(f'{st.id}: GPT báo thiếu chứng cứ khi sửa; không được công nhận PASS')
            if st.scope=='whole':
                errors=validate_content(content,st.validators,inputs)
                if st.output_type=='json':
                    try:json.loads(content)
                    except ValueError:errors.append('JSON không hợp lệ')
                if errors:continue
            try:
                self._qa_semantic(provider,st,content,evidence,run_id,prices,max_usd)
                return content
            except SemanticReviewFailure as next_issue:
                if next_issue.repair_scope!='OUTPUT_ONLY':raise
                issue=next_issue
        raise RunBlocked(f'{st.id}: không thể sửa đầu ra ngữ nghĩa sau 2 lượt; giữ nguyên dữ liệu nguồn')
    def _retry_structural(self,provider,run_id,st,content,inputs,errors,prices,max_usd,notify):
        """Bounded output-only regeneration. Never edits canon, source or dependency artifacts."""
        if st.adapter != 'api_text':
            raise RunBlocked(f'{st.id}: lỗi đầu ra phi API cần kiểm tra hợp đồng: {errors}')
        for attempt in range(1,3):
            notify(f'{st.title}: thử sửa lỗi cấu trúc {attempt}/2')
            system,user=self._make_prompt(st,inputs,None)
            user+='\n\nKẾT QUẢ KHÔNG ĐẠT:\n'+content[:12000]
            user+='\n\nLỖI CỤ THỂ:\n'+'; '.join(errors)
            user+='\nLàm lại CHỈ phần đầu ra hiện tại dựa trên nguồn/khóa đã cho. Không thay đổi canon hoặc dữ kiện upstream.'
            content=self._request(provider,run_id,st.id+':REPAIR',system,user,st.max_output_tokens,prices,max_usd)
            errors=validate_content(content,st.validators,inputs)
            if not errors:
                if st.output_type=='json':
                    try:json.loads(content)
                    except ValueError as e:errors=['JSON sai sau khi sửa: '+str(e)]
            if not errors:
                if st.semantic_qa:
                    try:
                        self._qa_semantic(provider,st,content,inputs,run_id,prices,max_usd)
                    except SemanticReviewFailure as issue:
                        # The output was structurally repaired but still failed
                        # semantic QA. Reuse the bounded, output-only repair path;
                        # upstream issues must not trigger invented source edits.
                        return self._retry_semantic_output(provider,run_id,st,content,inputs,None,
                                                           issue,prices,max_usd,notify)
                return content
        raise RunBlocked(f'{st.id}: không thể sửa sau 2 lượt: '+str(errors))

    def _request(self,provider,run_id,stage,system,user,max_out,prices,max_usd):
        if provider is None:raise RunBlocked('Công đoạn cần API nhưng chưa kết nối provider')
        if self.stop.is_set():raise RunBlocked('Dừng theo yêu cầu người dùng')
        # Conservative local budget reservation (not a provider hard cap).
        approximate_input=(len(system)+len(user))//2+1500
        estimate=(approximate_input*prices['input']+max_out*prices['output'])/1_000_000
        if not getattr(provider,'is_budget_manager',False) and max_usd and self.store.run_cost(run_id)+estimate>max_usd:
            raise RunBlocked(f'Ngân sách dự phòng không đủ cho {stage}: cần tối đa ước tính ${estimate:.2f}')
        if hasattr(provider,'current_stage'):provider.current_stage=stage
        result=provider.generate(system=system,user=user,max_output_tokens=max_out)
        cost=(max(0,result.input_tokens-result.cached_tokens)*prices['input']+
              result.cached_tokens*prices['cached_input']+result.output_tokens*prices['output'])/1_000_000
        self.store.record_usage(run_id,stage,result.input_tokens,result.output_tokens,result.cached_tokens,cost)
        if result.text.strip().startswith('ERROR_NEED_EVIDENCE'):
            raise RunBlocked(f'{stage}: thiếu bằng chứng: '+result.text[:300])
        return result.text.strip()
    def preflight(self, provider=None, *, selected_stage_ids=None, auto_dependencies=True):
        return prepare_plan(self.active_contract(), self.store, provider,
                 selected=set(selected_stage_ids) if selected_stage_ids is not None else None,
                 include_dependencies=auto_dependencies)

    def run(self,provider:Provider|None=None,*, max_usd:float=0.0,
            prices:dict|None=None,notify:Callable[[str],None]|None=None,
            selected_stage_ids=None, auto_dependencies:bool=True):
        if not self._run_lock.acquire(blocking=False):
            raise RunBlocked('Dự án đã có phiên RUN hoạt động')
        self.stop.clear()
        try:return self._run_impl(provider,max_usd=max_usd,prices=prices,notify=notify,
                    selected_stage_ids=selected_stage_ids,auto_dependencies=auto_dependencies)
        finally:self._run_lock.release()
    def _run_impl(self,provider:Provider|None=None,*, max_usd:float=0.0,
            prices:dict|None=None,notify:Callable[[str],None]|None=None,
            selected_stage_ids=None, auto_dependencies:bool=True):
        notify=notify or (lambda _:None)
        began=time.monotonic()
        self._confirmed_options()  # Detect any changes before allowing QA/checkpoint reuse.
        contract=self.active_contract()
        active=self.store.source_hashes()
        expected_source_hashes=dict(active)
        selected_revisions={}
        plan=prepare_plan(contract,self.store,provider,
                    selected=set(selected_stage_ids) if selected_stage_ids is not None else None,
                    include_dependencies=auto_dependencies)
        if not plan.ready:
            raise RunBlocked('KIỂM TRA TRƯỚC RUN KHÔNG ĐẠT:\n'+plan.report())
        prices=prices or {'input':2.0,'cached_input':0.2,'output':10.0} # editable illustration, not market quote
        run_id=self.store.begin(contract.contract_sha)
        status='BLOCKED';reason=''
        try:
            planned_include=set(plan.included)
            for sid in plan.ordered:
                if self.store.source_hashes()!=expected_source_hashes:
                    raise ContractError('Nguồn dự án đã thay đổi giữa phiên; dừng trước khi gọi API tiếp')
                self.active_contract() # verify rule/contract snapshots at each stage boundary
                if self.stop.is_set():raise RunBlocked('Đã dừng theo yêu cầu')
                st=contract.stage_by_id[sid]
                input_hashes={name:active[name] for name in st.inputs}
                fp=stage_fingerprint(contract,st,input_hashes,provider)
                old=self.store.find_artifact(st.output,fp)
                if old and old[2]=='PASS':
                    active[st.output]=old[1];selected_revisions[st.output]=old[0]
                    notify(f'Đã dùng checkpoint: {st.title}');continue
                if sid not in planned_include:
                    ext=self.store.external_output(st.output)
                    if ext is None:
                        raise RunBlocked(f'{sid}: thiếu dữ liệu đầu vào đã QA; hãy tích bước này hoặc bật tự tạo bước phụ thuộc')
                    # Never mark an uploaded file PASS without structural and semantic QA.
                    inputs={name:self.store.source_or_artifact(name,active) for name in st.inputs}
                    content=self.store.text(ext[0])
                    errors=validate_content(content,st.validators,inputs)
                    if st.output_type=='json':
                        try:json.loads(content)
                        except ValueError:errors.append('Tài liệu JSON nhập ngoài không hợp lệ')
                    if errors:
                        raise RunBlocked(f'{sid}: tài liệu nhập ngoài chưa đạt QA cấu trúc: '+', '.join(errors))
                    external_fp=digest({'stage_fp':fp,'external_sha':ext[0],'kind':'USER_SUPPLIED_QA'})
                    rec=self.store.find_artifact(st.output,external_fp)
                    if rec and rec[2]=='PASS':
                        active[st.output]=rec[1];selected_revisions[st.output]=rec[0]
                        notify('Dùng tài liệu ngoài đã được QA: '+st.title)
                        continue
                    if st.semantic_qa:
                        self._qa_semantic(provider,st,content,inputs,run_id,prices,max_usd)
                    rid=self.store.save_artifact(st.output,st.id,external_fp,content,'PASS',
                        'Tài liệu ngoài: QA cấu trúc + QA ngữ nghĩa theo hợp đồng' if st.semantic_qa else 'Tài liệu ngoài: QA cấu trúc',input_hashes)
                    active[st.output]=ext[0];selected_revisions[st.output]=rid
                    notify('Đã QA tài liệu ngoài: '+st.title)
                    continue
                inputs={name:self.store.source_or_artifact(name,active) for name in st.inputs}
                notify('Đang thực hiện: '+st.title)
                if st.adapter=='join':
                    content='\n'.join(inputs.values())
                elif st.adapter=='template':
                    content=st.instructions
                    for name,value in inputs.items():content=content.replace('{{'+name+'}}',value)
                else:
                    chunks=[];units=self._stage_units(st,inputs)
                    if not units:raise RunBlocked(f'{sid}: không có đơn vị xử lý')
                    for unit_id,unit in units:
                        cached=self.store.get_unit(sid,fp,unit_id)
                        if cached is not None:
                            chunks.append(cached);continue
                        system,user=self._make_prompt(st,inputs,unit)
                        text=self._request(provider,run_id,sid,system,user,st.max_output_tokens,prices,max_usd)
                        if st.scope=='each_audio_line':
                            if '\n' in text:raise RunBlocked(f'{sid} {unit_id}: API trả nhiều dòng')
                            text=unit_id+'|'+text
                        # For per-line tasks, semantic QA is needed with the exact local line evidence,
                        # not an enormous whole-source review at the end.
                        if st.semantic_qa and st.scope in ('each_audio_line','chunks'):
                            evidence={name:((json.dumps(unit,ensure_ascii=False) if st.scope=='each_audio_line' else unit) if name==st.chunk_source else val)
                                      for name,val in inputs.items()}
                            try:self._qa_semantic(provider,st,text,evidence,run_id,prices,max_usd)
                            except SemanticReviewFailure as issue:
                                text=self._retry_semantic_output(provider,run_id,st,text,inputs,unit,
                                                                 issue,prices,max_usd,notify)
                        if not text.strip():raise RunBlocked(f'{sid} {unit_id}: kết quả rỗng')
                        self.store.save_unit(sid,fp,unit_id,text)
                        chunks.append(text)
                        notify(f'{st.title}: {len(chunks)}/{len(units)} đơn vị')
                    content='\n'.join(chunks).strip()
                if st.output_type=='json':
                    try:json.loads(content)
                    except (ValueError,TypeError) as exc:raise RunBlocked(f'{sid}: JSON kết quả không hợp lệ') from exc
                problems=validate_content(content,st.validators,inputs)
                if problems:
                    if st.scope!='whole':
                        # Do not regenerate the whole set for a unit-level error.
                        raise RunBlocked(f'{sid}: QA cấu trúc FAIL: '+', '.join(problems))
                    content=self._retry_structural(provider,run_id,st,content,inputs,problems,prices,max_usd,notify)
                elif st.semantic_qa and st.scope=='whole':
                    try:self._qa_semantic(provider,st,content,inputs,run_id,prices,max_usd)
                    except SemanticReviewFailure as issue:
                        content=self._retry_semantic_output(provider,run_id,st,content,inputs,None,
                                                             issue,prices,max_usd,notify)
                rid=self.store.save_artifact(st.output,st.id,fp,content,'PASS',
                                         'Cấu trúc PASS; QA ngữ nghĩa theo cấu hình' if st.semantic_qa else 'Cấu trúc PASS',
                                         input_hashes)
                active[st.output]=digest(content)
                selected_revisions[st.output]=rid
                notify('Đã hoàn thành: '+st.title)
            # Selected mode never claims FINAL for a subset. All stages and all
            # deliverables must be resolved and QA checked before release.
            if not plan.all_outputs_requested or contract.raw.get('execution_scope')=='PARTIAL':
                notify('Đã hoàn thành các bước được chọn; kết quả lưu trong dự án, chưa xuất FINAL.')
                status='SELECTED_PASS'
                return 'ĐÃ LƯU CÁC BƯỚC ĐƯỢC CHỌN (chưa phải FINAL)'
            # Final only if every required output resolves to a PASS revision, not merely an input source.
            for name in contract.outputs:
                if name not in active:raise RunBlocked('Thiếu đầu ra: '+name)
                if name not in contract.producers:
                    raise RunBlocked('Đầu ra FINAL không được là dữ liệu nguồn thuần: '+name)
                rid=selected_revisions.get(name)
                record=self.store.artifact_revision(rid) if rid is not None else None
                if not record or record[4]!=active[name] or record[5]!='PASS':
                    raise RunBlocked('Đầu ra chưa đạt QA: '+name)
            from .exporter import export_final
            release_status='FINAL' if getattr(provider,'is_live',False) else 'TEST_ONLY'
            output=export_final(self.store,contract,active,selected_revisions,expected_source_hashes,release_status=release_status,elapsed_seconds=time.monotonic()-began)
            notify('Đã xuất: '+str(output))
            status=release_status;return output
        except Exception as e:
            reason=str(e)
            notify('Đã chặn: '+reason)
            raise
        finally:
            self.store.end(run_id,status,reason)
