"""Regression based on the real user-provided TeamSocLo malformed QA reply.

The provider returned an early closing } before ",continuity". It said FAIL,
with two substantive issues. Do not change its verdict, invent content, or
request another paid QA when a saved diagnostic can be safely re-parsed.
"""
import json
from hashlib import sha256
from types import SimpleNamespace as NS

import pytest

from studio.contract import ContractError
from studio.guide_flow import parse_review, GuideFlow, sha, atomic_json
from tests.test_scene_responsive_v14 import SceneProvider, project
from tests.test_scene_v17_scope_resume import window_folder

REAL_INCIDENT_RAW = '''{"verdict":"FAIL","issues":["La adaptación convierte una sospecha en certeza: la fuente plantea si la relación entre Sein y Lisa venía de antes o si Thor solo estaba imaginándolo («単なる思い込みかもしれない»); el candidato afirma que Sein «le había quitado» a Lisa y que ya estaban juntos, omitiendo esa incertidumbre.","Falla la condensación local: reproduce casi todos los beats y detalles en una paráfrasis extensa. Por ejemplo, la fuente enumera sucesivamente las dudas de Thor sobre qué hizo mal, qué vio Lisa en Sein y cómo pudo traicionarlo; el candidato conserva las tres preguntas casi completas. También mantiene íntegra la explicación repetida de que las habilidades de reserva son desconocidas para los especialistas y que todo sobre ellas sigue siendo un enigma."]}
,"continuity":"El source muestra a Thor expulsado del grupo, traicionado por Lisa y herido por la reacción de sus antiguos compañeros; se marcha, arroja el anillo, descarga su dolor y decide partir al país vecino. Revisa sus datos: nivel 20, humano, guerrero; las habilidades de almacenamiento siguen siendo un misterio. El fragmento posterior empieza confirmando que se considera un estorbo y continúa con su encuentro con un Black Hound. No juzgo aquí los requisitos globales del proyecto, incluido el objetivo de compresión del 40%."}'''


def test_exact_live_diagnostic_byte_equivalent_and_semantic_fail():
    assert len(REAL_INCIDENT_RAW) == 1304
    assert sha(REAL_INCIDENT_RAW) == 'f72e0fe43f9cfd17a7163c008d6c68bd6a578b10be97c22289b572bad976f363'
    with pytest.raises(json.JSONDecodeError):json.loads(REAL_INCIDENT_RAW)
    result=parse_review(REAL_INCIDENT_RAW)
    assert result['verdict']=='FAIL'
    assert len(result['issues'])==2
    assert 'La adaptación convierte' in result['issues'][0]
    assert result['continuity'].startswith('El source muestra')
    assert '40%' in result['continuity']


@pytest.mark.parametrize('raw',[
    '{"verdict":"FAIL","issues":["x"]}\n,"continuity":"yes"}{"verdict":"PASS","issues":[]}',
    '{"verdict":"FAIL","issues":["x"]}\n,"continuity":"unfinished',
    '{"verdict":"FAIL","issues":["x"]}\n,"continuity":"yes"}', # fixed counterpart elsewhere
    '{"verdict":"FAIL","issues":["x"]}\n,"continuity":"yes","verdict":"PASS"}',
    '{"verdict":"FAIL","issues":["x"]}\n,"continuity":{}}',
    '{"verdict":"FAIL","issues":["x"]}\n,"continuity":"yes"} trailing comments',
    '{"verdict":"FAIL","issues":["x"]}\n,"continuity":"yes"}}',
])
def test_not_launder_truncated_contradictory_or_extra_json(raw):
    if raw == '{"verdict":"FAIL","issues":["x"]}\n,"continuity":"yes"}':
        assert parse_review(raw)['verdict']=='FAIL'
    else:
        with pytest.raises(ContractError):parse_review(raw)


def test_valid_pass_with_extra_brace_remains_pass_but_not_invented():
    raw='{"verdict":"PASS","issues":[]}\n,"continuity":"verified"}'
    parsed=parse_review(raw)
    assert parsed=={'verdict':'PASS','issues':[],'continuity':'verified'}


def test_duplicate_key_or_conflicting_verdict_rejected():
    with pytest.raises(ContractError):
        parse_review('{"verdict":"FAIL","issues":["x"]}\n,"continuity":"ok","verdict":"PASS"}')
    with pytest.raises(ContractError):
        parse_review('{"verdict":"PASS","issues":["x"]}\n,"continuity":"ok"}')


class FailFormatOnce(SceneProvider):
    def __init__(self):
        super().__init__();self.seen=False
    def generate(self,*,system,user,max_output_tokens):
        if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system and not self.seen:
            self.seen=True
            self.calls.append((system,user,max_output_tokens))
            return NS(text=REAL_INCIDENT_RAW)
        return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)


def test_real_invalid_response_is_semantic_fail_not_format_error(tmp_path):
    flow=project(tmp_path)
    p=FailFormatOnce()
    # First QA is FAIL; normal REPAIR then QA PASS using fake provider.
    result=flow.run_next(p,max_output_tokens=1600,repair_attempts=1)
    assert result['state']=='LOCKED'
    folder=window_folder(flow)
    assert (folder/'window_00001_repair_1.txt').exists()
    assert not (folder/'window_00001_qa_invalid.json').exists()


def test_resume_existing_invalid_response_offline_before_any_new_qa(tmp_path):
    flow=project(tmp_path)
    # Force a failure whose raw response will be persisted by existing _qa.
    class RawDiagnostic(SceneProvider):
        def generate(self,*,system,user,max_output_tokens):
            if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
                self.calls.append((system,user,max_output_tokens))
                return NS(text='{"verdict":"FAIL","issues":["x"]')
            return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
    from studio.guide_scene import _qa
    provider=RawDiagnostic()
    with pytest.raises(ContractError): flow.run_next(provider,max_output_tokens=1600)
    folder=window_folder(flow)
    evidence_file=folder/'window_00001_qa_invalid.json'
    diagnostics=json.loads(evidence_file.read_text(encoding='utf8'))
    assert diagnostics['evidence']['candidate_sha']
    diagnostics['response_text']=REAL_INCIDENT_RAW
    diagnostics['response_length']=len(REAL_INCIDENT_RAW)
    diagnostics['response_sha256']=sha(REAL_INCIDENT_RAW)
    diagnostics['response_truncated']=False
    atomic_json(evidence_file,diagnostics)
    resumed=SceneProvider()
    progress=[]
    result=GuideFlow(flow.folder).run_next(resumed,progress=progress.append,
                                           max_output_tokens=1600,repair_attempts=1)
    assert result['state']=='LOCKED'
    assert (folder/'window_00001_repair_1.txt').exists()
    assert not evidence_file.exists()
    assert any('đọc lại QA đã lưu, không gọi thêm API' in line for line in progress)
    # The restored original FAIL needs NO repeat QA. Only its newly repaired
    # candidate is reviewed over the first window in this resumed process.
    assert len([1 for sys,usr,_ in resumed.calls
                if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in sys and
                   'BEGIN_CANDIDATE_WINDOW_1 |' in usr])==1


def test_wrong_candidate_sha_cannot_reuse_saved_invalid_qa(tmp_path):
    flow=project(tmp_path)
    class FirstInvalid(SceneProvider):
        def generate(self,*,system,user,max_output_tokens):
            if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
                self.calls.append((system,user,max_output_tokens))
                return NS(text='{"verdict":"PASS","issues":[')
            return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
    with pytest.raises(ContractError):
        flow.run_next(FirstInvalid(),max_output_tokens=1600)
    folder=window_folder(flow)
    path=folder/'window_00001_qa_invalid.json'
    diagnosis=json.loads(path.read_text(encoding='utf8'))
    diagnosis['response_text']=REAL_INCIDENT_RAW
    diagnosis['response_length']=len(REAL_INCIDENT_RAW)
    diagnosis['response_sha256']=sha(REAL_INCIDENT_RAW)
    diagnosis['response_truncated']=False
    diagnosis['evidence']['candidate_sha']='0'*64  # deliberately stale/untrusted
    atomic_json(path,diagnosis)
    p=SceneProvider()
    logs=[]
    assert GuideFlow(flow.folder).run_next(p,progress=logs.append,max_output_tokens=1600)['state']=='LOCKED'
    assert not any('đọc lại QA đã lưu' in log for log in logs)
    assert any('QA ĐỘC LẬP CHO SOURCE WINDOW' in sys and
               'BEGIN_CANDIDATE_WINDOW_1 |' in usr for sys,usr,_ in p.calls)


def test_truncated_or_tampered_saved_invalid_qa_does_not_recover(tmp_path):
    flow=project(tmp_path)
    class FirstInvalid(SceneProvider):
        def generate(self,*,system,user,max_output_tokens):
            if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
                self.calls.append((system,user,max_output_tokens))
                return NS(text='{"verdict":"PASS","issues":[')
            return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
    with pytest.raises(ContractError):flow.run_next(FirstInvalid(),max_output_tokens=1600)
    path=window_folder(flow)/'window_00001_qa_invalid.json'
    diagnosis=json.loads(path.read_text(encoding='utf8'))
    diagnosis.update(response_text=REAL_INCIDENT_RAW,response_length=len(REAL_INCIDENT_RAW),
                     response_sha256=sha(REAL_INCIDENT_RAW),response_truncated=True)
    atomic_json(path,diagnosis)
    p=SceneProvider();logs=[]
    GuideFlow(flow.folder).run_next(p,progress=logs.append,max_output_tokens=1600)
    assert not any('đọc lại QA đã lưu' in line for line in logs)
    assert any('QA ĐỘC LẬP CHO SOURCE WINDOW' in sys and
               'BEGIN_CANDIDATE_WINDOW_1 |' in usr for sys,usr,_ in p.calls)
