"""Independently targeted regressions for rule analysis and compiler integrity."""
from __future__ import annotations
import json, threading, time
from pathlib import Path
import pytest
from studio.api import Generation
from studio.contract import ContractError
from studio.fast_analysis import explicit_human_requirements, is_human_choice_line
from studio.rule_options import analyze_rules, pending_analysis_chunks, verify_report_constraints, read_rules
from studio.large_rule_compiler import compile_large
from studio.compiler import draft_contract


def make_question(filename, line, quote):
    return dict(question='Chọn ngôn ngữ?', kind='single', required=True,
                choices=['tiếng Việt','tiếng Anh'], source_file=filename,
                source_line=line, source_quote=quote)

class Offline:
    def __init__(self, questions=None, blockers=None):
        self.questions = questions or []
        self.blockers = blockers or []
        self.calls = 0
        self.model='offline';self.effort='default';self.provider_id='fake'
    def generate(self, *, system, user, max_output_tokens):
        self.calls+=1
        name=user.split('TÊN FILE QUY TẮC: ',1)[1].splitlines()[0]
        return Generation(json.dumps(dict(summary='Chỉ phân tích', steps=['Xử lý văn bản'],
            deliverables=['Kết quả TXT'], questions=self.questions,
            warnings=[], blockers=self.blockers, assertions=[]),ensure_ascii=False))


def test_model_omission_is_rejected_and_not_cached(tmp_path):
    src='Người dùng phải chọn ngôn ngữ: tiếng Việt hoặc tiếng Anh.'
    files={'NEW_WORKFLOW.md':src}
    m=Offline()
    with pytest.raises(ContractError,match='bỏ sót'):
        analyze_rules(files,m,checkpoint_dir=tmp_path,provider_identity='fake:offline')
    assert m.calls==2  # one bounded corrective attempt
    assert pending_analysis_chunks(files,tmp_path,'fake:offline')==1
    assert not list(tmp_path.rglob('*.json'))


def test_example_user_decision_is_not_a_real_question():
    src='Ví dụ minh họa người dùng phải chọn ngôn ngữ: tiếng Việt hoặc tiếng Anh.\n'
    assert explicit_human_requirements({'other.txt':src},'other.txt')=={}
    assert not is_human_choice_line(src.strip())
    report=analyze_rules({'other.txt':src},Offline())
    assert report['questions']==[]


def test_unverified_ai_blocker_must_not_block_project():
    files={'LANG.txt':'Ngôn ngữ đầu ra: tiếng Việt.'}
    report=analyze_rules(files,Offline(blockers=['Mâu thuẫn với tiếng Anh nhưng không có nguồn.']))
    assert report['blockers']==[]
    assert any('chưa dẫn chứng' in x for x in report['warnings'])
    verify_report_constraints(report,files)


def test_fake_grounded_blocker_quote_is_not_promoted():
    files={'LANG.txt':'Ngôn ngữ đầu ra: tiếng Việt.'}
    blocker={'description':'tiếng Việt xung đột với tiếng Anh', 'evidence':[
        dict(source_file='LANG.txt',source_line=1,source_quote='Ngôn ngữ đầu ra: tiếng Việt.'),
        dict(source_file='LANG.txt',source_line=99,source_quote='tiếng Anh')]}
    report=analyze_rules(files,Offline(blockers=[blocker]))
    assert not report['blockers']
    assert any('không xác minh' in x for x in report['warnings'])


def test_validated_chunk_cache_resists_missing_options(tmp_path):
    src='Người dùng phải chọn ngôn ngữ: tiếng Việt hoặc tiếng Anh.'
    files={'A.txt':src}
    m=Offline([make_question('A.txt',1,src)])
    report=analyze_rules(files,m,checkpoint_dir=tmp_path,provider_identity='model:1')
    assert report['questions']
    assert m.calls==1
    again=Offline()
    reread=analyze_rules(files,again,checkpoint_dir=tmp_path,provider_identity='model:1')
    assert reread['cache_hits']==1 and again.calls==0
    tampered=dict(reread,questions=[])
    with pytest.raises(ContractError,match='bỏ sót'):
        verify_report_constraints(tampered,files)


def test_current_eight_files_have_no_explicit_user_fields():
    # This is a situational CHECK, not a hard-coded bypass in production.
    names=['B1.txt','B2.txt','B3.txt','B4.txt','B5.txt','B6.txt','B7.txt','QUY_TRINH_HUONG_DAN.txt']
    root=Path('/mnt/data')
    if not all((root/name).is_file() for name in names):
        pytest.skip('User files not mounted here (source is never redistributed)')
    files=read_rules([root/name for name in names])
    assert set(files)==set(names)
    assert all(not explicit_human_requirements(files, n) for n in names)


def test_three_parallel_compiler_chunk_calls_are_bounded_and_ordered(tmp_path):
    from tests.test_large_rule_compile import rule_fixture,LargeMock
    files, hash_value, contract = rule_fixture(tmp_path)
    class ParallelMock(LargeMock):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.peak=0;self.current=0;self._lock=threading.Lock()
        def generate(self, *, system,user,max_output_tokens):
            if 'Phân tích MỘT ĐOẠN QUY TẮC' not in system:
                return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
            with self._lock:
                self.current+=1;self.peak=max(self.current,self.peak)
            try:
                time.sleep(.015)
                return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
            finally:
                with self._lock:self.current-=1
    fake=ParallelMock(contract)
    result=draft_contract(files,hash_value,fake,checkpoint_path=tmp_path/'checkpoint.json',max_workers=3)
    assert result['stages']
    assert 1<fake.peak<=3
    assert all(not line.startswith('None') for line in (tmp_path/'checkpoint.json').read_text().splitlines())


def test_large_compiler_checkpoint_can_be_reused_without_paid_calls(tmp_path):
    """Saved, validated state replays all clause coverage without paid requests."""
    from tests.test_large_rule_compile import rule_fixture, LargeMock
    files, source_hash, contract=rule_fixture(tmp_path)
    original=tmp_path/'original.json'
    one=LargeMock(contract)
    result=draft_contract(files,source_hash,one,checkpoint_path=original,max_workers=3)
    assert result['clause_coverage'] and one.calls
    resumed=tmp_path/'resumed.json'
    resumed.write_bytes(original.read_bytes())
    two=LargeMock(contract)
    other=draft_contract(files,source_hash,two,checkpoint_path=resumed,max_workers=3)
    assert other==result
    assert not two.calls
