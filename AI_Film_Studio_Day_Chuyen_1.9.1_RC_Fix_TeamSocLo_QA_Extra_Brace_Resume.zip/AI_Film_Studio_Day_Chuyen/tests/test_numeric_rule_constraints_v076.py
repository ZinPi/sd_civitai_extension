"""Regression tests for number-choice and parity bypasses found in v0.7.5.

All tests run offline with a fake model and the original unmodified rule text.
"""
import json

import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.project_setup import initialize_approved_project
from studio.rule_options import analyze_rules, validate_answers, verify_report_constraints


class FakeModel:
    def __init__(self, doc):
        self.doc = doc
        self.calls = 0
    def generate(self, *, system, user, max_output_tokens):
        self.calls += 1
        return Generation(json.dumps(self.doc, ensure_ascii=False))


def make_report(rule, kind='number'):
    original = rule.splitlines()[0]
    q = dict(question='Bạn chọn giá trị nào?', kind=kind, required=True, choices=[],
             source_file='QUY_TAC.txt', source_line=1,
             source_quote=original)
    document = dict(summary='Phân tích quy tắc', steps=['Xử lý'],
                    deliverables=['KET_QUA.txt'], questions=[q], warnings=[], blockers=[])
    return analyze_rules({'QUY_TAC.txt':rule}, FakeModel(document))


@pytest.mark.parametrize('rule,accepted,rejected', [
    ('Người dùng chọn số câu: 3 hoặc 5.', ('3', '5'), ('4', '0', '-1')),
    ('Người dùng PHẢI CHỌN độ dài: 3 câu HOẶC 5 câu trước khi sản xuất.', ('3', '5'), ('4',)),
    ('Chọn số lượng: 3 hay 5 cảnh', ('3', '5'), ('6',)),
    ('Choose number: 3 or 5 sentences', ('3', '5'), ('4',)),
    ('Chọn số câu:\n- 3 câu\n- 5 câu', ('3', '5'), ('4',)),
    ('Người dùng phải nhập số cảnh là số chẵn từ 2 đến 10.', ('2','4','10'), ('1','3','5','11','4.5')),
    ('Người dùng phải nhập số cảnh là số lẻ từ 1 đến 9.', ('1','3','9'), ('2','4','10','1.5')),
    ('Người dùng phải nhập số trang chia hết cho 3 trong khoảng 3 đến 30.', ('3','6','30'), ('4','10','31')),
    ('Người dùng phải nhập số cảnh là số nguyên từ 1 đến 10.', ('1','10'), ('0','11','3.5')),
])
def test_numeric_rules_enforced_from_original_text(rule, accepted, rejected):
    report = make_report(rule)
    assert report['constraint_engine_version'] == 2
    verify_report_constraints(report, {'QUY_TAC.txt': rule})
    for number in accepted:
        assert validate_answers(report, {'q001':number})['q001'] == number
    for number in rejected:
        with pytest.raises(ContractError):
            validate_answers(report, {'q001':number})


def test_explicit_number_alternatives_are_closed_set():
    report = make_report('Người dùng chọn số câu: 3 hoặc 5.')
    assert report['numeric_constraints']['q001']['allowed_values'] == ['3','5']
    assert report['numeric_constraints']['q001']['integer'] is False
    with pytest.raises(ContractError, match='phương án'):
        validate_answers(report, {'q001':'4'})


@pytest.mark.parametrize('rule', [
    'Chọn 3 hoặc 5 câu, phải là số chẵn.',
    'Người dùng phải nhập số cảnh vừa số chẵn vừa số lẻ.',
    'Người dùng phải nhập số cảnh là bội số của 0.',
])
def test_conflicting_rules_fail_before_approval(rule):
    with pytest.raises(ContractError):
        make_report(rule)


def test_audited_numeric_constraints_cannot_be_changed_after_analysis(tmp_path):
    rule = 'Người dùng chọn số câu: 3 hoặc 5.'
    report = make_report(rule)
    altered = json.loads(json.dumps(report))
    altered['numeric_constraints']['q001']['allowed_values'] = ['3','4','5']
    p = tmp_path / 'QUY_TAC.txt'
    p.write_text(rule, encoding='utf8')
    with pytest.raises(ContractError, match='không khớp TXT gốc'):
        verify_report_constraints(altered, {'QUY_TAC.txt':rule})
    with pytest.raises(ContractError, match='không khớp TXT gốc'):
        initialize_approved_project(tmp_path / 'project', [p], altered, {'q001':'4'})
    assert not (tmp_path / 'project').exists()


def test_old_report_is_rejected_before_project_creation(tmp_path):
    rule = 'Người dùng phải nhập số cảnh là số chẵn từ 2 đến 10.'
    report = make_report(rule)
    del report['constraint_engine_version']
    p = tmp_path / 'QUY_TAC.txt'
    p.write_text(rule, encoding='utf8')
    with pytest.raises(ContractError, match='Phân tích cũ'):
        initialize_approved_project(tmp_path / 'project', [p], report, {'q001':'3'})
    assert not (tmp_path / 'project').exists()


def test_verified_report_creates_and_reopens_project(tmp_path):
    from studio.engine import Studio
    rule = 'Người dùng phải nhập số cảnh là số chẵn từ 2 đến 10.'
    p = tmp_path / 'QUY_TAC.txt'
    p.write_text(rule, encoding='utf8')
    report = make_report(rule)
    project = initialize_approved_project(tmp_path / 'project', [p], report, {'q001':'4'})
    try:
        frozen = project._confirmed_options()
        assert '"4"' in frozen
    finally:
        project.close()
    reopened = Studio(tmp_path / 'project')
    try:
        assert reopened._confirmed_options() == frozen
    finally:
        reopened.close()


def test_numeric_decimals_are_compared_by_value():
    report = make_report('Người dùng chọn số câu: 3 hoặc 5.')
    assert validate_answers(report, {'q001':'3.0'})['q001'] == '3.0'
    with pytest.raises(ContractError):
        validate_answers(report, {'q001':'NaN'})


def test_explicit_numeric_user_choice_cannot_be_omitted_by_model():
    rule = 'Người dùng phải chọn số câu: 3 hoặc 5.'
    doc = dict(summary='x', steps=[], deliverables=[], questions=[], warnings=[], blockers=[])
    with pytest.raises(ContractError, match='bỏ sót'):
        analyze_rules({'QUY_TAC.txt':rule}, FakeModel(doc))


def test_numeric_constraints_cannot_be_disguised_as_free_text():
    rule = 'Người dùng nhập số cảnh: số chẵn từ 2 đến 10.'
    q = dict(question='Nhập số cảnh?', kind='text', required=True, choices=[],
             source_file='QUY_TAC.txt', source_line=1, source_quote=rule)
    doc = dict(summary='x', steps=[], deliverables=[], questions=[q], warnings=[], blockers=[])
    with pytest.raises(ContractError, match='nhầm lựa chọn số'):
        analyze_rules({'QUY_TAC.txt':rule}, FakeModel(doc))


def test_existing_unbounded_number_questions_remain_supported():
    rule='Người dùng nhập số cảnh cần tạo.'
    report=make_report(rule)
    assert validate_answers(report, {'q001':'4'})['q001']=='4'
