"""New guide-first pipeline: explicit sequential guarantees and content integrity."""
import json
import zipfile
from pathlib import Path
import pytest
from studio.guide_flow import (GuideFlow,LazyRuleLibrary,guide_sections,split_generated,
                               parse_review)
from studio.contract import ContractError
from studio.api import Generation

GUIDE='''QUY TRÌNH CHUNG — chỉ mở quy tắc khi đến bước đó.
1- TẠO BẢN THẢO
Đọc FILE_RULE_A.txt. Dùng truyện nguồn, xuất draft.txt. Chưa đọc bước sau.
2- CHỈNH VÀ QA
Đọc FILE_RULE_B.txt và QA_EXTRA.txt. Dùng draft.txt đã LOCK, xuất final.txt.
3- BÀN GIAO
Đọc FILE_RULE_C.txt. Dùng final.txt tạo publish.txt.
'''


def create_case(tmp_path,monkeypatch):
    folder=tmp_path/'rules';folder.mkdir()
    guide=folder/'HUONG_DAN.txt';guide.write_text(GUIDE,encoding='utf8')
    for name in ('FILE_RULE_A.txt','FILE_RULE_B.txt','QA_EXTRA.txt','FILE_RULE_C.txt'):
        (folder/name).write_text('RULE CONTENT '+name,encoding='utf8')
    source=tmp_path/'novel.txt';source.write_text('STORY FACT ALPHA',encoding='utf8')
    project=tmp_path/'project'
    return GuideFlow.create(project,None,[folder],[source]),folder,source


class DummyProvider:
    provider_id='dummy'
    model='fake'
    def __init__(self,contents,fail_stage=0):self.contents=list(contents);self.calls=[]
    def generate(self,*,system,user,max_output_tokens):
        self.calls.append((system,user))
        if not self.contents:raise AssertionError('Unexpected API call')
        return Generation(self.contents.pop(0),100,100,0)


def test_names_only_preparation_never_reads_future_rules(tmp_path,monkeypatch):
    orig=LazyRuleLibrary.read
    seen=[]
    def tracked(self,name):
        seen.append(name)
        if name.lower() in ('file_rule_b.txt','qa_extra.txt','file_rule_c.txt'):
            raise AssertionError('future file opened')
        return orig(self,name)
    monkeypatch.setattr(LazyRuleLibrary,'read',tracked)
    flow,_,_=create_case(tmp_path,monkeypatch)
    assert flow.status()['total']==3
    assert seen==['HUONG_DAN.txt']
    api=DummyProvider(['@@FILE:draft.txt@@\nDRAFT ALPHA','{"verdict":"PASS","issues":[]}'])
    flow.run_next(api)
    assert 'FILE_RULE_A.txt' in seen
    assert 'FILE_RULE_B.txt' not in seen
    assert flow.status()['completed']==1
    assert 'STORY FACT ALPHA' in api.calls[0][1]
    assert 'RULE CONTENT FILE_RULE_B' not in api.calls[0][0]
    assert 'RULE CONTENT FILE_RULE_B' not in api.calls[1][0]


def test_second_stage_reads_two_files_and_inherits_locked_output(tmp_path,monkeypatch):
    flow,_,_=create_case(tmp_path,monkeypatch)
    first=DummyProvider(['@@FILE:draft.txt@@\nDRAFT ALPHA','{"verdict":"PASS","issues":[]}'])
    flow.run_next(first)
    second=DummyProvider(['@@FILE:final.txt@@\nFINAL ALPHA','{"verdict":"PASS","issues":[]}'])
    result=flow.run_next(second)
    assert set(result['rules'])=={'FILE_RULE_B.txt','QA_EXTRA.txt'}
    assert 'DRAFT ALPHA' in second.calls[0][1]
    assert 'RULE CONTENT FILE_RULE_B.txt' in second.calls[0][0]
    assert 'RULE CONTENT QA_EXTRA.txt' in second.calls[0][0]
    assert 'RULE CONTENT FILE_RULE_C.txt' not in second.calls[0][0]
    assert flow.status()['completed']==2


def test_qa_fail_never_unlocks_later_stage_and_preserves_candidate(tmp_path,monkeypatch):
    flow,_,_=create_case(tmp_path,monkeypatch)
    api=DummyProvider(['@@FILE:draft.txt@@\nDRAFT BAD','{"verdict":"FAIL","issues":["Lost source fact"]}'])
    with pytest.raises(ContractError,match='QA chưa PASS'):
        flow.run_next(api)
    assert flow.status()['completed']==0
    assert (flow.folder/'candidates'/'STEP_001'/'candidate.txt').is_file()
    assert not (flow.folder/'steps'/'STEP_001').exists()


def test_qa_invalid_pass_with_issues_is_rejected(tmp_path,monkeypatch):
    flow,_,_=create_case(tmp_path,monkeypatch)
    api=DummyProvider(['@@FILE:draft.txt@@\nDRAFT','{"verdict":"PASS","issues":["ERROR"]}'])
    with pytest.raises(ContractError,match='PASS nhưng'):
        flow.run_next(api)
    assert flow.status()['completed']==0


def test_missing_rule_only_blocks_its_own_step(tmp_path,monkeypatch):
    flow,folder,_=create_case(tmp_path,monkeypatch)
    (folder/'QA_EXTRA.txt').unlink()
    flow.run_next(DummyProvider(['@@FILE:draft.txt@@\nDRAFT','{"verdict":"PASS","issues":[]}']))
    with pytest.raises(ContractError,match='QA_EXTRA.txt'):
        flow.run_next(DummyProvider([]))
    assert flow.status()['completed']==1


def test_changed_upstream_artifact_blocks_reuse(tmp_path,monkeypatch):
    flow,_,_=create_case(tmp_path,monkeypatch)
    flow.run_next(DummyProvider(['@@FILE:draft.txt@@\nDRAFT','{"verdict":"PASS","issues":[]}']))
    (flow.folder/'steps'/'STEP_001'/'draft.txt').write_text('TAMPERED',encoding='utf8')
    with pytest.raises(ContractError,match='Thành quả đã LOCK'):
        flow.status()
    with pytest.raises(ContractError):flow.run_next(DummyProvider([]))


def test_changed_old_rule_blocks_next_step(tmp_path,monkeypatch):
    flow,folder,_=create_case(tmp_path,monkeypatch)
    flow.run_next(DummyProvider(['@@FILE:draft.txt@@\nDRAFT','{"verdict":"PASS","issues":[]}']))
    (folder/'FILE_RULE_A.txt').write_text('CHANGED RULE',encoding='utf8')
    with pytest.raises(ContractError,match='Quy tắc của bước đã khóa'):
        flow.run_next(DummyProvider([]))


def test_guide_can_be_indexed_inside_zip_without_reading_all(tmp_path,monkeypatch):
    zip_path=tmp_path/'pack.zip'
    with zipfile.ZipFile(zip_path,'w') as z:
        z.writestr('dir/HUONG_DAN.txt',GUIDE)
        for name in ['FILE_RULE_A.txt','FILE_RULE_B.txt','QA_EXTRA.txt','FILE_RULE_C.txt']:
            z.writestr('dir/'+name,'secret '+name)
    story=tmp_path/'novel.txt';story.write_text('ABC',encoding='utf8')
    lib=LazyRuleLibrary([zip_path])
    assert len(lib.names())==5
    flow=GuideFlow.create(tmp_path/'newproj',None,[zip_path],[story])
    assert flow.status()['total']==3
    flow.run_next(DummyProvider(['@@FILE:draft.txt@@\nABC','{"verdict":"PASS","issues":[]}']))
    assert flow.status()['completed']==1


def test_non_hardcoded_multi_rule_guide(tmp_path):
    guide='''Bước 1: Tạo đầu ra\nĐọc RULE_A.md và RULE_B.md và thực hiện.\nBước 2: QA\nĐọc QA_1.yaml.\n'''
    stages=guide_sections(guide,'HUONG_DAN.txt')
    assert len(stages)==2
    assert stages[0]['references']==['RULE_A.md','RULE_B.md']
    assert stages[1]['references']==['QA_1.yaml']


def test_duplicates_ambiguous_are_rejected(tmp_path):
    folder=tmp_path/'a';folder.mkdir()
    (folder/'RULE_A.txt').write_text('1',encoding='utf8')
    folder2=tmp_path/'b';folder2.mkdir()
    (folder2/'RULE_A.txt').write_text('2',encoding='utf8')
    library=LazyRuleLibrary([folder,folder2])
    with pytest.raises(ContractError,match='Trùng tên'):
        library.read('RULE_A.txt')


def test_no_silent_output_acceptance():
    with pytest.raises(ContractError):split_generated('some text without header')
    with pytest.raises(ContractError):split_generated('@@FILE:a.txt@@\n')
    with pytest.raises(ContractError):split_generated('@@FILE:../evil.txt@@\nokay')
    with pytest.raises(ContractError):parse_review('{"verdict":"PASS","issues":["problem"]}')
    assert list(split_generated('@@FILE:a.txt@@\nONE\n@@FILE:b.txt@@\nTWO'))==['a.txt','b.txt']


def test_one_real_user_guide_maps_7_stages_without_rule_reads(tmp_path):
    from zipfile import ZipFile
    source=Path('/mnt/data/BO_8_QUY_TAC_B4_HO_NGUC_B5_ID_CHAR_BG.zip')
    if not source.is_file():pytest.skip('External user rules not available')
    with ZipFile(source) as z:guide=z.read('QUY_TRINH_HUONG_DAN.txt').decode('utf8')
    stages=guide_sections(guide,'QUY_TRINH_HUONG_DAN.txt')
    assert len(stages)==7
    assert 'B1.txt' in stages[0]['references'] or 'B1.TXT' in stages[0]['references']
    assert 'B4.TXT' in [n.upper() for n in stages[3]['references']]
    assert set(n.upper() for n in stages[5]['references'])>={'B5.TXT','B6.TXT'}
    assert 'B7.TXT' in [n.upper() for n in stages[6]['references']]


def test_human_required_choices_are_not_assigned_to_ai(tmp_path):
    folder=tmp_path/'rules';folder.mkdir()
    (folder/'HUONG_DAN.txt').write_text('1- TEST\nĐọc RULE_ONE.txt.',encoding='utf8')
    (folder/'RULE_ONE.txt').write_text('Trước khi bắt đầu, người dùng tự lựa chọn phong cách A hoặc B.',encoding='utf8')
    source=tmp_path/'story.txt';source.write_text('A story',encoding='utf8')
    flow=GuideFlow.create(tmp_path/'proj',None,[folder],[source])
    choices=flow.current_requirements()
    assert list(choices)==['RULE_ONE.txt:1']
    with pytest.raises(ContractError,match='chưa xác nhận'):
        flow.run_next(DummyProvider([]))
    fake=DummyProvider(['@@FILE:result.txt@@\nSTYLE A','{"verdict":"PASS","issues":[]}'])
    flow.run_next(fake,user_decisions={'RULE_ONE.txt:1':'A'})
    assert 'NGƯỜI DÙNG CHỌN: A' in fake.calls[0][0]


def test_missing_declared_output_cannot_pass_qa(tmp_path,monkeypatch):
    flow,_,_=create_case(tmp_path,monkeypatch)
    calls=DummyProvider(['@@FILE:wrong.txt@@\nTEXT', '{"verdict":"PASS","issues":[]}'])
    with pytest.raises(ContractError,match='Thiếu file đầu ra'):
        flow.run_next(calls)
    assert len(calls.calls)==1
    assert flow.status()['completed']==0


def test_no_execution_when_context_too_large(tmp_path,monkeypatch):
    from studio import guide_flow
    flow,_,_=create_case(tmp_path,monkeypatch)
    monkeypatch.setattr(guide_flow,'MAX_ALL_CONTEXT',100)
    api=DummyProvider([])
    with pytest.raises(ContractError,match='quá'):
        flow.run_next(api)
    assert api.calls==[]
    assert flow.status()['completed']==0


def test_source_srt_can_be_preserved(tmp_path):
    folder=tmp_path/'r';folder.mkdir()
    (folder/'HUONG_DAN.txt').write_text('1- TEST\nĐọc RULE.txt.',encoding='utf8')
    (folder/'RULE.txt').write_text('Quy tắc.',encoding='utf8')
    source=tmp_path/'episode.srt';source.write_text('1\n00:00:01,000 --> 00:00:03,000\nHello',encoding='utf8')
    flow=GuideFlow.create(tmp_path/'proj',None,[folder],[source])
    assert (flow.folder/'source'/'episode.srt').read_text(encoding='utf8')==source.read_text(encoding='utf8')
