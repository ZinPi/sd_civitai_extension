# -*- coding: utf-8 -*-
"""Windows GUI bootstrap. No .bat/.cmd nor console Python launched on normal path.

First-time venv + pip are executed with Windows CREATE_NO_WINDOW and logged.
Tk is used only while performing one-time setup, if available.
"""
from __future__ import annotations

import contextlib
import datetime
import importlib
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import traceback
import venv

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
VENV = ROOT / '.venv'
WINDOWED_PYTHON = VENV / 'Scripts' / 'pythonw.exe'
LOG = ROOT / 'NHAT_KY_KHOI_DONG.txt'
CREATE_NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)


def write_log(message: str):
    with LOG.open('a', encoding='utf-8') as fp:
        fp.write(f'[{datetime.datetime.now().isoformat(timespec="seconds")}] {message}\n')


def show_error(message: str):
    write_log('LOI: ' + message)
    if os.name == 'nt':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message + '\n\nChi tiet: ' + str(LOG),
                                           'AI Film Studio - Loi khoi dong', 0x10)
    else:
        print(message, file=sys.stderr)


def same_interpreter() -> bool:
    try:
        return Path(sys.executable).resolve() == WINDOWED_PYTHON.resolve()
    except (OSError, ValueError):
        return False


def dependencies_installed() -> bool:
    try:
        import PySide6  # noqa: F401
        import openai  # noqa: F401
        import anthropic  # noqa: F401
        import jsonschema  # noqa: F401
        return True
    except ImportError:
        return False


def start_gui() -> int:
    try:
        # run.py has no terminal I/O; UI runs in this windowless Python process.
        from studio.guide_gui import main
        result = main()
        return int(result) if result is not None else 0
    except BaseException:
        write_log('LOI MO CUA SO GUI:\n' + traceback.format_exc())
        show_error('Khong mo duoc giao dien. Vui long kiem tra nhat ky khoi dong.')
        return 1


class QuietEnvBuilder(venv.EnvBuilder):
    def _call_new_python(self, context, *py_args, **kwargs):
        # ensurepip within venv itself also must not open a Windows Terminal.
        kwargs['creationflags'] = CREATE_NO_WINDOW
        return super()._call_new_python(context, *py_args, **kwargs)


def launch_windowed_child() -> None:
    if not WINDOWED_PYTHON.is_file():
        raise RuntimeError('Khong tim thay .venv\\Scripts\\pythonw.exe sau khi tao venv.')
    subprocess.Popen(
        [str(WINDOWED_PYTHON), str(Path(__file__).resolve())],
        cwd=str(ROOT), creationflags=CREATE_NO_WINDOW,
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL, close_fds=True,
    )


def do_prepare(messages: queue.Queue):
    try:
        if not WINDOWED_PYTHON.is_file():
            messages.put(('status', 'Dang tao moi truong Python tren may...'))
            write_log('Tao venv: bat dau')
            # Python Launcher pyw.exe is windowless. The ensurepip subprocess
            # receives CREATE_NO_WINDOW through the builder override above.
            QuietEnvBuilder(with_pip=True).create(str(VENV))
            write_log('Tao venv: thanh cong')
        if not same_interpreter():
            messages.put(('status', 'Dang chuyen sang Python khong co cua so CMD...'))
            launch_windowed_child()
            messages.put(('done', 'relay'))
            return
        messages.put(('status', 'Dang kiem tra thu vien PySide6/OpenAI...'))
        if not dependencies_installed():
            messages.put(('status', 'Dang cai thu vien lan dau; co the mat vai phut...'))
            write_log('Cai dat thu vien: bat dau')
            with LOG.open('a', encoding='utf-8') as fp:
                proc = subprocess.run(
                    [str(WINDOWED_PYTHON), '-m', 'pip', 'install', '-r', str(ROOT / 'requirements.txt')],
                    cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=fp,
                    stderr=subprocess.STDOUT, creationflags=CREATE_NO_WINDOW,
                    timeout=1800, check=False,
                )
            write_log('Cai dat thu vien: ma ket qua ' + str(proc.returncode))
            if proc.returncode != 0:
                raise RuntimeError('Khong cai duoc thu vien Python. Xem nhat ky khoi dong.')
            if not dependencies_installed():
                raise RuntimeError('Cai thu vien xong nhung chua import duoc PySide6/OpenAI/Anthropic/jsonschema.')
        messages.put(('done', 'gui'))
    except BaseException:
        messages.put(('error', traceback.format_exc()))


def first_time_setup() -> int:
    updates = queue.Queue()
    try:
        import tkinter as tk
        root = tk.Tk()
        root.title('AI Film Studio - Dang khoi dong')
        root.resizable(False, False)
        root.geometry('470x125')
        root.configure(bg='#101827')
        root.eval('tk::PlaceWindow . center')
        lbl = tk.Label(root, text='Dang chuan bi ung dung... Vui long doi.',
                       bg='#101827', fg='#FFFFFF', font=('Segoe UI', 11),
                       wraplength=440)
        lbl.pack(expand=True, padx=12, pady=12)
        root.protocol('WM_DELETE_WINDOW', lambda: None)
    except BaseException:
        # Tk is optional. In rare Python installations without Tk, setup
        # still works hidden, with full log and a visible error popup.
        root = None
        lbl = None

    worker = threading.Thread(target=do_prepare, args=(updates,), daemon=True)
    worker.start()
    result = {'kind': None, 'details': None}

    def check_updates():
        try:
            while True:
                kind, details = updates.get_nowait()
                if kind == 'status' and lbl is not None:
                    lbl.configure(text=details)
                elif kind != 'status':
                    result['kind'], result['details'] = kind, details
                    if root is not None:
                        root.quit()
                    return
        except queue.Empty:
            pass
        if root is not None:
            root.after(150, check_updates)

    if root is not None:
        root.after(150, check_updates)
        root.mainloop()
        root.destroy()
    else:
        worker.join()
        check_updates()

    if result['kind'] == 'error':
        write_log('LOI CHUAN BI:\n' + result['details'])
        show_error('Khong chuan bi duoc moi truong Python. Chi tiet trong nhat ky.')
        return 1
    if result['details'] == 'relay':
        return 0
    if result['details'] == 'gui':
        return start_gui()
    show_error('Qua trinh khoi dong khong co ket qua hop le.')
    return 2


def main() -> int:
    try:
        if sys.version_info < (3, 11):
            show_error('Can Python 3.11 tro len de khoi dong AI Film Studio.')
            return 2
        if same_interpreter() and dependencies_installed():
            return start_gui()
        return first_time_setup()
    except BaseException:
        write_log('LOI KHOI DONG:\n' + traceback.format_exc())
        show_error('Gap loi ngoai du kien khi khoi dong.')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
