"""Independent regression checks for 0.7.2 fixes, separate from 0.7.1 suite."""
from __future__ import annotations
import copy, json, zipfile
import pytest
from studio.contract import validate_contract, digest, ContractError
from studio.engine import Studio
from studio.one_click import OneClickService
from studio.qa import validate_content
from studio.release import check_release_content
from tests.test_core import RULE, contract_template, FakeProvider


def test_enforced_clause_cannot_be_excluded_from_stage_rule_files():
    more='Điều bổ sung: phải khóa vị trí nhân vật.'
    files={'guide.txt':RULE,'more.txt':more}
    raw=contract_template(digest(files))
    raw['file_dispositions']['more.txt']={'role':'PRODUCTION','reason':'Yêu cầu bắt buộc của giai đoạn đầu'}
    raw['clause_coverage'].append({'file':'more.txt','start':1,'end':1,
                                   'decision':'ENFORCE','stage_ids':['STEP_ALPHA'],
                                   'reason':'Khóa bổ sung bắt buộc'})
    with pytest.raises(ContractError,match='chưa có trong stage.rules'):
        validate_contract(raw,files,digest(files))
    raw['stages'][0]['rules'].append('more.txt')
    contract=validate_contract(raw,files,digest(files))
    assert contract.stages[0].rules==('guide.txt','more.txt')


def test_missing_evidence_is_never_pass_even_with_nonempty_validator():
    markers=['ERROR_NEED_EVIDENCE: dữ liệu không đủ',
             '001|ERROR_NEED_EVIDENCE: không có canon']
    for marker in markers:
        problems=validate_content(marker,({'type':'nonempty'},),{})
        assert any('ERROR_NEED_EVIDENCE' in x for x in problems)
        with pytest.raises(ContractError,match='chưa hoàn thành'):
            check_release_content(marker,({'type':'nonempty'},),{},'SCENE_PROMPTS')


def test_one_click_automatic_delivery_uses_rule_requested_outputs_only(tmp_path):
    raw=contract_template('__CURRENT_RULEPACK__')
    path=tmp_path/'rules.zip'
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('guide.txt',RULE)
        z.writestr('workflow.json',json.dumps(raw,ensure_ascii=False))
    # For embedded contracts, all source files must be classified, including the JSON.
    raw['file_dispositions']['workflow.json']={'role':'REFERENCE','reason':'Mẫu quy trình người dùng đã cung cấp'}
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('guide.txt',RULE)
        z.writestr('workflow.json',json.dumps(raw,ensure_ascii=False))
    studio=Studio(tmp_path/'project')
    try:
        studio.import_pack(path)
        studio.import_source_text('SOURCE_AUDIO','001|Một cảnh.\n002|Cảnh tiếp.')
        studio.import_source_text('SOURCE_STORY','Truyện gốc.')
        policy=studio.policy()
        assert policy['mode']=='automatic'
        assert 'character_index' in policy['required_roles']
        result=OneClickService(studio).run(FakeProvider(),max_usd=15)
        assert result.is_file()
        assert set(studio.policy()['required_roles'])=={'scene_prompts','handoff'}
        assert set(studio.active_contract().outputs)=={'PROMPTS','HANDOFF'}
    finally:
        studio.close()


class FailOnceForFirstLine(FakeProvider):
    def __init__(self):
        super().__init__();self.qa_failed=False
    def generate(self,*,system,user,max_output_tokens):
        if 'JSON {"verdict"' in system and '001|' in user and not self.qa_failed:
            self.calls+=1
            self.qa_failed=True
            from studio.api import Generation
            return Generation(json.dumps({'verdict':'FAIL','issues':['chỉnh một dòng'],
                                          'repair_scope':'OUTPUT_ONLY'}),80,60,0)
        return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)


def test_each_audio_line_qa_repair_keeps_line_id(tmp_path):
    raw=contract_template('__CURRENT_RULEPACK__')
    path=tmp_path/'rules.zip'
    raw['file_dispositions']['workflow.json']={'role':'REFERENCE','reason':'Quy trình mẫu đầu vào'}
    with zipfile.ZipFile(path,'w') as z:
        z.writestr('guide.txt',RULE)
        z.writestr('workflow.json',json.dumps(raw,ensure_ascii=False))
    s=Studio(tmp_path/'project')
    try:
        s.import_pack(path)
        s.import_source_text('SOURCE_STORY','Truyện gốc')
        s.import_source_text('SOURCE_AUDIO','001|Một cảnh.\n002|Cảnh hai.')
        provider=FailOnceForFirstLine()
        output=OneClickService(s).run(provider,max_usd=20)
        assert output.exists() and provider.qa_failed
        with zipfile.ZipFile(output) as z:
            lines=z.read('03_SCENE_PROMPTS/SCENE_PROMPT_FINAL.txt').decode().splitlines()
        assert len(lines)==2
        assert [row.split('|',1)[0] for row in lines]==['001','002']
        assert not lines[0].startswith('001|001|')
    finally:s.close()


def test_mapping_validator_links_all_audio_char_bg_and_states():
    audio='001|Đứng cạnh cổng\n002|Vào sân\n003|Xuất hiện người mới'
    char=json.dumps({'characters':[
        {'id':'CHAR_01','states':[{'id':'CLEAN','effective_from_line':1},
                                  {'id':'WOUNDED','effective_from_line':2}]},
        {'id':'CHAR_02','first_reveal_line_id':'003'}]})
    bg=json.dumps({'backgrounds':[{'id':'BG_01','states':[{'id':'DAY','effective_from_line':1}]}]})
    source={'SOURCE_AUDIO':audio,'CHAR_MASTER':char,'BG_MASTER':bg}
    rule=({'type':'mapping_integrity','source':'SOURCE_AUDIO',
           'values':['CHAR_MASTER','BG_MASTER']},)
    valid={'frames':[
        {'line_id':'001','char_ids':['CHAR_01'],'bg_ids':['BG_01'],
         'char_states':{'CHAR_01':'CLEAN'},'bg_states':{'BG_01':'DAY'}},
        {'line_id':'002','char_ids':['CHAR_01'],'bg_ids':['BG_01'],
         'char_states':{'CHAR_01':'WOUNDED'},'bg_states':{'BG_01':'DAY'}},
        {'line_id':'003','char_ids':['CHAR_01','CHAR_02'],'bg_ids':['BG_01'],
         'char_states':{'CHAR_01':'WOUNDED'},'bg_states':{'BG_01':'DAY'}}]}
    assert not validate_content(json.dumps(valid),rule,source)
    wrong=copy.deepcopy(valid);wrong['frames'][0]['char_ids']+=['CHAR_02']
    assert any('first_reveal' in x for x in validate_content(json.dumps(wrong),rule,source))
    wrong=copy.deepcopy(valid);wrong['frames'][1]['char_states']['CHAR_01']='CLEAN'
    assert any('state' in x for x in validate_content(json.dumps(wrong),rule,source))
    wrong=copy.deepcopy(valid);wrong['frames'][1]['bg_ids']=['BG_99']
    assert any('ID không tồn tại' in x for x in validate_content(json.dumps(wrong),rule,source))
    wrong=copy.deepcopy(valid);wrong['frames']=wrong['frames'][:2]
    assert any('LINE_ID' in x for x in validate_content(json.dumps(wrong),rule,source))


def test_qa_reviewer_contradictory_pass_cannot_grant_release(tmp_path):
    from studio.api import Generation
    from studio.engine import RunBlocked
    class Contradiction(FakeProvider):
        def generate(self,*,system,user,max_output_tokens):
            if 'JSON {"verdict"' in system:
                return Generation(json.dumps({'verdict':'PASS',
                                              'issues':['Nội dung này đã vi phạm quy tắc']}),100,50,0)
            return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
    raw=contract_template('__CURRENT_RULEPACK__')
    raw['file_dispositions']['workflow.json']={'role':'REFERENCE','reason':'Quy trình ngoài đã khai báo'}
    pack=tmp_path/'rules.zip'
    with zipfile.ZipFile(pack,'w') as z:
        z.writestr('guide.txt',RULE)
        z.writestr('workflow.json',json.dumps(raw,ensure_ascii=False))
    s=Studio(tmp_path/'project')
    try:
        s.import_pack(pack)
        s.import_source_text('SOURCE_STORY','Tác phẩm')
        s.import_source_text('SOURCE_AUDIO','001|Một câu.')
        with pytest.raises(RunBlocked,match='JSON QA hợp lệ'):
            OneClickService(s).run(Contradiction(),max_usd=10)
        assert not list(s.folder.rglob('PROJECT_TEST_ONLY*.zip'))
    finally:s.close()


def test_nonhuman_scale_lock_rejects_species_and_size_drift():
    validator=({'type':'nonhuman_scale_lock','value':'characters'},)
    good={'characters':[{'id':'CHAR_09','is_nonhuman':True,'species':'Crystal Fox',
                         'height_m':0.58,'states':[{'id':'HOSTILE','height_m':0.58},
                                                    {'id':'RECOVERING','height_m':0.58}]}]}
    assert not validate_content(json.dumps(good),validator,{})
    no_species=copy.deepcopy(good);no_species['characters'][0]['species']=''
    assert validate_content(json.dumps(no_species),validator,{})
    changed=copy.deepcopy(good);changed['characters'][0]['states'][1]['height_m']=1.2
    assert any('scale' in x for x in validate_content(json.dumps(changed),validator,{}))


def test_invalid_mapping_validator_configuration_returns_failure_not_exception():
    issues=validate_content('{"frames": []}',({'type':'mapping_integrity','source':'SOURCE_AUDIO'},),
                            {'SOURCE_AUDIO':'001|X'})
    assert issues and 'values' in issues[0]
