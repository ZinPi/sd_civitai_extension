"""One canonical, side-effect-free preflight for full and selected-stage runs.

A requested stage cannot silently assume that its predecessors were run.
With include_dependencies=False, all missing predecessors need a *matching,
QA-PASS* checkpoint; otherwise execution is blocked before any API request.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from .contract import Contract, ContractError, digest


def stage_fingerprint(contract: Contract, stage, inputs: dict[str,str], provider) -> str:
    return digest({'contract':contract.contract_sha, 'stage':stage.id, 'input_hashes':inputs,
                   'max_output_tokens':stage.max_output_tokens,
                   'provider_model':getattr(provider,'model','mock_or_local') if stage.adapter=='api_text' else '',
                   'provider_is_live':bool(getattr(provider,'is_live',False)),
                   'provider_effort':getattr(provider,'effort','') if stage.adapter=='api_text' else '',
                   'provider_id':getattr(provider,'provider_id','openai') if stage.adapter=='api_text' else ''})


def needed_stages(contract: Contract, selected: set[str] | None):
    """(requested, ancestor IDs) in contract's topological order."""
    valid={s.id for s in contract.stages}
    targets=set(valid if selected is None else selected)
    if not targets or targets-valid:
        raise ContractError('Hãy chọn ít nhất một công đoạn hợp lệ; ID không tồn tại: '+', '.join(sorted(targets-valid)))
    closure=set()
    def walk(sid):
        if sid in closure:return
        closure.add(sid)
        for name in contract.stage_by_id[sid].inputs:
            producer=contract.producers.get(name)
            if producer:walk(producer)
    for sid in targets:walk(sid)
    return targets, tuple(sid for sid in contract.order if sid in closure)

@dataclass
class StagePlan:
    id: str
    title: str
    action: str  # RUN, REUSE, EXTERNAL_REUSE, BLOCKED
    reason: str
    requested: bool

@dataclass
class ExecutionPlan:
    stages: tuple[StagePlan,...]
    requested: tuple[str,...]
    ordered: tuple[str,...]
    included: tuple[str,...]
    missing_sources: tuple[str,...]
    missing_upstream: tuple[str,...]
    all_outputs_requested: bool
    @property
    def ready(self):return not (self.missing_sources or self.missing_upstream)
    def report(self)->str:
        sections=[f'Đã chọn: {len(self.requested)} bước; cần xem xét: {len(self.ordered)} bước.',
                  'Tạo dữ liệu thiếu bằng các bước phụ thuộc: '+('Có' if set(self.ordered)==set(self.included) else 'Chỉ các bước đã chọn')]
        if self.missing_sources:sections.append('THIẾU TÀI LIỆU NGUỒN: '+', '.join(self.missing_sources))
        if self.missing_upstream:sections.append('THIẾU KẾT QUẢ BƯỚC TRƯỚC: '+', '.join(self.missing_upstream))
        if self.ready:sections.append('ĐỦ ĐIỀU KIỆN ĐẦU VÀO. QA vẫn được thực hiện trong khi chạy.')
        sections.extend(f'  {x.id} — {x.title}: {x.action}'+(' — '+x.reason if x.reason else '') for x in self.stages)
        return '\n'.join(sections)


def prepare_plan(contract:Contract, store, provider=None, *, selected:set[str]|None=None,
                 include_dependencies:bool=True)->ExecutionPlan:
    targets, closure=needed_stages(contract,selected)
    include=set(closure) if include_dependencies else set(targets)
    active=dict(store.source_hashes());
    missing_docs=set();missing_steps=set();actions=[]
    for sid in closure:
        st=contract.stage_by_id[sid]
        missing=[]
        for name in st.inputs:
            if name not in active and name not in contract.producers:
                missing_docs.add(name);missing.append(name)
        inputs={name:active.get(name) for name in st.inputs}
        can_lookup=not any(x is None for x in inputs.values())
        found=None
        if can_lookup:
            fp=stage_fingerprint(contract,st,inputs,provider)
            rec=store.find_artifact(st.output,fp)
            if rec and rec[2]=='PASS':found=rec
        if found:
            active[st.output]=found[1]
            actions.append(StagePlan(sid,st.title,'REUSE','Checkpoint QA PASS đúng nguồn và cấu hình',sid in targets))
        elif sid in include:
            if missing:
                actions.append(StagePlan(sid,st.title,'BLOCKED','Thiếu '+', '.join(missing),sid in targets))
            else:
                actions.append(StagePlan(sid,st.title,'RUN','Sẽ tạo hoặc kiểm tra khi các bước trước hoàn thành',sid in targets))
            active[st.output]=None  # Cannot know SHA before producing this stage.
        else:
            external=store.external_output(st.output)
            if external and all(inputs.values()) and not missing:
                actions.append(StagePlan(sid,st.title,'VERIFY_EXTERNAL',
                    'Tài liệu đã nhập, bắt buộc QA trước khi dùng',False))
                active[st.output]=external[0]
            else:
                missing_steps.add(sid)
                actions.append(StagePlan(sid,st.title,'BLOCKED',
                    'Thiếu checkpoint QA PASS hoặc tài liệu đầu ra được người dùng cung cấp',False))
                active[st.output]=None
    return ExecutionPlan(tuple(actions),tuple(s for s in contract.order if s in targets),closure,
                         tuple(s for s in closure if s in include),tuple(sorted(missing_docs)),tuple(sorted(missing_steps)),
                         set(targets)==set(contract.order))
