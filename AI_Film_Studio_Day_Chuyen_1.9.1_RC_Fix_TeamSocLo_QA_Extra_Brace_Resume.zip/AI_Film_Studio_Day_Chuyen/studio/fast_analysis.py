"""Conservative, general-purpose classifier for human configuration requests.

Only *explicit* human decisions are allowed to turn into UI questions. Requests
addressed to the AI (choose a scene, compose a prompt, style a character) are
not user options. Citations of previously supplied/approved files are not
requests for new input. The original source remains the authority.
"""
from __future__ import annotations
import re

_EXAMPLE_START = re.compile(r"^\s*(?:[-*]\s*)?(?:ví\s+dụ|vd\s*[:.]|minh\s+họa|for\s+example|e\.g\.|example\s*[:.]|giả\s+sử)\b", re.I)

# Deliberately not a domain-specific or file-hash whitelist.
_HUMAN = r'(?:người\s+dùng|người\s+sử\s+dụng|khách\s+hàng|user|operator)'
_ACTION = r'(?:chọn|lựa\s+chọn|nhập|điền|quyết\s+định|xác\s+nhận|cung\s+cấp|choose|select|enter|provide|confirm)'
HUMAN_DIRECTIVE = re.compile(
    rf'\b{_HUMAN}\b\s+(?:(?:phải|cần|sẽ\s+phải|được\s+yêu\s+cầu|hãy|tự|tự\s+mình|được\s+quyền)\s+)*{_ACTION}\b'
    rf'|\b(?:yêu\s+cầu|để|cho)\s+{_HUMAN}\s+(?:(?:tự|tự\s+mình|phải|cần)\s+)*{_ACTION}\b', re.I
)
EXPLICIT_YOU = re.compile(
    r'^\s*(?:[-*\d.)\s]*)?(?:vui\s+lòng|bạn\s+(?:hãy|phải|cần)|you\s+must|please)\s+'
    r'(?:chọn|lựa\s+chọn|nhập|điền|quyết\s+định|choose|select|enter)\b', re.I
)
# Standalone interactive configuration field with closed choices.
CONFIG_CHOICE = re.compile(
    r'^\s*(?:[-*\d.)\s]*)?(?:chọn|select|choose|nhập|điền)\s+'
    r'(?:phong\s+cách|ngôn\s+ngữ|số\s+(?:câu|cảnh|lượng|trang|dòng|tập|prompt)|'
    r'định\s+dạng|giọng\s+kể|tỷ\s+lệ|tỉ\s+lệ|độ\s+dài|mode|style|language|format|number)\b'
    r'[^\n]{0,160}(?:\b(?:hoặc|hay|or)\b|\?|:)', re.I
)
NUMERIC_OPTIONS = re.compile(
    r'^\s*(?:[-*\d.)\s]*)?(?:chọn|choose|select|nhập)\s+\d+\s+(?:hoặc|hay|or)\s+\d+\b', re.I
)
NUMERIC_SETTING = re.compile(
    r'^\s*(?:số\s+(?:cảnh|câu|trang|dòng|tập|phút|prompt|ký\s+tự|từ))'
    r'\s+(?:phải\s+(?:là|chia\s+hết)|bắt\s+buộc)\s+', re.I
)
NO_QUESTION = re.compile(
    r'\b(?:không\s+(?:cần|được|yêu\s+cầu)\s+(?:người\s+dùng|bạn)\s+(?:chọn|nhập)|'
    r'(?:AI|GPT|Claude|model|hệ\s+thống|công\s+cụ)\s+(?:tự\s+)?(?:chọn|quyết\s+định))\b', re.I
)
PAST_OR_SOURCE = re.compile(
    rf'\b{_HUMAN}\b\s+(?:đã|được)\s+(?:chọn|nhập|điền|xác\s+nhận|cung\s+cấp)\b'
    rf'|\b(?:do|từ)\s+{_HUMAN}\s+(?:cung\s+cấp|xác\s+nhận)\b'
    rf'|\b(?:đã\s+được|được)\s+{_HUMAN}\s+(?:chọn|nhập|điền|xác\s+nhận|cung\s+cấp)\b', re.I
)
AI_INSTRUCTION = re.compile(
    r'^\s*(?:[-*\d.)\s]*)?(?:AI|GPT|Claude|model|công\s+cụ|hệ\s+thống)\s+'
    r'(?:phải|cần|tự|sẽ)?\s*(?:chọn|xác\s+định|thiết\s+kế|tạo)\b', re.I
)


# Negated *descriptions of the question policy* are not requests for a person
# to choose anything. Keep the remaining clauses visible, so a real human
# directive later in the same line is still detected.
NEGATED_META_USER_CHOICE = re.compile(
    r'\b(?:'
    r'không\s+phải\s+(?:một\s+)?(?:câu\s+hỏi|tùy\s+chọn|yêu\s+cầu)'
    r'[^.;\n]{0,120}?\bngười\s+dùng\s+(?:chọn|nhập|điền|quyết\s+định)'
    r'|không\s+(?:dùng|lấy)\s+[^.;\n]{0,200}?'
    r'\b(?:tạo|đặt)\s+câu\s+hỏi\s+người\s+dùng\s+(?:chọn|nhập|điền)'
    r')\b', re.I
)


def is_example_context(lines: list[str], line_number: int) -> bool:
    """Avoid turning explanatory examples into mandatory human input fields.

    Conservatively excludes explicitly labelled examples on the same line and
    the immediately following contiguous example block (until a blank line or
    another nonexample section). It does NOT suppress ordinary actual rules.
    """
    if not 1 <= line_number <= len(lines):
        return False
    row = lines[line_number - 1].strip()
    if _EXAMPLE_START.search(row):
        return True
    for j in range(line_number - 2, max(-1, line_number - 5), -1):
        previous = lines[j].strip()
        if not previous or re.match(r'^(?:#{1,6}\s+|={3,}|-{3,}|\d+[.)]\s+)', previous):
            break
        if _EXAMPLE_START.search(previous):
            return True
    return False


def explicit_human_requirements(files: dict[str,str], filename: str, permitted_lines: set[int] | None = None) -> dict[int,str]:
    """Cheap, source-grounded coverage audit independent of an AI response."""
    lines = files[filename].splitlines()
    return {n: row for n, row in enumerate(lines, 1)
            if (permitted_lines is None or n in permitted_lines)
            and is_human_choice_line(row)
            and not is_example_context(lines, n)}


def is_human_choice_line(line: str) -> bool:
    line = line.strip()
    if not line or _EXAMPLE_START.search(line):
        return False
    line = NEGATED_META_USER_CHOICE.sub('', line).strip()
    if not line:
        return False
    # Separate an explicit human instruction from an additional AI instruction
    # on the SAME source line. AI self-choice never cancels a human directive.
    explicitly_human = bool(HUMAN_DIRECTIVE.search(line) or EXPLICIT_YOU.search(line))
    no_human_request = bool(re.search(
        r'\bkhông\s+(?:cần|được|yêu\s+cầu)\s+(?:người\s+dùng|bạn)\s+(?:chọn|nhập)\b',
        line, re.I))
    if no_human_request:
        return False
    if AI_INSTRUCTION.search(line) and not explicitly_human:
        return False
    if NO_QUESTION.search(line) and not explicitly_human:
        return False
    if PAST_OR_SOURCE.search(line) and not EXPLICIT_YOU.search(line):
        return False
    # 'người dùng cung cấp' by itself describes an existing SOURCE, not a
    # new form field. A requirement to PROVIDE needs a modal/directive.
    supplied_source = re.search(rf'\b{_HUMAN}\s+cung\s+cấp\b', line, re.I)
    if supplied_source and not re.search(r'\b(?:phải|cần|hãy|bắt\s+buộc)\s+cung\s+cấp\b', line, re.I):
        if not EXPLICIT_YOU.search(line):
            return False
    return bool(explicitly_human or CONFIG_CHOICE.search(line)
                or NUMERIC_OPTIONS.search(line))


def is_human_question(question: dict, files: dict[str, str]) -> bool:
    """Verify quoted evidence before any model suggestion reaches the UI."""
    try:
        name = question['source_file']
        line = question['source_line']
        if type(line) is not int:
            return False
        origin = files[name].splitlines()
        quote = question['source_quote']
        if not 1 <= line <= len(origin) or not isinstance(quote, str):
            return False
        if len(quote.strip()) < 3 or quote not in origin[line-1]:
            return False
        return is_human_choice_line(origin[line-1]) and not is_example_context(origin, line)
    except (KeyError, IndexError, TypeError):
        return False
