"""Acceptance tests over an UNFAMILIAR rule pack, without network or Windows.
Mock provider is never counted as a real API / semantic accuracy pass.
"""
from __future__ import annotations
import json, tempfile, unittest, zipfile
from pathlib import Path
from studio.engine import Studio,RunBlocked
from studio.contract import ContractError
from studio.api import Generation
from studio.qa import audio_lines
from studio.release import check_release_content

STORY='An bước vào xưởng. Trong phòng có bàn gỗ. An nhìn máy phát sáng.'
AUDIO='001|An bước vào xưởng.\n002|Trong phòng có bàn gỗ.\n003|An nhìn máy phát sáng.\n'
RULES='''Bắt buộc xuất danh sách nhân vật kèm bằng chứng AUDIO.
Bắt buộc xuất danh sách bối cảnh kèm bằng chứng AUDIO.
Bắt buộc tạo prompt cho mỗi nhân vật theo khóa thiết kế.
Bắt buộc tạo prompt bối cảnh theo nguồn.
Bắt buộc mỗi dòng AUDIO có đúng một prompt phân cảnh.
Bắt buộc file kế thừa gồm K01 K02 K03 K04 K05 K06 và QA.
'''

def build_pack(dest:Path):
    fields=['character_index','background_index','character_prompts','background_prompts','scene_prompts','handoff']
    outs=['CHAR_MASTER','BG_MASTER','CHAR_PROMPTS','BG_PROMPTS','SCENE_PROMPTS','HANDOFF']
    stages=[]
    instructions=[
      'Từ STORY và AUDIO, trả về DUY NHẤT JSON object có characters là một mảng chứa nhân vật được nhắc trực tiếp. '
      'Mỗi item có id CHAR_01, name, evidence_line_ids là ID thực sự trong AUDIO; không bịa ngoại hình.',
      'Từ STORY và AUDIO, trả về DUY NHẤT JSON object có backgrounds là mảng bối cảnh có thật. '
      'Mỗi item gồm id BG_01, description ngắn, evidence_line_ids; không bịa thiết kế.',
      'Tạo CHAR_PROMPT chi tiết hợp lý với canon nhưng không bịa thuộc tính không có trong nguồn. '
      'Trả một dòng bắt đầu CHAR_01| cho nhân vật trong CHAR_MASTER; giữ định danh theo ledger.',
      'Tạo BG_PROMPT từ BG_MASTER; trả một dòng bắt đầu BG_01|. Không tự thêm kiến trúc chưa có căn cứ.',
      'Tạo đúng một prompt cho ĐÚNG dòng AUDIO đang được cung cấp (prev/current/next). '
      'KHÔNG ghi ID dòng ở đầu; hệ thống tự gắn ID. Có thể dùng CHAR_01.BG_01| và mô tả hành động của chính dòng.',
      'Tạo PROJECT_HANDOFF 6 mục, đúng tiêu đề K01:, K02:, K03:, K04:, K05:, K06:, '
      'chỉ ghi HANDOFF_STATUS: FULL khi dữ liệu đã đủ; không bịa sự kiện, thuật ngữ, trang phục.'
    ]
    def add(i, inputs, typ, check, scope='whole'):
        stage={'id':'step_'+str(i+1),'title':fields[i], 'adapter':'api_text',
               'inputs':inputs,'output':outs[i],'rules':['instructions_unseen.txt'],
               'instructions':'PHASE='+fields[i]+'\n'+instructions[i], 'validators':check,
               'source_evidence':['instructions_unseen.txt:'+str(i+1)],
               'semantic_qa':True,'output_type':typ,'scope':scope,
               'max_output_tokens':2000,'parallel':False}
        if scope=='each_audio_line':stage.update(chunk_source='SOURCE_AUDIO',chunk_lines=1)
        stages.append(stage)
    schemachar={'type':'object','required':['characters'],'properties':{'characters':{'type':'array','minItems':1,'items':{'type':'object','required':['id','name','evidence_line_ids'],'properties':{'id':{'type':'string','pattern':'^CHAR_[0-9]+$'},'name':{'type':'string','minLength':1},'evidence_line_ids':{'type':'array','minItems':1}}}}}}
    schemabg={'type':'object','required':['backgrounds'],'properties':{'backgrounds':{'type':'array','minItems':1,'items':{'type':'object','required':['id','description','evidence_line_ids'],'properties':{'id':{'type':'string','pattern':'^BG_[0-9]+$'},'description':{'type':'string','minLength':1},'evidence_line_ids':{'type':'array','minItems':1}}}}}}
    add(0,['SOURCE_STORY','SOURCE_AUDIO'],'json',[{'type':'json_schema','schema':schemachar},{'type':'evidence_line_refs','source':'SOURCE_AUDIO'}])
    add(1,['SOURCE_STORY','SOURCE_AUDIO'],'json',[{'type':'json_schema','schema':schemabg},{'type':'evidence_line_refs','source':'SOURCE_AUDIO'}])
    add(2,['SOURCE_STORY','SOURCE_AUDIO','CHAR_MASTER'],'text',[{'type':'required_sections','values':['CHAR_01|']},{'type':'entity_refs','source':'CHAR_MASTER','value':'CHAR'}])
    add(3,['SOURCE_STORY','SOURCE_AUDIO','BG_MASTER'],'text',[{'type':'required_sections','values':['BG_01|']},{'type':'entity_refs','source':'BG_MASTER','value':'BG'}])
    add(4,['SOURCE_STORY','SOURCE_AUDIO','CHAR_MASTER','BG_MASTER'],'lines',[{'type':'line_id_coverage','source':'SOURCE_AUDIO'},{'type':'unique_line_ids','source':'SOURCE_AUDIO'},{'type':'entity_refs','source':'CHAR_MASTER','value':'CHAR'},{'type':'entity_refs','source':'BG_MASTER','value':'BG'}],'each_audio_line')
    add(5,['SOURCE_STORY','SOURCE_AUDIO','CHAR_MASTER','BG_MASTER','SCENE_PROMPTS'],'text',[{'type':'required_sections','values':['K01:','K02:','K03:','K04:','K05:','K06:','HANDOFF_STATUS: FULL']}])
    contract={'schema_version':1,'rulepack_sha256':'__CURRENT_RULEPACK__',
              'required_inputs':['SOURCE_STORY','SOURCE_AUDIO'],'required_outputs':outs,
              'deliverables':dict(zip(fields,outs)),
              'export_names':{'CHAR_MASTER':'01_CHAR_MASTER_FINAL.txt','BG_MASTER':'02_BG_MASTER_FINAL.txt','CHAR_PROMPTS':'03_CHAR_PROMPT_FINAL.txt','BG_PROMPTS':'04_BG_PROMPT_FINAL.txt','SCENE_PROMPTS':'05_SCENE_PROMPT_FINAL.txt','HANDOFF':'06_PROJECT_HANDOFF_FINAL.txt'},
              'file_dispositions':{'instructions_unseen.txt':{'role':'PRODUCTION','reason':'Quy trình sản xuất tự định nghĩa'},'something.custom.workflow.json':{'role':'REFERENCE','reason':'Manifest cấu trúc không là lệnh diễn giải tự do'}},
              'stages':stages,'release_checks':{},
              'clause_coverage':[{'file':'instructions_unseen.txt','start':i+1,'end':i+1,'decision':'ENFORCE','stage_ids':[stages[i]['id']],'reason':'Ánh xạ công đoạn cụ thể'} for i in range(6)]}
    for i,out in enumerate(outs):
        contract['release_checks'][out]={'source_inputs':['SOURCE_STORY','SOURCE_AUDIO'],'validators':stages[i]['validators']}
    with zipfile.ZipFile(dest,'w') as z:
        z.writestr('instructions_unseen.txt',RULES)
        z.writestr('something.custom.workflow.json',json.dumps(contract,ensure_ascii=False))
    return contract

class MockProvider:
    is_live=False
    model='OFFLINE_EVIDENCE_ONLY'
    effort='none'
    def __init__(self,fail_mode=None):self.calls=[];self.fail_mode=fail_mode;self._bad_once=False
    def generate(self,*,system,user,max_output_tokens):
        self.calls.append((system,user))
        if 'Bạn là người kiểm tra ĐỘC LẬP' in system:
            fail='BỊA ĐẶT CANON' in user
            return Generation(json.dumps({'verdict':'FAIL' if fail else 'PASS','issues':['Thêm sự kiện trái nguồn'] if fail else []}),90,60,0)
        phase=system.split('PHASE=')[1].split('\n',1)[0] if 'PHASE=' in system else 'UNKNOWN'
        outs={
          'character_index':json.dumps({'characters':[{'id':'CHAR_01','name':'An','evidence_line_ids':['001','003']}]},ensure_ascii=False),
          'background_index':json.dumps({'backgrounds':[{'id':'BG_01','description':'Xưởng có bàn gỗ','evidence_line_ids':['001','002']}]},ensure_ascii=False),
          'character_prompts':'CHAR_01|An giữ đúng thiết kế, xuất hiện ở xưởng.',
          'background_prompts':'BG_01|Xưởng có một bàn gỗ.',
          'scene_prompts':'CHAR_01.BG_01|Cảnh đúng nguồn; nhân vật An trong xưởng.',
          'handoff':'K01: dự án thử nghiệm\nK02: An trong xưởng\nK03: CHAR_01\nK04: BG_01\nK05: thuật ngữ An\nK06: kiểm thử QA\nHANDOFF_STATUS: FULL'}
        t=outs[phase]
        if phase=='character_prompts' and self.fail_mode=='repair' and not self._bad_once:
            self._bad_once=True;t='SAI_DINH_DANG'
        if phase=='scene_prompts' and self.fail_mode=='canon':t+=' BỊA ĐẶT CANON'
        return Generation(t,150,100,0)

class Acceptance(unittest.TestCase):
    def setUp(self):
        self.td=tempfile.TemporaryDirectory();self.root=Path(self.td.name)
        self.zip=self.root/'bo_quy_tac_chua_tung_biet.zip';build_pack(self.zip)
        self.studio=Studio(self.root/'du_an')
        self.studio.import_pack(self.zip)
        self.studio.import_source_text('SOURCE_STORY',STORY)
        self.studio.import_source_text('SOURCE_AUDIO',AUDIO)
        draft=self.studio.propose_contract()
        self.studio.approve(draft)
    def tearDown(self):
        self.studio.close();self.td.cleanup()
    def test_01_compile_unfamiliar_rules_and_full_delivery(self):
        c=self.studio.active_contract()
        self.assertEqual(len(c.stages),6)
        fake=MockProvider(); path=self.studio.run(fake,max_usd=50)
        self.assertIn('TEST_ONLY',path.name)
        with zipfile.ZipFile(path) as z:
            names=set(z.namelist())
            self.assertTrue(set(self.studio.active_contract().raw['export_names'].values()).issubset(names))
            self.assertEqual(json.loads(z.read('PROJECT_MANIFEST.json'))['status'],'TEST_ONLY')
            self.assertEqual(len(z.read('05_SCENE_PROMPT_FINAL.txt').decode().splitlines()),3)
            self.assertIn('K06:',z.read('06_PROJECT_HANDOFF_FINAL.txt').decode())
        count=len(fake.calls)
        again=self.studio.run(fake)
        self.assertEqual(len(fake.calls),count,'Checkpoint must avoid rebilling on unchanged input')
    def test_02_auto_repair_structural_without_upstream_mutation(self):
        fake=MockProvider('repair');p=self.studio.run(fake,max_usd=30)
        self.assertTrue(p.exists())
        self.assertTrue(any('LỖI CỤ THỂ' in user for _,user in fake.calls))
        self.assertEqual(self.studio.store.source_text('SOURCE_STORY'),STORY)
    def test_03_block_semantic_fabrication(self):
        fake=MockProvider('canon')
        with self.assertRaisesRegex(RunBlocked,'QA ngữ nghĩa FAIL'):
            self.studio.run(fake)
        self.assertFalse(list((self.studio.folder/'FINAL').glob('*.zip')))
    def test_04_block_unknown_entity_reference(self):
        c=self.studio.active_contract()
        err=[]
        from studio.qa import validate_content
        err=validate_content('CHAR_09|Không có trong nguồn',({'type':'entity_refs','source':'CHAR_MASTER','value':'CHAR'},),{'CHAR_MASTER':json.dumps({'characters':[{'id':'CHAR_01'}]})})
        self.assertTrue(err)
    def test_05_block_false_handoff(self):
        with self.assertRaises(ContractError):
            check_release_content('K01: a\nHANDOFF_STATUS: PARTIAL',[{'type':'required_sections','values':['K01:','K02:']}],{'SOURCE_STORY':STORY},'HANDOFF')
    def test_06_no_approve_unknown_contract(self):
        c=self.studio.active_contract().raw
        c['stages'][0]['output']='NOT_DEFINED'
        test=self.root/'invalid.json';test.write_text(json.dumps(c,ensure_ascii=False),encoding='utf8')
        with self.assertRaises(ContractError):self.studio.approve(test)
    def test_07_wrong_released_revision_after_source_changes(self):
        f=MockProvider();a=self.studio.run(f)
        self.studio.import_source_text('SOURCE_STORY',STORY+' Thêm một câu.')
        b=self.studio.run(f)
        self.studio.import_source_text('SOURCE_STORY',STORY)
        calls=len(f.calls)
        c=self.studio.run(f)
        self.assertEqual(len(f.calls),calls)
        with zipfile.ZipFile(c) as z:self.assertEqual(json.loads(z.read('PROJECT_MANIFEST.json'))['source_hashes']['SOURCE_STORY'],self.studio.store.source_hashes()['SOURCE_STORY'])
    def test_08_unknown_natural_language_requires_model_no_silent_guess(self):
        from studio.compiler import draft_contract
        with self.assertRaises(ContractError):draft_contract({'unfamiliar.rst':'Làm việc theo cách khác.'},'hash',None)

if __name__=='__main__':unittest.main()

class AdditionalLogic(unittest.TestCase):
    def test_09_natural_language_compiler_wiring_unfamiliar_pack(self):
        """Verifies LLM adapter and draft validation; NOT semantic compiler quality."""
        from studio.compiler import draft_contract
        from studio.contract import digest
        with tempfile.TemporaryDirectory() as p:
            path=Path(p)/'new.zip';example=build_pack(path)
            files={'instructions_unseen.txt':RULES}
            example['file_dispositions'].pop('something.custom.workflow.json')
            rule_sha='2'*64;example['rulepack_sha256']=rule_sha
            class CompilerProvider:
                def generate(self,**kwargs):
                    assert 'Bắt buộc' in kwargs['user']
                    return Generation(json.dumps(example,ensure_ascii=False),120,2000,0)
            draft=draft_contract(files,rule_sha,CompilerProvider())
            self.assertEqual(len(draft['stages']),6)
    def test_10_contradictory_required_forbidden_is_blocked(self):
        from studio.contract import validate_contract,ContractError
        from studio.compiler import draft_contract
        from studio.rulepack import inspect_zip
        from studio.contract import digest
        with tempfile.TemporaryDirectory() as p:
            path=Path(p)/'new.zip';build_pack(path)
            files,raw=inspect_zip(path)
            c=draft_contract(files,digest(raw))
            c['stages'][0]['validators'] += [{'type':'required_phrases','values':['THƯỚC']},{'type':'forbidden_phrases','values':['THƯỚC']}]
            with self.assertRaisesRegex(ContractError,'vừa bắt buộc vừa cấm'):
                validate_contract(c,files,digest(raw))
