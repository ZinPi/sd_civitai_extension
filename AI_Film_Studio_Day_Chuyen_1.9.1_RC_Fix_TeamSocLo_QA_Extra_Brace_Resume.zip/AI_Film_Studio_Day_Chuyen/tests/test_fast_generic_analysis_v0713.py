"""Generic fast analysis, source evidence and safe incremental reuse (offline)."""
# No external API used by this test.
import json
import threading
import time
from pathlib import Path

import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.fast_analysis import is_human_choice_line
from studio.rule_options import (analysis_plan, analyze_rules, pending_analysis_chunks,
                                 verify_report_constraints, validate_answers)


class GenericModel:
    def __init__(self, delayed=False, bogus=True):
        self.calls = 0
        self.active = 0
        self.peak = 0
        self.lock = threading.Lock()
        self.delayed = delayed
        self.bogus = bogus

    def generate(self, *, system, user, max_output_tokens):
        with self.lock:
            self.calls += 1
            self.active += 1
            self.peak = max(self.peak, self.active)
        try:
            if self.delayed:
                time.sleep(.03)
            fn = user.split('TÊN FILE QUY TẮC: ')[1].splitlines()[0]
            rows = user.split('DÒNG NGUYÊN BẢN CÓ ĐÁNH SỐ:\n', 1)[1]
            questions = []
            for line in rows.splitlines():
                if line.startswith('L') and ': ' in line:
                    line_no, value = line.split(': ', 1)
                    if 'Người dùng phải chọn phong cách: Mềm mại hoặc Mạnh mẽ.' in value:
                        questions.append({
                            'question': 'Chọn phong cách?', 'kind': 'single',
                            'required': True, 'choices': ['Mềm mại', 'Mạnh mẽ'],
                            'source_file': fn, 'source_line': int(line_no[1:]),
                            'source_quote': 'Người dùng phải chọn phong cách: Mềm mại hoặc Mạnh mẽ.'})
                    elif self.bogus and 'AI tự chọn' in value:
                        for i in range(120):
                            questions.append({
                                'question': 'AI phải chọn cho tôi ' + str(i),
                                'kind': 'single', 'required': True,
                                'choices': ['Sai', 'Không có'],
                                'source_file': fn, 'source_line': int(line_no[1:]),
                                'source_quote': value})
            payload = {'summary': fn, 'steps': ['Tạo thành phẩm theo quy tắc'],
                       'deliverables': ['Văn bản'], 'questions': questions,
                       'assertions': [], 'warnings': [], 'blockers': []}
            return Generation(json.dumps(payload, ensure_ascii=False))
        finally:
            with self.lock:
                self.active -= 1


def test_generic_reference_is_not_a_question():
    for row in (
        'AI tự chọn mẫu tóc phù hợp.',
        'Hướng tóc phía sau được phép phải ưu tiên một trong các logic sau:',
        'Ảnh BG reference đã được người dùng xác nhận là nguồn chuẩn.',
        'Reference image đã được user xác nhận phải được giữ continuity.',
        'Người dùng cung cấp tác phẩm nguồn để hệ thống xử lý.',
        'Khi nguồn có 3 loại cảnh, AI tự quyết định loại phù hợp.',
    ):
        assert not is_human_choice_line(row), row
    for row in (
        'Người dùng phải chọn phong cách: Mềm mại hoặc Mạnh mẽ.',
        'Chọn số cảnh: 3 hoặc 5.',
        'Bạn phải nhập ngôn ngữ mong muốn trước sản xuất.',
    ):
        assert is_human_choice_line(row), row


def test_many_hallucinated_questions_removed_for_any_file_name():
    files = {f'rule_{i}_unrelated.md': 'AI tự chọn nhân vật phù hợp.\n' for i in range(12)}
    model = GenericModel()
    report = analyze_rules(files, model)
    assert model.calls == 12
    assert report['questions'] == []
    assert report['segment_count'] == 12
    verify_report_constraints(report, files)


def test_other_rulepack_real_question_survives_false_ones():
    files = {'RULE_OTHER.md': 'AI tự chọn góc quay.\nNgười dùng phải chọn phong cách: Mềm mại hoặc Mạnh mẽ.'}
    report = analyze_rules(files, GenericModel())
    assert len(report['questions']) == 1
    assert len(report['questions'][0]['choices']) == 2
    with pytest.raises(ContractError, match='chưa trả lời'):
        validate_answers(report, {})
    assert validate_answers(report, {'q001': 'Mềm mại'}) == {'q001': 'Mềm mại'}


def test_only_modified_files_need_rescanning_and_changing_file_order_is_safe(tmp_path):
    files = {'A.txt': 'AI tự chọn nội dung.\n' * 500,
             'B.txt': 'Hướng dẫn thứ hai.\n' * 400,
             'C.txt': 'Hướng dẫn thứ ba.\n' * 350}
    cache = tmp_path / 'cache'
    first = GenericModel()
    initial = analyze_rules(files, first, checkpoint_dir=cache, provider_identity='openai:fictional')
    assert first.calls == analysis_plan(files)['segments']
    # Swap input order: results should still be grounded in exact file/chunk.
    reordered = {'C.txt': files['C.txt'], 'A.txt': files['A.txt'], 'B.txt': files['B.txt']}
    assert pending_analysis_chunks(reordered, None, 'openai:fictional', shared_cache_dir=cache) == 0
    again = GenericModel()
    report = analyze_rules(reordered, again, shared_cache_dir=cache,
                           provider_identity='openai:fictional')
    assert again.calls == 0
    assert report['cache_hits'] == initial['segment_count']
    updated = dict(reordered, **{'B.txt': files['B.txt'].replace('thứ hai', 'mới', 1)})
    remaining = pending_analysis_chunks(updated, None, 'openai:fictional', shared_cache_dir=cache)
    assert remaining == 1
    model = GenericModel()
    updated_report = analyze_rules(updated, model, shared_cache_dir=cache,
                                   provider_identity='openai:fictional')
    assert model.calls == 1
    assert updated_report['cache_hits'] == updated_report['segment_count'] - 1


def test_concurrency_bounded_by_three_and_complete(tmp_path):
    files = {'big.txt': 'AI tự chọn những chi tiết phù hợp.\n' * 6000}
    model = GenericModel(delayed=True, bogus=False)
    result = analyze_rules(files, model, checkpoint_dir=tmp_path,
                           provider_identity='test:concurrent', max_workers=3)
    assert result['segment_count'] > 3
    assert model.calls == result['segment_count']
    assert 2 <= model.peak <= 3
    # Results are fully cached even across another run.
    another = GenericModel()
    result2 = analyze_rules(files, another, checkpoint_dir=tmp_path,
                            provider_identity='test:concurrent', max_workers=3)
    assert another.calls == 0
    assert result2['cache_hits'] == result['segment_count']


def test_original_eight_txt_complete_offline_if_attached():
    root = Path('/mnt/data')
    names = ['B1.txt','B2.txt','B3.txt','B4.txt','B5.txt','B6.txt',
             'B7.txt','QUY_TRINH_HUONG_DAN.txt']
    if not all((root/name).is_file() for name in names):
        pytest.skip('Production rules are not distributed in the installer.')
    files = {name: (root/name).read_text(encoding='utf8') for name in names}
    model = GenericModel()
    report = analyze_rules(files, model, max_workers=3)
    assert report['segment_count'] == analysis_plan(files)['segments']
    assert model.calls == report['segment_count']
    assert report['questions'] == []
    assert report['analyzed_characters'] > 400_000


def test_mixed_ai_and_user_instructions_on_the_same_line():
    # A genuine human decision must not disappear just because the same line
    # also delegates a DIFFERENT creative choice to the AI.
    assert is_human_choice_line('Người dùng phải chọn số cảnh: 3 hoặc 5. Sau đó AI tự chọn bố cục.')
    assert is_human_choice_line('AI tự chọn bố cục; người dùng phải nhập ngôn ngữ.')
    assert is_human_choice_line('Người dùng phải lựa chọn giữa A hoặc B.')
    assert is_human_choice_line('Bạn hãy quyết định ngôn ngữ trước khi sản xuất.')
    assert not is_human_choice_line('Không cần người dùng chọn: AI tự chọn.')
    assert not is_human_choice_line('Ảnh BG reference đã được người dùng xác nhận.')


def test_b4_visual_direction_list_not_a_human_question():
    # This was the actual source line behind the screenshot failure.
    text = 'Hướng tóc phía sau được phép phải ưu tiên một trong các logic sau:'
    assert not is_human_choice_line(text)


def test_parallel_scan_honors_bounded_session_request_budget(tmp_path):
    from studio.one_click import BudgetedProvider
    from studio.one_click import RunBlocked

    class Provider(GenericModel):
        provider_id = 'openai'
        model = 'test-model'
        effort = 'default'
        is_live = True

    files = {f'file{i}.txt': 'AI tự chọn phong cách sáng tạo.\n' for i in range(5)}
    base = Provider(delayed=True, bogus=False)
    guarded = BudgetedProvider(base, tmp_path, max_calls=2, max_usd=100)
    with pytest.raises(RunBlocked):
        analyze_rules(files, guarded, checkpoint_dir=tmp_path,
                      provider_identity='openai:test-model', max_workers=3)
    assert base.calls == 2
    assert guarded.calls == 2
    assert len((tmp_path / 'api_request_ledger.jsonl').read_text(encoding='utf8').splitlines()) == 2
