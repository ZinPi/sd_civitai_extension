"""V6: explicit versioned rule contracts. No media-specific branches.

A source ruleset is NOT a runnable contract until rules have been reviewed.
Reject unknown validators/adapters rather than quietly treating them as pass.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import hashlib, json, re

ADAPTERS = {'api_text', 'join', 'template'}
VALIDATORS = {'nonempty', 'line_id_coverage', 'unique_line_ids', 'prefix', 'required_phrases', 'forbidden_phrases', 'json_keys', 'required_sections', 'source_quote', 'json_schema', 'entity_refs', 'evidence_line_refs', 'entity_integrity', 'temporal_order', 'mapping_integrity', 'nonhuman_scale_lock'}
VALID_TYPES = {'text', 'json', 'lines'}
ALLOWED_TOP = {'schema_version','rulepack_sha256','required_inputs','required_outputs',
               'export_names','deliverables','stages','file_dispositions','description','release_checks','clause_coverage','execution_scope'}
ALLOWED_STAGE = {'id','title','adapter','inputs','output','rules','instructions','validators',
                 'scope','output_type','max_output_tokens','parallel','source_evidence','semantic_qa',
                 'chunk_source','chunk_lines'}
ALLOWED_VALIDATOR = {'type','source','value','values','schema'}
IDENTITY = re.compile(r'^[a-zA-Z][a-zA-Z0-9_\-]{0,79}$')

class ContractError(ValueError):
    pass

def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))

def digest(value: Any) -> str:
    if not isinstance(value, (bytes, str)):
        value = canonical_json(value)
    return hashlib.sha256(value if isinstance(value, bytes) else value.encode('utf-8')).hexdigest()

@dataclass(frozen=True)
class Stage:
    id: str
    title: str
    adapter: str
    inputs: tuple[str, ...]
    output: str
    rules: tuple[str, ...]
    instructions: str = ''
    validators: tuple[dict, ...] = field(default_factory=tuple)
    scope: str = 'whole'
    output_type: str = 'text'
    max_output_tokens: int = 8000
    parallel: bool = False
    source_evidence: tuple[str, ...] = field(default_factory=tuple)
    semantic_qa: bool = False
    chunk_source: str = ''
    chunk_lines: int = 80

@dataclass(frozen=True)
class Contract:
    raw: dict
    stages: tuple[Stage, ...]
    outputs: tuple[str, ...]
    required_inputs: tuple[str, ...]
    rules_sha: str
    contract_sha: str
    order: tuple[str, ...]

    @property
    def stage_by_id(self):
        return {x.id:x for x in self.stages}

    @property
    def producers(self):
        return {x.output:x.id for x in self.stages}


def validate_contract(raw: dict, rule_files: dict[str, str], rule_sha: str, *, approved_hash: str | None = None) -> Contract:
    if not isinstance(raw, dict) or raw.get('schema_version') != 1:
        raise ContractError('Hợp đồng quy tắc không có schema_version=1 hợp lệ')
    if raw.get('rulepack_sha256') != rule_sha:
        raise ContractError('Hợp đồng quy tắc không khớp SHA-256 của bộ quy tắc đã nhập')
    actual_sha = digest(raw)
    if approved_hash is not None and approved_hash != actual_sha:
        raise ContractError('Hợp đồng đã bị thay đổi sau khi phê duyệt')
    if raw.get('execution_scope','FULL') not in ('FULL','PARTIAL'):
        raise ContractError('execution_scope chỉ nhận FULL hoặc PARTIAL')
    unknown=set(raw)-ALLOWED_TOP
    if unknown:raise ContractError('Trường hợp đồng chưa được hỗ trợ: '+', '.join(sorted(unknown)))
    dispositions=raw.get('file_dispositions')
    if not isinstance(dispositions,dict) or set(dispositions)!=set(rule_files):
        raise ContractError('Phải phân loại ĐỦ mọi file trong ZIP (file_dispositions)')
    for fn,entry in dispositions.items():
        if not isinstance(entry,dict) or set(entry)!={'role','reason'}:
            raise ContractError('Thiếu lý do phân loại file quy tắc: '+fn)
        if entry['role'] not in ('PRODUCTION','CHAT_ONLY','REFERENCE','SUPERSEDED') or not str(entry['reason']).strip():
            raise ContractError('File quy tắc chưa được phân loại hoặc chưa hỗ trợ: '+fn)
    required = raw.get('required_inputs', [])
    outputs = raw.get('required_outputs', [])
    stages_raw = raw.get('stages', [])
    if not isinstance(required,list) or not isinstance(outputs,list) or not isinstance(stages_raw,list) or not stages_raw:
        raise ContractError('Thiếu danh sách đầu vào, đầu ra hoặc công đoạn')
    for name in [*required,*outputs]:
        if not isinstance(name,str) or not IDENTITY.fullmatch(name):
            raise ContractError('Mã dữ liệu không hợp lệ: '+str(name))
    if len(set(required)) != len(required) or len(set(outputs)) != len(outputs):
        raise ContractError('Trùng tên dữ liệu trong hợp đồng')
    stages=[]; produced=set(); ids=set()
    for row in stages_raw:
        if not isinstance(row,dict): raise ContractError('Công đoạn phải là object')
        unknown=set(row)-ALLOWED_STAGE
        if unknown:raise ContractError('Công đoạn có trường chưa hỗ trợ: '+', '.join(sorted(unknown)))
        sid=row.get('id'); out=row.get('output'); adapter=row.get('adapter')
        if not isinstance(sid,str) or not IDENTITY.fullmatch(sid) or sid in ids:
            raise ContractError('Mã công đoạn không hợp lệ hoặc trùng: '+str(sid))
        if not isinstance(out,str) or not IDENTITY.fullmatch(out) or out in produced or out in required:
            raise ContractError('Đầu ra bị trùng hoặc trùng với nguồn: '+str(out))
        if adapter not in ADAPTERS: raise ContractError(f'Công đoạn {sid}: adapter không được hỗ trợ: {adapter}')
        inputs=row.get('inputs',[]); rules=row.get('rules',[]); validators=row.get('validators',[])
        if not isinstance(inputs,list) or not inputs or not all(isinstance(x,str) for x in inputs):
            raise ContractError(f'{sid}: thiếu đầu vào')
        if not isinstance(rules,list) or not all(isinstance(x,str) for x in rules):
            raise ContractError(f'{sid}: rules không hợp lệ')
        if not isinstance(validators,list) or not validators:
            raise ContractError(f'{sid}: phải khai báo validator; không có PASS mặc định')
        for r in rules:
            if r not in rule_files:
                raise ContractError(f'{sid}: không tìm thấy file quy tắc {r}')
            if dispositions[r]['role'] not in ('PRODUCTION','REFERENCE'):
                raise ContractError(f'{sid}: file {r} không phải quy tắc production đang có hiệu lực')
        for v in validators:
            if not isinstance(v,dict) or v.get('type') not in VALIDATORS or set(v)-ALLOWED_VALIDATOR:
                raise ContractError(f'{sid}: điều kiện QA chưa được hỗ trợ: {v}')
            if v.get('type') in ('entity_refs','evidence_line_refs','mapping_integrity') and v.get('source','SOURCE_AUDIO') not in inputs:
                raise ContractError(f'{sid}: validator cần nguồn trong inputs: {v.get("source")}')
        for v in validators:
            if v.get('type')=='mapping_integrity':
                ledgers=v.get('values')
                if not isinstance(ledgers,list) or len(ledgers)!=2 or any(x not in inputs for x in ledgers):
                    raise ContractError(f'{sid}: mapping_integrity phải khai báo values=[CHAR_LEDGER, BG_LEDGER] trong inputs')
        required_terms={str(x) for v in validators if v['type']=='required_phrases' for x in v.get('values',[])}
        forbidden_terms={str(x) for v in validators if v['type']=='forbidden_phrases' for x in v.get('values',[])}
        contradictory=required_terms & forbidden_terms
        if contradictory:
            raise ContractError(f'{sid}: ràng buộc vừa bắt buộc vừa cấm: {sorted(contradictory)}')
        scope=row.get('scope','whole')
        if scope not in ('whole','each_audio_line','chunks'): raise ContractError(f'{sid}: scope không được hỗ trợ: {scope}')
        if row.get('parallel',False):
            # Fail closed. A future scheduler may enable concurrency with certified proof.
            raise ContractError(f'{sid}: V6 Clean chưa cho phép song song; hãy giữ parallel=false')
        output_type=row.get('output_type','text')
        if output_type not in VALID_TYPES: raise ContractError(f'{sid}: output_type không hỗ trợ')
        if scope=='each_audio_line' and not any(v.get('type')=='line_id_coverage' for v in validators):
            raise ContractError(f'{sid}: bắt buộc line_id_coverage để không sót dòng')
        if adapter=='template' and not any('{{'+name+'}}' in str(row.get('instructions','')) for name in inputs):
            raise ContractError(f'{sid}: template bắt buộc sử dụng dữ liệu đầu vào, cấm sản phẩm tĩnh giả')
        if output_type=='json' and scope!='whole':
            raise ContractError(f'{sid}: JSON từng mảnh phải dùng bộ hợp nhất có schema, hiện chưa hỗ trợ')
        if output_type=='json' and adapter!='api_text':
            raise ContractError(f'{sid}: JSON hiện chỉ hỗ trợ adapter api_text và cần kiểm tra cú pháp')
        if scope!='whole' and adapter!='api_text':
            raise ContractError(f'{sid}: chia nguồn chỉ hỗ trợ api_text')
        if scope=='each_audio_line' and output_type!='lines':
            raise ContractError(f'{sid}: each_audio_line yêu cầu output_type=lines')
        if adapter=='api_text' and row.get('semantic_qa') is not True:
            raise ContractError(f'{sid}: bước dùng GPT phải bật semantic_qa; không mặc định PASS')
        if scope in ('each_audio_line','chunks') and row.get('chunk_source','SOURCE_AUDIO') not in inputs:
            raise ContractError(f'{sid}: chunk_source phải nằm trong inputs')
        if int(row.get('chunk_lines',80)) not in range(1,1001):
            raise ContractError(f'{sid}: chunk_lines không hợp lệ')
        if adapter=='api_text' and not str(row.get('instructions','')).strip():
            raise ContractError(f'{sid}: thiếu hướng dẫn sinh nội dung')
        ev=row.get('source_evidence',[])
        if not isinstance(ev,list) or not ev:
            raise ContractError(f'{sid}: thiếu nguồn bằng chứng quy tắc')
        for proof in ev:
            if not isinstance(proof,str) or not any(proof.startswith(r+':') for r in rules):
                raise ContractError(f'{sid}: source_evidence phải ghi tên file quy tắc:số dòng')
            path,line=proof.rsplit(':',1)
            if not line.isdecimal() or int(line)<1 or int(line)>len(rule_files[path].splitlines()):
                raise ContractError(f'{sid}: dòng quy tắc không tồn tại: {proof}')
            if not rule_files[path].splitlines()[int(line)-1].strip():
                raise ContractError(f'{sid}: bằng chứng quy tắc nằm ngoài phạm vi đã chọn: {proof}')
        max_tokens=int(row.get('max_output_tokens',8000))
        if not 128<=max_tokens<=100000: raise ContractError(f'{sid}: max_output_tokens không hợp lệ')
        stages.append(Stage(sid,str(row.get('title',sid)),adapter,tuple(inputs),out,tuple(rules),
            str(row.get('instructions','')),tuple(validators),scope,output_type,max_tokens,False,tuple(ev),bool(row.get('semantic_qa',False)),str(row.get('chunk_source','SOURCE_AUDIO')),int(row.get('chunk_lines',80))))
        ids.add(sid);produced.add(out)
    known=set(required)|produced
    for st in stages:
        for name in st.inputs:
            if name not in known:
                raise ContractError(f'{st.id}: đầu vào {name} không có công đoạn cung cấp')
        if st.output in st.inputs:
            raise ContractError(f'{st.id}: vòng lặp tự tham chiếu')
    for name in outputs:
        if name not in known:
            raise ContractError(f'Không có dữ liệu để xuất file bắt buộc: {name}')
        if name not in produced:
            raise ContractError(f'Đầu ra bắt buộc {name} phải do công đoạn hợp lệ tạo, không thể dùng trực tiếp file nguồn')
    producers={s.output:s.id for s in stages}
    deps={s.id:{producers[i] for i in s.inputs if i in producers} for s in stages}
    order=[];ready={x for x,d in deps.items() if not d}
    while ready:
        current=sorted(ready)[0]
        ready.remove(current);order.append(current)
        for sid in deps:
            deps[sid].discard(current)
            if not deps[sid] and sid not in order and sid not in ready:ready.add(sid)
    if len(order)!=len(stages): raise ContractError('Phát hiện chu trình phụ thuộc')
    release_checks=raw.get('release_checks',{})
    if not isinstance(release_checks,dict):raise ContractError('release_checks phải là object')
    for out,spec in release_checks.items():
        if not isinstance(spec,dict):raise ContractError('release_checks không hợp lệ: '+str(out))
        for v in spec.get('validators',[]):
            if not isinstance(v,dict) or v.get('type') not in VALIDATORS or set(v)-ALLOWED_VALIDATOR:
                raise ContractError(f'{out}: validator bàn giao không hỗ trợ: {v}')
            if v.get('type')=='mapping_integrity':
                refs=v.get('values')
                if not isinstance(refs,list) or len(refs)!=2 or any(not isinstance(ref,str) for ref in refs):
                    raise ContractError(f'{out}: mapping_integrity cần hai ledger hợp lệ')
    # Release assurance is a separate contract with explicit proof obligations.
    contract=Contract(raw,tuple(stages),tuple(outputs),tuple(required),rule_sha,actual_sha,tuple(order))
    from .release import validate_release_contract
    validate_release_contract(raw,contract)
    from .rule_audit import validate_clause_coverage
    validate_clause_coverage(raw,rule_files,set(ids))
    # Clause classification must be reflected in EACH stage's actual context.
    # Merely listing an ENFORCE decision in the contract is not enough: if the
    # stage does not include that file in `rules`, the executor would omit it.
    for clause in raw['clause_coverage']:
        if clause['decision'] != 'ENFORCE':
            continue
        rule_file=clause['file']
        for stage_id in clause['stage_ids']:
            stage=contract.stage_by_id[stage_id]
            if rule_file not in stage.rules:
                raise ContractError(
                    f'{rule_file}:{clause["start"]}: điều khoản bắt buộc của '
                    f'{stage_id} chưa có trong stage.rules; sẽ không được gửi API')
    return contract
