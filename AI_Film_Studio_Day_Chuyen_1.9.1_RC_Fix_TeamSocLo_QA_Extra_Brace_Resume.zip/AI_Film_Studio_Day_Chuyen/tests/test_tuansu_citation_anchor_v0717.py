"""Gateway citation-repair regressions. Offline: no actual user key or HTTP.

Only the AI annotation can be rewritten from the literal source line; original
TXT, source line, claimed rule value, and human-facing questions never change.
"""
import json

import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.rule_options import (analyze_rules, analysis_plan,
                                 pending_analysis_chunks, verify_report_constraints)


def result(assertions=()):
    return {'summary': 'Đã đọc nguyên phần.', 'steps': [], 'deliverables': [],
            'questions': [], 'warnings': [], 'blockers': [],
            'assertions': list(assertions)}


def assertion(file, line, quote, value, topic='quy tắc cố định'):
    return {'topic': topic, 'value': value, 'source_file': file,
            'source_line': line, 'source_quote': quote}


class Replies:
    provider_id = 'tuansu'
    model = 'example-text-model'

    def __init__(self, *replies):
        self.replies = list(replies)
        self.calls = 0

    def generate(self, *, system, user, max_output_tokens):
        self.calls += 1
        output = self.replies.pop(0)
        return Generation(json.dumps(output, ensure_ascii=False))


def test_actual_b1_line_paraphrased_citation_is_restored_from_source_and_cached(tmp_path):
    original = 'JAPANESE_LN_NATURALNESS = PASS bắt buộc nếu source là Japanese LN.'
    files = {'B1.txt': original}
    bad_format = 'JAPANESE_LN_NATURALNESS: PASS bắt buộc nếu source là Japanese Light Novel.'
    model = Replies(result([assertion('B1.txt', 1, bad_format, 'PASS')]))
    report = analyze_rules(files, model, checkpoint_dir=tmp_path,
                           provider_identity='tuansu:example-text-model')
    assert model.calls == 1
    assert report['assertions'] == []  # A conditional is NOT a universal fixed requirement.
    assert any('đối chiếu lại đúng dòng TXT gốc' in w for w in report['warnings'])
    verify_report_constraints(report, files)
    assert files['B1.txt'] == original
    replay = Replies()
    second = analyze_rules(files, replay, checkpoint_dir=tmp_path,
                           provider_identity='tuansu:example-text-model')
    assert replay.calls == 0 and second['cache_hits'] == 1
    assert pending_analysis_chunks(files, tmp_path, 'tuansu:example-text-model') == 0


def test_ungrounded_citation_is_replaced_only_if_value_exists_on_same_line():
    a = 'Số cảnh: 10.'
    b = 'Số cảnh: 20.'
    files = {'A.txt': a, 'B.txt': b}
    fake = Replies(result([assertion('A.txt', 1, 'Số cảnh = 10', '10', 'số cảnh')]),
                   result([assertion('B.txt', 1, 'Số cảnh = 20', '20', 'số cảnh')]))
    report = analyze_rules(files, fake)
    assert len(report['conflicts']) == 1
    assert {report['conflicts'][0]['left']['source_quote'],
            report['conflicts'][0]['right']['source_quote']} == {a, b}


def test_fabricated_value_remains_rejected_even_after_retry(tmp_path):
    files = {'B1.txt': 'JAPANESE_LN_NATURALNESS = PASS bắt buộc nếu source là Japanese LN.'}
    invalid = result([assertion('B1.txt', 1, 'JAPANESE_LN_NATURALNESS: FAIL',
                                'FAIL')])
    model = Replies(invalid, invalid)
    with pytest.raises(ContractError, match='B1.txt.*phần 1/1.*nguyên văn'):
        analyze_rules(files, model, checkpoint_dir=tmp_path,
                      provider_identity='tuansu:example-text-model')
    assert model.calls == 2
    assert pending_analysis_chunks(files, tmp_path, 'tuansu:example-text-model') == 1


def test_wrong_file_or_line_not_reanchored():
    files = {'B1.txt': 'Số cảnh: 10.', 'B2.txt': 'Số cảnh: 20.'}
    # A cross-file AI assertion cannot be accepted inside the first file's scan.
    wrong = result([assertion('B2.txt', 1, 'Số cảnh = 20', '20', 'số cảnh')])
    model = Replies(wrong, wrong)
    with pytest.raises(ContractError, match='trỏ sai file'):
        analyze_rules({'B1.txt': files['B1.txt']}, model)


def test_invalid_or_empty_quote_is_not_filled_from_source():
    files = {'B1.txt': 'Số cảnh: 10.'}
    unquoted = result([assertion('B1.txt', 1, '', '10', 'số cảnh')])
    model = Replies(unquoted, unquoted)
    with pytest.raises(ContractError, match='không khớp nguyên văn'):
        analyze_rules(files, model)


def test_multi_segment_successful_cache_preserved_when_later_part_fails(tmp_path):
    first = 'Ghi chú mô tả quy tắc không có lựa chọn mới.\n' * 410
    last = 'JAPANESE_LN_NATURALNESS = PASS bắt buộc nếu source là Japanese LN.'
    files = {'B1.txt': first + last}
    assert analysis_plan(files)['segments'] >= 2
    class Partial:
        provider_id, model = 'tuansu', 'test'
        def __init__(self): self.calls = 0
        def generate(self, *, system, user, max_output_tokens):
            self.calls += 1
            lines = user.splitlines()
            if last in user:
                return Generation(json.dumps(result([assertion('B1.txt', 411, 'JAPANESE_LN_NATURALNESS: PASS', 'PASS')]), ensure_ascii=False))
            return Generation(json.dumps(result(), ensure_ascii=False))
    m = Partial()
    report = analyze_rules(files, m, checkpoint_dir=tmp_path,
                           provider_identity='tuansu:test')
    assert report['cache_hits'] == 0
    assert report['segment_count'] == m.calls
    verify_report_constraints(report, files)
    reuse = Replies()
    cached = analyze_rules(files, reuse, checkpoint_dir=tmp_path,
                           provider_identity='tuansu:test')
    assert reuse.calls == 0 and cached['cache_hits'] == m.calls

@pytest.mark.parametrize('statement', [
    '- Các quyết định “chọn resource, reference, state” ở B3 là việc AI xác định từ source/lock, không phải câu hỏi bắt buộc người dùng điền.',
    '- Không dùng chữ “người dùng” trong tên QA/GATE hay các câu hỏi nội bộ làm căn cứ tự tạo câu hỏi người dùng chọn. B6 kiểm output thật và không được ghi PASS sẵn.',
    '- “Chọn” cảnh, kiểu tóc, camera, CHAR/BG state, câu lệnh tự QA là quyết định chuyên môn AI dựa theo source/quy tắc, không phải tùy chọn bắt buộc người dùng nhập.',
])
def test_meta_explanations_about_no_human_question_are_not_questions(statement):
    from studio.fast_analysis import explicit_human_requirements
    assert explicit_human_requirements({'RULE.txt':statement}, 'RULE.txt') == {}


def test_real_explicit_human_decision_after_negated_explanation_still_detected():
    from studio.fast_analysis import explicit_human_requirements
    rule = ('Không phải câu hỏi bắt buộc người dùng điền. '
            'Người dùng phải chọn ngôn ngữ: tiếng Việt hoặc tiếng Anh.')
    assert explicit_human_requirements({'RULE.txt':rule}, 'RULE.txt')
