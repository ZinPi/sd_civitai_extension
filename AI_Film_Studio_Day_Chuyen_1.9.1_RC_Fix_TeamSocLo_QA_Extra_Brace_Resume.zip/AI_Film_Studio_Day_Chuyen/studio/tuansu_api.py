"""TuanSu text-only OpenAI-compatible Chat Completions adapter.

Only endpoint used for generation: POST https://tuansuapi.store/v1/chat/completions.
No hardcoded model catalogue; model enumeration is best-effort because the public
API documentation does not guarantee GET /v1/models for every key.
No credential logging, implicit retries, media generation, or response truncation.
"""
from __future__ import annotations

from .api import Generation, IncompleteGeneration
from .contract import ContractError

TUANSU_BASE_URL = 'https://tuansuapi.store/v1'


def _client(api_key: str, *, timeout: int, client_factory=None):
    if client_factory is None:
        from openai import OpenAI
        client_factory = OpenAI
    return client_factory(api_key=api_key.strip(), base_url=TUANSU_BASE_URL,
                          timeout=timeout, max_retries=0)


def _error_message(exc: Exception, action: str) -> str:
    """Do not return raw upstream error bodies that could expose credentials."""
    code = getattr(exc, 'status_code', None)
    typename = type(exc).__name__
    if code in (401, 403) or typename in ('AuthenticationError', 'PermissionDeniedError'):
        return f'TuanSu API từ chối key hoặc quyền truy cập (HTTP {code or 403}).'
    if code == 404 or typename == 'NotFoundError':
        return 'TuanSu không tìm thấy model/endpoint (404); kiểm tra mã model.'
    if code == 429 or typename == 'RateLimitError':
        return 'TuanSu hết quota/số dư hoặc vượt giới hạn đồng thời (429). Kiểm tra trang quản lý key.'
    if code == 400 or typename == 'BadRequestError':
        return 'TuanSu không chấp nhận model hoặc tham số chat (400). Hãy thử model khác.'
    if code in (502, 503, 504):
        return f'TuanSu đang có lỗi máy chủ ({code}); yêu cầu có thể đã tính phí, không tự thử lại.'
    if typename in ('APITimeoutError','APIConnectionError','ConnectError','TimeoutError'):
        return 'Không kết nối được hoặc TuanSu quá thời gian chờ; không tự thử lại để tránh tính phí trùng.'
    return f'{action} không thành công ({typename}, HTTP {code or "không rõ"}).'


def _usage(response):
    usage = getattr(response, 'usage', None)
    input_tokens = int(getattr(usage,'prompt_tokens',0) or 0)
    output_tokens = int(getattr(usage,'completion_tokens',0) or 0)
    details = getattr(usage,'prompt_tokens_details',None)
    cached = int(getattr(details,'cached_tokens',0) or 0)
    return input_tokens, output_tokens, cached


def _completed_text(response):
    choices = getattr(response,'choices',None) or []
    if len(choices) != 1:
        raise ContractError('TuanSu phải trả một lựa chọn văn bản (n=1); không sử dụng kết quả không rõ.')
    choice = choices[0]
    reason = getattr(choice,'finish_reason',None)
    used = _usage(response)
    if reason != 'stop':
        raise IncompleteGeneration('TuanSu Chat Completions',
                                   reason or 'không có finish_reason', *used)
    msg = getattr(choice,'message',None)
    content = getattr(msg,'content',None)
    if isinstance(content,str):
        text = content
    elif isinstance(content,list) and all(isinstance(block,dict) and
                                          block.get('type')=='text' and isinstance(block.get('text'),str)
                                          for block in content):
        text = '\n'.join(block['text'] for block in content)
    else:
        raise ContractError('TuanSu không trả về nội dung text được hỗ trợ. Không đánh dấu hoàn thành.')
    if not text.strip():
        raise ContractError('TuanSu trả về văn bản trống. Không đánh dấu hoàn thành.')
    return Generation(text,*used)


class TuansuProvider:
    is_live=True
    provider_id='tuansu'
    concurrency_limit=2

    def __init__(self, api_key: str, model: str, reasoning_effort: str='default', *, client_factory=None):
        if not api_key or not api_key.strip():
            raise ContractError('Chưa nhập TuanSu API key.')
        if not model or not model.strip():
            raise ContractError('Chưa chọn TuanSu model.')
        self.model=model.strip()
        self.effort='default'  # Gateway capabilities differ by model; no unverified reasoning flags.
        self.client=_client(api_key, timeout=180, client_factory=client_factory)

    def generate(self, *, system: str, user: str, max_output_tokens: int) -> Generation:
        if max_output_tokens <= 0:
            raise ContractError('Giới hạn token đầu ra phải > 0.')
        try:
            result=self.client.chat.completions.create(
                model=self.model, messages=[{'role':'system','content':system},
                                            {'role':'user','content':user}],
                max_tokens=int(max_output_tokens), n=1, stream=False)
        except Exception as exc:
            raise ContractError(_error_message(exc, 'Gọi TuanSu Chat Completions')) from None
        return _completed_text(result)


def fetch_tuansu_models(api_key: str, *, client_factory=None) -> list[str]:
    """Try account /models; failure is not proof chat API is unusable.

    Never inject advertised models into the 'verified available' selection.
    """
    if not api_key or not api_key.strip():
        raise ValueError('Chưa nhập TuanSu API key.')
    try:
        client=_client(api_key,timeout=30,client_factory=client_factory)
        result=client.models.list()
        raw=[getattr(m,'id',None) for m in getattr(result,'data',[])]
    except Exception as exc:
        raise ValueError(_error_message(exc,'Tải model TuanSu') +
                         ' Nếu /models không được hỗ trợ, hãy nhập mã model từ trang quản lý key và bấm Thử model.') from None
    exclusions=('embedding','tts','audio','video','image','whisper','moderation','realtime','speech')
    models=sorted({m.strip() for m in raw if isinstance(m,str) and m.strip() and
                   not any(t in m.lower() for t in exclusions)},key=str.casefold)
    if not models:
        raise ValueError('TuanSu chưa trả về model văn bản. Nhập mã model được cấp trong trang quản lý key và Thử model.')
    return models


def probe_tuansu_model(api_key: str, model: str, *, client_factory=None) -> tuple[int,int]:
    """Explicitly billable tiny real chat request; validates endpoint and usage."""
    provider=TuansuProvider(api_key,model,client_factory=client_factory)
    result=provider.generate(system='Trả lời ngắn gọn.',user='Chỉ trả lời OK.',max_output_tokens=128)
    return result.input_tokens,result.output_tokens
