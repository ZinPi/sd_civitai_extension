"""Project-safe model preflight receipts. Never persist an API key.

A model check is a small billable call; the guarded provider accounts for it.
Receipt is only a recent successful connectivity check, not a guarantee the
next generation works. Every real production call is still validated.
"""
from __future__ import annotations
import hashlib
import json
import threading
import time
from pathlib import Path

from .contract import ContractError

_CHECK_LOCK = threading.RLock()
_CURRENT = {}   # current process, including manual checks before project creation
_VALID_FOR = 6 * 3600  # recheck after a reasonable interval; never trust forever


def _identity(kind: str, model: str, key: str) -> str:
    # API keys are high-entropy credentials. Only a nonreversible fingerprint is stored.
    return hashlib.sha256((kind + '\0' + model + '\0' + key).encode('utf-8')).hexdigest()


def _file(project) -> Path | None:
    return Path(project) / 'model_preflight_receipt.json' if project is not None else None


def was_checked(project, kind: str, model: str, key: str, now=None) -> bool:
    now = time.time() if now is None else now
    identity = _identity(kind, model, key)
    with _CHECK_LOCK:
        if 0 <= now - _CURRENT.get(identity, -1e12) < _VALID_FOR:
            return True
        f = _file(project)
        if f is None or not f.exists():
            return False
        try:
            doc = json.loads(f.read_text(encoding='utf-8'))
            return (doc.get('identity') == identity and
                    0 <= now - float(doc.get('verified_at', -1e12)) < _VALID_FOR)
        except (ValueError, TypeError, OSError, AttributeError):
            return False


def mark_checked(project, kind: str, model: str, key: str, now=None):
    now = time.time() if now is None else now
    identity = _identity(kind, model, key)
    with _CHECK_LOCK:
        _CURRENT[identity] = now
        f = _file(project)
        if f is not None:
            f.parent.mkdir(parents=True, exist_ok=True)
            payload = json.dumps({'identity': identity, 'verified_at': now, 'version': 1})
            temp = f.with_name(f.name + '.tmp')
            temp.write_text(payload, encoding='utf-8')
            temp.replace(f)


def ensure_checked(guarded, project, kind: str, model: str, key: str, emit=None):
    emit = emit or (lambda msg: None)
    if was_checked(project, kind, model, key):
        emit('Model đã thử thành công gần đây với cùng API Key; bỏ qua request thử lặp lại.')
        return False
    emit('Thử model một lần bằng yêu cầu nhỏ (được ghi vào ngân sách dự án)...')
    # This request goes through the same persistent budget ledger as production.
    response = guarded.generate(system='Kiểm tra khả năng tạo văn bản.',
                                user='Chỉ trả lời: OK', max_output_tokens=128)
    if not isinstance(getattr(response, 'text', None), str) or not response.text.strip():
        raise ContractError('Model trả kết quả kiểm tra rỗng; không ghi nhận kết nối thành công.')
    mark_checked(project, kind, model, key)
    return True
