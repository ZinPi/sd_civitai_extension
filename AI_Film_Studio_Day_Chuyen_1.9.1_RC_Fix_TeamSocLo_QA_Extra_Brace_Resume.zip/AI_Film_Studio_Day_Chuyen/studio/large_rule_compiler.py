"""Source-complete, fail-closed compilation of large natural-language rule packs.

A chunk cannot be silently omitted.  Every lexical directive candidate is
classified after the workflow proposal.  Results remain an UNAPPROVED DRAFT:
lexical and LLM checks cannot prove semantic correctness of arbitrary rules.
"""
from __future__ import annotations
import json
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from pathlib import Path
from .contract import ContractError, validate_contract, digest
from .rule_audit import collect_candidates

CHUNK_CHARS = 12000
FINAL_INPUT_CHARS = 48000
COVERAGE_BATCH = 45
COVERAGE_MAX_CHARS = 13000
MAX_CALLS = 400


def parse_json_text(text: str) -> dict:
    value = text.strip()
    if value.startswith('```'):
        value = value.split('\n',1)[1].rsplit('```',1)[0].strip()
    try: parsed = json.loads(value)
    except (ValueError,IndexError) as err:
        raise ContractError('Phản hồi phân tích không phải JSON hợp lệ; xem báo cáo từng lượt') from err
    if not isinstance(parsed,dict):raise ContractError('Phản hồi phân tích không phải JSON object')
    if parsed.get('blocked'):raise ContractError('GPT không phân tích được: '+str(parsed['blocked']))
    return parsed


def rule_chunks(files: dict[str,str]):
    """Yield complete content, preserving exact line numbers; no hidden truncation."""
    for name, body in files.items():
        lines=body.splitlines(keepends=True)
        if not lines:
            yield name,1,0,''
            continue
        start=1; buf=[]; size=0
        for line_no, line in enumerate(lines,1):
            if len(line)>CHUNK_CHARS:
                raise ContractError(f'Dòng quy tắc quá dài không thể chia an toàn: {name}:{line_no}')
            if buf and size+len(line)>CHUNK_CHARS:
                yield name,start,line_no-1,''.join(buf)
                start=line_no;buf=[];size=0
            buf.append(line);size+=len(line)
        if buf:yield name,start,len(lines),''.join(buf)


def clause_batches(lines: list[int], source_lines: list[str]):
    batch=[];size=0
    for line in lines:
        row=f'{line}: {source_lines[line-1]}'
        if len(row)>COVERAGE_MAX_CHARS:
            raise ContractError(f'Dòng điều khoản dài quá mức an toàn để phân loại một lượt: {line}')
        if batch and (len(batch)>=COVERAGE_BATCH or size+len(row)>COVERAGE_MAX_CHARS):
            yield batch;batch=[];size=0
        batch.append(line);size+=len(row)
    if batch:yield batch

def planning_stats(files):
    parts=list(rule_chunks(files))
    return {'files':len(files),'characters':sum(len(s) for s in files.values()),
            'chunks':len(parts),'directive_candidates':sum(len(v) for v in collect_candidates(files,{k:{'role':'PRODUCTION'} for k in files}).values()),
            'coverage_batches':sum(len(list(clause_batches(v, files[k].splitlines()))) for k,v in
                collect_candidates(files,{k:{'role':'PRODUCTION'} for k in files}).items())}


def _generate_json(provider, system, user, max_output_tokens):
    return parse_json_text(provider.generate(system=system,user=user,max_output_tokens=max_output_tokens).text)


def _condense_notes(provider, notes, progress, call_count):
    """Hierarchical condensation is an index, never a replacement for raw clauses.
    Raw directives are independently classified in phase 3.
    """
    depth=0
    while len('\n'.join(notes))>FINAL_INPUT_CHARS:
        depth+=1
        if depth>6:raise ContractError('Không thể gộp mọi bản ghi quy tắc mà không mất căn cứ; giữ trạng thái CHƯA XÁC MINH')
        groups=[]; group=[]; used=0
        for s in notes:
            if len(s)>FINAL_INPUT_CHARS//2:
                raise ContractError('Một bản ghi phân tích quá dài, không được cắt mất điều khoản')
            if group and used+len(s)>FINAL_INPUT_CHARS//2:
                groups.append(group);group=[];used=0
            group.append(s);used+=len(s)
        if group:groups.append(group)
        reduced=[]
        for i,g in enumerate(groups,1):
            call_count[0]+=1
            if call_count[0]>MAX_CALLS:raise ContractError('Vượt giới hạn số lượt phân tích, chưa dùng đủ để chứng nhận workflow')
            progress(f'Hợp nhất bản ghi quy tắc tầng {depth}: nhóm {i}/{len(groups)}')
            obj=_generate_json(provider,
                'Tóm lược bản ghi thiết kế, KHÔNG lược bỏ tên bước, dependency, điều cấm, lỗi QA, trạng thái chưa rõ. '
                'Chỉ tóm lược nguồn dẫn chứng; không tự tạo workflow. Trả JSON {"notes": "..."}.',
                '\n'.join(g),max_output_tokens=6000)
            s=obj.get('notes')
            if not isinstance(s,str) or not s.strip():raise ContractError('Hợp nhất ghi chú không đầy đủ')
            reduced.append(s)
        if len('\n'.join(reduced))>=len('\n'.join(notes))*0.95:
            raise ContractError('Bản ghi quá lớn, hợp nhất không giảm kích thước; cần kiểm tra thủ công')
        notes=reduced
    return notes


def compile_large(files, rule_hash, provider, progress=None, checkpoint_path=None, *, partial=False, max_workers=1):
    """Return validated draft or explicit BLOCKED; never silently drop rule text."""
    progress=progress or (lambda m:None)
    from .compiler import _json_contract
    if _json_contract(files)[1] is not None:
        raise ContractError('Đã có hợp đồng JSON; không cần biên dịch dài')
    chunks=list(rule_chunks(files))
    max_workers=max(1, min(int(max_workers), 3))
    checkpoint_path=Path(checkpoint_path) if checkpoint_path else None
    identity=digest({'rules':rule_hash,'model':str(getattr(provider,'model','UNKNOWN')),
                     'effort':str(getattr(provider,'effort','default')),'format':2})
    state={'identity':identity,'chunk_notes':{},'coverage':{},'raw_contract':None}
    if checkpoint_path and checkpoint_path.is_file():
        try:
            cached=json.loads(checkpoint_path.read_text(encoding='utf8'))
            if isinstance(cached,dict) and cached.get('identity')==identity:
                state=cached
                progress(f'Đã khôi phục {len(state.get("chunk_notes",{}))} đoạn quy tắc từ checkpoint')
        except (OSError,ValueError,TypeError):
            raise ContractError('Checkpoint biên dịch bị hỏng; không được tự tái sử dụng dữ liệu không xác minh')
    def persist():
        if checkpoint_path:
            checkpoint_path.parent.mkdir(parents=True,exist_ok=True)
            tmp=checkpoint_path.with_name(checkpoint_path.name+'.tmp')
            tmp.write_text(json.dumps(state,ensure_ascii=False,sort_keys=True,indent=2),encoding='utf8')
            tmp.replace(checkpoint_path)
    provisional_calls=len(chunks)
    # + merge, final, directives and retries: explicit conservative first ceiling
    if provisional_calls>MAX_CALLS-3:
        raise ContractError(f'{len(chunks)} đoạn quy tắc vượt giới hạn biên dịch; chưa tự bỏ bớt nguồn')
    notes=[None]*len(chunks);counter=[0]
    jobs=[]
    for n, (name, start, end, body) in enumerate(chunks, 1):
        if not body.strip():
            notes[n-1] = ''
            continue
        key=digest({'file':name,'start':start,'end':end,'source':body})
        if key in state.get('chunk_notes',{}):
            notes[n-1]=state['chunk_notes'][key]
            continue
        jobs.append((n-1,name,start,end,body,key))

    def scan_one(item):
        n,name,start,end,body,key=item
        system=('Phân tích MỘT ĐOẠN QUY TẮC trong toàn bộ bộ tài liệu, không phải toàn bộ workflow. '
                'Giữ nguyên tên bước, đầu vào/đầu ra, cổng QA, ngoại lệ, quan hệ phụ thuộc, thứ tự, dấu hiệu xung đột. '
                'Phân loại đoạn là PRODUCTION/REFERENCE/CHAT_ONLY/SUPERSEDED nếu có bằng chứng, '
                'nếu không chắc ghi UNKNOWN. Trả JSON {"notes":"bản tóm lược có nguồn file:dòng",'
                '"possible_stages":[{"name":"...","evidence_lines":[1]}],"file_role":"..."}. '
                'KHÔNG ghi đây là hợp đồng được duyệt.')
        prompt=f'FILE={name}\nRANGE={start}-{end}\n'
        prompt+=''.join(f'{idx}: {line}' for idx,line in enumerate(body.splitlines(keepends=True),start))
        obj=_generate_json(provider,system,prompt,max_output_tokens=4400)
        if not isinstance(obj.get('notes'),str) or not obj['notes'].strip():
            raise ContractError(f'Thiếu kết quả phân tích file {name}, dòng {start}-{end}')
        record=f'FILE={name};DÒNG={start}-{end};VAI_TRÒ={obj.get("file_role","UNKNOWN")};\n' + \
               obj['notes']+'\nBƯỚC:'+json.dumps(obj.get('possible_stages',[]),ensure_ascii=False)
        return n,key,record

    def commit(result):
        n,key,record=result
        notes[n]=record
        state.setdefault('chunk_notes',{})[key]=record
        persist()

    if max_workers==1:
        for item in jobs:
            n,name,start,end,*_=item
            progress(f'Đọc file quy tắc ({n+1}/{len(chunks)}): {name} · dòng {start}–{end}')
            counter[0]+=1
            commit(scan_one(item))
    elif jobs:
        # Only the main thread writes checkpoint. Bounded worker window limits
        # concurrent API expenses; source order is restored before merging.
        with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix='RuleCompile') as pool:
            pending=iter(jobs); active={}
            def submit_next():
                item=next(pending,None)
                if item is None: return
                n,name,start,end,*_=item
                progress(f'Đọc file quy tắc ({n+1}/{len(chunks)}): {name} · dòng {start}–{end}')
                counter[0]+=1
                active[pool.submit(scan_one,item)]=item
            for _ in range(max_workers):submit_next()
            failure=None
            while active:
                done,_=wait(active,return_when=FIRST_COMPLETED)
                for future in done:
                    active.pop(future)
                    try: commit(future.result())
                    except Exception as err:
                        failure=failure or err
                    if failure is None: submit_next()
            if failure is not None:raise failure
    notes=[x for x in notes if x]
    progress(f'Đã đọc {len(chunks)}/{len(chunks)} đoạn; đang hợp nhất bản đồ quy trình')
    if not state.get('reduced_notes'):
        notes=_condense_notes(provider,notes,progress,counter)
        state['reduced_notes']=notes;persist()
    else:notes=state['reduced_notes']
    from .compiler import COMPILER_SYSTEM, PARTIAL_COMPILER_SUFFIX
    # Draft workflow without clause_coverage; directives are classified
    # using actual, unabridged source in the independent final phase.
    sys=COMPILER_SYSTEM + (PARTIAL_COMPILER_SUFFIX if partial else '') + '\nKhông được điền giả clause_coverage; trả clause_coverage=[]; sẽ kiểm tra toàn bộ điều khoản ở lượt kế.'
    counter[0]+=1
    if counter[0]>MAX_CALLS:raise ContractError('Vượt ngân sách lượt phân tích')
    summary='\n'.join(notes)
    if len(summary)>FINAL_INPUT_CHARS:raise ContractError('Tóm lược quy tắc vượt giới hạn an toàn')
    if state.get('raw_contract'):
        raw=state['raw_contract']
    else:
        raw=_generate_json(provider,sys,
            'RULE_SHA256: '+rule_hash+'\nQUY TẮC GỐC ĐƯỢC LƯU NGUYÊN VẸN; BẢN GHI CÓ CHỈ DẪN NGUỒN:\n'+summary,
            max_output_tokens=25000)
        raw['rulepack_sha256']=rule_hash
        raw['clause_coverage']=[]
        state['raw_contract']=raw;persist()
    if not isinstance(raw.get('stages'),list) or not raw['stages']:
        raise ContractError('Không nhận diện được công đoạn từ toàn bộ nguồn; không cấp quyền RUN')
    disp=raw.get('file_dispositions')
    if not isinstance(disp,dict) or set(disp)!=set(files):
        raise ContractError('Bản hợp đồng chưa phân loại được đầy đủ mọi file')
    stages=raw['stages']; ids={s.get('id') for s in stages if isinstance(s,dict)}
    if None in ids or len(ids)!=len(stages):raise ContractError('Danh sách công đoạn gộp bị lỗi/trùng ID')
    candidates=collect_candidates(files,disp)
    total=sum(len(v) for v in candidates.values())
    batches=sum(len(list(clause_batches(v,files[k].splitlines()))) for k,v in candidates.items())
    if counter[0]+batches>MAX_CALLS:
        raise ContractError(f'Cần {counter[0]+batches} lượt phân tích (giới hạn {MAX_CALLS}); chưa thể kiểm chứng {total} điều khoản')
    progress(f'Kiểm tra {total} điều khoản ứng viên trong {batches} lượt, không bỏ qua phần cuối')
    coverage=[];done=0
    listing='\n'.join(f'{s["id"]}: {s.get("title","")} | {s.get("output","")} | {s.get("instructions","")[:130]}' for s in stages)
    for fn,lines in candidates.items():
        raw_lines=files[fn].splitlines()
        for group_i, batch in enumerate(clause_batches(lines,raw_lines),1):
            batch_key=digest({'file':fn,'lines':batch,'stage_ids':sorted(ids),
                              'contract':digest(raw)})
            if batch_key in state.get('coverage',{}):
                coverage.extend(state['coverage'][batch_key]);done+=len(batch)
                continue
            text='\n'.join(f'{ln}: {raw_lines[ln-1]}' for ln in batch)
            prompt=('FILE: '+fn+'\nDANH SÁCH CÔNG ĐOẠN:\n'+listing+'\n\n'
                    'PHÂN LOẠI TỪNG DÒNG dưới đây: ENFORCE (và id bước thực thi), '
                    'NOT_APPLICABLE (lý do ít nhất 12 ký tự), hoặc UNRESOLVED nếu chưa rõ. '
                    'Không được đánh dấu ENFORCE chỉ vì có tên bước tương tự. '
                    'JSON {"assignments":[{"line":1,"decision":"ENFORCE",'
                    '"stage_ids":["stage_id"],"reason":"chi tiết"}]}\n'+text)
            counter[0]+=1;d=_generate_json(provider,
                'Bạn là bộ đối chiếu điều khoản; căn cứ dòng quy tắc và danh sách bước. '
                'Không suy đoán thành đã thực thi nếu thiếu liên kết. Trả duy nhất JSON.',
                prompt, max_output_tokens=6200)
            assignments=d.get('assignments')
            if not isinstance(assignments,list) or len(assignments)!=len(batch):
                raise ContractError(f'Đối chiếu chưa đủ điều khoản: {fn}, lượt {group_i}')
            byline={}
            for a in assignments:
                if not isinstance(a,dict) or type(a.get('line'))!=int or a['line'] in byline:
                    raise ContractError('Phân loại điều khoản trùng/sai số dòng')
                byline[a['line']]=a
            if set(byline)!=set(batch):raise ContractError(f'Có dòng quy tắc chưa phân loại: {fn}')
            batch_coverage=[]
            for ln in batch:
                a=byline[ln];decision=a.get('decision');assigned=a.get('stage_ids');reason=a.get('reason','')
                if decision=='UNRESOLVED':
                    raise ContractError(f'{fn}:{ln} chưa thể xác minh. Không phê duyệt workflow đoán mò.')
                if decision=='ENFORCE' and (not isinstance(assigned,list) or not assigned or not set(assigned)<=ids):
                    raise ContractError(f'{fn}:{ln} chưa liên kết với bước hợp lệ')
                if decision=='NOT_APPLICABLE' and (not isinstance(reason,str) or len(reason.strip())<12):
                    raise ContractError(f'{fn}:{ln} thiếu căn cứ ngoại lệ')
                if decision not in ('ENFORCE','NOT_APPLICABLE'):raise ContractError(f'{fn}:{ln} trạng thái sai: {decision}')
                batch_coverage.append({'file':fn,'start':ln,'end':ln,'decision':decision,
                                       'stage_ids':assigned if decision=='ENFORCE' else [],
                                       'reason':reason if isinstance(reason,str) else ''})
            coverage.extend(batch_coverage)
            state.setdefault('coverage',{})[batch_key]=batch_coverage
            persist()
            done+=len(batch)
            progress(f'Đã đối chiếu {done}/{total} điều khoản ({fn})')
    raw['clause_coverage']=coverage
    progress('Đang kiểm tra hợp đồng, phụ thuộc, validator và bao phủ điều khoản')
    return validate_contract(raw,files,rule_hash).raw
