from __future__ import annotations
import json
from pathlib import Path
from types import SimpleNamespace as Obj
import pytest

from studio.api import IncompleteGeneration
from studio.contract import ContractError
from studio.one_click import BudgetedProvider
from studio.teamsoclo_api import (
    TeamSocLoProvider, TEAMSOCLO_BASE_URL, fetch_teamsoclo_models,
    probe_teamsoclo_model,
)


def item(**values):
    return Obj(**values)


def finished(text='OK', inp=7, out=2, cached=1, status='completed'):
    return item(status=status, output_text=text, usage=item(input_tokens=inp,
                output_tokens=out, input_tokens_details=item(cached_tokens=cached)),
                incomplete_details=item(reason='max_output_tokens'))


class Stream:
    def __init__(self, events):
        self.events = events
        self.closed = False
    def __iter__(self):
        yield from self.events
    def close(self):
        self.closed = True


class FakeClient:
    def __init__(self, events=None, error=None, model_ids=None):
        self.events = events
        self.error = error
        self.model_ids = model_ids or []
        self.kwargs = []
        self.responses = item(create=self.create)
        self.models = item(list=lambda: item(data=[item(id=m) for m in self.model_ids]))
        self.last_stream = None
    def create(self, **kwargs):
        self.kwargs.append(kwargs)
        if self.error:
            raise self.error
        if kwargs['stream']:
            self.last_stream = Stream(self.events if self.events is not None else [
                item(type='response.output_text.delta', delta='OK'),
                item(type='response.completed', response=finished())])
            return self.last_stream
        return finished()


def factory(fake):
    def create(**kwargs):
        assert kwargs['base_url'] == TEAMSOCLO_BASE_URL
        assert kwargs['max_retries'] == 0
        assert kwargs['timeout'] in (30,180)
        assert kwargs['api_key'] == 'private-testing-key'
        return fake
    return create


def make(fake, *, stream=True):
    return TeamSocLoProvider('private-testing-key','user-model-id',
                             client_factory=factory(fake),stream=stream)


def test_gateway_configuration_and_identity():
    p = make(FakeClient())
    assert p.provider_id == 'teamsoclo'
    assert p.is_live and p.concurrency_limit == 1
    assert p.model == 'user-model-id' and p.effort == 'default'


def test_streaming_completion_with_usage():
    fake = FakeClient(events=[
        item(type='response.output_text.delta', delta='Xin '),
        item(type='response.output_text.delta', delta='chào'),
        item(type='response.completed', response=finished('Xin chào')),
    ])
    r = make(fake).generate(system='system', user='user', max_output_tokens=200)
    assert (r.text,r.input_tokens,r.output_tokens,r.cached_tokens)==('Xin chào',7,2,1)
    assert fake.kwargs == [{'model':'user-model-id','instructions':'system',
                            'input':'user','max_output_tokens':200,'stream':True}]
    assert fake.last_stream.closed


def test_streaming_final_deltas_when_completed_has_no_text():
    fake=FakeClient(events=[item(type='response.output_text.delta',delta='A'),
                            item(type='response.output_text.delta',delta='B'),
                            item(type='response.completed',response=finished(''))])
    assert make(fake).generate(system='s',user='u',max_output_tokens=20).text == 'AB'


def test_standard_responses_output_blocks_supported():
    complete=finished('')
    complete.output=[item(type='message',content=[item(type='output_text',text='valid output')])]
    fake=FakeClient(events=[item(type='response.completed',response=complete)])
    assert make(fake).generate(system='s',user='u',max_output_tokens=20).text=='valid output'


def test_no_completed_event_rejects_partial_stream():
    fake=FakeClient(events=[item(type='response.output_text.delta',delta='Nội dung dở dang')])
    with pytest.raises(IncompleteGeneration):
        make(fake).generate(system='s',user='u',max_output_tokens=100)
    assert fake.last_stream.closed


def test_failure_event_rejects_output():
    fake=FakeClient(events=[item(type='response.output_text.delta',delta='Nửa bài'),
                            item(type='response.failed',response=item(status='failed'))])
    with pytest.raises(IncompleteGeneration):
        make(fake).generate(system='s',user='u',max_output_tokens=100)


def test_final_non_completed_rejected_with_usage():
    fake=FakeClient(events=[item(type='response.completed',response=finished('partial',status='incomplete'))])
    with pytest.raises(IncompleteGeneration) as exc:
        make(fake).generate(system='s',user='u',max_output_tokens=100)
    assert exc.value.input_tokens == 7


def test_empty_final_output_not_locked():
    fake=FakeClient(events=[item(type='response.completed',response=finished(''))])
    with pytest.raises(ContractError,match='không có văn bản'):
        make(fake).generate(system='s',user='u',max_output_tokens=20)


def test_nonstream_mode_for_compatible_response():
    fake=FakeClient()
    result=make(fake,stream=False).generate(system='s',user='u',max_output_tokens=64)
    assert result.text == 'OK'
    assert fake.kwargs[0]['stream'] is False


def test_no_auto_retry_on_524_and_credentials_never_in_exception():
    class InternalServerError(Exception):
        status_code=524
    fake=FakeClient(error=InternalServerError('private-testing-key secret upstream response'))
    with pytest.raises(ContractError) as exc:
        make(fake).generate(system='s',user='u',max_output_tokens=20)
    assert '524' in str(exc.value)
    assert 'private-testing-key' not in str(exc.value)
    assert len(fake.kwargs)==1


@pytest.mark.parametrize('code,term',[(401,'401'),(403,'403'),(404,'404'),(429,'429'),(400,'400')])
def test_common_http_errors_are_safe(code,term):
    class UpstreamError(Exception):
        status_code=code
    with pytest.raises(ContractError) as exc:
        make(FakeClient(error=UpstreamError('private-testing-key'))).generate(
            system='s',user='u',max_output_tokens=20)
    assert term in str(exc.value)
    assert 'private-testing-key' not in str(exc.value)


def test_user_model_list_is_dynamic_and_text_filtered():
    fake=FakeClient(model_ids=['model-of-key','model-of-key','audio-x','embedding-1','claude-x','image-1'])
    assert fetch_teamsoclo_models('private-testing-key',client_factory=factory(fake)) == ['claude-x','model-of-key']


def test_missing_models_endpoint_allows_manual_entry_message():
    class ApiError(Exception):
        status_code=404
    fake=FakeClient()
    fake.models=item(list=lambda: (_ for _ in ()).throw(ApiError()))
    with pytest.raises(ValueError,match='nhập model'):
        fetch_teamsoclo_models('private-testing-key',client_factory=factory(fake))


def test_probe_is_paid_small_request_and_uses_stream():
    fake=FakeClient()
    assert probe_teamsoclo_model('private-testing-key','model',client_factory=factory(fake)) == (7,2)
    assert fake.kwargs[0]['max_output_tokens']==128
    assert fake.kwargs[0]['stream'] is True


def test_cost_guard_preserves_identity_without_price_claims(tmp_path):
    p=make(FakeClient())
    guard=BudgetedProvider(p,tmp_path,max_usd=2,max_calls=5)
    r=guard.generate(system='hi',user='there',max_output_tokens=60)
    assert r.text=='OK'
    data=json.loads((tmp_path/'api_usage_guard.json').read_text('utf8'))
    assert data['provider_id']=='teamsoclo'
    assert 'KHÔNG phải giá TeamSocLo' in data['note']
    assert 'private-testing-key' not in json.dumps(data)


def test_failed_stream_does_not_mark_final_and_reserves_exposure(tmp_path):
    p=make(FakeClient(events=[item(type='response.output_text.delta',delta='unfinished')]))
    guard=BudgetedProvider(p,tmp_path,max_usd=2,max_calls=5)
    with pytest.raises(IncompleteGeneration):
        guard.generate(system='hi',user='there',max_output_tokens=60)
    data=json.loads((tmp_path/'api_usage_guard.json').read_text('utf8'))
    assert data['failed_requests_this_session']==1
    assert data['unknown_exposure_usd']>0


def test_no_credentials_or_user_specific_model_in_distribution_source():
    import studio.teamsoclo_api as api
    contents=Path(api.__file__).read_text('utf8')
    assert 'private-testing-key' not in contents
    assert 'model-of-key' not in contents
    assert 'gpt-astra' not in contents  # no hard-coded model catalogue


def test_validation():
    with pytest.raises(ContractError):TeamSocLoProvider('','model')
    with pytest.raises(ContractError):TeamSocLoProvider('key','')
    with pytest.raises(ContractError):make(FakeClient()).generate(system='s',user='u',max_output_tokens=0)


def test_teamsoclo_end_to_end_lazy_two_steps(tmp_path):
    """Use the real lazy guide engine with a mocked Responses-compatible gateway."""
    from studio.guide_flow import GuideFlow
    rule_dir=tmp_path/'rules'
    rule_dir.mkdir()
    (rule_dir/'HUONG_DAN.txt').write_text(
        '1- TẠO DRAFT\nĐọc FIRST.txt. Xuất draft.txt.\n'
        '2- TẠO FINAL\nĐọc SECOND.txt. Dùng draft.txt LOCK, xuất final.txt.\n',encoding='utf8')
    (rule_dir/'FIRST.txt').write_text('FIRST_ONLY_TOKEN\n',encoding='utf8')
    (rule_dir/'SECOND.txt').write_text('SECOND_ONLY_TOKEN\n',encoding='utf8')
    src=tmp_path/'input.txt';src.write_text('STORY_SOURCE_TOKEN\n',encoding='utf8')
    project=GuideFlow.create(tmp_path/'project',None,[rule_dir],[src])
    outputs=[
        '@@FILE:draft.txt@@\nNội dung draft',
        '{"verdict":"PASS","issues":[]}',
        '@@FILE:final.txt@@\nNội dung final',
        '{"verdict":"PASS","issues":[]}',
    ]
    fake=FakeClient()
    def create(**kwargs):
        fake.kwargs.append(kwargs)
        answer=outputs.pop(0)
        return Stream([item(type='response.output_text.delta',delta=answer),
                       item(type='response.completed',response=finished(answer))])
    fake.responses=item(create=create)
    provider=make(fake)
    provider.model='fake-model'
    first=project.run_next(provider,max_output_tokens=1000)
    assert first['state']=='LOCKED'
    assert project.status()['completed']==1
    assert all('SECOND_ONLY_TOKEN' not in str(req) for req in fake.kwargs[:2])
    assert 'FIRST_ONLY_TOKEN' in fake.kwargs[0]['instructions']
    assert 'STORY_SOURCE_TOKEN' in fake.kwargs[0]['input']
    second=project.run_next(provider,max_output_tokens=1000)
    assert second['state']=='LOCKED'
    assert project.status()['finished']
    assert 'SECOND_ONLY_TOKEN' in fake.kwargs[2]['instructions']
    assert 'Nội dung draft' in fake.kwargs[2]['input']
    assert not outputs


def test_gui_wires_all_four_providers_and_paid_probe():
    gui=(Path(__file__).parents[1]/'studio'/'guide_gui.py').read_text('utf8')
    assert "('TeamSocLo API','teamsoclo')" in gui
    assert "return TeamSocLoProvider(key,model)" in gui
    assert "fetch_teamsoclo_models(self.key)" in gui
    assert "probe_teamsoclo_model(self.key,self.model)" in gui
    assert "self.btn_probe=QPushButton('Thử model')" in gui
    assert 'QMessageBox.question(self,\'Thử model — có thể tính phí\'' in gui
