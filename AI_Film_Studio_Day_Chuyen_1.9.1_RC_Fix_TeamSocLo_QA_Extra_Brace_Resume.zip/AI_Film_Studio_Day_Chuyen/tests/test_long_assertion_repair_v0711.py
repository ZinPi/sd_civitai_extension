"""v0.7.11 regressions: real-world long statements, contextual errors, safe retry.

Offline only; no user documents included in the application package.
"""
import json
from pathlib import Path

import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.rule_conflicts import (MAX_ASSERTION_QUOTE_CHARS, MAX_ASSERTION_VALUE_CHARS,
                                   validate_assertions)
from studio.rule_options import analyze_rules, pending_analysis_chunks, analysis_plan


def response(claims=()):
    return {'summary':'Đã đọc nguyên đoạn nguồn', 'steps':[], 'deliverables':[],
            'questions':[], 'warnings':[], 'blockers':[], 'assertions':list(claims)}


def claim(filename, line, quote, value, topic='thuộc tính'):
    return {'source_file':filename, 'source_line':line, 'source_quote':quote,
            'topic':topic, 'value':value}


class SequenceModel:
    def __init__(self, responses):
        self.responses=list(responses)
        self.calls=[]
    def generate(self, *, system, user, max_output_tokens):
        self.calls.append((system,user))
        nxt=self.responses.pop(0)
        if isinstance(nxt, Exception):
            raise nxt
        return Generation(json.dumps(nxt, ensure_ascii=False))


def test_long_686_character_source_value_is_valid_if_verbatim():
    value='quy tắc ' + 'kiểm tra ' * 70
    assert 160 < len(value) < MAX_ASSERTION_VALUE_CHARS
    line='Thuộc tính bắt buộc: ' + value + ' kết thúc.'
    files={'B7.txt':line}
    assertions=validate_assertions([claim('B7.txt',1,line,value)],files)
    assert assertions[0]['value']==value.strip()
    assert assertions[0]['source_quote']==line


def test_complete_source_quote_over_900_is_allowed_when_anchored():
    value='lời kể chuẩn'
    line='Hướng dẫn: ' + ('nội dung dài, ' * 91) + value
    assert len(line)>900
    assert len(line)<MAX_ASSERTION_QUOTE_CHARS
    result=validate_assertions([claim('B7.txt',1,line,value)],{'B7.txt':line})
    assert result[0]['source_quote']==line


def test_contextual_errors_do_not_hide_file_line():
    line='Quy tắc đầu ra: ' + ('A' * 1200)
    with pytest.raises(ContractError, match=r'B7\.txt:1.*900'):
        validate_assertions([claim('B7.txt',1,line,'A'*1100)],{'B7.txt':line})
    with pytest.raises(ContractError, match=r'B7\.txt:1.*nguyên văn'):
        validate_assertions([claim('B7.txt',1,line,'KHÔNG TỒN TẠI')],{'B7.txt':line})
    with pytest.raises(ContractError, match=r'B7\.txt:99.*bằng chứng'):
        validate_assertions([claim('B7.txt',99,line,'A')],{'B7.txt':line})


def test_invalid_long_assertion_retries_only_failed_chunk(tmp_path):
    first='Ngôn ngữ đầu ra: tiếng Việt.'
    second='Ghi chú: ' + 'A' * 1200
    files={'a.txt':first, 'b.txt':second}
    bad=claim('b.txt',1,second,'A'*1050)
    good=claim('b.txt',1,second,'A'*750)
    model=SequenceModel([response(),response([bad]),response([good])])
    messages=[]
    report=analyze_rules(files,model,messages.append,
                         checkpoint_dir=tmp_path,provider_identity='openai:test')
    assert len(model.calls)==3
    assert report['segment_count']==2
    assert any('Thử xác minh lại riêng đoạn này' in m for m in messages)
    assert 'LƯỢT SỬA LỖI' in model.calls[2][0]
    assert pending_analysis_chunks(files,tmp_path,'openai:test')==0
    unchanged=SequenceModel([])
    after=analyze_rules(files,unchanged,checkpoint_dir=tmp_path,provider_identity='openai:test')
    assert after['cache_hits']==2
    assert not unchanged.calls


def test_second_failure_blocks_project_but_successful_chunks_remain_cached(tmp_path):
    files={'a.txt':'Số câu: 5','b.txt':'Thuộc tính: ' + 'A' * 1100}
    bad=claim('b.txt',1,files['b.txt'],'A'*1050)
    first=SequenceModel([response(),response([bad]),response([bad])])
    with pytest.raises(ContractError,match=r'b\.txt.*phần 2/2.*b\.txt:1'):
        analyze_rules(files,first,checkpoint_dir=tmp_path,provider_identity='openai:model')
    assert pending_analysis_chunks(files,tmp_path,'openai:model')==1
    ok=SequenceModel([response([claim('b.txt',1,files['b.txt'],'A'*600)])])
    report=analyze_rules(files,ok,checkpoint_dir=tmp_path,provider_identity='openai:model')
    assert report['cache_hits']==1
    assert len(ok.calls)==1


def test_unrecoverable_validation_does_not_create_cache(tmp_path):
    files={'a.txt':'Ngôn ngữ đầu ra: tiếng Việt.'}
    fake='Không có trong văn bản.'
    bad=response([claim('a.txt',1,fake,'bịa')])
    model=SequenceModel([bad,bad])
    with pytest.raises(ContractError,match='a.txt:1'):
        analyze_rules(files,model,checkpoint_dir=tmp_path,provider_identity='one')
    assert pending_analysis_chunks(files,tmp_path,'one')==1
    assert len(model.calls)==2


def test_reject_quote_over_absolute_limit_without_silent_cut():
    line='Quy trình: ' + 'A' * (MAX_ASSERTION_QUOTE_CHARS+20)
    with pytest.raises(ContractError,match=r'B7\.txt:1.*trích dẫn dài'):
        validate_assertions([claim('B7.txt',1,line,'A'*100)],{'B7.txt':line})
