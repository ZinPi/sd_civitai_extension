"""OpenAI provider boundary, replaceable by FakeProvider for offline tests."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol
from .contract import ContractError

@dataclass
class Generation:
    text:str
    input_tokens:int=0
    output_tokens:int=0
    cached_tokens:int=0

class IncompleteGeneration(ContractError):
    """A response can be incomplete AND have metered usage."""
    def __init__(self,status,reason,input_tokens=0,output_tokens=0,cached_tokens=0):
        super().__init__('Phản hồi API chưa hoàn tất: '+str(status)+'; lý do: '+str(reason or 'không rõ')+
                         '. Có thể đã phát sinh phí.')
        self.input_tokens=input_tokens
        self.output_tokens=output_tokens
        self.cached_tokens=cached_tokens

class Provider(Protocol):
    def generate(self, *, system:str, user:str, max_output_tokens:int)->Generation:...

class OpenAIProvider:
    provider_id='openai'
    is_live=True  # real network API adapter; fake providers must never mark FINAL
    def __init__(self,api_key:str,model:str,reasoning_effort:str='medium'):
        from openai import OpenAI
        if not api_key:raise ContractError('Chưa có API key')
        # Disable SDK's invisible network retry; the session request/cost guard
        # must account for every retry explicitly.
        self.client=OpenAI(api_key=api_key,timeout=180,max_retries=0)
        self.model=model
        self.effort=reasoning_effort
    def generate(self, *, system:str,user:str,max_output_tokens:int)->Generation:
        kwargs=dict(model=self.model,instructions=system,input=user,max_output_tokens=max_output_tokens,store=False)
        if self.effort not in ('','default'):
            kwargs['reasoning']={'effort':self.effort}
        r=self.client.responses.create(**kwargs)
        usage=getattr(r,'usage',None)
        details=getattr(usage,'input_tokens_details',None)
        input_tokens=int(getattr(usage,'input_tokens',0) or 0)
        output_tokens=int(getattr(usage,'output_tokens',0) or 0)
        cached_tokens=int(getattr(details,'cached_tokens',0) or 0)
        if r.status != 'completed':
            reason=getattr(getattr(r,'incomplete_details',None),'reason',None)
            raise IncompleteGeneration(r.status,reason,input_tokens,output_tokens,cached_tokens)
        output=r.output_text or ''
        if not output.strip(): raise ContractError('GPT API không trả về văn bản')
        return Generation(output,input_tokens,output_tokens,cached_tokens)
