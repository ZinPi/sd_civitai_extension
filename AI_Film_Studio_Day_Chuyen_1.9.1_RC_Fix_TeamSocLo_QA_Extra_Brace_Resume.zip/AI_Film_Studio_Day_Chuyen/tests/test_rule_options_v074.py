"""Offline tests: no paid API calls; new mandatory human-review gate."""
import json
import zipfile
import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.engine import Studio, RunBlocked
from studio.rule_options import (
    read_rules, chunks, analyze_rules, validate_answers, confirmed_choices_text,
    validate_chunk, rules_digest, MAX_ANALYSIS_CHARS,
)

TEXT = ('Quy trình: chia nội dung thành các cảnh.\n'
        'Người dùng phải chọn phong cách: Cổ điển hoặc Hiện đại.\n'
        'Người dùng nhập số cảnh cần tạo.\n'
        'Thành phẩm: bản phân cảnh văn bản.')


def report_part():
    return {
        'summary': 'Tạo bản phân cảnh theo văn bản nguồn.',
        'steps': ['Chia nội dung thành cảnh'],
        'deliverables': ['Bản phân cảnh văn bản'],
        'questions': [
            {'question': 'Chọn phong cách?', 'kind': 'single', 'required': True,
             'choices': ['Cổ điển', 'Hiện đại'], 'source_file': 'QUY_TAC.txt',
             'source_line': 2, 'source_quote': 'chọn phong cách: Cổ điển hoặc Hiện đại'},
            {'question': 'Số cảnh cần tạo?', 'kind': 'number', 'required': True,
             'choices': [], 'source_file': 'QUY_TAC.txt', 'source_line': 3,
             'source_quote': 'Người dùng nhập số cảnh cần tạo.'},
        ],
        'warnings': [], 'blockers': [],
    }


class AnalyzerFake:
    def __init__(self, answers):
        self.answers = answers
        self.calls = 0
    def generate(self, *, system, user, max_output_tokens):
        self.calls += 1
        assert 'TRÍCH NGUYÊN VĂN' in system
        assert 'L2: ' in user
        assert max_output_tokens == 6400
        return Generation(json.dumps(self.answers, ensure_ascii=False))


def test_read_rules_and_zip(tmp_path):
    p = tmp_path/'QUY_TAC.txt'; p.write_text(TEXT, encoding='utf8')
    assert read_rules([p]) == {'QUY_TAC.txt': TEXT}
    z = tmp_path/'rules.zip'
    with zipfile.ZipFile(z, 'w') as zipfileobj:
        zipfileobj.writestr('QUY_TAC.txt', TEXT)
    assert read_rules([z]) == {'QUY_TAC.txt': TEXT}
    with pytest.raises(ContractError, match='trùng tên'):
        read_rules([p, z])


def test_analysis_extracts_questions_with_grounded_quotes(tmp_path):
    p = tmp_path/'QUY_TAC.txt'; p.write_text(TEXT, encoding='utf8')
    engine = AnalyzerFake(report_part())
    results = analyze_rules(read_rules([p]), engine)
    assert engine.calls == 1
    assert results['file_count'] == 1
    assert len(results['questions']) == 2
    assert results['questions'][0]['id'] == 'q001'
    assert results['steps'] == ['Chia nội dung thành cảnh']
    assert results['deliverables'] == ['Bản phân cảnh văn bản']
    assert results['rules_digest'] == rules_digest({'QUY_TAC.txt': TEXT})
    assert results['reviewed'] is False


def test_answers_required_and_exact_choice(tmp_path):
    p = tmp_path/'QUY_TAC.txt'; p.write_text(TEXT, encoding='utf8')
    report = analyze_rules(read_rules([p]), AnalyzerFake(report_part()))
    with pytest.raises(ContractError, match='chưa trả lời'):
        validate_answers(report, {'q001': 'Hiện đại'})
    with pytest.raises(ContractError, match='ngoài các phương án'):
        validate_answers(report, {'q001': 'Khoa học viễn tưởng', 'q002': '30'})
    answers = validate_answers(report, {'q001': 'Hiện đại', 'q002': '30'})
    frozen = confirmed_choices_text(report, answers)
    assert 'Hiện đại' in frozen
    assert 'CÂU TRẢ LỜI ĐÃ XÁC NHẬN: "30"' in frozen
    assert 'QUY_TAC.txt:2' in frozen
    assert 'Khoa học viễn tưởng' not in frozen


def test_wrong_source_line_or_hallucinated_quote_is_blocked():
    part = report_part()
    part['questions'][0]['source_quote'] = 'không tồn tại trong file'
    with pytest.raises(ContractError, match='không nguyên văn'):
        validate_chunk(part, {'QUY_TAC.txt': TEXT}, 'QUY_TAC.txt')


def test_blockers_refuse_run_even_if_questions_answered(tmp_path):
    doc = report_part()
    doc['blockers'] = ['Quy tắc A mâu thuẫn với quy tắc B']
    report = analyze_rules({'QUY_TAC.txt': TEXT}, AnalyzerFake(doc))
    # AI-only text is not a verified blocker. Grounded conflicts remain blocking.
    assert not report['blockers']
    assert any('chưa dẫn chứng' in w for w in report['warnings'])
    assert 'Hiện đại' in confirmed_choices_text(report, {'q001': 'Hiện đại', 'q002': '30'})


def test_no_choices_requires_review_but_no_value(tmp_path):
    doc = dict(report_part(), questions=[])
    # Explicit user-choice lines cannot be dropped merely because AI returns [].
    with pytest.raises(ContractError, match='bỏ sót'):
        analyze_rules({'QUY_TAC.txt': TEXT}, AnalyzerFake(doc))


def test_false_boolean_is_explicit_answer():
    q = dict(report_part()['questions'][0], kind='yes_no', choices=[], question='Bật chế độ A?')
    report = dict(report_part(), questions=[dict(q, id='q001')])
    assert validate_answers(report, {'q001': False}) == {'q001': False}
    with pytest.raises(ContractError, match='chưa trả lời'):
        validate_answers(report, {})
    assert 'Không' in confirmed_choices_text(report, {'q001': False})


def test_large_input_blocks_before_provider_charge():
    fake = AnalyzerFake(report_part())
    with pytest.raises(ContractError, match='không được bỏ sót'):
        analyze_rules({'QUY_TAC.txt': 'A' * (MAX_ANALYSIS_CHARS + 1)}, fake)
    assert fake.calls == 0


def test_long_line_is_not_silently_truncated():
    line = 'Q' * 22_000
    result = list(chunks({'large.txt': line}))
    assert len(result) >= 2
    full = ''.join(row[4:] for _, part in result for row in part.splitlines())
    assert full == line


def test_locked_choices_detect_external_edit(tmp_path):
    project = Studio(tmp_path/'project')
    try:
        with pytest.raises(ContractError):
            # No options file from earlier projects is still fine.
            project.rule_files()
        assert project._confirmed_options() == ''
        project.import_rule_inputs([_make(tmp_path, '00_TUY_CHON_NGUOI_DUNG.txt', 'CHỐT: A')])
        (project.folder/'user_choices_confirmed.txt').write_text('CHỐT: B', encoding='utf8')
        with pytest.raises(RunBlocked, match='bị sửa'):
            project._confirmed_options()
        (project.folder/'user_choices_confirmed.txt').write_text('CHỐT: A', encoding='utf8')
        assert project._confirmed_options() == 'CHỐT: A'
    finally:
        project.close()


def _make(tmp, name, content):
    f = tmp/name
    f.write_text(content, encoding='utf8')
    return f
