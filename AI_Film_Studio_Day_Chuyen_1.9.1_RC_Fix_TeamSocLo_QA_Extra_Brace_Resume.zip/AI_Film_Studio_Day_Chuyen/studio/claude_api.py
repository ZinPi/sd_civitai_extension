"""Anthropic Claude Messages adapter for the dynamic text-contract engine.

No tool-use or external code execution: text in, text out. SDK retries disabled so
BudgetedProvider remains the only request/cost guard.
"""
from __future__ import annotations
from .api import Generation, IncompleteGeneration
from .contract import ContractError


class ClaudeProvider:
    is_live = True
    provider_id = 'anthropic'

    def __init__(self, api_key: str, model: str, reasoning_effort: str = 'default', *, client_factory=None):
        if not api_key.strip():
            raise ContractError('Chưa có Claude API key.')
        if not model.strip():
            raise ContractError('Chưa chọn Claude model.')
        if client_factory is None:
            from anthropic import Anthropic
            client_factory = Anthropic
        self.client = client_factory(api_key=api_key.strip(), timeout=180, max_retries=0)
        self.model = model.strip()
        self.effort = 'default'  # Claude has a separate API/configuration for adaptive thinking.

    def generate(self, *, system: str, user: str, max_output_tokens: int) -> Generation:
        response = self.client.messages.create(
            model=self.model,
            max_tokens=max_output_tokens,
            system=system,
            messages=[{'role':'user', 'content':user}],
        )
        usage = getattr(response, 'usage', None)
        # Claude usage reports uncached input separately from cache read/write tokens.
        noncached = int(getattr(usage, 'input_tokens', 0) or 0)
        cache_read = int(getattr(usage, 'cache_read_input_tokens', 0) or 0)
        cache_creation = int(getattr(usage, 'cache_creation_input_tokens', 0) or 0)
        output = int(getattr(usage, 'output_tokens', 0) or 0)
        total_input = noncached + cache_read + cache_creation
        stop = getattr(response, 'stop_reason', None)
        if stop not in ('end_turn', 'stop_sequence'):
            raise IncompleteGeneration('Claude: ' + str(stop),
                                       'đã chạm giới hạn đầu ra hoặc kết thúc bất thường',
                                       total_input, output, cache_read)
        content = '\n'.join(getattr(block, 'text', '') for block in getattr(response, 'content', ())
                            if getattr(block, 'type', None) == 'text')
        if not content.strip():
            raise ContractError('Claude API không trả về văn bản.')
        return Generation(content, total_input, output, cache_read)


def fetch_claude_models(api_key: str, *, client_factory=None) -> list[str]:
    """List current account's Claude model IDs, without paid generation requests."""
    if not api_key.strip():
        raise ValueError('Hãy nhập Claude API key.')
    if client_factory is None:
        from anthropic import Anthropic
        client_factory = Anthropic
    try:
        client = client_factory(api_key=api_key.strip(), timeout=30, max_retries=0)
        page = client.models.list(limit=100)
        models = [str(getattr(item, 'id', '')) for item in page.data]
        result = sorted({mid for mid in models if mid.startswith('claude-')}, reverse=True)
    except Exception as exc:
        cls = type(exc).__name__
        messages = {
            'AuthenticationError': 'Claude API key không hợp lệ (401).',
            'PermissionDeniedError': 'Tài khoản không có quyền xem danh sách model (403).',
            'RateLimitError': 'Claude API đang giới hạn tần suất (429).',
            'APIConnectionError': 'Không kết nối được Claude API.',
            'APITimeoutError': 'Kết nối Claude API quá thời gian chờ.',
        }
        raise ValueError(messages.get(cls, 'Không lấy được model Claude (' + cls + ').')) from None
    if not result:
        raise ValueError('Không có Claude text model trong danh sách trả về; bạn có thể nhập mã model thủ công.')
    return result
