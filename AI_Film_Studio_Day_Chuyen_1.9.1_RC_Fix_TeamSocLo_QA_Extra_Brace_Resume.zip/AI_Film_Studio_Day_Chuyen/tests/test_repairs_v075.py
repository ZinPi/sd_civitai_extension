"""New regression coverage for independently reproduced 0.7.4 defects."""
import json
from pathlib import Path

import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.engine import Studio
from studio.one_click import BudgetedProvider, new_project_folder
from studio.project_setup import analysis_budget_dir, initialize_approved_project
from studio.rule_options import analyze_rules, validate_answers, confirmed_choices_text


RULES = ("Quy trình: viết tóm tắt văn bản.\n"
         "Người dùng chọn phong cách: Cổ điển hoặc Hiện đại.\n"
         "Người dùng phải nhập số cảnh trong khoảng từ 5 đến 10 (số nguyên).\n"
         "Nếu người dùng chọn Có thì xuất thêm tài liệu nhân vật.\n")


def proposal(choices=None):
    return dict(summary='Tóm tắt theo quy tắc', steps=['Tóm tắt'], deliverables=['TOM_TAT.txt'],
        questions=[
            dict(question='Chọn phong cách?', kind='single', required=True,
                 choices=['Cổ điển', 'Hiện đại'] if choices is None else choices,
                 source_file='QUY_TAC.txt', source_line=2,
                 source_quote='chọn phong cách: Cổ điển hoặc Hiện đại'),
            dict(question='Số cảnh?', kind='number', required=True, choices=[],
                 source_file='QUY_TAC.txt', source_line=3,
                 source_quote='Người dùng phải nhập số cảnh'),
            dict(question='Xuất thêm nhân vật?', kind='yes_no', required=True, choices=[],
                 source_file='QUY_TAC.txt', source_line=4,
                 source_quote='Nếu người dùng chọn Có thì xuất thêm tài liệu nhân vật.'),
        ], warnings=[], blockers=[])


class FakeAnalyzer:
    def __init__(self, data): self.data = data; self.model = 'offline-model'; self.effort = 'default'; self.is_live = False; self.calls = 0
    def generate(self, *, system, user, max_output_tokens):
        self.calls += 1
        return Generation(json.dumps(self.data, ensure_ascii=False), input_tokens=40, output_tokens=100)


def analyze():
    return analyze_rules({'QUY_TAC.txt': RULES}, FakeAnalyzer(proposal()))


def test_hallucinated_enum_options_are_blocked_even_if_quote_is_real():
    for bad in (['Kinh dị', 'Hài'], ['Cổ điển', 'Hiện đại hư cấu'], ['Điển', 'Hiện đại']):
        with pytest.raises(ContractError, match='không có trong quy tắc'):
            analyze_rules({'QUY_TAC.txt': RULES}, FakeAnalyzer(proposal(bad)))


def test_valid_enum_option_accepts_literal_phrases():
    report = analyze()
    assert report['questions'][0]['choices'] == ['Cổ điển', 'Hiện đại']
    assert report['schema_version'] == 2


@pytest.mark.parametrize('value', ['-999', '4', '11', '6.5', '-1', 'NaN', 'Infinity'])
def test_numeric_range_integer_and_finite_validation(value):
    with pytest.raises(ContractError, match='giới hạn|số nguyên|Giá trị số'):
        validate_answers(analyze(), {'q001': 'Hiện đại', 'q002': value, 'q003': False})


@pytest.mark.parametrize('value', ['5', '6', '10'])
def test_numeric_inclusive_valid_boundaries(value):
    result = validate_answers(analyze(), {'q001': 'Cổ điển', 'q002': value, 'q003': False})
    assert result['q002'] == value


def test_false_conditional_choice_retained_and_pinned():
    report = analyze()
    text = confirmed_choices_text(report, {'q001': 'Hiện đại', 'q002': '6', 'q003': False})
    assert 'Không' in text and 'Hiện đại' in text


def test_project_created_after_preflight_usage_without_folder_collision(tmp_path):
    rule_path = tmp_path / 'QUY_TAC.txt'
    rule_path.write_text(RULES, encoding='utf-8')
    target = new_project_folder(tmp_path)
    assert not any(target.iterdir())
    preflight = analysis_budget_dir(target)
    preflight.mkdir(parents=True)
    model = FakeAnalyzer(proposal())
    safe_model = BudgetedProvider(model, preflight, max_usd=2, max_calls=2)
    report = analyze_rules({'QUY_TAC.txt': RULES}, safe_model)
    assert not any(target.iterdir())  # No V6 sentinel collision before starting.
    assert (preflight / 'api_usage_guard.json').exists()
    answers = {'q001': 'Hiện đại', 'q002': '6', 'q003': False}
    project = initialize_approved_project(target, [rule_path], report, answers)
    try:
        assert (target / '.ai_film_studio_v6').exists()
        assert (target / 'analysis_api_usage' / 'api_usage_guard.json').exists()
        assert '00_TUY_CHON_NGUOI_DUNG.txt' in project.rule_files()
        assert project._confirmed_options() == (target / 'user_choices_confirmed.txt').read_text(encoding='utf-8')
        assert (target / 'PHAN_TICH_QUY_TAC.txt').is_file()
        assert json.loads((target / 'TUY_CHON_DA_CHON.json').read_text(encoding='utf-8')) == {'q001': 'Hiện đại', 'q002': '6', 'q003': False}
    finally:
        project.close()
    reopened = Studio(target)
    try: assert 'Hiện đại' in reopened._confirmed_options()
    finally: reopened.close()


def test_stale_rules_fail_before_creating_project(tmp_path):
    f = tmp_path / 'QUY_TAC.txt'; f.write_text(RULES+'\nBổ sung nội dung.', encoding='utf-8')
    target = tmp_path / 'project'
    with pytest.raises(ContractError, match='thay đổi'):
        initialize_approved_project(target, [f], analyze(), {'q001': 'Cổ điển', 'q002': '7', 'q003': False})
    assert not target.exists()


def test_reserved_option_name_rejected_without_overwriting_rule(tmp_path):
    f = tmp_path / '00_TUY_CHON_NGUOI_DUNG.txt'
    f.write_text(RULES, encoding='utf-8')
    report = analyze_rules({'00_TUY_CHON_NGUOI_DUNG.txt': RULES}, FakeAnalyzer(dict(proposal(), questions=[dict(q, source_file='00_TUY_CHON_NGUOI_DUNG.txt') for q in proposal()['questions']])))
    with pytest.raises(ContractError, match='trùng tên'):
        initialize_approved_project(tmp_path / 'p', [f], report, {})
    assert f.read_text(encoding='utf-8') == RULES


def test_blockers_prevent_writing_project(tmp_path):
    report = analyze()
    report['blockers'] = ['Không đủ điều kiện để tạo văn bản.']
    file = tmp_path / 'QUY_TAC.txt'
    file.write_text(RULES, encoding='utf-8')
    with pytest.raises(ContractError, match='mâu thuẫn'):
        initialize_approved_project(tmp_path / 'p', [file], report, {})
    assert not (tmp_path / 'p').exists()


def test_choices_in_adjacent_bullets_are_grounded():
    source = 'Chọn phong cách:\n- Cổ điển\n- Hiện đại\n\nBắt đầu sản xuất.'
    doc = dict(proposal(), questions=[dict(proposal()['questions'][0], source_line=1,
                 source_quote='Chọn phong cách:')])
    assert len(analyze_rules({'QUY_TAC.txt': source}, FakeAnalyzer(doc))['questions']) == 1
    doc['questions'][0]['choices'] = ['Cổ điển', 'Kinh dị']
    with pytest.raises(ContractError, match='không có trong quy tắc'):
        analyze_rules({'QUY_TAC.txt': source}, FakeAnalyzer(doc))


def test_report_tampering_is_detectable_against_frozen_choices(tmp_path):
    f = tmp_path / 'QUY_TAC.txt'; f.write_text(RULES, encoding='utf-8')
    project = initialize_approved_project(tmp_path / 'p', [f], analyze(),
                                           {'q001': 'Hiện đại', 'q002': '6', 'q003': False})
    try:
        saved = json.loads((project.folder / 'PHAN_TICH_QUY_TAC.json').read_text(encoding='utf-8'))
        saved['numeric_constraints']['q002']['maximum'] = '9999'
        bogus = confirmed_choices_text(saved, {'q001': 'Hiện đại', 'q002': '6', 'q003': False})
        assert bogus != project._confirmed_options()
    finally:
        project.close()


def test_number_minimum_and_maximum_with_exclusive_bounds():
    rules = 'Người dùng nhập số trang: trên 5 và dưới 10, số nguyên dương.'
    q = dict(proposal()['questions'][1], source_file='S.txt', source_line=1,
             source_quote='Người dùng nhập số trang: trên 5 và dưới 10, số nguyên dương.')
    report = analyze_rules({'S.txt': rules}, FakeAnalyzer(dict(proposal(), questions=[q])))
    assert validate_answers(report, {'q001': '6'})['q001'] == '6'
    for x in ('5', '10', '-6', '8.5'):
        with pytest.raises(ContractError): validate_answers(report, {'q001': x})


def test_explicit_choices_with_trailing_production_instruction():
    source = 'Người dùng PHẢI CHỌN độ dài: 3 câu HOẶC 5 câu trước khi sản xuất.'
    q = dict(proposal()['questions'][0], choices=['3 câu', '5 câu'], source_file='QUY_TAC.txt',
             source_line=1, source_quote='độ dài: 3 câu HOẶC 5 câu trước khi sản xuất.')
    doc = dict(proposal(), questions=[q])
    assert len(analyze_rules({'QUY_TAC.txt': source}, FakeAnalyzer(doc))['questions']) == 1
