"""Offline regression: verify TuanSu wire contract, no real HTTP/key usage."""
from pathlib import Path
from types import SimpleNamespace as Obj
import pytest
from studio.api import IncompleteGeneration
from studio.contract import ContractError
from studio.tuansu_api import (TuansuProvider, fetch_tuansu_models,
                               probe_tuansu_model, TUANSU_BASE_URL)
from studio.one_click import BudgetedProvider

class Fake:
    def __init__(self, reply=None, mids=None, error=None):
        self.reply=reply
        self.error=error
        self.history=[]
        self.data=mids if mids is not None else ['gpt-5.6-luna','grok-4.7','text-embedding-3-small',
                                                 'Qwen-TTS','IMAGE-generation']
        self.chat=Obj(completions=Obj(create=self._create))
        self.models=Obj(list=self._list)
    def _create(self, **kwargs):
        self.history.append(kwargs)
        if self.error:raise self.error
        return self.reply or response('OK')
    def _list(self):
        if self.error:raise self.error
        return Obj(data=[Obj(id=m) for m in self.data])

def response(content,reason='stop',input_tokens=12,output_tokens=3,cached_tokens=4):
    return Obj(choices=[Obj(finish_reason=reason,message=Obj(content=content))],
               usage=Obj(prompt_tokens=input_tokens,completion_tokens=output_tokens,
                         prompt_tokens_details=Obj(cached_tokens=cached_tokens)))

def factory(fake):
    def mk(**kwargs):
        assert kwargs['base_url']==TUANSU_BASE_URL
        assert kwargs['max_retries']==0
        assert kwargs['timeout'] in (30,180)
        assert kwargs['api_key']=='key-fake'
        return fake
    return mk

def test_chat_adapter_form_and_usage():
    f=Fake(response('Xin chào'))
    p=TuansuProvider('key-fake','gemini-3.8-flash-high', client_factory=factory(f))
    r=p.generate(system='S',user='U',max_output_tokens=900)
    assert (r.text,r.input_tokens,r.output_tokens,r.cached_tokens)==('Xin chào',12,3,4)
    assert f.history==[{'model':'gemini-3.8-flash-high',
                        'messages':[{'role':'system','content':'S'},{'role':'user','content':'U'}],
                        'max_tokens':900,'n':1,'stream':False}]
    assert (p.provider_id,p.concurrency_limit)==('tuansu',2)

@pytest.mark.parametrize('reason',['length','content_filter','tool_calls',None])
def test_incomplete_never_accepted_and_metering_saved(reason):
    p=TuansuProvider('key-fake','model',client_factory=factory(Fake(response('PARTIAL',reason))))
    with pytest.raises(IncompleteGeneration) as x:
        p.generate(system='S',user='U',max_output_tokens=200)
    assert (x.value.input_tokens,x.value.output_tokens)==(12,3)

@pytest.mark.parametrize('bad',[None,'',[],[{'type':'image','image_url':'x'}]])
def test_empty_or_unsupported_text_never_passes(bad):
    p=TuansuProvider('key-fake','model',client_factory=factory(Fake(response(bad))))
    with pytest.raises(ContractError):p.generate(system='S',user='U',max_output_tokens=200)

def test_text_parts_supported_without_inventing_content():
    p=TuansuProvider('key-fake','model',client_factory=factory(
        Fake(response([{'type':'text','text':'A'},{'type':'text','text':'B'}]))))
    assert p.generate(system='S',user='U',max_output_tokens=200).text=='A\nB'

@pytest.mark.parametrize('status,expected',[ (400,'400'),(401,'401'),(403,'403'),
                                               (404,'404'),(429,'429'),(503,'503') ])
def test_http_errors_are_explicit_and_do_not_leak_credentials(status,expected):
    class UpstreamError(Exception):pass
    e=UpstreamError('key-fake TOP_SECRET request body')
    e.status_code=status
    p=TuansuProvider('key-fake','model',client_factory=factory(Fake(error=e)))
    with pytest.raises(ContractError) as x:p.generate(system='S',user='U',max_output_tokens=200)
    assert expected in str(x.value)
    assert 'key-fake' not in str(x.value)
    assert 'TOP_SECRET' not in str(x.value)


def test_model_list_is_account_derived_and_filters_other_media():
    assert fetch_tuansu_models('key-fake',client_factory=factory(Fake()))==['gpt-5.6-luna','grok-4.7']


def test_model_list_is_not_claimed_supported_on_error():
    class NotFoundError(Exception):status_code=404
    with pytest.raises(ValueError) as x:
        fetch_tuansu_models('key-fake',client_factory=factory(Fake(error=NotFoundError('key-fake'))))
    assert 'nhập mã model' in str(x.value)
    assert 'key-fake' not in str(x.value)


def test_paid_probe_uses_same_chat_endpoint_and_small_request():
    f=Fake()
    usage=probe_tuansu_model('key-fake','grok-4.7',client_factory=factory(f))
    assert usage==(12,3)
    assert len(f.history)==1 and f.history[0]['max_tokens']<=128
    assert f.history[0]['model']=='grok-4.7'


def test_budget_guard_tracks_gateway_and_parallelism(tmp_path):
    p=TuansuProvider('key-fake','model',client_factory=factory(Fake()))
    b=BudgetedProvider(p,tmp_path,max_usd=5,max_calls=5)
    assert b.provider_id=='tuansu' and b.concurrency_limit==2
    b.generate(system='x',user='hi',max_output_tokens=10)
    contents=(tmp_path/'api_usage_guard.json').read_text('utf8')
    assert 'tuansu' in contents and 'KHÔNG phải giá TuanSu/VND' in contents
    assert 'key-fake' not in contents


def test_gui_integration_routing_present_without_importing_pyside6():
    # Headless CI cannot open Windows GUI: assert all entry paths are wired.
    ui=(Path(__file__).parents[1]/'studio/minimal_gui.py').read_text('utf8')
    assert "self.provider.addItem('TuanSu API', 'tuansu')" in ui
    assert ui.count("base = TuansuProvider(values['api_key'], values['model'])")==2
    assert ui.count("probe_tuansu_model(values['api_key'], values['model'])")==2
    assert "else fetch_tuansu_models(self.api_key) if self.provider == 'tuansu'" in ui
    engine=(Path(__file__).parents[1]/'studio/engine.py').read_text('utf8')
    assert "getattr(provider,'concurrency_limit',3)" in engine
