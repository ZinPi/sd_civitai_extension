"""Adversarial release, lineage, and checkpoint tests (no paid API)."""
from __future__ import annotations
import copy, json, zipfile
import pytest
from studio.contract import validate_contract, ContractError
from studio.api import Generation
from studio.qa import validate_content
from studio.rule_audit import collect_candidates
from tests.test_core import env, FakeProvider

class ContentProvider(FakeProvider):
    def __init__(self, content):
        super().__init__()
        self.content = content
    def generate(self, *, system, user, max_output_tokens):
        self.calls += 1
        if 'JSON {"verdict"' in system:
            return Generation('{"verdict":"PASS","issues":[]}', 100, 45, 0)
        self.text_calls += 1
        return Generation(self.content, 100, 75, 0)


def test_a_b_a_same_revision_and_no_extra_api(env):
    s, raw, f, z = env
    s.approve(f)
    a=s.run(ContentProvider('Nhân vật bước vào căn phòng.'),max_usd=50)
    with zipfile.ZipFile(a) as archive:
        original=archive.read('03_SCENE_PROMPTS/SCENE_PROMPT_FINAL.txt')
        original_manifest=json.loads(archive.read('PROJECT_MANIFEST.json'))
    s.import_source_text('SOURCE_STORY','Thời điểm truyện B.')
    b=s.run(ContentProvider('Nhân vật ra hành lang.'),max_usd=50)
    with zipfile.ZipFile(b) as archive:
        assert archive.read('03_SCENE_PROMPTS/SCENE_PROMPT_FINAL.txt')!=original
    s.import_source_text('SOURCE_STORY','Một câu chuyện gốc.')
    fake=ContentProvider('KHÔNG ĐƯỢC GỌI')
    c=s.run(fake,max_usd=50)
    assert fake.calls==0
    with zipfile.ZipFile(c) as archive:
        assert archive.read('03_SCENE_PROMPTS/SCENE_PROMPT_FINAL.txt')==original
        assert json.loads(archive.read('PROJECT_MANIFEST.json'))['artifacts']==original_manifest['artifacts']


def test_mock_cannot_mark_production_final(env):
    s,raw,f,z=env
    s.approve(f)
    result=s.run(ContentProvider('Nhân vật nhìn quanh.'),max_usd=50)
    assert result.parent.name=='TEST_OUTPUT'
    assert not (s.folder/'FINAL').exists()
    with zipfile.ZipFile(result) as archive:
        assert json.loads(archive.read('PROJECT_MANIFEST.json'))['status']=='TEST_ONLY'


def test_synthetic_vs_live_like_cache_disjoint(env):
    s,raw,f,z=env
    s.approve(f)
    s.run(ContentProvider('Nhân vật đứng ở cửa.'),max_usd=50)
    live=ContentProvider('Nhân vật bước lên bậc thềm.')
    live.is_live=True; live.model='mock-live-for-regression'
    result=s.run(live,max_usd=50)
    assert live.text_calls==3
    assert result.parent.name=='FINAL'


def test_placeholder_content_blocked_even_if_reviewer_passes(env):
    s,raw,f,z=env
    s.approve(f)
    with pytest.raises(ContractError,match='chưa hoàn thành'):
        s.run(ContentProvider('PLACEHOLDER_CHUA_QA'),max_usd=50)
    assert not (s.folder/'TEST_OUTPUT').exists()


def test_partial_handoff_blocked(env):
    s,raw,f,z=env
    updated=copy.deepcopy(raw)
    updated['stages'][1]['instructions']='Bàn giao:\nHANDOFF_STATUS: PARTIAL\n{{PROMPTS}}'
    f.write_text(json.dumps(updated),encoding='utf8')
    s.approve(f)
    with pytest.raises(ContractError,match='chưa hoàn thành'):
        s.run(ContentProvider('Nhân vật đứng ngoài trời.'),max_usd=50)


def test_missing_release_checks_blocked(env):
    s,raw,f,z=env
    updated=copy.deepcopy(raw);updated.pop('release_checks')
    with pytest.raises(ContractError,match='release_checks'):
        validate_contract(updated,s.rule_files(),s.rule_hash())


def test_release_validator_nonempty_alone_blocked(env):
    s,raw,f,z=env
    updated=copy.deepcopy(raw)
    updated['release_checks']['HANDOFF']['validators']=[{'type':'nonempty'}]
    with pytest.raises(ContractError,match='không đủ'):
        validate_contract(updated,s.rule_files(),s.rule_hash())


def test_missing_lineage_source_blocked(env):
    s,raw,f,z=env
    updated=copy.deepcopy(raw)
    updated['release_checks']['HANDOFF']['source_inputs']=['MISSING']
    with pytest.raises(ContractError,match='liên kết'):
        validate_contract(updated,s.rule_files(),s.rule_hash())


def test_template_without_input_usage_blocked(env):
    s,raw,f,z=env
    updated=copy.deepcopy(raw);updated['stages'][1]['instructions']='TỰ BỊA NỘI DUNG'
    with pytest.raises(ContractError,match='template bắt buộc'):
        validate_contract(updated,s.rule_files(),s.rule_hash())


def test_clause_coverage_gap_blocked(env):
    s,raw,f,z=env
    updated=copy.deepcopy(raw);updated['clause_coverage']=updated['clause_coverage'][:1]
    with pytest.raises(ContractError,match='Chưa phân loại'):
        validate_contract(updated,s.rule_files(),s.rule_hash())


def test_clause_coverage_ignore_requires_explanation(env):
    s,raw,f,z=env
    updated=copy.deepcopy(raw)
    clause=updated['clause_coverage'][1];clause['decision']='NOT_APPLICABLE';clause['stage_ids']=[];clause['reason']='không'
    with pytest.raises(ContractError,match='giải thích'):
        validate_contract(updated,s.rule_files(),s.rule_hash())


def test_version_locked_delivery_policy(env):
    s,raw,f,z=env
    s.approve(f)
    (s.folder/'delivery_policy.json').write_text(json.dumps({'required_roles':['scene_prompts']}),encoding='utf8')
    with pytest.raises(ContractError,match='đã thay đổi'):
        s.active_contract()


def test_last_second_source_change_blocks_export(env,monkeypatch):
    s,raw,f,z=env;s.approve(f)
    orig=s.store.source_hashes;count=[0]
    def mutated():
        count[0]+=1
        hashes=orig()
        if count[0]>1:hashes['SOURCE_AUDIO']='1'*64
        return hashes
    monkeypatch.setattr(s.store,'source_hashes',mutated)
    with pytest.raises(ContractError,match='đã thay đổi'):
        s.run(ContentProvider('Nhân vật quay người.'),max_usd=50)


def test_selected_revision_dependency_mismatch_blocks(env,monkeypatch):
    s,raw,f,z=env;s.approve(f)
    orig=s.store.artifact_dependencies
    def corrupt(revision):
        deps=orig(revision)
        if 'SOURCE_AUDIO' in deps:deps['SOURCE_AUDIO']='f'*64
        return deps
    monkeypatch.setattr(s.store,'artifact_dependencies',corrupt)
    with pytest.raises(ContractError,match='Phụ thuộc'):
        s.run(ContentProvider('Nhân vật ngồi xuống.'),max_usd=50)


def test_json_schema_generic_typed_data():
    validator={'type':'json_schema','schema':{'type':'object','required':['id','states'],
        'properties':{'id':{'type':'string','pattern':'^CHAR_[0-9]+$'},
                      'states':{'type':'array','minItems':1}}}}
    assert not validate_content('{"id":"CHAR_01","states":["visible"]}',[validator],{})
    assert validate_content('{"id":"BG_01","states":[]}',[validator],{})
    assert validate_content('{"id":"CHAR_01"}',[validator],{})


def test_remote_json_schema_ref_blocked():
    validator={'type':'json_schema','schema':{'$ref':'https://example.com/remote.json'}}
    assert 'tham chiếu động' in str(validate_content('{}',[validator],{}))


def test_rule_inventory_new_unrelated_filename():
    contents={'RULES_FOR_NEW_PIPELINE.md':'Step 1 phải làm trước.\nChỉ là ghi chú.\nNever invent identities.'}
    dispositions={'RULES_FOR_NEW_PIPELINE.md':{'role':'PRODUCTION'}}
    assert collect_candidates(contents,dispositions)=={'RULES_FOR_NEW_PIPELINE.md':[1,3]}


def test_chunks_qa_per_unit_instead_of_oversized_whole_source(env):
    s,raw,f,z=env
    updated=copy.deepcopy(raw)
    stage=updated['stages'][0]
    stage['scope']='chunks';stage['output_type']='text';stage['chunk_lines']=1
    stage['validators']=[{'type':'nonempty'}]
    updated['release_checks']['PROMPTS']['validators']=[{'type':'required_sections','values':['Nhân vật']}]
    updated['release_checks']['HANDOFF']['validators']=[{'type':'required_sections','values':['Bàn giao:','Nhân vật']}]
    f.write_text(json.dumps(updated),encoding='utf8');s.approve(f)
    api=ContentProvider('Nhân vật đi vào phòng.')
    s.run(api,max_usd=50)
    assert api.calls==6
