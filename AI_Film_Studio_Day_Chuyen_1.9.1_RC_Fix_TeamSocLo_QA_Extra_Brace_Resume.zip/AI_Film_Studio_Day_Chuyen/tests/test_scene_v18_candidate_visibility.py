"""Regression for real 1.7 RC Windows screenshot: candidate misclassified as continuity.

These tests require that QA neither spends REPAIR on a model's mistaken
'candidate missing' report nor trusts that report as evidence of a story flaw.
"""
import json
from types import SimpleNamespace as NS
import pytest

from studio.contract import ContractError
from studio.guide_flow import GuideFlow
from studio.guide_scene import _window_qa_input, _candidate_visibility_failure
from tests.test_scene_responsive_v14 import project, SceneProvider
from tests.test_scene_v17_scope_resume import _Provider, window_folder


class CandidateConfusion(SceneProvider):
    def __init__(self, persist=False, only_window=None):
        super().__init__()
        self.persist=persist
        self.only_window=only_window

    def generate(self, *, system, user, max_output_tokens):
        if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
            self.calls.append((system,user,max_output_tokens))
            target=self.only_window is None or f'WINDOW {self.only_window}' in user
            if target and (self.persist or 'KIỂM TRA LẠI NHÃN DỮ LIỆU:' not in system):
                return NS(text=json.dumps({'verdict':'FAIL','issues':[
                    'Không có candidate cho STEP_001 trong cửa sổ hiện tại. Phần CANDIDATE nằm dưới nhãn CONTINUITY TRƯỚC, nên không thể đối chiếu nguồn.'],
                    'continuity':'Không có thông tin đáng tin cậy'},ensure_ascii=False))
            return NS(text=json.dumps({'verdict':'PASS','issues':[],
                'continuity':'Đã đối chiếu chính xác source và candidate của cửa sổ'}))
        return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)


def test_candidate_first_delimited_and_window_one_has_no_empty_continuity():
    msg=_window_qa_input(1,'ORIGINAL_SOURCE_1','REAL_CANDIDATE_1','','','')
    assert msg.index('BEGIN_CANDIDATE_WINDOW_1') < msg.index('BEGIN_SOURCE_WINDOW_1')
    assert 'REAL_CANDIDATE_1' in msg and 'ORIGINAL_SOURCE_1' in msg
    assert 'BEGIN_PRIOR_CONTINUITY' not in msg
    assert f'LENGTH={len("REAL_CANDIDATE_1")}' in msg


def test_qa_conflates_candidate_with_continuity_rechecks_without_story_repair(tmp_path):
    flow=project(tmp_path)
    p=CandidateConfusion()
    result=flow.run_next(p,max_output_tokens=1600,repair_attempts=2)
    assert result['state']=='LOCKED'
    checks=[(s,u) for s,u,_ in p.calls if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in s]
    assert checks
    assert any('KIỂM TRA LẠI NHÃN DỮ LIỆU:' in s for s,_ in checks)
    assert all('BEGIN_CANDIDATE_WINDOW_' in u and 'BEGIN_SOURCE_WINDOW_' in u for _,u in checks)
    assert not any('CHỈ SỬA ĐÚNG LỖI QA' in s for s,_,_ in p.calls)
    folder=window_folder(flow)
    assert not list(folder.glob('window_*_repair_*.txt'))


def test_repeated_false_missing_candidate_blocks_without_repair_or_lock(tmp_path):
    flow=project(tmp_path)
    p=CandidateConfusion(persist=True)
    with pytest.raises(ContractError,match='liên tục báo thiếu/nhầm CANDIDATE'):
        flow.run_next(p,max_output_tokens=1600,repair_attempts=2)
    checks=[(s,u) for s,u,_ in p.calls if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in s]
    assert len(checks)==2  # 1 QA + 1 focused recheck; no story repair
    assert flow.status()['completed']==0
    assert not any('CHỈ SỬA ĐÚNG LỖI QA' in s for s,_,_ in p.calls)
    folder=window_folder(flow)
    assert (folder/'window_00001_candidate.txt').exists()
    assert (folder/'window_00001_candidate.json').exists()
    assert not (folder/'window_00001.json').exists() # no false PASS


def test_resume_v17_checkpoint_rechecks_latest_repair_in_new_qa_format(tmp_path):
    flow=project(tmp_path)
    with pytest.raises(ContractError,match='QA chưa PASS'):
        flow.run_next(_Provider(),max_output_tokens=1600,repair_attempts=2)
    folder=window_folder(flow)
    p1=(folder/'window_00001.json').read_bytes()
    p2=(folder/'window_00002.json').read_bytes()
    assert (folder/'window_00003_repair_2.txt').exists()
    # A version-3 QA failure must be discarded as a reviewer-layout failure;
    # the version-4 reviewer sees repair_2, not regenerated source.
    doc=json.loads((folder/'window_00003_qa.json').read_text(encoding='utf8'))
    doc['qa_scope_version']=3
    doc['verdict']='FAIL'
    doc['issues']=['Không có candidate; nó nằm dưới nhãn CONTINUITY TRƯỚC']
    (folder/'window_00003_qa.json').write_text(json.dumps(doc),encoding='utf8')
    follow=CandidateConfusion(only_window=3)
    result=GuideFlow(flow.folder).run_next(follow,max_output_tokens=1600,repair_attempts=2)
    assert result['state']=='LOCKED'
    assert (folder/'window_00001.json').read_bytes()==p1
    assert (folder/'window_00002.json').read_bytes()==p2
    rechecks=[u for s,u,_ in follow.calls if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in s and 'WINDOW 3.' in u]
    assert rechecks and all('R2_WINDOW_3' in u for u in rechecks)
    assert not (folder/'window_00003_repair_3.txt').exists()


def test_real_local_defect_still_not_misclassified_as_visibility():
    assert not _candidate_visibility_failure(['Candidate bỏ sót một scene beat nguồn và sai canon.'])
    assert _candidate_visibility_failure(['Không có candidate cho STEP_001 trong cửa sổ hiện tại'])


def test_real_b1_seven_step_guide_has_candidate_envelope_and_preserves_future_rules(tmp_path):
    """Run the user's actual 72KB B1 with a fake API, including screenshot failure."""
    from pathlib import Path
    root=Path('/mnt/data')
    if not (root/'QUY_TRINH_HUONG_DAN_CHO_TOOL.txt').is_file():
        pytest.skip('User files absent from environment')
    (tmp_path/'novel.txt').write_text(('Một diễn biến nối tiếp của câu chuyện. '*80+'\n\n')*12,encoding='utf8')
    flow=GuideFlow.create(tmp_path/'real_project',root/'QUY_TRINH_HUONG_DAN_CHO_TOOL.txt',
                          [root/f'B{i}.txt' for i in range(1,8)],[tmp_path/'novel.txt'])
    p=CandidateConfusion(only_window=1)
    outcome=flow.run_next(p,max_output_tokens=5000,repair_attempts=2)
    assert outcome['state']=='LOCKED'
    qas=[(system,user) for system,user,_ in p.calls if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system]
    assert qas
    assert all('BEGIN_CANDIDATE_WINDOW_' in user for _,user in qas)
    assert all('quy tắc b1.txt' in system.casefold() for system,_ in qas)
    assert all('quy tắc b2.txt' not in system.casefold() for system,_ in qas)
    assert not any('CHỈ SỬA ĐÚNG LỖI QA' in sys for sys,_,_ in p.calls)
