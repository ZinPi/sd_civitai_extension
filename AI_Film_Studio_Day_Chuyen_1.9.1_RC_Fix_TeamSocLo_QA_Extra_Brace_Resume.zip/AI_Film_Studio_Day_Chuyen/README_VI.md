# AI FILM STUDIO — DÂY CHUYỀN HƯỚNG DẪN (BẢN 1.9.1 RC — SỬA LỖI JSON THỰC TẾ)

## Cập nhật 1.9.1 RC — Sửa đúng QA JSON do TeamSocLo trả về (26/10/2026)

**Lỗi đã được tái hiện từ phản hồi QA thật người dùng cung cấp**: model trả `{"verdict":"FAIL","issues":[...]}` rồi viết tiếp `,"continuity":"..."}`, tức đóng ngoặc `}` quá sớm trước trường `continuity`. Phản hồi này dài 1304 ký tự, SHA-256 `f72e0fe43f9cfd17a7163c008d6c68bd6a578b10be97c22289b572bad976f363`.

- Parser chỉ bỏ **một dấu `}` thừa** nếu sau đó là **duy nhất** trường chuỗi `continuity` và dấu kết thúc hợp lệ, kết quả ghép là một JSON hoàn chỉnh, không trùng khóa. Tuyệt đối không tự tạo verdict/issues/continuity hay tự chuyển `FAIL` thành `PASS`.
- Nếu thư mục dự án cũ có `window_XXXXX_qa_invalid.json`, tool kiểm tra dấu vết `contract`, `source_sha`, `candidate_sha`, `scope_version`, độ dài và SHA-256 của phản hồi thô, `response_truncated=false`. Chỉ khi toàn bộ khớp và JSON đọc được an toàn, **sử dụng lại kết quả QA đó mà không gọi API thêm lần nữa**. Nếu file sai/mất/hỏng/khác candidate/khác model hoặc không đọc được, không tự coi là QA PASS.
- Bản phản hồi thực tế mang `verdict=FAIL` và 2 nhận xét. Đây là **FAIL thật của model** sau khi đọc được; tool sẽ đi đúng nhánh xử lý QA, không được tự LOCK. Đúng/sai ngữ nghĩa của 2 nhận xét còn phải đối chiếu nguyên tác và B1; parser không phán xét thay.
- Những trường hợp có hai JSON, verdict mâu thuẫn, trùng khóa, phản hồi thiếu hoặc thêm nội dung lạ vẫn bị chặn.
- Giữ bốn API OpenAI / Claude / TuanSu / TeamSocLo, cơ chế tuần tự 7 bước, checkpoint và GUI co giãn. Không đụng đến 8 quy tắc TXT.

**Cách tiếp tục:** sao lưu thư mục dự án; giải nén ZIP 1.9.1 RC vào thư mục mới; mở dự án cũ và giữ nguyên nguồn/quy tắc/API/model, sau đó CHẠY BƯỚC HIỆN TẠI. Nếu file phản hồi lỗi từ v1.9 còn khớp, tool sẽ đọc lại không phát sinh lượt QA lặp cho phản hồi này. Nếu kết quả là FAIL, những lần REPAIR/QA sau đó vẫn có thể phát sinh phí; kiểm tra các nhận xét QA trước khi quyết định chạy tiếp.

**Giới hạn:** mới kiểm thử tự động offline; chưa xác nhận TeamSocLo thật trên Windows. Việc sửa cú pháp JSON không đảm bảo model đánh giá chính xác chất lượng B1 hay chắc chắn không timeout.

## Cập nhật 1.9 RC — QA trả JSON sai định dạng sau REPAIR

- **Lỗi thực tế trong log:** Sau khi TeamSocLo đã sinh và REPAIR một cửa sổ, model QA trả phản hồi không được parser JSON cũ chấp nhận; trước đây công cụ báo chung `Bộ kiểm tra không trả JSON hợp lệ, chưa PASS.` nhưng không lưu nội dung phản hồi để xác minh nguyên nhân thực.
- **Bộ đọc JSON an toàn:** Nhận một JSON QA hoàn chỉnh được bao trong code fence, có nhãn kết quả đơn giản, dấu phẩy cuối thừa hoặc xuống dòng chưa escape bên trong chuỗi. Giữ nguyên giá trị thực của `verdict`, `issues` và các trường gate; tuyệt đối không suy đoán PASS/FAIL, không lấy JSON minh họa làm verdict.
- **Chặn định dạng không đáng tin:** JSON bị cắt, trùng khóa, hai object có thể mâu thuẫn, PASS kèm issues hoặc thiếu issues khi FAIL đều bị từ chối. Không tự gọi lại request có thể đã tính phí. Phản hồi thô không hợp lệ của QA cửa sổ được lưu ở `candidates/STEP_XXX/scene_windows/<fingerprint>/window_XXXXX_qa_invalid.json` **trong thư mục dự án của người dùng**, gồm hash nguồn và bản ứng viên để đối chiếu. File có thể chứa nội dung riêng tư; không chia sẻ công khai nguyên file nếu chưa xem nội dung.
- **Không sửa truyện vì lỗi JSON:** Candidate và các bản `repair_N.txt` được giữ với SHA-256; mở lại dự án với cùng model/rules/output cap sẽ QA tiếp ứng viên đã hoàn tất, không gọi lại sinh/REPAIR chỉ vì phản hồi QA sai cú pháp.
- **Giữ nguyên checkpoint PASS và 4 nhà cung cấp:** không thay fingerprint thực thi, không sửa B1–B7, không gọi trước quy tắc của bước sau.
- **Kiểm thử:** Có thêm regression cho đúng chuỗi QA FAIL → REPAIR → JSON dở dang → khôi phục bản sửa và các trường hợp JSON mâu thuẫn. Chỉ được kiểm tra offline bằng API giả lập, **chưa xác định chính xác TeamSocLo thực tế trả chuỗi nào khi lỗi**, chưa nghiệm thu Windows/API thật.

## Cập nhật 1.8 RC — QA nhận nhầm CANDIDATE là CONTINUITY TRƯỚC

- **Lỗi thực tế đã tái hiện từ ảnh Windows:** Ở B1, model QA trả FAIL vì bảo không có `CANDIDATE`, hoặc bảo nội dung candidate nằm dưới `CONTINUITY TRƯỚC`, dù ứng viên đã được lưu và truyền vào QA. Bản 1.7 có thể dùng kết luận sai này để yêu cầu **REPAIR** nhiều lần, tiêu phí và chặn cả những bản chuyển thể chưa được QA đúng cách.
- **Đóng khung đầu vào QA:** Mỗi request gửi rõ `BEGIN_CANDIDATE_WINDOW_N / END_CANDIDATE_WINDOW_N` và `BEGIN_SOURCE_WINDOW_N / END_SOURCE_WINDOW_N`, ghi độ dài và SHA-256; đưa ứng viên lên trước; ghi chú continuity trước đó nằm trong khung RIÊNG ở sau; **không phát nhãn continuity rỗng ở cửa sổ đầu tiên**.
- **Không sửa truyện khi model nhầm trường dữ liệu:** Với lỗi QA báo thiếu/nhầm candidate, tool chạy **tối đa một lượt QA xác minh lại nhãn dữ liệu**. Nếu vẫn không thể nhìn thấy ứng viên đã gửi, tool báo lỗi **model QA nhận sai dữ liệu**, giữ candidate, **KHÔNG tự chạy hai lượt REPAIR vô nghĩa** và KHÔNG giả PASS. Lượt QA xác minh lại là một request API có thể tính phí.
- **Phân biệt lỗi thật:** Nếu QA cho rằng candidate thiếu chi tiết, sai canon, nói sát nguyên tác, sai tiếng Tây Ban Nha hoặc không đúng quy tắc, vẫn **FAIL/REPAIR theo bằng chứng**; logic chỉ chặn việc sửa do model đọc nhầm nhãn/trường dữ liệu.
- **Tiếp tục dự án B1 từ 1.7:** Giữ nguyên định danh checkpoint và những cửa sổ `window_XXXXX.json` đã QA PASS. QA chưa PASS (scope cũ 1.7) phải được chạy lại với cấu trúc v1.8; ưu tiên bản sửa mới nhất có receipt, không sinh lại phần đã hoàn tất. Giữ nguyên cùng project, nguồn, model, nhà cung cấp, giới hạn output và quy tắc.
- **Không chỉnh bộ B1–B7** và không bỏ điều khoản nào trong B1. Cả bốn API vẫn sẵn có.
- **Giới hạn kiểm chứng:** Đã thử với API giả lập, gồm trường hợp model cố ý báo sai hệt ảnh và thử B1/hướng dẫn thật. **Chưa chứng minh model TeamSocLo thật sẽ không bao giờ nhầm dữ liệu**, chưa thử Windows trực tiếp, không cam kết 100% hiệu quả. Không có API Key nào được sử dụng trong test.

## Cập nhật 1.7 RC — lỗi cửa sổ B1 FAIL do target 40% và lặp REPAIR

- **Giữ nguyên quy tắc B1, không bỏ MODE B 40%.** Mục tiêu cô đọng 40% được đánh giá ở **QA toàn tác phẩm**, KHÔNG lấy việc chưa đủ chứng cứ toàn truyện ở cửa sổ 3/19 để làm lỗi riêng cửa sổ. QA từng cửa sổ vẫn bắt buộc kiểm tra sự cô đọng *theo chức năng*, canon, nguồn, thoại gián tiếp, chất lượng ngôn ngữ và chi tiết không cần thiết. Nếu candidate giữ sát nguồn một cách không phù hợp, QA phải FAIL với lý do cục bộ; không tự PASS.
- Nếu model chỉ báo FAIL vì chưa thấy toàn bộ tác phẩm, tool **rà lại đúng phạm vi một lần**, không lập tức mua hai lượt REPAIR. Nếu model tiếp tục đánh giá sai phạm vi, chương trình dừng an toàn, không giả PASS.
- **Tiếp tục từ bản sửa mới nhất:** Khi khởi động lại dự án B1 đang FAIL, tool đọc bản `window_XXXXX_repair_N.txt` gần nhất thay vì ứng viên gốc. Các bản sửa mới có biên nhận SHA-256; bản sửa của v1.6 không có biên nhận phải QA lại mới được PASS, không tự tin tưởng kết quả cũ.
- QA PASS/FAIL của bản sửa được gắn với hash nguồn/candidate/model/rule; timeout sau sinh bản sửa thì có thể chỉ tiếp tục QA. Các cửa sổ đã có `window_XXXXX.json` QA PASS được giữ khi hợp đồng không đổi.
- Hạn mức **tối đa 4 bản sửa cho cùng cửa sổ cộng dồn qua nhiều lần chạy**, không khởi động lại số lượt bằng cách nhấn CHẠY thêm nhiều lần. Nếu vẫn FAIL, giữ checkpoint và lý do để người dùng xem xét; không tự nới gate.
- Chọn **Mở dự án đã tạo** và giữ nguyên nhà cung cấp, model, cấu hình output, nguồn và quy tắc nếu muốn khôi phục checkpoint 1–2 ở dự án cũ. Nếu hợp đồng thay đổi, không dùng lại dữ liệu không khớp.
- **Chưa kiểm thử TeamSocLo thật trên Windows.** Không thể bảo đảm model luôn tuân thủ phân biệt phạm vi hoặc không timeout; các bài test offline chỉ chứng minh hành vi của mã với API mô phỏng.

## Khác biệt cốt lõi

- **Hướng dẫn điều phối trước.** Chọn bộ file TXT/ZIP có file hướng dẫn (ví dụ `QUY_TRINH_HUONG_DAN.txt`), hoặc chọn file hướng dẫn riêng. Bấm **Đọc hướng dẫn → Tạo kế hoạch**. Bước này **không gọi API và không đọc nội dung của B1–B7**; chỉ đọc hướng dẫn và lập chỉ mục tên các file trong ZIP.
- **Một bước một lần.** Ở bước hiện tại, tool mở nội dung đúng những quy tắc mà hướng dẫn gọi. Nếu hướng dẫn gọi hai quy tắc, tool mở cả hai. Không mở quy tắc của bước tương lai để phân tích trước.
- **Liền mạch thật.** Thành quả sau QA PASS được ghi vào `steps/STEP_XXX/*.txt` và LOCK với SHA-256; toàn bộ thành quả đã khóa có sẵn như dữ liệu cho bước kế tiếp.
- **Không nhảy bước.** Nếu API trả thiếu, QA FAIL, mất file phụ thuộc, quy tắc thay đổi, context quá dài hoặc kết quả chưa hoàn chỉnh, chưa có bước nào được LOCK và không mở bước kế tiếp.
- **Chỉ hỏi người dùng** khi bộ phát hiện tìm thấy câu yêu cầu người dùng lựa chọn thực sự trong các quy tắc của bước hiện tại.
- **Chỉ tạo văn bản**. `CHAR_XX`, `BG_XX` là mã tham chiếu văn bản; không yêu cầu ảnh thật và không tạo ảnh/video.

## Cài đặt trên Windows

1. Giải nén ZIP vào một thư mục mới (không đè phiên bản 0.7.x).
2. Cài Python 3.11 trở lên, có Python Launcher `pyw.exe`.
3. Chạy `MO_AI_FILM_STUDIO.vbs`. Lần đầu công cụ có thể cài thư viện vào `.venv` và ghi tình trạng cài vào `NHAT_KY_KHOI_DONG.txt`. Nếu máy không có kết nối Internet, cài thư viện theo `requirements.txt` bằng cách khác trước.
4. Chọn **TuanSu**, **TeamSocLo**, **OpenAI** hoặc **Claude**; nhập API Key trong ứng dụng; nhấn **Lấy model** hoặc tự nhập mã model. Nhấn **Thử model** (có xác nhận vì có thể tính phí), và tool ghi nhớ lần thử thành công gần đây trong 6 giờ với cùng API Key và model. Không thử lại tự động mỗi lần nhấn chạy.
5. Chọn nguồn truyện TXT/SRT và chọn ZIP hoặc thư mục chứa **các file quy tắc và file hướng dẫn**. Nếu hướng dẫn nằm trong ZIP và có tên chứa `HUONG_DAN` thì không cần chọn riêng.
6. Bấm **Đọc hướng dẫn → Tạo kế hoạch bước (KHÔNG gọi API)**. Đọc danh sách bước và file được gọi trong nhật ký; nếu không đúng, dừng để sửa cách đặt tiêu đề hoặc hướng dẫn.
7. Bấm **CHẠY DUY NHẤT BƯỚC HIỆN TẠI**. Công cụ hỏi xác nhận chi phí, chỉ thử model khi chưa có kết quả thử hợp lệ gần đây, đọc file của đúng bước, gọi API tạo thành quả, gọi API lần hai làm QA. **Chỉ khi QA PASS** mới lưu LOCK và chuyển sang bước tiếp theo.
8. Thành quả ở thư mục dự án: `steps/STEP_001/*.txt`, `steps/STEP_002/*.txt`…; trạng thái khóa tại `workflow.json` (không chỉnh sửa bằng tay). Các kết quả chưa PASS tại `candidates/` để điều tra, không phải thành phẩm chính thức.
9. Bấm **Mở dự án đã tạo** để tiếp tục ở bước chưa khóa. Không phải chạy lại các bước đã PASS/LOCK.

## Định dạng hướng dẫn được nhận diện chắc chắn

Các mục công việc cần có tiêu đề rõ ràng dạng `1- ...`, `2- ...`, `Bước 1: ...`, `STEP 2: ...` và **tên file có đuôi** `.txt/.md/.json/.yaml`. Ví dụ:

```
1- SOẠN THẢO
Đọc QUY_TAC_SOAN_THAO.txt, dùng văn bản nguồn, xuất draft.txt.
2- QA VÀ CHỈNH SỬA
Đọc QUY_TAC_QA.txt và QA_KHAC.txt, dùng draft.txt đã khóa, xuất final.txt.
```

Chỉ các file được viện dẫn trong bước hiện tại mới được nạp vào request API. Nếu hướng dẫn ghi sai tên file, file trùng tên hoặc thiếu file, chương trình dừng và báo đúng tên. Ký hiệu đầu ra từ AI phải là:

```
@@FILE:ten_thanh_pham.txt@@
Nội dung đầy đủ của tệp...
@@FILE:tep_thu_hai.txt@@
Nội dung...
```

Những file đầu ra được hướng dẫn ghi rõ `xuất xyz.txt` sẽ được kiểm tra đủ tên trước khi QA. Dạng `XUẤT FILE TÊN "XX.TXT"` là tên đầu ra dạng biến, không được đưa vào danh sách file QUY TẮC cần đọc. Tên file dữ liệu hỗ trợ được phân loại riêng. Với hướng dẫn hiện hành, `TBN6A.txt` là file dữ liệu hỗ trợ của bước B5/B6 (phải cung cấp thật hoặc tạo trong bước trước), KHÔNG phải một quy tắc và KHÔNG tự sinh nội dung khi chưa có.

## Những thành phần đã dùng lại từ tool cũ

- Giao tiếp **OpenAI Responses API**, **Claude Messages API**, **TuanSu Chat Completions API**, **TeamSocLo Responses API** và truy xuất danh sách model khi có hỗ trợ.
- Bảo vệ ngân sách/giới hạn lượt API ước tính CỘNG DỒN TOÀN DỰ ÁN (không đặt lại khi mở phiên mới), phản hồi lỗi và kết quả không hoàn tất, tránh gửi lại yêu cầu âm thầm.
- Windows launcher không hiển thị cửa sổ CMD; giao diện tối với ba khung chức năng.
- Kiểm tra dòng thật của câu yêu cầu con người lựa chọn; xử lý TXT, ZIP và checkpoint nội dung.
- Mã nguồn cũ và bộ test cũ được giữ làm phần lõi tham khảo, nhưng **giao diện mặc định giờ chỉ khởi động engine DÂY CHUYỀN mới**.

## Kiểm soát xung đột nguồn — thay đổi ở 1.1 RC

- Chỉ rà các **quy tắc được gọi trong bước hiện tại**. Không đọc nội dung B2–B7 khi chạy B1.
- Phát hiện cặp ràng buộc cố định mâu thuẫn bằng bộ so sánh nội bộ; với **bất cứ bước nào có quy tắc, kể cả chỉ một file** chạy thêm lượt rà ngữ nghĩa qua API. Kết quả phải có hai nguồn và hai trích dẫn **khớp nguyên văn file/dòng**; dẫn chứng AI tự bịa bị từ chối.
- Mâu thuẫn cứng phải quyết định ưu tiên; nghi vấn ngữ nghĩa có thể được người dùng xác nhận là không mâu thuẫn. Chỉ ghi quyết định cho **bước đang chạy**; không sửa TXT gốc, không tuyên bố tất cả quy tắc đã sạch tuyệt đối.
- Nếu chưa rà hoặc chưa chọn đủ, công đoạn hiện tại **tạm dừng trước sản xuất**, không làm mất checkpoint của bước đã LOCK. Đổi nhà cung cấp/model phải rà lại.

## Batch dòng/câu theo chính hướng dẫn

Nếu hướng dẫn của bước hiện tại nêu đủ ba thông tin: `1 dòng/câu = 1 IMAGE_PROMPT`, `mỗi lượt N dòng` và `sau M lượt = N×M prompt QA`, tool sẽ dùng chế độ batch:

- Lấy **đúng file nguồn 1 câu/1 dòng** với tên tài liệu đã nêu trong hướng dẫn, không lấy nhầm file TTS hay văn bản nguồn khác. Thử với bộ quy tắc hiện hành sẽ đọc `AUDIO_ES_LATAM_40_ONE_SENTENCE_PER_LINE.txt` đã có từ công đoạn trước.
- Tạo lần lượt **20 dòng/lượt** và sau **5 lượt = 100 prompt** sẽ QA theo quy tắc của bước; lượt cuối ít hơn vẫn QA.
- Kiểm tra bằng mã dòng `IMAGE_PROMPT_000001 | ...` để chặn thiếu/thừa/trùng/đảo prompt. Nếu QA phát hiện lỗi kèm ID, có thể sửa đúng batch liên quan rồi RE-QA. Nếu không biết chính xác phạm vi lỗi, **dừng, không sửa mò**.
- Checkpoint từng cửa sổ đã QA PASS, có mã SHA-256 và fingerprint bao gồm model, nhà cung cấp, hướng dẫn, quy tắc, nguồn, lựa chọn người dùng và giới hạn đầu ra. Đổi model/quyết định bắt buộc sinh lại các cửa sổ liên quan; checkpoint v1.2 không được tái sử dụng vì không có đủ fingerprint.
- Cuối bước vẫn kiểm tra **QA tổng thể toàn bộ nguồn và prompt**. Nếu dữ liệu vượt giới hạn context của model, chương trình giữ các batch PASS nhưng **không khóa toàn bước**.

## Cập nhật 1.6 RC — xử lý timeout TeamSocLo và QA bị ngắt

- **Thử model một lần có thời hạn:** Ghi dấu vân tay SHA-256 của nhà cung cấp/model/key và thời gian thành công; không lưu API Key trong file. Trong 6 giờ, không gửi lại probe nếu cùng thông tin. Đổi key/model hoặc hết hạn phải thử lại. Thử tự động nằm trong sổ ngân sách/lượt API dự án. Nút **Thử model** thủ công vẫn có thể gọi API và phát sinh phí.
- **Nguồn B1 vừa/dài qua gateway:** TeamSocLo và TuanSu sử dụng cửa sổ nguồn tối đa khoảng **2.800 ký tự**, không dùng một request lớn chỉ vì người dùng đặt output cap cao. Giới hạn đầu ra của mỗi cửa sổ được tính riêng (tối đa mức người dùng đặt). Đây là giới hạn kỹ thuật của gateway, không phải quy tắc sáng tác. **Mọi dòng quy tắc B1 vẫn được gửi đầy đủ** ở mỗi lượt; không bỏ hoặc tóm tắt quy tắc.
- **Khôi phục candidate sau lỗi QA:** Khi API đã hoàn tất sinh một phần, file candidate và biên nhận SHA-256 được ghi trước QA. Nếu QA timeout, chạy lại có thể dùng đúng candidate đã xác minh để QA mà không sinh lại phần đó. Candidate chưa QA PASS **không phải thành phẩm đã LOCK**. Candidate sửa tay, thiếu biên nhận hoặc sai model/nguồn/rule sẽ bị chặn.
- **Không tự thử lại request gateway bị lỗi:** TeamSocLo/TuanSu không tự động retry ngay cả khi phản hồi bị cắt vì `max_output_tokens`, để tránh khả năng tính phí lặp. Chương trình giữ đúng bước chưa hoàn thành và người dùng tự quyết định thử lại/đổi model.
- **Giới hạn chưa giải quyết:** TeamSocLo vẫn có thể timeout với B1 rất dài do quy tắc đầy đủ được gửi trong mỗi request. Không có cách chứng nhận gateway ổn định nếu chưa chạy API thật. Những phần sinh chưa nhận phản hồi hoàn tất không có văn bản hợp lệ để khôi phục. Kiểm thử GUI co giãn trực tiếp trên Windows vẫn chưa thực hiện trong môi trường này.

## Cập nhật 1.5 RC — QA toàn nguồn và khôi phục sau gián đoạn

- Sửa lỗi khi `full_qa.json` đã PASS nhưng ứng dụng tắt trước khi LOCK: khi tiếp tục phải đọc lại **đầy đủ** `H_ERROR`, `Q_TOTAL`, mọi trạng thái QA và fingerprint; không được chỉ giữ `verdict`/`issues` rồi báo sai.
- Các checkpoint QA cũ **chỉ kiểm tra hồ sơ continuity** không được dùng để LOCK. Tool giữ nguyên các cửa sổ nguồn đã QA PASS, nhưng chạy lại QA tổng thể bằng cơ chế mới.
- Nếu toàn bộ nguồn và thành phẩm ghép **vừa context đã cấu hình**, gửi cả hai bản nguyên văn đến QA tổng thể để đối chiếu trực tiếp.
- Nếu quá dài, tool QA các nhóm liên tiếp với **đủ source và output nguyên văn của từng cửa sổ**, lưu biên nhận có hash, rồi QA toàn cục trên tất cả báo cáo nhóm và hồ sơ continuity. Không nhóm nào được bị bỏ hoặc lặp. Nếu hồ sơ cuối vẫn quá dài, giữ checkpoint và STOP, không tự LOCK.
- Nếu QA nhóm FAIL hoặc PASS mà thiếu ghi chú kiểm chứng, không được khóa. Bản ghi QA tổng thể ràng buộc nguồn, thành phẩm, nhóm QA, provider/model, quy tắc và quyết định.
- Khi ghi xong TXT đã QA PASS mà ứng dụng bị ngắt trước khi cập nhật `workflow.json`, lần sau xác thực lại **đúng nội dung SHA-256** rồi hoàn tất đăng ký bước. Không ghi đè kết quả khác.
- **Giới hạn:** nhóm QA và ghi chú liên kết không thay thế khả năng hiểu toàn tác phẩm của model. Không có bảo đảm mọi lỗi ngữ nghĩa đều được phát hiện. Chưa kiểm thử trên Windows với API thật; kiểm tra co giãn cửa sổ cần chạy thực tế. B1 vẫn xử lý theo cửa sổ văn bản, chưa phải nhận diện scene nghệ thuật đầy đủ.

## Cập nhật 1.4 RC — B1 dài và cửa sổ Windows

- **Nguồn truyện B1 dài**: phần mềm không còn mặc định từ chối khi văn bản vượt giới hạn đầu ra một request. Những bước được hướng dẫn yêu cầu chuyển thể theo scene và FULL-SCOPE QA có đường chạy riêng chia thành **cửa sổ nguồn nối tiếp**, không cắt bỏ chữ nguồn. Mỗi cửa sổ được chuyển thể, QA, có thể sửa/RE-QA, sau PASS mới lưu checkpoint. Sau đó QA liên kết các cửa sổ kề nhau và QA continuity tổng thể rồi mới LOCK B1.
- **QA B1 chặt hơn**: với hướng dẫn có H_ERROR và Q_TOTAL, một chữ PASS chung không đủ. Cần thêm số H_ERROR = 0, điểm Q_TOTAL thực đạt ngưỡng, cùng trạng thái PASS cho user gate, kiểm tra source toàn bộ, scene QA, full-scope QA, orality và UG khi được yêu cầu. Nếu không có bằng chứng QA đủ, dừng, không LOCK.
- **Tiếp tục được**: đóng app sau checkpoint hợp lệ có thể mở lại đúng dự án, không sinh lại phần đã QA PASS. Đổi model/quy tắc/nguồn hay lựa chọn sẽ không dùng lại checkpoint không khớp.
- **Giới hạn lượt API**: B1 dài có thể cần nhiều request; tool kiểm tra số lượt tối thiểu trước khi gửi để không tiêu ngân sách rồi mới phát hiện không đủ lượt. Các ước tính chi phí vẫn không phải giá nhà cung cấp.
- **Thu nhỏ cửa sổ Windows**: các nút, ô nhập và ba nhóm giới hạn API chuyển 3/2/1 cột theo độ rộng; nội dung cuộn dọc, nhãn tự xuống dòng. Không chỉnh giá trị API khi bạn kéo thay kích thước cửa sổ.
- **Quan trọng**: cửa sổ văn bản không bảo đảm là một scene hoàn chỉnh. Mỗi phần được QA với nguồn; phần nối nhau được kiểm tra continuity, nhưng chưa kiểm chứng thật việc đáp ứng đầy đủ mọi QA-S01…36 và FULL-QA ở các tác phẩm dài bất kỳ. Đây là bản RC để thử có kiểm soát.

## Giới hạn vẫn còn (không tuyên bố đạt 100%)

1. Chưa chạy kiểm chứng thật trên Windows hoặc với API TuanSu/TeamSocLo/OpenAI/Claude thực tế. Các test offline dùng API giả lập.
2. Phân tích xung đột ngữ nghĩa là dựa trên AI; có thể bỏ sót hoặc nêu nghi vấn không cần thiết. Hai trích dẫn thật không tự chứng minh hai câu nhất định mâu thuẫn.
3. Với bước có yêu cầu chuyển thể theo scene và full-scope, engine 1.4 có chia nguồn theo cửa sổ, checkpoint và QA nhiều tầng. Đây là cửa sổ xử lý (không chắc trùng scene thực); model QA vẫn có thể sai và request nhỏ vẫn có thể timeout. Các bước khác có đầu ra quá dài có thể chưa có engine chia riêng.
4. Chế độ batch cần file nguồn có tên chính xác và 1 câu mỗi dòng. Dữ liệu hỗ trợ như `TBN6A.txt` phải tồn tại trong nguồn/ZIP hay trong output các bước trước; tool không tự bịa.
5. Chế độ batch dùng output mỗi dòng `IMAGE_PROMPT_000001 | ...`. Không tự động thực hiện mọi sub-task trung gian mà file hướng dẫn viết thành văn xuôi (ví dụ khâu tổng hợp `XX.TXT` nếu nó không được mô tả rõ là gì). Nếu kết quả thiếu đầu ra phải dừng và kiểm tra lại.
6. B1 dùng đối chiếu nguồn ở từng cửa sổ, QA nối cảnh và tổng hợp continuity trên mọi cửa sổ. Nếu tổng hồ sơ còn vượt context hoặc QA không đủ bằng chứng, tool không được LOCK. B5/B6 vẫn yêu cầu QA tổng thể riêng và có thể phải dừng khi vượt context.
7. QA bởi một model là đánh giá tự động, **không đảm bảo đúng toàn bộ logic hoặc canon**. Mọi bảng giá USD chỉ là dự phòng, không phải phí thực tế của TuanSu/TeamSocLo.
8. Nếu model trả lỗi hoặc kết nối đứt sau khi gửi request, không tự động gửi lại do có thể phát sinh phí trùng.

## Bảo mật

Không gửi API key vào chat/file TXT, không đưa key vào ZIP. Nếu đã từng gửi công khai, hãy thu hồi và tạo key mới. Tool không tạo ảnh/video và chỉ tham chiếu CHAR_XX/BG_XX bằng văn bản.


## Sửa lỗi trọng yếu — v1.3 RC

- **Bước có số lượng đầu ra cụ thể:** nếu hướng dẫn yêu cầu 10 prompt thumbnail, 10 tiêu đề, mô tả đúng 300 từ, tool tạo hợp đồng cấu trúc riêng (`THUMBNAIL_PROMPTS.txt`, `YOUTUBE_TITLES.txt`, `YOUTUBE_DESCRIPTION.txt`) và tự kiểm đếm **trước cả QA model**; không nhận PASS giả cho một câu hoặc thiếu mục. Đây là kiểm tra cấu trúc/số từ, KHÔNG chứng nhận canon hay chất lượng nội dung. Với hướng dẫn khác, chỉ áp dụng những số lượng được viết rõ; không tự đặt 10/300 làm quy tắc chung.
- **Rà ngữ nghĩa trong một file:** không bỏ qua chỉ vì bước có một file quy tắc. Model phải dẫn hai dòng nguồn chính xác; người dùng quyết định khi nghi vấn có thật. Việc phát hiện vẫn có sai số ngữ nghĩa, nên không có lời hứa phát hiện hết mọi xung đột.
- **Checkpoint batch:** fingerprint theo cấu hình sinh, model, tài liệu và quyết định. Batch của model A KHÔNG chuyển thành batch model B khi đổi model; các checkpoint cũ v1.2 được giữ để tra cứu nhưng không dùng lại.
- **Giới hạn API:** cộng dồn theo dự án qua tệp `api_usage_guard.json`, tính cả lượt lỗi và dự phòng rủi ro phí chưa rõ. Đây là mức ước tính cục bộ, KHÔNG phải cam kết giá/quota của nhà cung cấp. Không mở cùng một dự án ở nhiều tiến trình để tránh cạnh tranh ghi sổ.
- **B1 dài:** thay bằng engine cửa sổ nguồn và QA nhiều tầng trong bản 1.4 RC. Cần kiểm thử live để xác nhận tính đúng ngữ nghĩa và QA source/continuity, chưa nghiệm thu 100%.
- **Kiểm thử:** có bài test chuyên biệt cho PASS giả, mâu thuẫn một file, đổi model, đổi quyết định, khôi phục hạn mức sau restart. Chưa thử live API/Windows.

## TeamSocLo — API thứ tư (giữ từ 1.2 RC)

- Trong **API XỬ LÝ VĂN BẢN**, chọn **TeamSocLo API**, nhập key của TeamSocLo và nhấn **Lấy model**. Chỉ chọn mã model mà gói key của bạn được cấp; nếu `/models` không khả dụng, có thể nhập mã từ trang quản lý key. Danh sách model chỉ có tính tham khảo, không chứng minh model chạy được.
- Nhấn **Thử model**, xác nhận yêu cầu có thể tính phí. Tool kiểm tra bằng **Responses API** và luồng streaming, rồi mới cho chạy thử B1. Khi bắt đầu bước mới, nếu đã thử model thành công gần đây bằng cùng API Key thì không phát sinh request thử lại. Khi cần thử tự động, request đó được tính vào sổ lượt/ngân sách toàn dự án.
- Địa chỉ API theo tài liệu nhà cung cấp: `https://gpt.teamsoclo.site/v1`. Công cụ gọi thẳng từ Python; **không cần Codex CLI, Node.js, VS Code hoặc script cài đặt của TeamSocLo**.
- Tool dùng `stream=True` và chỉ coi kết quả hợp lệ khi nhận sự kiện `response.completed`, trạng thái `completed` cùng nội dung văn bản. Nếu đứt luồng, lỗi 524/429, bị cắt đầu ra hoặc thiếu sự kiện hoàn tất: **không LOCK và không tự gửi lại**, bởi request lỗi có thể đã phát sinh phí.
- TeamSocLo được cài riêng, không tự động chuyển từ OpenAI/TuanSu/Claude. Không tích hợp TTS, video, ảnh hay các công cụ lập trình. API key không lưu vào file dự án.
- Quota, context window, giới hạn output, độ trễ và bảng giá **chưa được xác minh với key thật**. Mức giới hạn USD trong ứng dụng là rào chắn nội bộ, không phải bảng giá TeamSocLo.
- **Hạn chế còn lại:** B1 1.4 RC đã có cửa sổ nguồn/QA/checkpoint; vẫn chưa có bộ nhận diện ranh giới scene truyện được nghiệm thu. Streaming không bảo đảm hết HTTP 524; mỗi request vẫn cần phù hợp model/quota. Nên thử nguồn ngắn trước.

Tài liệu nhà cung cấp: `https://docs.teamsoclo.site/cai-dat/codex` (cấu hình `wire_api=responses`), `https://docs.teamsoclo.site/cai-dat/api`.
