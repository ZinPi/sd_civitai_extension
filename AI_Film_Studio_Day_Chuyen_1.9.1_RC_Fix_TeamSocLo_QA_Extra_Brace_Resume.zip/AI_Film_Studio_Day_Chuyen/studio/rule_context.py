"""Auditable per-stage rule retrieval. No BOY/GIRL/VIDEO-specific logic.

Never truncate or summarize a clause silently. Large source files are reduced to
fully preserved paragraphs associated with the stage's explicitly classified
clauses and source evidence. A rule contract with missing/ambiguous coverage
must be rejected upstream. Original rules remain in rules_source.zip.
"""
from __future__ import annotations
from collections import defaultdict
from .contract import ContractError

# Local estimates, configurable per model only after verified context capability.
SHORT_FILE_CHARS=24000
STAGE_RULE_BUDGET=145000
MAX_PARAGRAPH_CONTEXT_LINES=36


def _whole_paragraph(lines:list[str], index:int)->tuple[int,int]:
    """1-based inclusive paragraph; preserve the complete source paragraph."""
    lo=hi=index
    while lo>1 and lines[lo-2].strip():lo-=1
    while hi<len(lines) and lines[hi].strip():hi+=1
    if hi-lo+1>MAX_PARAGRAPH_CONTEXT_LINES:
        # Some authored TXT files contain an entire chapter with no blank lines.
        # Every referenced directive line is still copied verbatim; bounded local
        # neighbors are context only. Never claim this is a complete paragraph.
        lo=max(lo,index-10)
        hi=min(hi,index+10)
    return lo,hi


def stage_rules(stage, contract, files:dict[str,str], *, budget:int=STAGE_RULE_BUDGET) -> str:
    """Return verified stage-relevant excerpts + provenance, or fail closed.

    A mapping is provenance for retrieval, not a mathematical guarantee that an
    LLM classified the rule correctly. The release gate must still perform QA.
    """
    if not hasattr(contract,'raw'):
        raise ContractError('Thiếu hợp đồng quy tắc được xác minh')
    coverage=contract.raw.get('clause_coverage',[])
    by_file=defaultdict(set)
    for e in coverage:
        if e.get('decision')=='ENFORCE' and stage.id in e.get('stage_ids',[]):
            for i in range(e['start'],e['end']+1):by_file[e['file']].add(i)
    for proof in stage.source_evidence:
        name,num=proof.rsplit(':',1)
        by_file[name].add(int(num))
    result=[]
    for name in stage.rules:
        if name not in files:raise ContractError('Thiếu file quy tắc: '+name)
        original=files[name];lines=original.splitlines()
        if len(original)<=SHORT_FILE_CHARS:
            part=f'### {name} (NGUYÊN VĂN)\n'+original
        else:
            refs=sorted(by_file.get(name,()))
            if not refs:
                raise ContractError(f'{stage.id}: file {name} quá dài nhưng thiếu điều khoản được ánh xạ; không cắt ngầm')
            intervals=[]
            for index in refs:
                if index>len(lines) or index<1:
                    raise ContractError(f'{name}:{index} không tồn tại')
                lo,hi=_whole_paragraph(lines,index)
                # Attach nearest section heading only if close enough; never invent
                # or reinterpret a heading that has no source text.
                if lo>1:
                    for back in range(lo-1,max(0,lo-9),-1):
                        t=lines[back-1].strip()
                        if t.startswith(('#','【','[','BƯỚC','STEP','PHẦN')):
                            lo=back;break
                intervals.append((lo,hi))
            intervals.sort();merged=[]
            for lo,hi in intervals:
                if merged and lo<=merged[-1][1]+1:
                    merged[-1]=(merged[-1][0],max(merged[-1][1],hi))
                else:merged.append((lo,hi))
            parts=[f'FILE {name} DÒNG {lo}–{hi} (GIỮ NGUYÊN VĂN):\n'+
                   ''.join(f'{i}: {lines[i-1]}\n' for i in range(lo,hi+1))
                   for lo,hi in merged]
            part=f'### {name} (TRÍCH NGUYÊN VĂN THEO BẰNG CHỨNG)\n'+'\n'.join(parts)
        result.append(part)
    rendered='\n\n'.join(result)
    if len(rendered)>budget:
        raise ContractError(f'{stage.id}: điều khoản quy tắc áp dụng có {len(rendered):,} ký tự, vượt giới hạn đã kiểm soát ({budget:,}). Cần model có context phù hợp hoặc phân rã bước, không bỏ quy tắc.')
    return rendered
