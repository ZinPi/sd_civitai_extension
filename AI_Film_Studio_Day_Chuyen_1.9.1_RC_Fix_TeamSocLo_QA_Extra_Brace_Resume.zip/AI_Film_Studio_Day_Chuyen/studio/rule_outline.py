"""Offline, source-preserving document outline for arbitrary rule TXT/ZIP packs.

This module DOES NOT infer executable workflow, dependency edges, semantics or QA.
It only identifies well-formed visible headings and assigns exact source spans.
Missing / weak headings become one file-level section; no lines are discarded.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib
import json
import os
import re

_TAG = re.compile(r'^\s*\[([\w\-]{2,100})\]\s*$', re.UNICODE)
_MD = re.compile(r'^\s*(#{1,6})\s+(.+?)\s*#*\s*$')
_STEP = re.compile(r'^\s*((?:BƯỚC|BUOC|STEP|PHẦN|PHAN|MỤC|MUC|SECTION|CHAPTER)\s*[_\- ]*\d{1,4}(?:\.\d+)*\b[^\n]*)\s*$', re.I)
_NUM = re.compile(r'^\s*((\d{1,3}(?:\.\d{1,3}){1,4})\s*[.)\-–—:]\s*(.+))$')
_ROMAN = re.compile(r'^\s*([IVXLCDM]{1,8})\.\s+(.+)$')


@dataclass(frozen=True)
class RuleSection:
    key: str
    file: str
    title: str
    start: int
    end: int
    depth: int
    kind: str
    parent: str | None
    executable: bool = False  # Only a separately approved contract may set this.

    def to_dict(self):
        return dict(key=self.key, file=self.file, title=self.title, start=self.start,
                    end=self.end, depth=self.depth, kind=self.kind, parent=self.parent,
                    executable=self.executable)


def heading(line: str):
    """Return (depth, title, kind) or None. This is intentionally conservative."""
    text = line.strip()
    if not text or len(text) > 145: return None
    m = _MD.match(text)
    if m:return min(2 + len(m.group(1)), 7), m.group(2).strip(), 'markdown'
    m = _TAG.fullmatch(text)
    if m:return 3, '[' + m.group(1) + ']', 'tag'
    m = _STEP.fullmatch(text)
    if m:return 2, m.group(1).strip(), 'explicit_step'
    m = _NUM.fullmatch(text)
    if m:
        label = m.group(3).strip()
        # Avoid classifying ordinary numbered instructions as document sections.
        letters = [ch for ch in label if ch.isalpha()]
        if len(letters) < 3 or sum(ch.isupper() for ch in letters) / len(letters) < .78:
            return None
        return 3 + min(m.group(2).count('.'), 3), m.group(1).strip(), 'numbered_heading'
    m = _ROMAN.fullmatch(text)
    if m:
        letters=[ch for ch in m.group(2) if ch.isalpha()]
        if len(letters)>=3 and sum(ch.isupper() for ch in letters)/len(letters)>.8:
            return 3, text, 'roman_heading'
    return None


def outline_for_file(name: str, content: str) -> tuple[RuleSection, ...]:
    lines = content.splitlines()
    total = max(1, len(lines))
    base = hashlib.sha256(name.encode('utf-8')).hexdigest()[:14]
    root_key = f'{base}:file'
    specs = [dict(key=root_key,file=name,title=name,start=1,end=total,depth=0,kind='file',parent=None)]
    stack = [(0, 0)]  # (depth, index in specs)
    for line_no, text in enumerate(lines, 1):
        match = heading(text)
        if match is None:continue
        level,title,kind=match
        # A Markdown # heading is treated as a top-level document heading.
        if kind == 'markdown':level = min(2 + max(0, level - 3), 7)
        while stack and stack[-1][0] >= level:
            depth, prev = stack.pop()
            if prev != 0: specs[prev]['end'] = line_no - 1
        parent = specs[stack[-1][1]]['key'] if stack else root_key
        key = f'{base}:{line_no}'
        specs.append(dict(key=key,file=name,title=title,start=line_no,end=total,
                          depth=level,kind=kind,parent=parent))
        stack.append((level,len(specs)-1))
    return tuple(RuleSection(**spec) for spec in specs)


def build_outline(files: dict[str, str]) -> tuple[RuleSection,...]:
    return tuple(section for name,content in files.items()
                 for section in outline_for_file(name, content))


def display_span(files: dict[str,str], section: RuleSection, max_chars: int = 150000)->str:
    """Preview exact inclusive lines without altering original content."""
    content = files[section.file]
    lines = content.splitlines(keepends=True)
    preview = ''.join(lines[section.start-1:section.end])
    if len(preview) > max_chars:
        preview = preview[:max_chars]+'\n\n[Bản xem trước đã giới hạn kích thước; file nguồn vẫn đầy đủ.]'
    return preview


def outline_stats(sections: tuple[RuleSection,...])->dict:
    return {'files':sum(x.kind=='file' for x in sections),
            'sections':sum(x.kind!='file' for x in sections),
            'candidate_steps':sum(x.kind=='explicit_step' for x in sections)}


class OutlineSelection:
    """User review preferences only, never changes source ZIP or approved contract."""
    def __init__(self, path:Path):self.path=Path(path)

    def read(self, rulepack_sha:str, known_keys:set[str])->set[str]:
        if not self.path.is_file():return set(known_keys)
        try:
            data=json.loads(self.path.read_text(encoding='utf-8'))
            if data.get('rulepack_sha256') != rulepack_sha: return set(known_keys)
            raw=data.get('selected_keys')
            if not isinstance(raw,list) or not all(isinstance(x,str) for x in raw):
                return set(known_keys)
            return set(raw)&known_keys
        except (ValueError,OSError):return set(known_keys)

    def write(self, rulepack_sha:str, selected:set[str], known:set[str]):
        if not selected<=known:raise ValueError('Có ID mục không thuộc bộ quy tắc hiện hành')
        doc={'schema':1,'rulepack_sha256':rulepack_sha,'purpose':'SELECTED_RULE_SCOPE_REQUIRES_VALIDATION',
             'selected_keys':sorted(selected)}
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_name(self.path.name+'.tmp')
        tmp.write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(tmp,self.path)
        return self.path
