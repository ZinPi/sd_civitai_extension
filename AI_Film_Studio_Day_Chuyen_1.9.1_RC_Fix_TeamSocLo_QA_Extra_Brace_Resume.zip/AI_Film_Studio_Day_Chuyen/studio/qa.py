"""Deterministic validators. Fail closed for unsupported predicates."""
from __future__ import annotations
import re
from .contract import ContractError

def audio_lines(src: str) -> list[tuple[str,str]]:
    result=[]
    for ix,line in enumerate(src.splitlines(),1):
        if not line.strip(): continue
        match=re.match(r'^\s*(\d{1,8})\s*(?:\||[.:：]\s+|\t)\s*(.*)$',line)
        key=match.group(1).zfill(3) if match else f'{ix:03d}'
        text=match.group(2).strip() if match else line.strip()
        if not text:raise ContractError(f'Dòng AUDIO {key} rỗng')
        result.append((key,text))
    if not result or len({x[0] for x in result})!=len(result):
        raise ContractError('AUDIO trống hoặc có LINE_ID trùng')
    return result

def validate_content(data: str, validators:tuple[dict,...], sources:dict[str,str]) -> list[str]:
    failures=[]
    # The model is explicitly instructed to emit this marker when evidence is
    # missing. Treat it as a failure EVEN if a reviewer responds PASS.
    if re.search(r'(?m)^\s*(?:[A-Za-z0-9_-]+\|)?ERROR_NEED_EVIDENCE\b',data):
        failures.append('GPT báo thiếu dữ kiện gốc: ERROR_NEED_EVIDENCE; không thể QA PASS')
    for v in validators:
        kind=v['type']
        if kind=='nonempty':
            if not data.strip():failures.append('Nội dung trống')
        elif kind in ('line_id_coverage','unique_line_ids'):
            ref=v.get('source','SOURCE_AUDIO')
            if ref not in sources: failures.append('Thiếu AUDIO cho kiểm tra LINE_ID: '+ref);continue
            expected=[x[0] for x in audio_lines(sources[ref])]
            found=[line.split('|',1)[0].strip() for line in data.splitlines() if line.strip()]
            if kind=='line_id_coverage' and found!=expected:
                failures.append('LINE_ID thiếu, dư hoặc sai thứ tự')
            if kind=='unique_line_ids' and len(found)!=len(set(found)):
                failures.append('LINE_ID xuất hiện lặp')
        elif kind=='prefix':
            prefix=v.get('value','')
            if not prefix or any(not line.startswith(prefix) for line in data.splitlines() if line.strip()):
                failures.append('Sai tiền tố yêu cầu: '+str(prefix))
        elif kind=='required_phrases':
            missing=[x for x in v.get('values',[]) if x not in data]
            if missing:failures.append('Thiếu cụm từ bắt buộc: '+', '.join(missing[:5]))
        elif kind=='forbidden_phrases':
            found=[x for x in v.get('values',[]) if x in data]
            if found:failures.append('Có cụm bị cấm: '+', '.join(found[:5]))
        elif kind=='json_keys':
            import json
            try: obj=json.loads(data)
            except (ValueError,TypeError): failures.append('JSON không hợp lệ');continue
            if not isinstance(obj,dict) or any(key not in obj for key in v.get('values',[])):
                failures.append('Thiếu khóa JSON bắt buộc')
        elif kind=='required_sections':
            # Sections must exist on their own lines, rather than as casual prose.
            sections=[line.strip() for line in data.splitlines()]
            missing=[h for h in v.get('values',[]) if not any(line.startswith(h) for line in sections)]
            if missing: failures.append('Thiếu mục: '+', '.join(missing[:6]))
        elif kind=='json_schema':
            import json
            from jsonschema import Draft202012Validator
            schema=v.get('schema')
            if not isinstance(schema,dict):
                failures.append('Thiếu JSON Schema');continue
            def unsafe_ref(value):
                if isinstance(value,dict):
                    for k,x in value.items():
                        if k in ('$ref','$dynamicRef','$recursiveRef'):
                            # No runtime fetching or resolving user-controlled references.
                            return True
                        if unsafe_ref(x):return True
                elif isinstance(value,list):
                    return any(unsafe_ref(x) for x in value)
                return False
            if unsafe_ref(schema):
                failures.append('JSON Schema tham chiếu động không được phép');continue
            try:
                Draft202012Validator.check_schema(schema)
                instance=json.loads(data)
                errors=list(Draft202012Validator(schema).iter_errors(instance))
                if errors:failures.append('JSON Schema FAIL: '+errors[0].message[:140])
            except (ValueError,TypeError) as exc:
                failures.append('Không đọc được JSON: '+str(exc)[:120])
            except Exception as exc:
                failures.append('JSON Schema lỗi: '+str(exc)[:120])
        elif kind=='entity_refs':
            import json
            ref=v.get('source'); prefix=str(v.get('value',''))
            if ref not in sources or prefix not in ('CHAR','BG'):
                failures.append('Thiếu ledger hoặc loại entity_refs không hỗ trợ');continue
            try:
                master=json.loads(sources[ref])
                coll=master['characters' if prefix=='CHAR' else 'backgrounds']
                allowed={str(item['id']) for item in coll}
            except (ValueError,KeyError,TypeError):
                failures.append('Ledger tham chiếu không phải JSON có ID hợp lệ: '+str(ref));continue
            used=set(re.findall(r'\b'+prefix+r'_\d+\b',data))
            # Empty references may be a valid BG-only or narration scene;
            # source contract can add a required_phrases check when necessary.
            missing=used-allowed
            if missing:failures.append('ID chưa có trong ledger: '+', '.join(sorted(missing)))
        elif kind=='evidence_line_refs':
            import json
            ref=v.get('source','SOURCE_AUDIO')
            if ref not in sources:
                failures.append('Không có AUDIO để đối chiếu evidence_line_refs');continue
            try:
                obj=json.loads(data)
                if not isinstance(obj,dict):raise ValueError()
                entries=obj.get('characters',obj.get('backgrounds',None))
                if not isinstance(entries,list):raise ValueError()
                actual={x[0] for x in audio_lines(sources[ref])}
                for item in entries:
                    ev=item.get('evidence_line_ids',[])
                    if not ev or any(str(key).zfill(3) not in actual for key in ev):
                        failures.append('CHAR/BG thiếu evidence_line_ids hoặc ID không thuộc AUDIO');break
            except (ValueError,KeyError,TypeError):failures.append('Không đọc được evidence_line_refs trong JSON')
        elif kind=='entity_integrity':
            # A general ledger validator, configured by contract rather than
            # assuming fixed MANGA/VIDEO characters or appearance fields.
            import json
            collection=v.get('value','entities')
            required_fields=v.get('values',[])
            try:
                record=json.loads(data)
                items=record.get(collection) if isinstance(record,dict) else None
                if not isinstance(items,list):raise ValueError('không có danh sách '+str(collection))
                seen=set();aliases={}
                for row in items:
                    if not isinstance(row,dict):raise ValueError('mục dữ liệu không phải object')
                    entity_id=row.get('id')
                    if not isinstance(entity_id,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_\-]*',entity_id):
                        raise ValueError('mã entity sai định dạng')
                    if entity_id in seen:raise ValueError('trùng entity_id '+entity_id)
                    seen.add(entity_id)
                    for field in required_fields:
                        if field not in row or row[field] in ('',None,[]):
                            raise ValueError(entity_id+': thiếu trường khóa '+str(field))
                    for alias in [entity_id,*row.get('aliases',[])]:
                        if not isinstance(alias,str) or not alias.strip():raise ValueError('alias trống/sai loại')
                        normalized=alias.strip().casefold()
                        if normalized in aliases and aliases[normalized]!=entity_id:
                            raise ValueError('alias trùng giữa hai entity: '+alias)
                        aliases[normalized]=entity_id
                    states=row.get('states',[])
                    if not isinstance(states,list):raise ValueError('states không phải danh sách')
                    state_ids=set();prior=-1
                    for state in states:
                        if not isinstance(state,dict) or not isinstance(state.get('id'),str):
                            raise ValueError(entity_id+': state không có id')
                        if state['id'] in state_ids:raise ValueError(entity_id+': trùng state id')
                        state_ids.add(state['id'])
                        line=state.get('effective_from_line')
                        if line is not None:
                            start=int(line)
                            if start<prior:raise ValueError(entity_id+': state không theo timeline')
                            prior=start
            except (ValueError,TypeError,KeyError) as exc:
                failures.append('Entity ledger không hợp lệ: '+str(exc)[:150])
        elif kind=='temporal_order':
            import json
            try:
                record=json.loads(data)
                collection=v.get('value','events')
                entries=record.get(collection) if isinstance(record,dict) else None
                if not isinstance(entries,list):raise ValueError('thiếu danh sách sự kiện '+str(collection))
                previous=-1
                for event in entries:
                    if not isinstance(event,dict) or 'line_id' not in event:
                        raise ValueError('sự kiện không có line_id')
                    line=int(event['line_id'])
                    if line<previous or line<0:raise ValueError('timeline lùi hoặc sai')
                    previous=line
            except (ValueError,TypeError,KeyError) as exc:
                failures.append('Timeline không hợp lệ: '+str(exc)[:150])
        elif kind=='nonhuman_scale_lock':
            # Opt-in structural lock: the model must explicitly mark entities
            # nonhuman and provide a stable metric scale. We do not infer
            # species, size, or exceptions that the source did not establish.
            import json
            try:
                body=json.loads(data)
                collection=v.get('value','characters')
                entities=body.get(collection) if isinstance(body,dict) else None
                if not isinstance(entities,list):
                    raise ValueError('Thiếu danh sách '+str(collection))
                for entity in entities:
                    if not isinstance(entity,dict):raise ValueError('entity không phải object')
                    if entity.get('is_nonhuman') is not True:continue
                    eid=str(entity.get('id','UNKNOWN'))
                    if not isinstance(entity.get('species'),str) or not entity['species'].strip():
                        raise ValueError(eid+': thiếu khóa loài phi nhân loại')
                    height=entity.get('height_m')
                    if type(height) not in (float,int) or not 0<height<=10000:
                        raise ValueError(eid+': thiếu/không hợp lệ chiều cao mét')
                    states=entity.get('states',[])
                    if not isinstance(states,list):raise ValueError(eid+': states sai loại')
                    for state in states:
                        if not isinstance(state,dict):raise ValueError(eid+': state sai loại')
                        physical=state.get('height_m',height)
                        if type(physical) not in (float,int) or abs(physical-height)>1e-6:
                            raise ValueError(eid+': state làm thay đổi scale phi nhân loại không có khóa cho phép')
            except (ValueError,KeyError,TypeError,AttributeError) as exc:
                failures.append('Nonhuman scale không hợp lệ: '+str(exc)[:160])
        elif kind=='mapping_integrity':
            # Opt-in contract for a structured, line-locked JSON Mapping.
            # It validates evidence and temporal state against the *actual*
            # upstream ledgers; a model's PASS cannot override a local error.
            import json
            audio=v.get('source','SOURCE_AUDIO')
            ids=v.get('values')
            if not isinstance(ids,list) or len(ids)!=2 or any(not isinstance(ref,str) for ref in ids):
                failures.append('mapping_integrity phải có values=[CHAR_LEDGER,BG_LEDGER]');continue
            char_ref,bg_ref=ids
            if any(x not in sources for x in (audio,char_ref,bg_ref)):
                failures.append('Mapping thiếu AUDIO hoặc CHAR/BG ledger trong inputs');continue
            try:
                frames=json.loads(data)
                if isinstance(frames,dict):frames=frames.get('frames')
                if not isinstance(frames,list):raise ValueError('frames phải là danh sách JSON')
                expected=[x[0] for x in audio_lines(sources[audio])]
                actual=[str(row['line_id']).zfill(3) for row in frames]
                if actual!=expected:
                    raise ValueError('Mapping thiếu/dư/đảo thứ tự LINE_ID so với AUDIO')
                chars=json.loads(sources[char_ref])['characters']
                bgs=json.loads(sources[bg_ref])['backgrounds']
                if not isinstance(chars,list) or not isinstance(bgs,list):
                    raise ValueError('CHAR/BG master không phải danh sách')
                catalogues=({c['id']:c for c in chars},{b['id']:b for b in bgs})
                for row,line_id in zip(frames,expected):
                    if not isinstance(row,dict):raise ValueError('frame không phải object')
                    for ids_field,states_field,catalogue in (
                        ('char_ids','char_states',catalogues[0]),
                        ('bg_ids','bg_states',catalogues[1])):
                        values=row.get(ids_field)
                        if not isinstance(values,list) or any(not isinstance(x,str) for x in values):
                            raise ValueError(line_id+': '+ids_field+' phải là danh sách ID')
                        if len(values)!=len(set(values)):
                            raise ValueError(line_id+': ID lặp trong '+ids_field)
                        if set(values)-set(catalogue):
                            raise ValueError(line_id+': ID không tồn tại trong ledger: '+str(sorted(set(values)-set(catalogue))))
                        state_map=row.get(states_field,{})
                        if not isinstance(state_map,dict) or set(state_map)-set(values):
                            raise ValueError(line_id+': '+states_field+' chứa ID không xuất hiện')
                        for key in values:
                            entity=catalogue[key]
                            reveal=entity.get('first_reveal_line_id',entity.get('first_reveal_line'))
                            if reveal is not None and int(line_id)<int(reveal):
                                raise ValueError(line_id+': '+key+' xuất hiện trước first_reveal_line')
                            states=entity.get('states',[])
                            if states:
                                if key not in state_map:
                                    raise ValueError(line_id+': thiếu state của '+key)
                                if state_map[key] not in {st['id'] for st in states}:
                                    raise ValueError(line_id+': state không tồn tại cho '+key)
                                starts=[(int(st['effective_from_line']),st['id'])
                                        for st in states if st.get('effective_from_line') is not None]
                                if starts:
                                    current=[(start,sid) for start,sid in starts if start<=int(line_id)]
                                    if current and state_map[key]!=max(current)[1]:
                                        raise ValueError(line_id+': sai timeline state '+key)
                                    if not current:
                                        raise ValueError(line_id+': state '+key+' chưa có hiệu lực')
            except (ValueError,KeyError,IndexError,TypeError,AttributeError) as exc:
                failures.append('Mapping không khớp nguồn/ledger: '+str(exc)[:180])
        elif kind=='source_quote':
            ref=v.get('source')
            if ref not in sources:
                failures.append('Không có nguồn đối chiếu: '+str(ref));continue
            # Only intended for deterministic exact-copy excerpts, not creative prompts.
            if data.strip() not in sources[ref]:failures.append('Trích dẫn không nguyên văn nguồn: '+str(ref))
        else:
            raise ContractError('Validator không hỗ trợ: '+kind)
    return failures
