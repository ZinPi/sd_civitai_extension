"""Source-anchored, stage-scoped conflict audit.

Lexical conflicts are definitive candidates; model semantic candidates require
human review and *both* exact, independently verified citations. No claims by
an LLM are trusted without verbatim source anchors.
"""
from __future__ import annotations
import hashlib
import json
import re
from .contract import ContractError
from .rule_conflicts import detect_conflicts, validate_conflict_decisions

MAX_CANDIDATES=25


def rules_digest(rules:dict[str,str])->str:
    raw=json.dumps(rules,ensure_ascii=False,sort_keys=True)
    return hashlib.sha256(raw.encode('utf8')).hexdigest()


def semantic_candidates(response:str,rules:dict[str,str])->list[dict]:
    raw=response.strip()
    if raw.startswith('```'):
        raw=re.sub(r'^```(?:json)?\s*','',raw,flags=re.I).rsplit('```',1)[0].strip()
    try: doc=json.loads(raw)
    except (ValueError,TypeError) as exc:raise ContractError('Kiểm tra xung đột ngữ nghĩa không trả JSON hợp lệ; chưa sản xuất.') from exc
    if not isinstance(doc,dict) or not isinstance(doc.get('conflicts'),list) or len(doc['conflicts'])>MAX_CANDIDATES:
        raise ContractError('Báo cáo rà mâu thuẫn không đúng cấu trúc hoặc vượt giới hạn.')
    collected=[];seen=set()
    for c in doc['conflicts']:
        if not isinstance(c,dict) or not isinstance(c.get('reason'),str) or not c['reason'].strip():
            raise ContractError('Nghi vấn mâu thuẫn thiếu giải thích.')
        refs=[]
        for side in ('left','right'):
            a=c.get(side)
            if not isinstance(a,dict):raise ContractError('Mâu thuẫn ngữ nghĩa thiếu một vế dẫn chứng.')
            fn,ln,quote=a.get('source_file'),a.get('source_line'),a.get('source_quote')
            if (not isinstance(fn,str) or fn not in rules or type(ln) is not int or
                ln<1 or ln>len(rules[fn].splitlines()) or not isinstance(quote,str)
                or not quote.strip() or len(quote)>400 or quote not in rules[fn].splitlines()[ln-1]):
                raise ContractError('Mâu thuẫn trích sai dòng/nguyên văn nguồn; chưa được chấp nhận.')
            refs.append({'source_file':fn,'source_line':ln,'source_quote':quote,
                         'value':quote,'topic':'nghi vấn ngữ nghĩa'})
        if refs[0]['source_file']==refs[1]['source_file']:
            # Within-file contradictions can also be real. Keep them for review.
            if refs[0]['source_line']==refs[1]['source_line']:raise ContractError('Hai vế mâu thuẫn trỏ cùng một câu.')
        signature=json.dumps([refs,c['reason'].strip()[:220]],ensure_ascii=False,sort_keys=True)
        uid='s'+hashlib.sha256(signature.encode('utf8')).hexdigest()[:14]
        if uid in seen:continue
        seen.add(uid)
        collected.append({'id':uid,'topic':'nghi vấn ngữ nghĩa','left':refs[0],
                          'right':refs[1],'reason':c['reason'].strip()[:220], 'kind':'review'})
    return collected


def literal_candidates(rules:dict[str,str])->list[dict]:
    return [dict(item,kind='fixed') for item in detect_conflicts(rules)]


def decision_text(conflicts:list[dict],decisions:dict[str,str])->str:
    if set(decisions)!=set(item['id'] for item in conflicts):
        raise ContractError('Cần giải quyết mọi mâu thuẫn của bước hiện tại, không được tự bỏ qua.')
    fixed=[c for c in conflicts if c['kind']=='fixed']
    # Reuse the mature consistency checker: no contradictory winners or
    # priority cycles for the same fixed-value topic.
    validate_conflict_decisions({'conflicts':fixed},
                                {'__conflicts__':{c['id']:decisions[c['id']] for c in fixed}})
    output=['QUYẾT ĐỊNH CỦA NGƯỜI DÙNG VỀ MÂU THUẪN CÓ DẪN CHỨNG (CHỈ BƯỚC NÀY)']
    for item in conflicts:
        answer=decisions[item['id']]
        if answer not in (('left','right','not_conflict') if item['kind']=='review' else ('left','right')):
            raise ContractError('Quyết định xử lý mâu thuẫn không hợp lệ.')
        if answer=='not_conflict':
            output.append('KHÔNG MÂU THUẪN THEO NGƯỜI DÙNG: '+item['id']+' (chỉ đóng nghi vấn; giữ cả hai điều khoản)')
            continue
        chosen=item[answer]; rejected=item['right' if answer=='left' else 'left']
        output.append(f'ƯU TIÊN TRONG PHẠM VI CHỦ ĐỀ {item["topic"]}: '
                      f'{chosen["source_file"]}:{chosen["source_line"]} — {chosen["source_quote"]}\n'
                      f'Không áp dụng phần trái ngược: {rejected["source_file"]}:{rejected["source_line"]} — {rejected["source_quote"]}')
    return '\n'.join(output)


def audit_prompt(rules:dict[str,str])->tuple[str,str]:
    system=('RÀ MÂU THUẪN NGỮ NGHĨA CHO CÁC QUY TẮC ĐANG ÁP DỤNG CÙNG MỘT BƯỚC. '
            'Không xem câu ví dụ, trích dẫn legacy không active, các điều kiện khác nhau hoặc điều khoản ưu tiên đã giải quyết là mâu thuẫn. '
            'Không đoán câu chưa có trong file. Chỉ báo hai mệnh lệnh không thể đồng thời tuân thủ trong cùng điều kiện. '
            'Nếu nghi ngờ cần xác nhận thì vẫn có thể nêu ở dạng nghi vấn. '
            'BẮT BUỘC mỗi bên có tên file, dòng đánh số và đoạn trích NGUYÊN VĂN. '
            'Chỉ trả JSON {"conflicts":[{"reason":"...","left":{"source_file":"...","source_line":1,"source_quote":"..."},'
            '"right":{"source_file":"...","source_line":2,"source_quote":"..."}}]}. Nếu không có trả {"conflicts":[]}. '
            'Tối đa 25 cặp, không tạo lựa chọn hộ người dùng.')
    content='\n\n'.join('FILE '+name+'\n'+'\n'.join(f'{i}: {line}' for i,line in enumerate(body.splitlines(),1))
                           for name,body in rules.items())
    return system,content
