"""Project creation after human-approved rule analysis (no GUI/Qt dependency).

The paid analysis uses a sibling audit directory, never a project directory:
Studio() must be the first writer of the project's sentinel and database.
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Callable

from .contract import ContractError
from .engine import Studio
from .rule_options import read_rules, rules_digest, confirmed_choices_text, validate_answers, verify_report_constraints


def shared_rule_cache_dir() -> Path:
    """Local per-user cache; no API keys, never inside exported project ZIP."""
    import os
    base = os.environ.get('LOCALAPPDATA')
    if base:
        return Path(base) / 'AI_Film_Studio' / 'rule_cache'
    return Path.home() / '.ai_film_studio' / 'rule_cache'


def analysis_budget_dir(project: Path) -> Path:
    project = Path(project)
    return project.parent / '.analysis_sessions' / project.name


def initialize_approved_project(
    project: Path, rule_paths: list[Path], report: dict, answers: dict,
    *, import_sources: Callable[[Studio], None] | None = None,
) -> Studio:
    """Validate snapshot, then initialize a legitimate V6 project.

    Keeps old data if an import fails. On retry, a V6 project is reopened safely.
    This function never deletes project content or silently re-approves questions.
    """
    files = read_rules(rule_paths)
    if '00_TUY_CHON_NGUOI_DUNG.txt' in files:
        raise ContractError('File quy tắc trùng tên tệp tùy chọn nội bộ. Hãy đổi tên file này trước khi phân tích.')
    if report.get('rules_digest') != rules_digest(files):
        raise ContractError('Quy tắc đã thay đổi sau phân tích; phải phân tích lại.')
    verify_report_constraints(report, files)
    if report.get('blockers'):
        raise ContractError('Quy tắc có mâu thuẫn; chưa thể sản xuất.')
    checked = validate_answers(report, answers)
    approved_text = confirmed_choices_text(report, checked)
    project = Path(project)
    project.mkdir(parents=True, exist_ok=True)
    studio = Studio(project)
    try:
        # File-name collision already rejected before creating this directory.
        option_path = project / '00_TUY_CHON_NGUOI_DUNG.txt'
        option_path.write_text(approved_text, encoding='utf-8')
        studio.import_rule_inputs([*rule_paths, option_path])
        (project / 'user_choices_confirmed.txt').write_text(approved_text, encoding='utf-8')
        if import_sources:
            import_sources(studio)
        reviewed = dict(report, reviewed=True)
        (project / 'PHAN_TICH_QUY_TAC.json').write_text(json.dumps(reviewed, ensure_ascii=False, indent=2), encoding='utf-8')
        (project / 'TUY_CHON_DA_CHON.json').write_text(json.dumps(checked, ensure_ascii=False, indent=2), encoding='utf-8')
        explanations = []
        for q in report['questions']:
            answer = checked.get(q['id'], '(không bắt buộc / chưa chọn)')
            limits = report.get('numeric_constraints', {}).get(q['id'], {})
            explanations.append(f"- {q['question']} [{q['source_file']}:{q['source_line']}]\n"
                                f"  Quy tắc gốc: {q['source_quote']}\n"
                                f"  Người dùng chọn: {answer}\n"
                                + (f"  Giới hạn số: {limits}\n" if limits else ''))
        conflicts_list = []
        decisions = checked.get('__conflicts__', {})
        for c in report.get('conflicts', []):
            direction = decisions[c['id']]
            preferred = c[direction]
            other = c['right' if direction == 'left' else 'left']
            conflicts_list.append(
                f'- VẤN ĐỀ: {c["topic"]}\n'
                f'  ƯU TIÊN {preferred["source_file"]}:{preferred["source_line"]}: {preferred["source_quote"]}\n'
                f'  KHÔNG ÁP DỤNG {other["source_file"]}:{other["source_line"]}: {other["source_quote"]}\n'
            )
        (project / 'PHAN_TICH_QUY_TAC.txt').write_text(
            'PHÂN TÍCH QUY TẮC — ĐÃ XÁC NHẬN\n\n'
            + report['summary']
            + '\n\nQUY TRÌNH:\n' + '\n'.join(report.get('steps', []))
            + '\n\nTHÀNH PHẨM:\n' + '\n'.join(report.get('deliverables', []))
            + '\n\nCÂU HỎI VÀ LỰA CHỌN:\n' + '\n'.join(explanations)
            + '\n\nQUYẾT ĐỊNH XUNG ĐỘT GIỮA CÁC FILE:\n' + ('\n'.join(conflicts_list) if conflicts_list else 'Không có xung đột được phát hiện.')
            + '\n\nCẢNH BÁO:\n' + '\n'.join(report.get('warnings', [])) + '\n',
            encoding='utf-8',
        )
        budget = analysis_budget_dir(project)
        if budget.is_dir() and any(budget.iterdir()):
            dest = project / 'analysis_api_usage'
            if dest.exists():
                raise ContractError('Dữ liệu phân tích API đã tồn tại trong dự án; không thể ghi đè.')
            shutil.move(str(budget), str(dest))
        return studio
    except Exception:
        studio.close()
        raise
