"""Regression: no billable compiler/generator may read an excluded rule file."""
import json, zipfile
import pytest
from studio.engine import Studio
from studio.contract import ContractError
from studio.api import Generation
from studio.rule_outline import build_outline, OutlineSelection

A = 'BƯỚC 09 — TRÍCH DANH SÁCH CHAR\nBắt buộc tạo CHAR_MASTER có CHAR_01 theo truyện.\n'
B = 'BƯỚC 87 — QUY TRÌNH KHÁC\nSECRET_EXCLUDED_DO_NOT_SEND: Nội dung cực dài không được gửi API.\n'

class TrackingProvider:
    model='test-offline';effort='medium';is_live=False
    def __init__(self, sha):
        self.calls=[];self.sha=sha
    def generate(self,*,system,user,max_output_tokens):
        self.calls.append((system,user))
        assert 'SECRET_EXCLUDED_DO_NOT_SEND' not in system+user
        if 'Bạn là người kiểm tra ĐỘC LẬP' in system:
            return Generation('{"verdict":"PASS","issues":[]}')
        if 'biên dịch quy tắc' in system:
            contract=dict(schema_version=1,rulepack_sha256=self.sha,required_inputs=['SOURCE_STORY'],
                required_outputs=['CHAR_MASTER'], deliverables={'character_index':'CHAR_MASTER'},
                export_names={'CHAR_MASTER':'char_master.txt'},
                file_dispositions={'first.txt':{'role':'PRODUCTION','reason':'Bước người dùng đã tích'}},
                stages=[dict(id='CHAR_JOB',title='Trích xuất CHAR',adapter='api_text',
                             inputs=['SOURCE_STORY'],output='CHAR_MASTER',rules=['first.txt'],
                             source_evidence=['first.txt:1'],instructions='Trích xuất CHAR_01.',
                             validators=[{'type':'required_sections','values':['CHAR_01']}],
                             semantic_qa=True,output_type='text',scope='whole',parallel=False)],
                release_checks={'CHAR_MASTER':{'source_inputs':['SOURCE_STORY'],
                     'validators':[{'type':'required_sections','values':['CHAR_01']}]}},
                clause_coverage=[dict(file='first.txt',start=2,end=2,decision='ENFORCE',
                                      stage_ids=['CHAR_JOB'],reason='Trích CHAR')])
            return Generation(json.dumps(contract,ensure_ascii=False))
        return Generation('CHAR_01|Nhân vật theo truyện.')

def make(tmp_path):
    z=tmp_path/'rules.zip'
    with zipfile.ZipFile(z,'w') as f:
        f.writestr('first.txt', A);f.writestr('second.txt',B)
    s=Studio(tmp_path/'project');s.import_pack(z)
    s.import_source_text('SOURCE_STORY','Truyện có nhân vật CHAR_01.')
    secs=build_outline(s.rule_files())
    selected={n.key for n in secs if n.file=='first.txt'}
    OutlineSelection(s.folder/'rule_outline_selection.json').write(s.rule_hash(),selected,{n.key for n in secs})
    return s,secs

def test_only_selected_reaches_compiler_and_runtime(tmp_path):
    s,_=make(tmp_path)
    try:
        scope=s.rule_scope()
        assert not scope.full
        assert set(scope.files)=={'first.txt'}
        assert 'SECRET_EXCLUDED_DO_NOT_SEND' not in str(scope.files)
        api=TrackingProvider(scope.sha)
        path=s.propose_contract(api)
        contract=s.approve(path)
        assert contract.raw['execution_scope']=='PARTIAL'
        assert s.active_contract().contract_sha==contract.contract_sha
        result=s.run(api, max_usd=20)
        assert 'chưa phải FINAL' in result
        assert not list((s.folder/'FINAL').glob('*')) if (s.folder/'FINAL').exists() else True
        assert len(api.calls)>=3
        # The imported original is still intact.
        assert s.rule_files()['second.txt']==B
    finally:s.close()

def test_changing_selection_invalidates_previous_approval(tmp_path):
    s,sections=make(tmp_path)
    try:
        api=TrackingProvider(s.rule_scope().sha)
        s.approve(s.propose_contract(api))
        selected={n.key for n in sections if n.file=='second.txt'}
        OutlineSelection(s.folder/'rule_outline_selection.json').write(
            s.rule_hash(),selected,{n.key for n in sections})
        with pytest.raises(ContractError,match='khớp|SHA'):
            s.active_contract()
    finally:s.close()

def test_no_selection_blocks_without_api(tmp_path):
    s,sections=make(tmp_path)
    try:
        OutlineSelection(s.folder/'rule_outline_selection.json').write(
            s.rule_hash(),set(),{n.key for n in sections})
        api=TrackingProvider('none')
        with pytest.raises(ContractError,match='chưa tích'):
            s.propose_contract(api)
        assert api.calls==[]
    finally:s.close()

def test_explicit_unselected_reference_blocks_before_paid_call(tmp_path):
    s,sections=make(tmp_path)
    try:
        # A selected step explicitly depends on an unselected file.
        files=s.rule_files()
        from studio.rule_scope import scope_view
        state=scope_view({'first.txt':A+'Bắt buộc dùng second.txt để QA.\n','second.txt':B},
                         s.rule_hash(),s.folder/'rule_outline_selection.json')
        assert state.missing_references
        # The scope preflight must be the caller's gate before compilation.
        with pytest.raises(ContractError,match='chưa được chọn'):
            from studio.rule_scope import ScopeView
            if state.missing_references:raise ContractError('; '.join(state.missing_references))
    finally:s.close()

def test_same_file_only_selected_section_is_sent(tmp_path):
    rules={'all.txt': 'BƯỚC 01 — CẦN XỬ LÝ\nBắt buộc tạo ghi chú nhỏ.\n'
                    'BƯỚC 02 — KHÔNG ĐƯỢC GỬI\nSECRET_IN_SAME_FILE\n'}
    from studio.rule_scope import scope_view
    nodes=build_outline(rules)
    chosen={n.key for n in nodes if n.title.startswith('BƯỚC 01')}
    selection=tmp_path/'selected.json'
    OutlineSelection(selection).write('sha',chosen,{n.key for n in nodes})
    view=scope_view(rules,'sha',selection)
    assert 'SECRET_IN_SAME_FILE' not in view.files['all.txt']
    assert len(view.files['all.txt'].splitlines())==len(rules['all.txt'].splitlines())
    assert 'Bắt buộc tạo ghi chú' in view.files['all.txt']


def test_checked_parent_cannot_silently_override_unchecked_child(tmp_path):
    rules={'x.txt':'BƯỚC 01 — NHÓM\n[PHAM_VI]\nCần A\n[QA]\nCần B\n'}
    from studio.rule_scope import scope_view
    nodes=build_outline(rules)
    # A broken or stale client selecting both a parent and only one child
    # must not cause an unselected nested QA clause to leak into requests.
    sel={n.key for n in nodes if n.kind=='file' or n.title=='[PHAM_VI]'}
    fname=tmp_path/'scope.json'
    OutlineSelection(fname).write('h',sel,{n.key for n in nodes})
    with pytest.raises(ContractError,match='không nhất quán'):
        scope_view(rules,'h',fname)


def test_real_dependency_guard_does_not_call_provider(tmp_path):
    A2='BƯỚC 09 — TRÍCH CHAR\nBắt buộc tham chiếu second.txt để thực hiện.\n'
    z=tmp_path/'rules.zip'
    with zipfile.ZipFile(z,'w') as f:
        f.writestr('first.txt',A2);f.writestr('second.txt',B)
    s=Studio(tmp_path/'project')
    try:
        s.import_pack(z)
        secs=build_outline(s.rule_files())
        selected={n.key for n in secs if n.file=='first.txt'}
        OutlineSelection(s.folder/'rule_outline_selection.json').write(
            s.rule_hash(),selected,{n.key for n in secs})
        api=TrackingProvider(s.rule_scope().sha)
        with pytest.raises(ContractError,match='Thiếu quy tắc'):
            s.propose_contract(api)
        assert api.calls==[]
    finally:s.close()
