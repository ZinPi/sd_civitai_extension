"""One immutable, user-selected scope shared by compilation, QA and production.

Never silently expand the paid request back to the complete imported archive.
An unselected file or clause is not permission to ignore mandatory constraints:
explicit cross-file references to excluded files block before payment.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import re
from .contract import ContractError, digest
from .rule_outline import build_outline, OutlineSelection

@dataclass(frozen=True)
class ScopeView:
    files: dict[str, str]
    sha: str
    full: bool
    selected: int
    total: int
    characters: int
    original_characters: int
    missing_references: tuple[str, ...]


def scope_view(files: dict[str, str], original_sha: str, selection_path: Path) -> ScopeView:
    nodes=build_outline(files)
    known={x.key for x in nodes}
    selected=OutlineSelection(selection_path).read(original_sha,known)
    if not selected:
        raise ContractError('Bạn chưa tích mục quy tắc nào. Không gọi GPT API.')
    # Treat parent and descendant selections consistently. Never allow a checked
    # file-level checkbox to override a deselected nested clause in a malformed
    # or manually edited sidecar.
    for p in nodes:
        if p.key not in selected:continue
        children=[x for x in nodes if x.file==p.file and x.key!=p.key and
                  p.start<=x.start<=x.end and x.depth>p.depth]
        missing=[x.title for x in children if x.key not in selected]
        if missing:
            raise ContractError(f'Lựa chọn không nhất quán trong {p.file}: mục "{p.title}" '
                'được tích nhưng có mục con bỏ chọn: '+', '.join(missing[:3]))
    if selected==known:
        return ScopeView(files,original_sha,True,len(known),len(known),
                         sum(len(x) for x in files.values()),sum(len(x) for x in files.values()),())
    grouped={name:set() for name in files}
    for n in nodes:
        if n.key in selected:
            grouped[n.file].update(range(n.start,n.end+1))
    subset={}
    for name,src in files.items():
        keep=grouped[name]
        if not keep:continue
        # Preserve physical line numbering for file:line evidence checks.
        lines=src.splitlines(keepends=True)
        masked=''.join(row if idx in keep else ('\r\n' if row.endswith('\r\n') else '\n' if row.endswith('\n') else '')
                       for idx,row in enumerate(lines,1))
        if masked.strip():subset[name]=masked
    if not subset:raise ContractError('Các mục đã chọn không chứa nội dung quy tắc để phân tích.')
    # Explicit *file* references in selected text that point to excluded source files.
    # Never auto-include the file; user must choose it. This is a conservative guard,
    # not a semantic dependency solver for natural-language clauses.
    ignored={name for name in files if name not in subset}
    missed=[]
    # Obvious GLOBAL / shared QA headings are never silently disabled by a
    # section checkbox. We do not leak the excluded text to the API: instead
    # ask the user to include the mandatory section or revise the scope.
    global_lock=re.compile(r'(?i)(GLOBAL[_ \-]*(?:RULE|LOCK|QA)|MASTER[_ \-]*RULE|'
                           r'QUY[_ \-]*TẮC[_ \-]*CHUNG|QUY\s*TẮC\s*BẮT\s*BUỘC\s*CHUNG|'
                           r'QA\s*(?:TOÀN\s*BỘ|BẮT\s*BUỘC))')
    for node in nodes:
        if node.kind!='file' and global_lock.search(node.title) and node.key not in selected:
            missed.append(f'{node.file}:{node.start} có mục quy tắc chung/QA "{node.title}" chưa chọn')
    for fn in ignored:
        stem=Path(fn).stem
        if not stem or len(stem)<4:continue
        pattern=r'(?<![\w])'+re.escape(stem)+r'(?:\.txt)?(?![\w])'
        for name,text in subset.items():
            if re.search(pattern,text,re.I):
                missed.append(f'{name} có tham chiếu tới {fn} nhưng tệp này chưa được chọn')
                break
    hash_id=digest({'rulepack':original_sha,'selected':sorted(selected),
                    'source':{fn:digest(body) for fn,body in subset.items()},'scope_version':1})
    return ScopeView(subset,hash_id,False,len(selected),len(known),
                     sum(len(x) for x in subset.values()),sum(len(x) for x in files.values()),tuple(missed))
