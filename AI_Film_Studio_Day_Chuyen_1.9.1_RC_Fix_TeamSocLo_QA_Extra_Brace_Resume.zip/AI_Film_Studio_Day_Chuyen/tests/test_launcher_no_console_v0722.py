from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_primary_vbs_does_not_launch_bat_cmd_powershell():
    t = (ROOT / 'MO_AI_FILM_STUDIO.vbs').read_text(encoding='utf-8-sig').lower()
    for term in ('shell.run("cmd.exe', 'cmd.exe /c', 'chay_an_windows.bat', 'chay_ung_dung_windows.bat', 'powershell.exe -'):
        assert term not in t
    assert 'pythonw.exe' in t
    assert 'pyw.exe' in t

def test_bootstrap_uses_no_console_pip():
    t = (ROOT / 'KHOI_DONG_KHONG_CMD.pyw').read_text(encoding='utf-8').lower()
    assert 'creationflags=create_no_window' in t
    assert "kwargs['creationflags'] = create_no_window" in t
    assert "'-m', 'pip'" in t

def test_obsolete_bat_entrypoint_removed():
    assert not (ROOT / 'CHAY_UNG_DUNG_WINDOWS.bat').exists()
    assert not (ROOT / 'CHAY_AN_WINDOWS.bat').exists()
    assert (ROOT / 'MO_AI_FILM_STUDIO.vbs').is_file()
