"""AI Film Studio — guide-first Windows project."""
__version__ = "1.9.1rc1"
