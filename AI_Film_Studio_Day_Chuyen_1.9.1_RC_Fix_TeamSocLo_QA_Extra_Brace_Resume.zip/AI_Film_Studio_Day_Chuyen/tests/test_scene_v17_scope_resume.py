"""B1 project-global target cannot invalidate local QA; resume latest repair."""
from __future__ import annotations
import json
from pathlib import Path
from types import SimpleNamespace as NS
import pytest

from studio.contract import ContractError
from studio.guide_flow import GuideFlow
from studio.guide_scene import MAX_TOTAL_WINDOW_REPAIRS
from tests.test_scene_responsive_v14 import project, SceneProvider


def window_folder(flow):
    return next((flow.folder/'candidates'/'STEP_001'/'scene_windows').iterdir())


class _Provider(SceneProvider):
    """Legacy QA incorrectly fails window three solely for global evidence."""
    def __init__(self, scope_fixed=False,timeout_repair=False):
        super().__init__()
        self.scope_fixed=scope_fixed
        self.timeout_repair=timeout_repair
        self.timed_out=False

    def generate(self,*,system,user,max_output_tokens):
        self.calls.append((system,user,max_output_tokens))
        if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
            assert 'KHÔNG FAIL chỉ vì' in system
            assert 'thiếu cô đọng theo chức năng' in system
            if self.timeout_repair and 'R1_WINDOW_1' in user and not self.timed_out:
                self.timed_out=True
                raise ContractError('timeout khi QA repair, có thể tính phí')
            if ('WINDOW 3' in user and not self.scope_fixed):
                return NS(text=json.dumps({'verdict':'FAIL',
                    'issues':['Candidate giữ quá nhiều chi tiết không cần thiết, thiếu cô đọng chức năng dù target 40% ở cấp toàn tác phẩm'],
                    'continuity':'Không thể kết luận QA cục bộ'}))
            if ('WINDOW 1' in user and 'R1_WINDOW_1' not in user and self.timeout_repair):
                return NS(text=json.dumps({'verdict':'FAIL','issues':['cần sửa lỗi câu nguồn']}))
            return NS(text=json.dumps({'verdict':'PASS','issues':[],
                                      'continuity':'Canon, nhân vật và thứ tự nguồn giữ nguyên'}))
        if 'QA RANH GIỚI ĐỘC LẬP' in system:
            return NS(text='{"verdict":"PASS","issues":[]}')
        if 'QA TỔNG THỂ toàn tác phẩm' in system:
            assert '40% ở cấp TOÀN TÁC PHẨM' in system
            return NS(text='{"verdict":"PASS","issues":[]}')
        if 'CHỈ SỬA ĐÚNG LỖI QA' in system:
            import re
            match=re.search(r'PHẦN (\d+)/',user)
            assert match
            return NS(text=f'R{1 if "R1_WINDOW" not in user else 2}_WINDOW_{match.group(1)}')
        import re
        match=re.search(r'PHẦN (\d+)/',user)
        return NS(text=f'ORIGINAL_WINDOW_{match.group(1)}')


def _text_history(provider):
    return '\n'.join(a+'\n'+b for a,b,_ in provider.calls)


def test_legacy_two_repairs_resume_from_second_and_keep_earlier_windows(tmp_path):
    flow=project(tmp_path)
    first=_Provider()
    with pytest.raises(ContractError,match='QA chưa PASS'):
        flow.run_next(first,max_output_tokens=1600,repair_attempts=2)
    folder=window_folder(flow)
    assert (folder/'window_00001.json').is_file()
    assert (folder/'window_00002.json').is_file()
    repair2=folder/'window_00003_repair_2.txt'
    assert repair2.is_file()
    assert 'R2_WINDOW_3' in repair2.read_text(encoding='utf8')

    # Simulate artifacts written by v1.6: repair files not accompanied by
    # SHA receipts; its QA receipt has no scope/version metadata.
    for n in (1,2):
        (folder/f'window_00003_repair_{n}.json').unlink()
    old_qa=folder/'window_00003_qa.json'
    old_qa.write_text(json.dumps({'verdict':'FAIL','issues':['40% global unresolved']}),encoding='utf8')
    follow=_Provider(scope_fixed=True)
    receipt=GuideFlow(flow.folder).run_next(follow,max_output_tokens=1600,repair_attempts=2)
    assert receipt['state']=='LOCKED'
    window_qa=[user for system,user,_ in follow.calls if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system]
    assert any('R2_WINDOW_3' in user for user in window_qa)
    assert not any('ORIGINAL_WINDOW_3' in user for user in window_qa)
    assert not any('PHẦN 1/' in user or 'PHẦN 2/' in user for _,user,_ in follow.calls)
    assert (folder/'window_00001.json').is_file() and (folder/'window_00002.json').is_file()


def test_timeout_during_repair_qa_resume_without_regenerating_revision(tmp_path):
    flow=project(tmp_path)
    first=_Provider(scope_fixed=True,timeout_repair=True)
    with pytest.raises(ContractError,match='timeout khi QA repair'):
        flow.run_next(first,max_output_tokens=1600,repair_attempts=2)
    folder=window_folder(flow)
    receipt=folder/'window_00001_repair_1.json'
    assert receipt.exists()
    # Resume from exact successfully generated text, not from source.
    follow=_Provider(scope_fixed=True)
    final=GuideFlow(flow.folder).run_next(follow,max_output_tokens=1600,repair_attempts=2)
    assert final['state']=='LOCKED'
    assert any('R1_WINDOW_1' in u for s,u,_ in follow.calls if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in s)
    assert not any('PHẦN 1/' in u for s,u,_ in follow.calls if 'QA ' not in s)


def test_new_repair_sha_receipt_tampering_is_fatal(tmp_path):
    flow=project(tmp_path)
    with pytest.raises(ContractError):
        flow.run_next(_Provider(),max_output_tokens=1600,repair_attempts=2)
    folder=window_folder(flow)
    path=folder/'window_00003_repair_2.txt'
    path.write_text('FORGED',encoding='utf8')
    with pytest.raises(ContractError,match='không khớp SHA-256'):
        GuideFlow(flow.folder).run_next(_Provider(scope_fixed=True),max_output_tokens=1600,repair_attempts=2)


def test_real_local_compression_failure_cannot_be_auto_accepted(tmp_path):
    flow=project(tmp_path)
    class Literal(_Provider):
        def generate(self,*,system,user,max_output_tokens):
            if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
                self.calls.append((system,user,max_output_tokens))
                return NS(text=json.dumps({'verdict':'FAIL',
                    'issues':['Candidate chép sát chi tiết không cần thiết tại đoạn nguồn hiện tại']}))
            return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
    with pytest.raises(ContractError,match='QA chưa PASS'):
        flow.run_next(Literal(scope_fixed=True),max_output_tokens=1600,repair_attempts=2)
    assert flow.status()['completed']==0


def test_total_repairs_never_unbounded_across_restarts(tmp_path):
    flow=project(tmp_path)
    for attempt in range(2):
        with pytest.raises(ContractError,match='QA chưa PASS'):
            GuideFlow(flow.folder).run_next(_Provider(),max_output_tokens=1600,repair_attempts=2)
    folder=window_folder(flow)
    assert (folder/f'window_00003_repair_{MAX_TOTAL_WINDOW_REPAIRS}.txt').exists()
    no_calls=_Provider()
    with pytest.raises(ContractError,match='QA chưa PASS'):
        GuideFlow(flow.folder).run_next(no_calls,max_output_tokens=1600,repair_attempts=2)
    assert no_calls.calls==[]


def test_global_only_qa_uncertainty_re_scoped_once_never_auto_pass(tmp_path):
    flow=project(tmp_path)
    class Reviewer(SceneProvider):
        def generate(self,*,system,user,max_output_tokens):
            if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
                self.calls.append((system,user,max_output_tokens))
                if 'RÀ LẠI PHẠM VI:' not in system:
                    return NS(text=json.dumps({'verdict':'FAIL',
                        'issues':['Chưa đủ căn cứ xác nhận 40% ở cấp toàn tác phẩm']}))
                return NS(text=json.dumps({'verdict':'PASS','issues':[],
                    'continuity':'Đã đối chiếu source và candidate ở cửa sổ'}))
            return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
    p=Reviewer()
    rec=flow.run_next(p,max_output_tokens=1600,repair_attempts=2)
    assert rec['state']=='LOCKED'
    assert sum('RÀ LẠI PHẠM VI:' in s for s,_,_ in p.calls)>=1
    assert not any('CHỈ SỬA ĐÚNG LỖI QA' in s for s,_,_ in p.calls)


def test_global_only_repeat_fails_without_spending_repair_calls(tmp_path):
    flow=project(tmp_path)
    class Incapable(SceneProvider):
        def generate(self,*,system,user,max_output_tokens):
            if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
                self.calls.append((system,user,max_output_tokens))
                return NS(text=json.dumps({'verdict':'FAIL',
                    'issues':['Chưa thể đánh giá 40% toàn tác phẩm từ cửa sổ']}))
            return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)
    p=Incapable()
    with pytest.raises(ContractError,match='tiếp tục yêu cầu bằng chứng 40%'):
        flow.run_next(p,max_output_tokens=1600,repair_attempts=2)
    assert sum('QA ĐỘC LẬP CHO SOURCE WINDOW' in s for s,_,_ in p.calls)==2
    assert not any('CHỈ SỬA ĐÚNG LỖI QA' in s for s,_,_ in p.calls)
    assert flow.status()['completed']==0
