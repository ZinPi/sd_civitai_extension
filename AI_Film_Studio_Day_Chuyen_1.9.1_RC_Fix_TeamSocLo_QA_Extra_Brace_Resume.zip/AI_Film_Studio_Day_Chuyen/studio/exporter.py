"""Deterministic all-output release gate; never uses GPT."""
from __future__ import annotations
from pathlib import Path
import os, tempfile, time, zipfile, json
from .contract import Contract, ContractError, digest, canonical_json


def export_final(store,contract:Contract,active:dict[str,str],selected_revisions:dict[str,int],expected_source_hashes:dict[str,str], *, release_status:str='TEST_ONLY', elapsed_seconds:float|None=None)->Path:
    from .release import check_release_content
    if release_status not in ('FINAL','TEST_ONLY'):raise ContractError('Trạng thái xuất không hợp lệ')
    if store.source_hashes()!=expected_source_hashes:
        raise ContractError('Dữ liệu nguồn đã thay đổi trước khi xuất; không được bàn giao FINAL')
    export_names=contract.raw.get('export_names',{})
    if not isinstance(export_names,dict):raise ContractError('export_names phải là object')
    mapped={};content_hashes={};qa_reports={}
    producers=contract.producers
    for name in contract.outputs:
        if name not in producers or name not in active:raise ContractError('Thiếu kết quả chính thức: '+name)
        rev=selected_revisions.get(name)
        row=store.artifact_revision(rev) if rev is not None else None
        if not row or row[1]!=name or row[2]!=producers[name] or row[4]!=active[name] or row[5]!='PASS':
            raise ContractError('Kết quả không đúng revision được chọn hoặc chưa PASS: '+name)
        if store.artifact_dependencies(rev)!={key:active[key] for key in contract.stage_by_id[row[2]].inputs}:
            raise ContractError('Phụ thuộc đã thay đổi trước khi xuất: '+name)
        text=store.text(row[4])
        release=contract.raw['release_checks'][name]
        release_sources={src:store.source_text(src) for src in release['source_inputs']}
        # Dynamic validators may need a verified upstream ledger, not just the raw story.
        from .release import lineage
        _,ancestor_stages=lineage(contract,name)
        for spec in release['validators']:
            ref=spec.get('source')
            if ref and ref in active and ref not in release_sources:
                if ref not in producers or producers[ref] not in ancestor_stages:
                    raise ContractError(f'{name}: validator tham chiếu artifact ngoài dependency: {ref}')
                release_sources[ref]=store.text(active[ref])
        check_release_content(text,release['validators'],release_sources,name)
        target=export_names.get(name,name+'.txt')
        if not isinstance(target,str) or target.startswith(('/', '\\')) or '\\' in target or '..' in Path(target).parts or Path(target).is_absolute() or ':' in target:
            raise ContractError('Tên file đầu ra không an toàn: '+str(target))
        if target in ('PROJECT_MANIFEST.json','QA_REPORT_FINAL.txt'):
            raise ContractError('Tên file đầu ra trùng báo cáo bắt buộc: '+target)
        if target in mapped:raise ContractError('Trùng đường dẫn đầu ra: '+target)
        mapped[target]=store.get_blob(row[4]);content_hashes[target]=row[4];qa_reports[name]=row[6]
    manifest={'status':release_status,'schema_version':1,'contract_sha256':contract.contract_sha,
              'rulepack_sha256':contract.rules_sha,'source_hashes':expected_source_hashes,
              'artifacts':content_hashes,'qa':qa_reports,'generated_unix':time.time(),
              'api_usage':store.usage_summary(),
              'api_current_session_compilation_and_production':store.session_api_guard_summary(),
              'qa_source_evidence_review_counts':store.qa_review_summary(),
              'current_run_elapsed_seconds':elapsed_seconds,
              'notes':'MODEL_REVIEWED là đánh giá ngữ nghĩa, không phải chứng nhận đúng 100%; release_checks và revision được xác minh trước xuất'}
    mapped['PROJECT_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8')
    mapped['QA_REPORT_FINAL.txt']=('\n'.join(f'{k}: {v}' for k,v in qa_reports.items())+'\n').encode('utf8')
    outdir=store.root/('FINAL' if release_status=='FINAL' else 'TEST_OUTPUT');outdir.mkdir(parents=True,exist_ok=True)
    stamp=time.strftime('%Y%m%d_%H%M%S')
    suffix=contract.contract_sha[:8]
    out=outdir/f'PROJECT_{release_status}_{stamp}_{suffix}.zip'
    count=1
    while out.exists():
        out=outdir/f'PROJECT_{release_status}_{stamp}_{suffix}_{count}.zip';count+=1
    fd,tmp=tempfile.mkstemp(prefix='.export_',suffix='.zip',dir=outdir)
    os.close(fd)
    try:
        with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
            for name,data in mapped.items():z.writestr(name,data)
        with zipfile.ZipFile(tmp,'r') as z:
            if z.testzip() is not None or set(z.namelist())!=set(mapped):
                raise ContractError('Không xác minh được ZIP vừa xuất')
        os.replace(tmp,out)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    return out
