"""Checks large rulesets without paying for API calls; not proof of AI rule comprehension."""
import copy,json,zipfile
from studio.api import Generation
from studio.compiler import draft_contract
from studio.contract import digest,ContractError
from studio.large_rule_compiler import rule_chunks,planning_stats
from tests.test_acceptance_end_to_end import RULES,build_pack
import pytest


def rule_fixture(tmp_path):
    z=tmp_path/'tmp.zip';contract=build_pack(z)
    contract=copy.deepcopy(contract)
    contract['file_dispositions'].pop('something.custom.workflow.json')
    files={'instructions_unseen.txt':RULES+('Mô tả tham khảo về quy trình.\n'*2800)}
    rulehash=digest('test-pack')
    contract['rulepack_sha256']=rulehash
    contract['clause_coverage']=[]
    return files,rulehash,contract

class LargeMock:
    def __init__(self, contract, unresolved=False):self.contract=contract;self.calls=[];self.unresolved=unresolved
    def generate(self,*,system,user,max_output_tokens):
        self.calls.append((system,user))
        if 'Phân tích MỘT ĐOẠN QUY TẮC' in system:
            return Generation(json.dumps({'notes':'Các ràng buộc nguồn đã đọc nguyên đoạn, giữ nguyên công đoạn và đầu vào',
                                         'possible_stages':[{'name':'step_1','evidence_lines':[1]}],
                                         'file_role':'PRODUCTION'},ensure_ascii=False))
        if 'bộ đối chiếu điều khoản' in system:
            import re
            section=user.rsplit('JSON {',1)[-1].split('\n',1)[-1]
            candidates=[int(v) for v in re.findall(r'^([0-9]+): ',section,re.M)]
            # Coverage must identify exactly all candidate lines.
            return Generation(json.dumps({'assignments':[{'line':ln,'decision':'UNRESOLVED' if self.unresolved and ln==1 else 'ENFORCE',
                                     'stage_ids':['step_'+str(ln)],'reason':'Gắn nguồn vào bước hợp lệ'} for ln in candidates]}))
        if 'Bạn là chuyên gia biên dịch' in system:
            return Generation(json.dumps(self.contract,ensure_ascii=False))
        raise AssertionError('Unexpected compiler phase')

def test_large_pack_analyzes_every_file_no_silent_truncation(tmp_path):
    files,h,contract=rule_fixture(tmp_path)
    assert sum(len(v) for v in files.values())>55000
    chunks=list(rule_chunks(files));assert ''.join(c[3] for c in chunks)==next(iter(files.values()))
    progress=[];p=LargeMock(contract)
    result=draft_contract(files,h,p,progress=progress.append)
    assert len(result['stages'])==6
    assert len(result['clause_coverage'])==6
    assert len([c for c in p.calls if 'Phân tích MỘT' in c[0]])==len(chunks)
    assert any('Đã đối chiếu' in x for x in progress)

def test_large_pack_blocks_missing_comprehension(tmp_path):
    files,h,contract=rule_fixture(tmp_path)
    with pytest.raises(ContractError,match='chưa thể xác minh'):
        draft_contract(files,h,LargeMock(contract,unresolved=True))

def test_preview_stats_reads_every_rule_file(tmp_path):
    files,h,c=rule_fixture(tmp_path)
    files['other_chapter.txt']='Bắt buộc khóa thời gian.\n'+'Tham chiếu.\n'*300
    p=planning_stats(files)
    assert p['files']==2 and p['directive_candidates']==7

def test_compilation_resume_skips_paid_chunks(tmp_path):
    files,h,contract=rule_fixture(tmp_path)
    saved=tmp_path/'compiler_checkpoint.json'
    first=LargeMock(contract)
    seen=[]
    def stop_after_two(msg):
        seen.append(msg)
        if len([x for x in seen if 'Đọc file quy tắc' in x])>=3:
            raise RuntimeError('user cancellation before the next charge')
    with pytest.raises(RuntimeError):
        draft_contract(files,h,first,progress=stop_after_two,checkpoint_path=saved)
    assert saved.exists()
    assert len(json.loads(saved.read_text())['chunk_notes'])==2
    second=LargeMock(contract)
    result=draft_contract(files,h,second,checkpoint_path=saved)
    assert len(result['stages'])==6
    assert len([x for x in second.calls if 'Phân tích MỘT' in x[0]])==len(list(rule_chunks(files)))-2


def test_reject_oversize_single_line_without_paid_api(tmp_path):
    files,h,contract=rule_fixture(tmp_path)
    files['other.txt']='Văn bản '+('A'*13000)
    with pytest.raises(ContractError,match='quá dài'):
        planning_stats(files)
