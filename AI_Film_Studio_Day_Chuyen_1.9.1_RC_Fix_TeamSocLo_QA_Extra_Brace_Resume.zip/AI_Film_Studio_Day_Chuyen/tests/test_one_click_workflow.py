"""Guarantees no paid calls at import; SRT fidelity and dynamic end-to-end output."""
import json
import tempfile
import unittest
from pathlib import Path
from studio.engine import Studio,RunBlocked
from studio.api import Generation
from studio.one_click import (OneClickService,normalize_srt,add_story_file,
                              BudgetedProvider,new_project_folder)
from tests.test_acceptance_end_to_end import build_pack,STORY,AUDIO,MockProvider

class CountingMock(MockProvider):
    model='mock-model';effort='none';is_live=False

class OneClickTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.base=Path(self.temp.name)
        self.rules=self.base/'completely_unfamiliar_pack.zip';build_pack(self.rules)
        self.studio=Studio(self.base/'project')
    def tearDown(self):
        self.studio.close();self.temp.cleanup()
    def test_no_api_on_import(self):
        fake=CountingMock()
        self.studio.import_pack(self.rules)
        self.studio.import_source_text('SOURCE_STORY',STORY)
        self.studio.import_source_text('SOURCE_AUDIO',AUDIO)
        scope=self.studio.rule_scope()
        self.assertGreater(scope.characters,0)
        self.assertEqual(len(fake.calls),0)
        self.assertFalse((self.studio.folder/'workflow_DRAFT_REVIEW.json').exists())
    def test_missing_source_blocks_before_generating(self):
        fake=CountingMock();self.studio.import_pack(self.rules)
        self.studio.import_source_text('SOURCE_STORY',STORY)
        with self.assertRaises(RunBlocked):OneClickService(self.studio).run(fake)
        self.assertEqual(len(fake.calls),0)
        self.assertFalse((self.studio.folder/'FINAL').exists())
    def test_full_run_with_external_contract_and_checkpoint(self):
        fake=CountingMock();self.studio.import_pack(self.rules)
        self.studio.import_source_text('SOURCE_STORY',STORY)
        self.studio.import_source_text('SOURCE_AUDIO',AUDIO)
        svc=OneClickService(self.studio)
        output=svc.run(fake,export_intermediate=True)
        self.assertTrue(output.is_file());self.assertIn('TEST_ONLY',output.name)
        n=len(fake.calls)
        self.assertGreater(n,0)
        svc.run(fake)
        self.assertEqual(n,len(fake.calls))
        self.assertTrue((self.studio.folder/'EXPORT_THEM'/'TAI_LIEU_TRUNG_GIAN_DA_QA.zip').exists())
    def test_srt_format_preservation(self):
        srt='''1\n00:00:01,000 --> 00:00:02,000\nDòng đầu.\n\n2\n00:00:02,100 --> 00:00:03,000\nLời nói tiếp\ntrên hai dòng.\n'''
        self.assertEqual(normalize_srt(srt),'001|Dòng đầu.\n002|Lời nói tiếp trên hai dòng.\n')
        path=self.base/'source.srt';path.write_text(srt,encoding='utf-8')
        add_story_file(self.studio,path)
        self.assertIn('00:00:01,000',self.studio.store.source_text('SOURCE_STORY'))
        self.assertIn('002|Lời nói tiếp',self.studio.store.source_text('SOURCE_AUDIO'))
    def test_srt_rejects_bad_timing(self):
        with self.assertRaises(ValueError):normalize_srt('1\nNội dung không có timestamp')
    def test_request_cap(self):
        fake=CountingMock()
        p=BudgetedProvider(fake,self.studio.folder,max_usd=3,max_calls=1)
        p.generate(system='PHASE=character_index\n',user='hello',max_output_tokens=20)
        with self.assertRaises(RunBlocked):p.generate(system='PHASE=character_index\n',user='hello',max_output_tokens=20)
        self.assertEqual(len(fake.calls),1)
        self.assertFalse(p.is_live)
    def test_project_folder_unique(self):
        a=new_project_folder(self.base);b=new_project_folder(self.base)
        self.assertNotEqual(a,b)
        self.assertTrue(a.exists() and b.exists())
if __name__=='__main__':unittest.main()
