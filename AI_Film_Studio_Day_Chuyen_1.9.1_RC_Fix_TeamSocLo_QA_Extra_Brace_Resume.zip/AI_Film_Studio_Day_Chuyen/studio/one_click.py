"""Một lần RUN, giữ tài liệu ở PC trước khi RUN; không chứa nhánh theo tên bộ quy tắc.

This is orchestration over the audited V6 contract executor, NOT a replacement for
rule semantics / model verification. Never marks partial results as FINAL.
"""
from __future__ import annotations
import json, os, re, time, threading
from pathlib import Path
from datetime import datetime
from uuid import uuid4
from .engine import Studio, RunBlocked
from .contract import ContractError
from .api import OpenAIProvider
from .rule_outline import build_outline, OutlineSelection
from .large_rule_compiler import planning_stats

DEFAULT_PRICES = {'input':2.0, 'cached_input':0.2, 'output':10.0} # CHỈ ƯỚC TÍNH; không phải giá niêm yết


def new_project_folder(root:Path|None=None)->Path:
    root=Path(root or Path.home()/'Documents'/'AI_Film_Studio'/'Projects')
    root.mkdir(parents=True,exist_ok=True)
    dest=root/('Du_an_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:6])
    dest.mkdir(parents=False,exist_ok=False)
    return dest


def normalize_srt(content:str)->str:
    """Produce one numbered AUDIO text line per subtitle, preserving original SRT in SOURCE_STORY.
    Do not interpolate, paraphrase or invent the original words.
    """
    content=content.lstrip('\ufeff').replace('\r\n','\n').replace('\r','\n')
    blocks=re.split(r'\n\s*\n',content.strip())
    entries=[]
    ts=re.compile(r'^\s*(\d{1,2}:\d\d:\d\d[,.]\d{1,3})\s*-->\s*(\d{1,2}:\d\d:\d\d[,.]\d{1,3})(?:\s+.*)?$')
    def ms(value):
        hours,minutes,rest=value.replace(',','.').split(':')
        secs,frac=rest.split('.')
        h,m,s=int(hours),int(minutes),int(secs)
        if m>59 or s>59:raise ValueError('SRT có mốc thời gian không hợp lệ')
        return ((h*60+m)*60+s)*1000+int(frac.ljust(3,'0'))
    previous_start=-1;previous_end=-1
    for block in blocks:
        rows=block.splitlines()
        if rows and rows[0].strip().isdigit():rows=rows[1:]
        match=ts.fullmatch(rows[0]) if rows else None
        if not match:
            raise ValueError('SRT có đoạn không đúng mốc thời gian; không tự suy đoán nội dung.')
        start,end=ms(match[1]),ms(match[2])
        if start>=end or start<previous_start or start<previous_end:
            raise ValueError('SRT có đoạn trùng/lùi thời gian hoặc thời lượng không hợp lệ')
        previous_start,previous_end=start,end
        words=' '.join(r.strip() for r in rows[1:] if r.strip())
        if not words:raise ValueError('SRT có đoạn phụ đề trống.')
        if '\u007c' in words:
            # Separator is a technical ID delimiter, not content; safe normalization.
            words=words.replace('|','｜')
        entries.append(f'{len(entries)+1:03d}|{words}')
    if not entries:raise ValueError('File SRT không có phụ đề hợp lệ.')
    return '\n'.join(entries)+'\n'


def add_story_file(studio:Studio,path:Path):
    path=Path(path)
    if path.suffix.lower()=='.srt':
        from .rulepack import decode_text
        content=decode_text(path.read_bytes())
        audio=normalize_srt(content)  # MUST validate before ANY project mutation.
        studio.import_sources_atomic({'SOURCE_STORY':(content,str(path.resolve())),
                                      'SOURCE_AUDIO':(audio,str(path.resolve())+' [SRT → AUDIO]')})
        return ('SOURCE_STORY','SOURCE_AUDIO')
    studio.import_source_file('SOURCE_STORY',path)
    return ('SOURCE_STORY',)


def add_audio_file(studio:Studio,path:Path):
    path=Path(path)
    if path.suffix.lower()=='.srt':
        from .rulepack import decode_text
        content=decode_text(path.read_bytes())
        studio.import_source_text('SOURCE_AUDIO',normalize_srt(content))
    else:studio.import_source_file('SOURCE_AUDIO',path)
    return 'SOURCE_AUDIO'


class BudgetedProvider:
    """Conservative request guard covering BOTH compilation and production.

    A local guard cannot enforce the cloud provider's actual invoice. It is meant to
    prevent accidentally issuing hundreds of large requests without a budget decision.
    """
    is_live=True
    def __init__(self, base, project:Path, max_usd:float=20, max_calls:int=180, prices=None, notify=None):
        self.base=base;self.is_live=bool(getattr(base,'is_live',False));self.model=base.model;self.effort=base.effort
        self.provider_id=getattr(base,'provider_id','unknown')
        self.concurrency_limit=getattr(base,'concurrency_limit',3)
        self.project=Path(project);self.max_usd=float(max_usd);self.max_calls=int(max_calls)
        self.prices=prices or DEFAULT_PRICES
        self.notify=notify or (lambda msg:None)
        if self.max_usd<=0:raise ValueError('Giới hạn ngân sách phải lớn hơn $0 trước khi sản xuất.')
        if self.max_calls<1:raise ValueError('Số lượt API tối đa không hợp lệ.')
        self.path=self.project/'api_usage_guard.json'
        self.calls=0;self.cost=0.0;self.in_tokens=0;self.out_tokens=0;self.failed=0
        self.is_budget_manager=True
        self.unknown_exposure=0.0
        self.inflight_reserved=0.0
        self.current_stage='RULE_COMPILATION'
        self._lock=threading.RLock()
        # Limits apply to the ENTIRE project, including prior runs, failed calls
        # and independent conflict-audit workers. Never reset on a new session.
        self.total_calls=0;self.total_cost=0.0;self.total_failed=0
        if self.path.exists():
            try:
                previous=json.loads(self.path.read_text(encoding='utf8'))
                if not isinstance(previous,dict):raise ValueError('invalid guard')
                self.total_calls=int(previous.get('requests_total',previous.get('requests_this_session',0)))
                self.total_cost=float(previous.get('estimated_usd_total',previous.get('estimated_usd_this_session',0)))
                self.total_failed=int(previous.get('failed_requests_total',previous.get('failed_requests_this_session',0)))
                self.unknown_exposure=float(previous.get('unknown_exposure_usd',0.0))
                pending=float(previous.get('inflight_reserved_usd',0.0))
                if min(self.total_calls,self.total_cost,self.total_failed,self.unknown_exposure,pending)<0:
                    raise ValueError('negative guard values')
                if pending:
                    # Process terminated mid-request: it may have been billed.
                    # Never forget that exposure, and never automatically retry.
                    self.unknown_exposure+=pending
                    self._persist()
            except (OSError,ValueError,TypeError,KeyError) as exc:
                raise RunBlocked('Không đọc được hạn mức API đã lưu; dừng để tránh đặt lại ngân sách.') from exc
    def _persist(self):
        data={'provider_id':self.provider_id,'model':self.model,'effort':self.effort,'requests_this_session':self.calls,
              'estimated_usd_this_session':round(self.cost,8),
              'input_tokens_this_session':self.in_tokens,'output_tokens_this_session':self.out_tokens,
              'failed_requests_this_session':self.failed,
              'requests_total':self.total_calls,'estimated_usd_total':round(self.total_cost,8),
              'failed_requests_total':self.total_failed,
              'unknown_exposure_usd':round(self.unknown_exposure,8),
              'inflight_reserved_usd':round(self.inflight_reserved,8),
              'updated':time.time(),'note':('Chỉ là mức dự phòng USD cục bộ, KHÔNG phải giá TuanSu/VND; xem ví TuanSu để biết phí thật. ' if self.provider_id=='tuansu' else 'Chỉ là giới hạn USD dự phòng nội bộ, KHÔNG phải giá TeamSocLo. Kiểm tra phí thực tế tại TeamSocLo. ' if self.provider_id=='teamsoclo' else '') + 'Request lỗi không có usage có rủi ro phí KHÔNG RÕ.'}
        tmp=self.path.with_name(self.path.name+'.tmp')
        tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
        os.replace(tmp,self.path)
    def _one(self,system,user,max_output_tokens):
        # All calls (compiler, generator, QA, repair) enter the SAME budget guard.
        input_upper=len(system)+len(user)+2000
        cap=(input_upper*self.prices['input']+max_output_tokens*self.prices['output'])/1_000_000
        with self._lock:
            if self.total_calls>=self.max_calls:
                raise RunBlocked(f'Đã đạt tổng số lượt API toàn dự án ({self.max_calls}).')
            if self.total_cost+self.unknown_exposure+self.inflight_reserved+cap>self.max_usd:
                raise RunBlocked(f'Không đủ ngân sách toàn dự án: còn ${max(0,self.max_usd-self.total_cost-self.unknown_exposure):.2f}; request cần dự phòng ${cap:.2f}.')
            self.calls+=1
            self.total_calls+=1
            self.inflight_reserved+=cap
            self._persist()  # durable reservation BEFORE the potentially billed request
        try:
            res=self.base.generate(system=system,user=user,max_output_tokens=max_output_tokens)
        except Exception as exc:
            # The API may have consumed tokens even if the adapter raised on
            # incomplete/network timeout. Reserve possible exposure, NOT paid cost.
            with self._lock:
                self.inflight_reserved-=cap
                self.failed+=1;self.total_failed+=1
                in_tok=int(getattr(exc,'input_tokens',0) or 0)
                out_tok=int(getattr(exc,'output_tokens',0) or 0)
                cached=int(getattr(exc,'cached_tokens',0) or 0)
                if in_tok or out_tok:
                    known=(max(0,in_tok-cached)*self.prices['input']+
                           cached*self.prices['cached_input']+out_tok*self.prices['output'])/1_000_000
                    self.cost+=known;self.total_cost+=known;self.in_tokens+=in_tok;self.out_tokens+=out_tok
                    self._event('INCOMPLETE_METERED',known,in_tok,out_tok,cached,str(exc)[:250])
                else:
                    self.unknown_exposure+=cap
                    self._event('UNKNOWN',cap,0,0,0,str(exc)[:250])
                self._persist()
            raise
        actual=(max(0,res.input_tokens-res.cached_tokens)*self.prices['input']+
                res.cached_tokens*self.prices['cached_input']+res.output_tokens*self.prices['output'])/1_000_000
        with self._lock:
            self.inflight_reserved-=cap
            self.cost+=actual;self.total_cost+=actual;self.in_tokens+=res.input_tokens;self.out_tokens+=res.output_tokens
            self._event('COMPLETED',actual,res.input_tokens,res.output_tokens,res.cached_tokens,'')
            self._persist()
        self.notify(f'API toàn dự án: {self.total_calls} lượt; chi phí ước tính ${self.total_cost:.3f} (chưa tính rủi ro phí chưa rõ).')
        return res
    def _event(self,status,value,input_tokens,output_tokens,cached_tokens,message):
        row={'stage':self.current_stage,'status':status,'estimated_or_reserved_usd':round(value,8),
             'input_tokens':input_tokens,'output_tokens':output_tokens,'cached_tokens':cached_tokens,
             'error':message,'timestamp':time.time()}
        with (self.project/'api_request_ledger.jsonl').open('a',encoding='utf8') as f:
            f.write(json.dumps(row,ensure_ascii=False)+'\n')
    def generate(self, *, system:str, user:str, max_output_tokens:int):
        try:return self._one(system,user,max_output_tokens)
        except ContractError as exc:
            # Gateways can bill truncated or interrupted requests. Do NOT
            # silently re-submit them; the user must explicitly choose.
            if self.provider_id in ('teamsoclo','tuansu'):
                raise
            # Other direct providers preserve the prior bounded behavior.
            reason=str(exc)
            if ('max_output_tokens' not in reason and 'giới hạn đầu ra' not in reason) or max_output_tokens>=12000:
                raise
            next_cap=min(12000,max_output_tokens*2+400)
            self.notify(f'Đầu ra chưa hoàn tất; thử lại duy nhất một lần với giới hạn {next_cap} token (có thể tính phí).')
            return self._one(system,user,next_cap)


class OneClickService:
    def __init__(self, studio:Studio):self.studio=studio
    def scope_info(self):
        selected=self.studio.rule_scope()
        return selected
    def estimated_rule_work(self):
        return planning_stats(self.studio.rule_scope().files)
    def prepare_contract(self, provider=None, notify=None):
        notify=notify or (lambda text:None)
        try:
            contract=self.studio.active_contract()
            notify('Sử dụng lại quy trình đã xác minh trong dự án; không cần đọc lại quy tắc bằng GPT.')
            return contract
        except ContractError:
            pass
        notify('Đang chuẩn bị quy trình từ quy tắc đã nạp...')
        draft=self.studio.propose_contract(provider,approve_paid_compilation=(provider is not None),progress=notify)
        notify('Đang kiểm tra ràng buộc, số liệu nguồn, phụ thuộc và điều kiện QA...')
        # New three-panel projects use output roles discovered from the ACTUAL
        # rules, rather than imposing six products from a previous use case.
        # An explicitly edited delivery policy (no automatic marker) is sacred.
        policy_path=self.studio.folder/'delivery_policy.json'
        policy=self.studio.policy()
        if policy.get('mode')=='automatic' and self.studio.rule_scope().full:
            raw=json.loads(Path(draft).read_text(encoding='utf8'))
            binding=raw.get('deliverables')
            if not isinstance(binding,dict) or not binding:
                raise ContractError('Không có vai trò đầu ra được ánh xạ từ quy tắc; không thể sản xuất')
            requested=sorted(binding)
            if policy.get('required_roles')!=requested:
                policy['required_roles']=requested
                tmp=policy_path.with_suffix('.tmp')
                tmp.write_text(json.dumps(policy,ensure_ascii=False,indent=2),encoding='utf8')
                os.replace(tmp,policy_path)
                notify('Tự xác định '+str(len(requested))+' loại thành phẩm từ bộ quy tắc; không ép mẫu sáu file.')
        # Approval is technical contract validation, NOT proof of perfect semantic interpretation.
        contract=self.studio.approve(draft)
        notify(f'Đã khóa quy trình kiểm tra cấu trúc: {len(contract.stages)} công đoạn.')
        return contract
    def run(self,provider, *, notify=None, export_intermediate=False, max_usd=20.0, allow_rule_only=False):
        notify=notify or (lambda text:None)
        if not self.studio._session_lock.acquire(blocking=False):
            raise RunBlocked('Dự án đang có phiên chạy khác')
        self.studio._session_owner_ident=threading.get_ident()
        try:
            present=self.studio.store.source_hashes()
            if not present and not allow_rule_only:
                raise RunBlocked('Chưa có tác phẩm hoặc SRT; không gửi API khi thiếu nguồn.')
            scoped=self.studio.rule_scope()
            if scoped.missing_references:
                raise RunBlocked('Phạm vi quy tắc thiếu tham chiếu: '+'; '.join(scoped.missing_references))
            # Free preflight FIRST. It catches literal SOURCE_* declarations and
            # missing explicitly required audio before any paid compilation.
            self._early_preflight(present,scoped.files)
            initial_sources=dict(present)
            initial_scope=scoped.sha
            contract=self.prepare_contract(provider,notify)
            if self.studio.store.source_hashes()!=initial_sources or self.studio.contract_rule_hash()!=initial_scope:
                raise RunBlocked('Nguồn hoặc phạm vi quy tắc đã thay đổi trong phiên')
            plan=self.studio.preflight(provider)
            if not plan.ready:
                raise RunBlocked('CHƯA ĐỦ TÀI LIỆU — không gọi API sản xuất:\n'+plan.report())
            notify('Đã đủ dữ liệu theo hợp đồng. Bắt đầu các công đoạn...')
            if hasattr(provider,'current_stage'):provider.current_stage='PRODUCTION_AND_QA'
            # BudgetedProvider is the sole authoritative guard across ALL calls.
            result=self.studio.run(provider,max_usd=0 if getattr(provider,'is_budget_manager',False) else max_usd,notify=notify)
            if isinstance(result,Path) and export_intermediate:
                self._export_extra(contract,provider,notify)
            return result
        finally:
            self.studio._session_owner_ident=None
            self.studio._session_lock.release()
    @staticmethod
    def _early_preflight(present,rule_files):
        """Cheap, conservative check: only explicit source identifiers are definitive.

        Implicit natural-language requirements are checked by the compiled plan.
        """
        # Embedded structured contracts can be checked without calling GPT.
        for fn,body in rule_files.items():
            if fn.lower().endswith('.json'):
                try:doc=json.loads(body)
                except (ValueError,TypeError):continue
                if isinstance(doc,dict) and doc.get('schema_version')==1:
                    missing=[name for name in doc.get('required_inputs',[])
                             if isinstance(name,str) and name not in present]
                    if missing:raise RunBlocked('Hợp đồng quy tắc thiếu nguồn bắt buộc: '+', '.join(missing))
        # Never mistake a *mention* of an optional source for a requirement.
        # Only explicit mandatory declaration lines are strong enough to block.
        mandatory=re.compile(r'(?i)\b(REQUIRED_INPUTS?|INPUTS?_REQUIRED|bắt buộc|phải cung cấp|đầu vào cần|must provide|required source)\b')
        for name in ('SOURCE_STORY','SOURCE_AUDIO','SOURCE_HANDOFF'):
            for text in rule_files.values():
                if any(name in line and mandatory.search(line) for line in text.splitlines()):
                    if name not in present:
                        raise RunBlocked(f'Chưa có {name}, trong khi điều khoản quy tắc khai báo là đầu vào bắt buộc. Vui lòng nhập trước khi chạy API.')
    def _export_extra(self,contract,provider,notify):
        """Only intermediate revisions with current dependency fingerprints pass.
        Never label these archives FINAL and never call GPT.
        """
        import zipfile
        from .workflow_plan import stage_fingerprint
        folder=self.studio.folder/'EXPORT_THEM';folder.mkdir(exist_ok=True)
        dest=folder/'TAI_LIEU_TRUNG_GIAN_DA_QA.zip'
        verified=dict(self.studio.store.source_hashes())
        verified_names=set(contract.outputs)
        count=0
        with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
            for sid in contract.order:
                stage=contract.stage_by_id[sid]
                if any(name not in verified for name in stage.inputs):
                    continue
                fp=stage_fingerprint(contract,stage,{x:verified[x] for x in stage.inputs},provider)
                rec=self.studio.store.find_artifact(stage.output,fp)
                if not rec or rec[2]!='PASS':continue
                verified[stage.output]=rec[1]
                if stage.output in verified_names:continue
                z.writestr(stage.output+'.txt',self.studio.store.text(rec[1]))
                count+=1
        notify(f'Đã xuất {count} tài liệu trung gian có QA PASS và phụ thuộc hiện hành, không dùng API: {dest}')
