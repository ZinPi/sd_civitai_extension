"""Independently reproduce vulnerabilities found after the 0.7.14 release.
No real API keys, provider calls, image generation, or paid operations.
"""
from __future__ import annotations
import copy
import json
from pathlib import Path
import pytest
from studio.api import Generation
from studio.contract import ContractError
from studio.fast_analysis import explicit_human_requirements
from studio.rule_conflicts import detect_conflicts
from studio.rule_options import (
    analyze_rules, verify_report_constraints, validate_answers,
    confirmed_choices_text, pending_analysis_chunks, read_rules,
)
from studio.project_setup import initialize_approved_project

class Fake:
    def __init__(self, questions=(), blockers=()):
        self.questions = list(questions)
        self.blockers = list(blockers)
        self.calls = 0
    def generate(self, *, system, user, max_output_tokens):
        self.calls += 1
        name = user.split('TÊN FILE QUY TẮC: ')[1].splitlines()[0]
        questions=[q for q in self.questions if q['source_file']==name]
        data=dict(summary='Offline scan',steps=[],deliverables=[],questions=questions,
                  warnings=[],blockers=self.blockers,assertions=[])
        return Generation(json.dumps(data,ensure_ascii=False))

@pytest.mark.parametrize('wording', [
    'Trước khi bắt đầu, người dùng tự lựa chọn phong cách A hoặc B.',
    'Người dùng tự chọn ngôn ngữ: tiếng Việt hoặc tiếng Anh.',
    'Người dùng được quyền lựa chọn ngôn ngữ: tiếng Việt hoặc tiếng Anh.',
    'Yêu cầu người dùng tự chọn ngôn ngữ: tiếng Việt hoặc tiếng Anh.',
])
def test_fails_closed_if_model_omits_explicit_human_choice(wording,tmp_path):
    rules={'RULES.txt':wording}
    assert explicit_human_requirements(rules,'RULES.txt')
    model=Fake()
    with pytest.raises(ContractError,match='bỏ sót'):
        analyze_rules(rules,model,checkpoint_dir=tmp_path,provider_identity='test:v15')
    assert model.calls==2
    assert pending_analysis_chunks(rules,tmp_path,'test:v15')==1

@pytest.mark.parametrize('wording', [
    'Ví dụ minh họa người dùng tự lựa chọn phong cách A hoặc B.',
    'Example: the user must choose A or B.',
    'AI tự lựa chọn một kiểu tóc trong danh sách được phép.',
])
def test_examples_or_ai_choices_not_user_questions(wording):
    rules={'EX.txt':wording}
    assert not explicit_human_requirements(rules,'EX.txt')
    assert not analyze_rules(rules,Fake())['questions']

@pytest.mark.parametrize('left,right,should_conflict', [
    ('Số cảnh: 10','Số cảnh: 20',True),
    ('Tạo 10 cảnh.','Tạo 20 cảnh.',True),
    ('Số cảnh: 010','Số cảnh: 10',False),
    ('Tạo 010 cảnh.','Tạo 10 cảnh.',False),
    ('Mô tả YouTube: 300 từ','Mô tả YouTube: 300 ký tự',True),
    ('Viết 1 mô tả YouTube dài 300 từ.','Viết 1 mô tả YouTube dài 300 ký tự.',True),
    ('Mô tả YouTube: 300 từ','Mô tả YouTube: 300 words',False),
    ('Phải giữ nguyên toàn bộ lời thoại trực tiếp.',
     'Phải chuyển toàn bộ lời thoại trực tiếp thành gián tiếp, không giữ nguyên.',True),
    ('Nếu người dùng muốn, tạo 10 cảnh.','Tạo 20 cảnh.',False),
    ('Ví dụ: mô tả YouTube 300 từ.','Mô tả YouTube: 300 ký tự',False),
    ('Mô tả nhân vật: 300 từ','Mô tả YouTube: 300 ký tự',False),
])
def test_source_grounded_cross_file_conflict_detection(left,right,should_conflict):
    files={'one.txt':left,'two.txt':right}
    found=detect_conflicts(files)
    assert bool(found)==should_conflict
    if should_conflict:
        report=analyze_rules(files,Fake())
        with pytest.raises(ContractError,match='chưa quyết định'):
            validate_answers(report,{})
        assert len(report['conflicts'])==1


def test_uncertain_cited_model_conflict_requires_review_and_approval(tmp_path):
    files={'A.txt':'Mọi thành phẩm phải trang trọng.', 'B.txt':'Tài liệu phải tự nhiên.'}
    alleged={'description':'Hai câu có thể không tương thích trong một bối cảnh hẹp', 'evidence':[
        dict(source_file='A.txt',source_line=1,source_quote=files['A.txt']),
        dict(source_file='B.txt',source_line=1,source_quote=files['B.txt'])]}
    one=Fake(blockers=[alleged]); report=analyze_rules(files,one,checkpoint_dir=tmp_path,provider_identity='v15')
    assert report['review_items'] and not report['blockers']
    assert not report['conflicts']
    verify_report_constraints(report,files)
    with pytest.raises(ContractError,match='Chưa xem xét'):
        validate_answers(report,{})
    r_id=report['review_items'][0]['id']
    accept={'__reviews__':{r_id:'not_conflict'}}
    assert validate_answers(report,accept)==accept
    assert 'KHÔNG PHẢI XUNG ĐỘT' in confirmed_choices_text(report,accept)
    again=Fake()
    cached=analyze_rules(files,again,checkpoint_dir=tmp_path,provider_identity='v15')
    assert again.calls==0 and cached['review_items']==report['review_items']
    altered=copy.deepcopy(report)
    altered['review_items'][0]['evidence'][0]['source_quote']='fake'
    with pytest.raises(ContractError,match='không khớp'):
        verify_report_constraints(altered,files)
    paths=[]
    for name,value in files.items():
        src=tmp_path/name;src.write_text(value,encoding='utf-8');paths.append(src)
    studio=initialize_approved_project(tmp_path/'project',paths,report,accept)
    try:
        assert 'KHÔNG PHẢI XUNG ĐỘT' in (tmp_path/'project'/'user_choices_confirmed.txt').read_text(encoding='utf-8')
    finally:
        studio.close()


def test_citation_fabrication_cannot_create_review():
    files={'A.txt':'Ngôn ngữ đầu ra: tiếng Việt.'}
    alleged={'description':'Phải dùng tiếng Anh', 'evidence':[
        dict(source_file='A.txt',source_line=1,source_quote=files['A.txt']),
        dict(source_file='fake.txt',source_line=1,source_quote='tiếng Anh')]}
    report=analyze_rules(files,Fake(blockers=[alleged]))
    assert not report['review_items'] and not report['blockers']
    assert report['warnings']


def test_previous_cache_and_report_schema_invalidated(tmp_path):
    source='Ngôn ngữ đầu ra: tiếng Việt.'
    files={'A.txt':source}
    report=analyze_rules(files,Fake(),checkpoint_dir=tmp_path,provider_identity='v15')
    old=copy.deepcopy(report);old['analysis_engine_version']=4
    with pytest.raises(ContractError,match='Báo cáo từ bộ phân tích cũ'):
        verify_report_constraints(old,files)
    old=copy.deepcopy(report);old['conflict_engine_version']=3
    with pytest.raises(ContractError,match='Bản phân tích cũ'):
        verify_report_constraints(old,files)


def test_original_eight_rule_files_are_not_modified_or_detected_as_forms():
    names=['B1.txt','B2.txt','B3.txt','B4.txt','B5.txt','B6.txt','B7.txt','QUY_TRINH_HUONG_DAN.txt']
    root=Path('/mnt/data')
    if not all((root/name).exists() for name in names):
        pytest.skip('Original user files are not mounted')
    rules=read_rules([root/name for name in names])
    assert all(not explicit_human_requirements(rules, name) for name in names)
    report=analyze_rules(rules,Fake(),max_workers=3)
    assert report['file_count']==8 and report['segment_count']==35
    assert not report['questions'] and not report['conflicts']

