"""Source-preserving import for arbitrary rulesets; no profile guesses."""
from __future__ import annotations
from pathlib import Path, PurePosixPath
import zipfile, io, re
from .contract import digest, ContractError

MAX_ARCHIVE=40_000_000
MAX_EXPANDED=80_000_000
MAX_ENTRY=7_000_000
ALLOWED={'.txt','.md','.json','.yaml','.yml'}

def decode_text(raw: bytes) -> str:
    for enc in ('utf-8-sig','utf-16','utf-8','cp1258'):
        try:
            s=raw.decode(enc)
            if '\0' not in s: return s
        except UnicodeError:continue
    raise ContractError('Không thể đọc văn bản quy tắc; cần cung cấp UTF-8')

def inspect_zip(path: Path) -> tuple[dict[str,str], bytes]:
    path=Path(path)
    raw=path.read_bytes()
    if len(raw)>MAX_ARCHIVE:raise ContractError('ZIP quy tắc vượt 40 MB')
    entries={};total=0
    try:
        zf=zipfile.ZipFile(io.BytesIO(raw))
    except (zipfile.BadZipFile,OSError) as e:
        raise ContractError('ZIP quy tắc đã bị thay đổi hoặc bị hỏng') from e
    with zf as z:
        for inf in z.infolist():
            if inf.is_dir():continue
            member=PurePosixPath(inf.filename.replace('\\','/'))
            if member.is_absolute() or '..' in member.parts or inf.filename.startswith(('/', '\\')):
                raise ContractError('Tên file không an toàn trong ZIP')
            if member.suffix.lower() not in ALLOWED:continue
            if inf.file_size>MAX_ENTRY:raise ContractError('Một file quy tắc vượt 7 MB')
            total+=inf.file_size
            if total>MAX_EXPANDED:raise ContractError('ZIP vượt 80 MB sau giải nén')
            name=str(member)
            if name in entries:raise ContractError('Trùng tên file quy tắc: '+name)
            entries[name]=decode_text(z.read(inf))
    if not entries:raise ContractError('Không tìm thấy TXT/MD/JSON/YAML trong ZIP')
    return entries,raw
