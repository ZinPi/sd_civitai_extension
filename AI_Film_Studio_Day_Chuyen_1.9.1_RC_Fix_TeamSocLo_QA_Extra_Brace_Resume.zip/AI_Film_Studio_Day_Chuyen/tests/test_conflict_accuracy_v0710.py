"""v0.7.10: broader mandatory Vietnamese, numeric equivalence and report lifecycle.

These tests target the exact v0.7.9 misclassifications, including when the AI
analyser supplies no additional assertions. They do not claim general NLU.
"""
from __future__ import annotations

import copy
import json

import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.rule_conflicts import detect_conflicts, extract_fixed_rules
from studio.rule_options import analyze_rules, validate_answers, verify_report_constraints
from studio.project_setup import initialize_approved_project


class MissedByAI:
    def generate(self, *, system, user, max_output_tokens):
        return Generation(json.dumps({'summary': 'Đã đọc', 'steps': [],
            'deliverables': [], 'questions': [], 'warnings': [],
            'blockers': [], 'assertions': []}, ensure_ascii=False))


@pytest.mark.parametrize('left,right', [
    ('Các thành phẩm phải viết bằng tiếng Việt.',
     'Các thành phẩm phải viết bằng tiếng Anh.'),
    ('Các thành phẩm đều phải viết bằng tiếng Việt.',
     'Các thành phẩm đều phải được viết bằng tiếng Anh.'),
    ('Những tài liệu phải soạn bằng tiếng Việt.',
     'Những tài liệu phải soạn bằng tiếng Anh.'),
    ('Yêu cầu các thành phẩm bằng tiếng Việt.',
     'Yêu cầu các thành phẩm bằng tiếng Anh.'),
    ('Yêu cầu tất cả tài liệu bằng tiếng Việt.',
     'Yêu cầu tất cả tài liệu bằng tiếng Anh.'),
    ('Quy định các văn bản phải viết bằng tiếng Việt.',
     'Quy định các văn bản phải viết bằng tiếng Anh.'),
    ('Bắt buộc các thành phẩm sử dụng tiếng Việt.',
     'Bắt buộc các thành phẩm sử dụng tiếng Anh.'),
    ('Yêu cầu các thành phẩm viết bằng tiếng Việt.',
     'Yêu cầu các thành phẩm viết bằng tiếng Anh.'),
    ('Các tài liệu phải trình bày bằng tiếng Việt.',
     'Các tài liệu phải trình bày bằng tiếng Anh.'),
    ('Các kết quả phải thể hiện bằng tiếng Việt.',
     'Các kết quả phải thể hiện bằng tiếng Anh.'),
    ('Các thành phẩm phải viết bằng tiếng Việt.',
     'Output language: English.'),
    ('Yêu cầu các thành phẩm bằng tiếng Việt.',
     'All outputs must be written in English.'),
])
def test_mandatory_language_conflicts_without_model_help(left, right):
    files = {'a.txt': left, 'b.txt': right}
    facts = extract_fixed_rules(files)
    assert len(facts) == 2
    report = analyze_rules(files, MissedByAI())
    assert report['conflict_engine_version'] == 4
    assert len(report['conflicts']) == 1
    c = report['conflicts'][0]
    assert (c['left']['source_quote'], c['right']['source_quote']) == (left, right)
    with pytest.raises(ContractError, match='chưa quyết định'):
        validate_answers(report, {})


@pytest.mark.parametrize('left,right', [
    ('Các thành phẩm phải viết bằng tiếng Việt.',
     'Yêu cầu các thành phẩm bằng tiếng Việt.'),
    ('Các thành phẩm phải được viết bằng tiếng Anh.',
     'All outputs must be written in English.'),
    ('Yêu cầu tất cả tài liệu bằng tiếng Việt.',
     'Ngôn ngữ đầu ra: Vietnamese'),
    ('Bắt buộc những văn bản sử dụng tiếng Nhật.',
     'Output language: Japanese.'),
    ('Yêu cầu các thành phẩm bằng tiếng Anh.',
     'Yêu cầu những thành phẩm viết bằng tiếng Anh.'),
])
def test_equivalent_language_phrases_are_not_conflicts(left, right):
    assert not detect_conflicts({'a.txt':left,'b.txt':right})


@pytest.mark.parametrize('left,right', [
    ('Số cảnh: 10', 'Số cảnh: 010'),
    ('Số cảnh: +10', 'Số cảnh: 10'),
    ('Số cảnh: 00010.', 'Số lượng cảnh: 10.0'),
    ('Số câu: 009', 'Số lượng câu: 9'),
    ('Số câu: 000', 'Số câu: 0'),
    ('Số cảnh: 10.00', 'Number of scenes: 10'),
])
def test_fixed_number_written_differently_is_same_count(left, right):
    assert not detect_conflicts({'a.txt':left,'b.txt':right})
    report = analyze_rules({'a.txt':left,'b.txt':right}, MissedByAI())
    assert report['conflicts'] == []


@pytest.mark.parametrize('left,right', [
    ('Số cảnh: 10', 'Số cảnh: 11'),
    ('Số cảnh: 010', 'Số cảnh: 12'),
    ('Số câu: 7', 'Số câu: 08'),
    ('Số cảnh: 10.0', 'Số cảnh: 10.5'),
])
def test_distinct_fixed_counts_still_conflict(left, right):
    assert len(detect_conflicts({'a.txt':left,'b.txt':right})) == 1


@pytest.mark.parametrize('left,right', [
    ('Nếu chọn tiếng Việt, các thành phẩm phải viết bằng tiếng Việt.',
     'Các thành phẩm phải viết bằng tiếng Anh.'),
    ('Yêu cầu các thành phẩm bằng tiếng Việt nếu người dùng muốn.',
     'Yêu cầu các thành phẩm bằng tiếng Anh.'),
    ('Các thành phẩm có thể viết bằng tiếng Việt.',
     'Các thành phẩm phải viết bằng tiếng Anh.'),
    ('Yêu cầu một thành phẩm bằng tiếng Việt.',
     'Các thành phẩm phải viết bằng tiếng Anh.'),
    ('Yêu cầu các thành phẩm bằng tiếng Việt, trừ tài liệu ABC.',
     'Các thành phẩm phải viết bằng tiếng Anh.'),
    ('Số cảnh: 3 hoặc 5', 'Số cảnh: 10'),
])
def test_no_false_global_conflict_from_conditional_optional_or_specific(left,right):
    assert detect_conflicts({'a.txt':left,'b.txt':right}) == []


def test_numeric_identifier_not_changed_and_different_topic_not_compared():
    assert detect_conflicts({'a.txt':'Số cảnh: 10', 'b.txt':'Số câu: 010'}) == []
    assert detect_conflicts({'a.txt':'Định dạng: 010', 'b.txt':'Định dạng: 10'})


def test_multi_file_conflict_choices_propagate_and_reopen(tmp_path):
    items = {'a.txt':'Các thành phẩm phải viết bằng tiếng Việt.\nSố cảnh: 10',
             'b.txt':'Yêu cầu các thành phẩm bằng tiếng Anh.\nSố cảnh: 010',
             'c.txt':'Ngôn ngữ đầu ra: tiếng Việt.\nSố câu: 10'}
    rule_paths=[]
    for filename, content in items.items():
        path=tmp_path/filename
        path.write_text(content, encoding='utf8')
        rule_paths.append(path)
    report=analyze_rules(items, MissedByAI())
    assert report['conflict_engine_version'] == 4
    assert len(report['conflicts']) == 2
    assert {c['topic'] for c in report['conflicts']} == {'ngon_ngu'}
    # Both conflicts choose the Vietnamese rule, despite input file variation.
    decisions={}
    for c in report['conflicts']:
        decisions[c['id']] = ('left' if c['left']['value'] in ('tiếng Việt',)
                               else 'right')
    answers={'__conflicts__':decisions}
    checked=validate_answers(report, answers)
    assert checked==answers
    studio=initialize_approved_project(tmp_path/'project', rule_paths, report, answers)
    try:
        content=(tmp_path/'project'/'user_choices_confirmed.txt').read_text(encoding='utf8')
        assert 'ƯU TIÊN' in content and 'KHÔNG ÁP DỤNG' in content
        frozen=json.loads((tmp_path/'project'/'PHAN_TICH_QUY_TAC.json').read_text(encoding='utf8'))
        verify_report_constraints(frozen, items)
    finally:
        studio.close()


def test_v079_analysis_must_be_reapproved():
    items={'a.txt':'Các thành phẩm phải viết bằng tiếng Việt.',
           'b.txt':'Yêu cầu các thành phẩm bằng tiếng Anh.'}
    report=analyze_rules(items, MissedByAI())
    old=copy.deepcopy(report)
    old['conflict_engine_version']=2
    with pytest.raises(ContractError, match='Bản phân tích cũ'):
        verify_report_constraints(old, items)
    altered=copy.deepcopy(report)
    altered['conflicts']=[]
    with pytest.raises(ContractError, match='không khớp'):
        verify_report_constraints(altered, items)
