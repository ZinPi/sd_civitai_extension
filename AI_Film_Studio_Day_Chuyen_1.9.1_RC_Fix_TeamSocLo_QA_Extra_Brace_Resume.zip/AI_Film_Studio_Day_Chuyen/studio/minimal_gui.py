"""Minimal 3-panel Windows application; workflow logic remains contract-driven.

No credentials written to disk. No generation occurs before the Run confirmation.
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QFrame,
    QLabel, QPushButton, QFileDialog, QComboBox, QLineEdit, QPlainTextEdit,
    QProgressBar, QMessageBox, QDoubleSpinBox, QSpinBox, QScrollArea,
    QDialog, QDialogButtonBox, QCheckBox, QGroupBox,
)
from .api import OpenAIProvider
from .claude_api import ClaudeProvider, fetch_claude_models
from .api_connection import fetch_account_models, probe_responses_model
from .tuansu_api import TuansuProvider, fetch_tuansu_models, probe_tuansu_model
from .contract import ContractError
from .engine import Studio
from .one_click import BudgetedProvider, OneClickService, add_story_file, new_project_folder, normalize_srt
from .rulepack import decode_text
from .local_settings import settings_path
from .rule_options import (read_rules, analyze_rules, analysis_plan, pending_analysis_chunks,
                           rules_digest, validate_answers, confirmed_choices_text, verify_report_constraints)
from .project_setup import analysis_budget_dir, initialize_approved_project, shared_rule_cache_dir

THEME = """
QWidget { background:#0e1626; color:#e9eff9; font-family:'Segoe UI'; font-size:12px; }
QLabel#Head {font-size:23px; font-weight:700; color:#f9fbff;}
QLabel#Sub, QLabel#Muted {color:#9eafc9;}
QLabel#Section {font-size:15px; font-weight:700;}
QFrame#Card {background:#17243a; border:1px solid #2a3b55; border-radius:12px;}
QFrame#Card QLabel {background:transparent;}
QLineEdit, QComboBox, QPlainTextEdit, QDoubleSpinBox, QSpinBox {
 background:#0c1729; color:#ebf3ff; border:1px solid #354866; border-radius:7px; padding:7px;
 selection-background-color:#357ce4; min-height:25px;
}
QComboBox QAbstractItemView {background:#19283d; color:white; selection-background-color:#345c9b;}
QPushButton {background:#263d60; border:1px solid #36587d; border-radius:8px; padding:9px 13px; font-weight:550;}
QPushButton:hover {background:#33527d;}
QPushButton:disabled {background:#1a273a; color:#8294af;}
QPushButton#Start {background:#2770d5; color:white; font-size:14px; font-weight:700; border:1px solid #3981e7;}
QPushButton#Start:hover {background:#3985e5;}
QPushButton#Tiny {padding:5px 9px;}
QProgressBar {height:13px; border:1px solid #36506d; border-radius:6px; text-align:center; background:#0b1626;}
QProgressBar::chunk {background:#3986e5; border-radius:5px;}
QScrollArea {border:0;}
"""


def label(s: str, name: str = 'Muted') -> QLabel:
    l = QLabel(s)
    l.setObjectName(name)
    l.setWordWrap(True)
    return l


def push(name: str, callback, *, primary=False) -> QPushButton:
    b = QPushButton(name)
    b.setCursor(Qt.PointingHandCursor)
    if primary: b.setObjectName('Start')
    b.clicked.connect(callback)
    return b


def card(parent: QVBoxLayout, title: str):
    frame = QFrame()
    frame.setObjectName('Card')
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(17, 14, 17, 14)
    layout.setSpacing(10)
    layout.addWidget(label(title, 'Section'))
    parent.addWidget(frame)
    return layout


def preferences_file() -> Path:
    return settings_path().with_name('simple_preferences.json')


def load_prefs() -> dict:
    try:
        doc = json.loads(preferences_file().read_text(encoding='utf-8'))
        return doc if isinstance(doc, dict) else {}
    except (OSError, ValueError):
        return {}


def save_prefs(values: dict):
    """Save only provider/model/limits; API keys never persist on disk."""
    target = preferences_file()
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix('.tmp')
    tmp.write_text(json.dumps(values, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, target)


def import_inputs(studio: Studio, paths: list[Path]) -> None:
    """Preserve each file's text and label it. SOURCE_STORY is a composite when needed.

    Additional inputs can be referred to in a rulepack using their SOURCE_NAME role.
    SOURCE_AUDIO/HANDOFF preserve legacy contract expectations when recognized.
    """
    if not paths: return
    if len(paths) == 1 and paths[0].suffix.lower() == '.srt':
        add_story_file(studio, paths[0])
        return
    texts = []
    entries: dict[str, tuple[str, str]] = {}
    for i, path in enumerate(paths):
        if not path.is_file(): raise ValueError('Không tìm thấy file: ' + str(path))
        if path.stat().st_size > 20_000_000:
            raise ValueError('File nguồn vượt 20 MB: ' + path.name)
        original = decode_text(path.read_bytes())
        if not original.strip(): raise ValueError('File nguồn trống: ' + path.name)
        texts.append('=== FILE ' + path.name + ' ===\n' + original)
        role = 'SOURCE_' + re.sub(r'[^A-Z0-9_]', '_', path.stem.upper())
        if 'AUDIO' in role or path.suffix.lower() == '.srt':
            if 'SOURCE_AUDIO' not in entries:
                entries['SOURCE_AUDIO'] = ((normalize_srt(original) if path.suffix.lower() == '.srt' else original), str(path))
        elif 'HANDOFF' in role or 'KE_THUA' in role:
            if 'SOURCE_HANDOFF' not in entries:
                entries['SOURCE_HANDOFF'] = (original, str(path))
        # Offer a unique additional source role when a workflow explicitly references it.
        role = role if role not in ('SOURCE_STORY', 'SOURCE_AUDIO', 'SOURCE_HANDOFF') else 'SOURCE_FILE_' + str(i+1)
        if role not in entries: entries[role] = (original, str(path))
    combined = '\n\n'.join(texts)
    if len(combined.encode('utf8')) > 20_000_000:
        raise ValueError('Tổng tài liệu nguồn vượt 20 MB; hãy chia dự án hoặc chọn ít file hơn.')
    entries['SOURCE_STORY'] = (combined, 'Tổng hợp các file nguồn gốc; mỗi file được ghi rõ tên')
    studio.import_sources_atomic(entries)


class ModelWorker(QThread):
    ready = Signal(list)
    failed = Signal(str)

    def __init__(self, provider: str, api_key: str):
        super().__init__()
        self.provider = provider
        self.api_key = api_key

    def run(self):
        try:
            models = (fetch_claude_models(self.api_key) if self.provider == 'claude'
                      else fetch_tuansu_models(self.api_key) if self.provider == 'tuansu'
                      else fetch_account_models(self.api_key))
            self.ready.emit(models)
        except Exception as exc:
            self.failed.emit(str(exc))


class ProbeWorker(QThread):
    ready = Signal(tuple)
    failed = Signal(str)
    def __init__(self, provider: str, key: str, model: str):
        super().__init__()
        self.provider, self.key, self.model = provider, key, model
    def run(self):
        try:
            if self.provider == 'tuansu':
                usage = probe_tuansu_model(self.key, self.model)
            elif self.provider == 'openai':
                usage = probe_responses_model(self.key, self.model, 'default')
            else:
                result = ClaudeProvider(self.key, self.model).generate(
                    system='Trả lời ngắn gọn.', user='Chỉ trả lời OK.', max_output_tokens=64)
                usage = (result.input_tokens, result.output_tokens)
            self.ready.emit(usage)
        except Exception as exc:
            self.failed.emit(type(exc).__name__ + ': ' + str(exc)[:500])


class AnalysisWorker(QThread):
    progress = Signal(str)
    ready = Signal(dict)
    failed = Signal(str)

    def __init__(self, values: dict, rule_paths: list[Path], session_folder: Path):
        super().__init__()
        self.values = dict(values)
        self.rule_paths = list(rule_paths)
        self.session_folder = session_folder

    def run(self):
        try:
            values = self.values
            files = read_rules(self.rule_paths)
            if values['provider'] == 'claude':
                base = ClaudeProvider(values['api_key'], values['model'])
            elif values['provider'] == 'tuansu':
                base = TuansuProvider(values['api_key'], values['model'])
            else:
                base = OpenAIProvider(values['api_key'], values['model'], 'default')
            audit_dir = analysis_budget_dir(self.session_folder)
            audit_dir.mkdir(parents=True, exist_ok=True)
            budget = BudgetedProvider(
                base, audit_dir, max_usd=values['budget'],
                max_calls=values['max_calls'], notify=self.progress.emit,
            )
            budget.current_stage = 'PHAN_TICH_QUY_TAC'
            identity = values['provider'] + ':' + values['model']
            remaining = pending_analysis_chunks(files, audit_dir, identity,
                                               shared_cache_dir=shared_rule_cache_dir())
            if remaining > values['max_calls']:
                raise ContractError(
                    f'Còn {remaining} phần quy tắc cần phân tích, nhưng giới hạn chỉ '
                    f'{values["max_calls"]} lượt API. Hãy tăng giới hạn trong Tùy chọn. '
                    'Chưa gửi yêu cầu API nào trong lần này.'
                )
            if values['provider'] == 'tuansu' and remaining:
                self.progress.emit('Kiểm tra model TuanSu trước khi gửi quy tắc (request ngắn, có thể tính phí)...')
                probe_tuansu_model(values['api_key'], values['model'])
            report = analyze_rules(files, budget, self.progress.emit,
                                   checkpoint_dir=audit_dir, provider_identity=identity,
                                   shared_cache_dir=shared_rule_cache_dir(),
                                   max_workers=values.get('parallel', 3))
            self.ready.emit(report)
        except Exception as exc:
            self.failed.emit(type(exc).__name__ + ': ' + str(exc)[:900])


class RuleOptionsDialog(QDialog):
    """Human review of model-extracted questions and rule references."""
    def __init__(self, report: dict, saved: dict | None = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Phân tích quy tắc — Tùy chọn và xung đột' if report.get('questions') else 'Báo cáo phân tích quy tắc')
        self.resize(720, 625)
        self.report = report
        self.answers = None
        self.editors = {}
        self.conflict_editors = {}
        self.review_editors = {}
        outer = QVBoxLayout(self)
        outer.addWidget(label('BÁO CÁO PHÂN TÍCH QUY TẮC', 'Section'))
        info = QLabel(f"Đã phân tích {report['file_count']} file, "
                      f"{report.get('analyzed_characters', 0):,} ký tự / "
                      f"{report.get('segment_count', 1)} phần. "
                      f"Có {len(report['questions'])} câu hỏi cần xem xét, "
                      f"{len(report.get('conflicts', []))} xung đột cần quyết định, "
                      f"{len(report.get('review_items', []))} nghi vấn cần xem xét.")
        info.setWordWrap(True)
        outer.addWidget(info)
        summary = QPlainTextEdit()
        summary.setReadOnly(True)
        summary.setMinimumHeight(150)
        summary.setMaximumHeight(230)
        full_summary = report['summary'] or 'Không có tóm tắt từ AI.'
        if report.get('steps'):
            full_summary += '\n\nQUY TRÌNH ĐƯỢC NHẬN DIỆN:\n' + '\n'.join('• ' + x for x in report['steps'])
        if report.get('deliverables'):
            full_summary += '\n\nTHÀNH PHẨM ĐƯỢC NHẬN DIỆN:\n' + '\n'.join('• ' + x for x in report['deliverables'])
        summary.setPlainText(full_summary)
        outer.addWidget(summary)
        for heading, key in (('CẢNH BÁO CẦN XEM LẠI', 'warnings'), ('MÂU THUẪN CẦN SỬA FILE GỐC', 'blockers')):
            if report[key]:
                outer.addWidget(label(heading, 'Section'))
                problems = QPlainTextEdit()
                problems.setReadOnly(True)
                problems.setMaximumHeight(75)
                problems.setPlainText('\n'.join('• ' + t for t in report[key]))
                outer.addWidget(problems)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll, 1)
        area = QWidget()
        layout = QVBoxLayout(area)
        scroll.setWidget(area)
        if not report['questions']:
            layout.addWidget(label('Không thấy mục nào đòi NGƯỜI DÙNG lựa chọn.\nCác bước AI tự quyết vẫn theo quy tắc gốc.'))
        saved = saved or {}
        if report.get('conflicts'):
            layout.addWidget(label('XUNG ĐỘT GIỮA CÁC FILE — BẮT BUỘC CHỌN', 'Section'))
            layout.addWidget(label('Chọn điều khoản được ưu tiên cho từng xung đột. '
                                   'Không tự động bỏ qua các quy tắc khác trong file còn lại.'))
            for item in report['conflicts']:
                group = QGroupBox('Xung đột: ' + item['topic'])
                content = QVBoxLayout(group)
                left, right = item['left'], item['right']
                for tag, rule in (('A', left), ('B', right)):
                    quote = label(f'{tag} · {rule["source_file"]}:{rule["source_line"]}\n'
                                  + rule['source_quote'][:500])
                    quote.setTextInteractionFlags(Qt.TextSelectableByMouse)
                    content.addWidget(quote)
                pick = QComboBox()
                pick.addItem('— Chọn điều khoản ưu tiên —', None)
                for key, rule in (('left', left), ('right', right)):
                    pick.addItem(f'{rule["source_file"]} · dòng {rule["source_line"]}', key)
                decided = saved.get('__conflicts__', {}).get(item['id'])
                for ix in range(pick.count()):
                    if pick.itemData(ix) == decided and decided:
                        pick.setCurrentIndex(ix)
                content.addWidget(pick)
                layout.addWidget(group)
                self.conflict_editors[item['id']] = pick
        if report.get('review_items'):
            layout.addWidget(label('NGHI VẤN TỪ AI — CẦN NGƯỜI DÙNG ĐỐI CHIẾU', 'Section'))
            layout.addWidget(label('Hai dẫn chứng có thật không có nghĩa đã mâu thuẫn. '
                                   'Đọc lại cả hai và quyết định.'))
            for item in report['review_items']:
                group = QGroupBox('Cần đối chiếu: ' + item['description'][:120])
                content = QVBoxLayout(group)
                for tag, rule in zip(('A', 'B'), item['evidence']):
                    detail = label(f'{tag} · {rule["source_file"]}:{rule["source_line"]}\n'
                                   + rule['source_quote'][:700])
                    detail.setTextInteractionFlags(Qt.TextSelectableByMouse)
                    content.addWidget(detail)
                pick = QComboBox()
                pick.addItem('— Chưa quyết định —', None)
                pick.addItem('Không mâu thuẫn — giữ cả hai', 'not_conflict')
                pick.addItem('Mâu thuẫn — ưu tiên A', 'left')
                pick.addItem('Mâu thuẫn — ưu tiên B', 'right')
                selected = saved.get('__reviews__', {}).get(item['id'])
                for ix in range(pick.count()):
                    if pick.itemData(ix) == selected and selected:
                        pick.setCurrentIndex(ix)
                content.addWidget(pick)
                layout.addWidget(group)
                self.review_editors[item['id']] = pick
        for q in report['questions']:
            g = QGroupBox((('* ' if q['required'] else '') + q['question']))
            gl = QVBoxLayout(g)
            gl.addWidget(label(f"Nguồn: {q['source_file']} · dòng {q['source_line']}"))
            quote = label('“' + q['source_quote'][:350] + '”')
            quote.setTextInteractionFlags(Qt.TextSelectableByMouse)
            gl.addWidget(quote)
            if q['kind'] == 'number':
                limits = report.get('numeric_constraints', {}).get(q['id'], {})
                desc = []
                if 'minimum' in limits: desc.append('Từ ' + str(limits['minimum']) + (' (không gồm)' if limits.get('exclude_minimum') else ''))
                if 'maximum' in limits: desc.append('Đến ' + str(limits['maximum']) + (' (không gồm)' if limits.get('exclude_maximum') else ''))
                if limits.get('integer'): desc.append('Số nguyên')
                if limits.get('positive'): desc.append('Số dương')
                if limits.get('allowed_values'): desc.append('Chỉ chọn: ' + ' / '.join(limits['allowed_values']))
                if limits.get('parity'): desc.append('Số chẵn' if limits['parity'] == 'even' else 'Số lẻ')
                if limits.get('multiple_of'): desc.append('Chia hết cho ' + str(limits['multiple_of']))
                if desc: gl.addWidget(label('Giới hạn theo quy tắc: ' + '; '.join(desc)))
            current = saved.get(q['id'])
            enum_numbers = (report.get('numeric_constraints', {}).get(q['id'], {}).get('allowed_values', [])
                            if q['kind'] == 'number' else [])
            if q['kind'] in ('single', 'yes_no') or enum_numbers:
                box = QComboBox()
                box.addItem('— Chưa chọn —', None)
                if enum_numbers:
                    for item in enum_numbers: box.addItem(item, item)
                elif q['kind'] == 'single':
                    for item in q['choices']: box.addItem(item, item)
                else:
                    box.addItem('Có', True)
                    box.addItem('Không', False)
                for i in range(box.count()):
                    if current is not None and box.itemData(i) == current:
                        box.setCurrentIndex(i)
                        break
                gl.addWidget(box)
                self.editors[q['id']] = ('combo', box)
            elif q['kind'] == 'multi':
                boxes = []
                for choice in q['choices']:
                    check = QCheckBox(choice)
                    check.setChecked(choice in (current or []))
                    gl.addWidget(check)
                    boxes.append((choice, check))
                self.editors[q['id']] = ('multi', boxes)
            else:
                edit = QLineEdit()
                edit.setPlaceholderText('Nhập con số' if q['kind'] == 'number' else 'Điền tùy chọn của bạn')
                if current is not None: edit.setText(str(current))
                gl.addWidget(edit)
                self.editors[q['id']] = ('text', edit)
            layout.addWidget(g)
        layout.addStretch(1)
        note = label('* là câu hỏi bắt buộc. Hãy đối chiếu file gốc trước khi xác nhận.' if report['questions'] else 'Xung đột/chặn sản xuất (nếu có) vẫn phải được xử lý.')
        outer.addWidget(note)
        buttons = QDialogButtonBox(QDialogButtonBox.Cancel | QDialogButtonBox.Ok)
        buttons.button(QDialogButtonBox.Ok).setText('Xác nhận báo cáo' if not report['questions'] else 'Xác nhận các tùy chọn')
        buttons.button(QDialogButtonBox.Cancel).setText('Quay lại')
        if report['blockers']:
            buttons.button(QDialogButtonBox.Ok).setEnabled(False)
        buttons.accepted.connect(self.accept_checked)
        buttons.rejected.connect(self.reject)
        outer.addWidget(buttons)

    def accept_checked(self):
        answers = {}
        for q in self.report['questions']:
            kind, editor = self.editors[q['id']]
            if kind == 'combo':
                val = editor.currentData()
            elif kind == 'multi':
                val = [name for name, checkbox in editor if checkbox.isChecked()]
            else:
                val = editor.text().strip()
            if val not in (None, '', []):
                answers[q['id']] = val
        if self.review_editors:
            answers['__reviews__'] = {key: editor.currentData()
                                      for key, editor in self.review_editors.items()
                                      if editor.currentData() is not None}
        if self.conflict_editors:
            answers['__conflicts__'] = {key: editor.currentData()
                                        for key, editor in self.conflict_editors.items()
                                        if editor.currentData() is not None}
        try:
            self.answers = validate_answers(self.report, answers)
            confirmed_choices_text(self.report, self.answers)
        except ContractError as exc:
            QMessageBox.warning(self, 'Còn thiếu tùy chọn', str(exc))
            return
        self.accept()


class RunWorker(QThread):
    progress = Signal(str)
    done = Signal(str)
    failed = Signal(str)

    def __init__(self, studio, values):
        super().__init__()
        self.studio = studio
        self.values = dict(values)

    def run(self):
        try:
            values = self.values
            self.studio.stop.clear()
            if values['provider'] == 'claude':
                base = ClaudeProvider(values['api_key'], values['model'])
            elif values['provider'] == 'tuansu':
                base = TuansuProvider(values['api_key'], values['model'])
            else:
                base = OpenAIProvider(values['api_key'], values['model'], 'default')
            if values['provider'] == 'tuansu':
                base.concurrency_limit = min(2, values.get('parallel', 2))
                self.progress.emit('Kiểm tra model TuanSu trước khi sản xuất (gọi API nhỏ có thể tính phí)...')
                probe_tuansu_model(values['api_key'], values['model'])
            budget = BudgetedProvider(
                base, self.studio.folder, max_usd=values['budget'],
                max_calls=values['max_calls'], notify=self._progress,
            )
            result = OneClickService(self.studio).run(
                budget, notify=self._progress, allow_rule_only=True, export_intermediate=False,
            )
            self.done.emit(str(result))
        except Exception as exc:
            # No request payload or key is shown in a GUI traceback.
            self.failed.emit(type(exc).__name__ + ': ' + str(exc)[:900])

    def _progress(self, msg):
        if self.studio.stop.is_set():
            raise ContractError('Đã yêu cầu dừng; kiểm tra và checkpoint đã lưu được giữ lại.')
        self.progress.emit(str(msg))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('AI FILM STUDIO v0.7.17 | Văn bản → Văn bản')
        self.resize(860, 780)
        self.setMinimumSize(690, 620)
        self.source_paths = []
        self.rule_paths = []
        self.studio: Studio | None = None
        self.model_worker = None
        self.worker = None
        self.loaded_project = False
        self.latest_output = None
        self.prefs = load_prefs()
        self.analysis_worker = None
        self.analysis_folder = None
        self.analysis_report = None
        self.analysis_identity = None
        self.selected_answers = None
        self.analysis_approved = False
        self.project_root = Path(self.prefs.get('project_root', str(Path.home()/'Documents'/'AI_Film_Studio'/'Projects')))

        main = QWidget()
        self.setCentralWidget(main)
        outer = QVBoxLayout(main)
        outer.setContentsMargins(18, 15, 18, 15)
        outer.setSpacing(12)
        top = QHBoxLayout()
        heading = QVBoxLayout()
        heading.addWidget(label('AI FILM STUDIO', 'Head'))
        heading.addWidget(label('Tự động xử lý văn bản theo quy trình và quy tắc bạn cung cấp.', 'Sub'))
        top.addLayout(heading, 1)
        top.addWidget(push('Mở dự án cũ', self.open_project))
        top.addWidget(push('Dự án mới', self.reset_project))
        outer.addLayout(top)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        outer.addWidget(scroll, 1)
        inner = QWidget()
        scroll.setWidget(inner)
        col = QVBoxLayout(inner)
        col.setContentsMargins(3, 3, 6, 3)
        col.setSpacing(12)

        ai = card(col, 'AI XỬ LÝ')
        selectors = QHBoxLayout()
        self.provider = QComboBox()
        self.provider.addItem('OpenAI', 'openai')
        self.provider.addItem('Claude (Anthropic)', 'claude')
        self.provider.addItem('TuanSu API', 'tuansu')
        self.provider.setMinimumWidth(175)
        self.provider.currentIndexChanged.connect(self.provider_changed)
        selectors.addWidget(self.provider, 1)
        self.model = QComboBox()
        self.model.setEditable(True)
        self.model.setInsertPolicy(QComboBox.NoInsert)
        self.model.lineEdit().setPlaceholderText('Chọn hoặc nhập mã model')
        self.model.setMinimumWidth(210)
        selectors.addWidget(self.model, 2)
        self.refresh = push('Lấy danh sách model', self.load_models)
        selectors.addWidget(self.refresh)
        self.probe = push('Thử model', self.test_model)
        selectors.addWidget(self.probe)
        ai.addLayout(selectors)
        keyline = QHBoxLayout()
        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.Password)
        self.key.setPlaceholderText('API key của nhà cung cấp đã chọn — chỉ giữ trong phiên')
        keyline.addWidget(self.key, 1)
        self.toggle_key = push('Hiện', self.toggle_password)
        self.toggle_key.setObjectName('Tiny')
        keyline.addWidget(self.toggle_key)
        ai.addLayout(keyline)
        ai.addWidget(label('Model trong danh sách CHƯA chắc gọi được; bấm Thử model (request nhỏ có phí). '
                           'TuanSu không hỗ trợ /models thì nhập mã được cấp và bấm Thử model.', 'Muted'))

        inp = card(col, '1. TÀI LIỆU NGUỒN')
        inp.addWidget(label('Truyện, nội dung, tài liệu tham chiếu (có thể bỏ trống nếu bộ quy tắc không cần).'))
        input_row = QHBoxLayout()
        input_row.addWidget(push('+ Chọn file nguồn', self.choose_inputs))
        self.inp_info = label('Chưa có file nguồn', 'Muted')
        input_row.addWidget(self.inp_info, 1)
        inp.addLayout(input_row)

        rules = card(col, '2. QUY TRÌNH · HƯỚNG DẪN · QUY TẮC')
        rules.addWidget(label('Chọn một hoặc nhiều file TXT / MD / JSON / YAML / ZIP. Chính các file này quyết định các bước và thành phẩm.'))
        rule_row = QHBoxLayout()
        rule_row.addWidget(push('+ Chọn file quy tắc', self.choose_rules))
        self.rule_info = label('Chưa có file quy tắc', 'Muted')
        rule_row.addWidget(self.rule_info, 1)
        rules.addLayout(rule_row)
        rule_analyze = QHBoxLayout()
        self.analyze_btn = push('① Phân tích quy tắc', self.analyze_selected_rules)
        rule_analyze.addWidget(self.analyze_btn)
        self.review_btn = push('Xem / sửa tùy chọn', self.review_options)
        self.review_btn.setEnabled(False)
        rule_analyze.addWidget(self.review_btn)
        rule_analyze.addStretch(1)
        rules.addLayout(rule_analyze)
        self.analysis_note = label('Chưa phân tích. AI sẽ tìm các mục cần người dùng lựa chọn trước khi sản xuất.')
        rules.addWidget(self.analysis_note)


        output = card(col, '3. THÀNH PHẨM')
        self.status = label('Sẵn sàng nhận tài liệu.', 'Muted')
        output.addWidget(self.status)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        output.addWidget(self.progress)
        actions = QHBoxLayout()
        self.start_btn = push('② BẮT ĐẦU SẢN XUẤT', self.start, primary=True)
        self.start_btn.setMinimumHeight(44)
        actions.addWidget(self.start_btn, 2)
        self.stop_btn = push('Dừng an toàn', self.stop)
        self.stop_btn.setEnabled(False)
        actions.addWidget(self.stop_btn)
        actions.addWidget(push('Mở kết quả', self.open_results))
        output.addLayout(actions)
        small = QHBoxLayout()
        self.detail_btn = push('Chi tiết ▾', self.toggle_details)
        small.addWidget(self.detail_btn)
        small.addWidget(push('Nơi lưu...', self.choose_project_root))
        small.addStretch()
        self.more_btn = push('Tùy chọn ▾', self.toggle_advanced)
        small.addWidget(self.more_btn)
        output.addLayout(small)
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setMaximumBlockCount(1000)
        self.details.setMinimumHeight(145)
        self.details.setVisible(False)
        output.addWidget(self.details)
        self.advanced = QWidget()
        more = QHBoxLayout(self.advanced)
        more.setContentsMargins(0, 4, 0, 3)
        more.addWidget(label('Ngân sách dự phòng ($, không phải giá TuanSu)'))
        self.budget = QDoubleSpinBox()
        self.budget.setRange(1, 1000)
        self.budget.setValue(float(self.prefs.get('budget', 20)))
        self.budget.setDecimals(2)
        more.addWidget(self.budget)
        more.addWidget(label('Số lượt API tối đa'))
        self.max_calls = QSpinBox()
        self.max_calls.setRange(1, 1000)
        self.max_calls.setValue(int(self.prefs.get('max_calls', 180)))
        more.addWidget(self.max_calls)
        more.addWidget(label('Song song'))
        self.parallel = QSpinBox()
        self.parallel.setRange(1, 3)
        self.parallel.setValue(int(self.prefs.get('parallel', 2)))
        more.addWidget(self.parallel)
        self.advanced.setVisible(False)
        output.addWidget(self.advanced)
        col.addStretch()
        foot = label('Chỉ gửi dữ liệu đến API khi bạn xác nhận chạy. Ngân sách là bảo vệ ước tính, không phải giới hạn hóa đơn tuyệt đối.', 'Muted')
        outer.addWidget(foot)
        provider_idx = self.provider.findData(self.prefs.get('provider', 'openai'))
        self.provider.setCurrentIndex(max(provider_idx, 0))
        self.model.setEditText(self.prefs.get('model_' + self.provider.currentData(), ''))

    def provider_changed(self):
        self.model.clear()
        if hasattr(self, 'prefs'):
            self.model.setEditText(self.prefs.get('model_' + self.provider.currentData(), ''))
        if hasattr(self, 'key'):
            self.key.clear()  # Never inadvertently use an OpenAI key with Anthropic or vice versa.
        if hasattr(self, 'status'):
            if hasattr(self, 'parallel'):
                self.parallel.setMaximum(2 if self.provider.currentData() == 'tuansu' else 3)
                if self.provider.currentData() == 'tuansu': self.parallel.setValue(min(2, self.parallel.value()))
            self.status.setText('Chọn model và nhập API key cho ' + self.provider.currentText() + '.')

    def toggle_password(self):
        show = self.key.echoMode() == QLineEdit.Password
        self.key.setEchoMode(QLineEdit.Normal if show else QLineEdit.Password)
        self.toggle_key.setText('Ẩn' if show else 'Hiện')

    def load_models(self):
        if not self.key.text().strip():
            self.warn('Hãy nhập API key trước khi lấy danh sách model.')
            return
        if self.model_worker and self.model_worker.isRunning(): return
        self.refresh.setEnabled(False)
        self.provider.setEnabled(False)
        self.status.setText('Đang lấy danh sách model (không gọi API sinh nội dung)...')
        self.model_worker = ModelWorker(self.provider.currentData(), self.key.text().strip())
        self.model_worker.ready.connect(self.models_ready)
        self.model_worker.failed.connect(self.models_failed)
        self.model_worker.start()

    def test_model(self):
        if not self.key.text().strip() or not self.model.currentText().strip():
            return self.warn('Hãy nhập key và mã model trước khi thử.')
        if getattr(self, 'probe_worker', None) and self.probe_worker.isRunning(): return
        reply = QMessageBox.question(self, 'Kiểm tra model có thể tính phí',
                    'Sẽ gửi một câu thử rất ngắn tới nhà cung cấp API, có thể tính phí. Tiếp tục?',
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply != QMessageBox.Yes: return
        self.probe.setEnabled(False)
        self.provider.setEnabled(False)
        self.probe_worker = ProbeWorker(self.provider.currentData(), self.key.text().strip(),
                                        self.model.currentText().strip())
        self.probe_worker.ready.connect(self.probe_ready)
        self.probe_worker.failed.connect(self.probe_failed)
        self.probe_worker.start()

    def probe_ready(self, usage):
        self.probe.setEnabled(True)
        self.provider.setEnabled(True)
        self.status.setText(f'Model đã trả văn bản thành công (input {usage[0]}, output {usage[1]} token).')

    def probe_failed(self, message):
        self.probe.setEnabled(True)
        self.provider.setEnabled(True)
        self.warn('Model chưa vượt qua kiểm tra: ' + message)

    def models_ready(self, values):
        before = self.model.currentText().strip()
        self.model.clear()
        self.model.addItems(values)
        if before and before in values: self.model.setCurrentText(before)
        elif before: self.model.setEditText(before)
        self.status.setText(f'Có {len(values)} model. Chọn model phù hợp rồi bắt đầu.')
        self.refresh.setEnabled(True)
        self.provider.setEnabled(True)

    def models_failed(self, err):
        self.refresh.setEnabled(True)
        self.provider.setEnabled(True)
        self.status.setText('Không lấy được model: ' + err)

    def warn(self, text):
        QMessageBox.warning(self, 'AI Film Studio', str(text))

    def _detach_project(self):
        if self.studio:
            self.studio.close()
            self.studio = None
        self.loaded_project = False
        self.latest_output = None

    def _running(self):
        return bool(self.worker and self.worker.isRunning())

    def clear_analysis(self):
        self.analysis_identity = None
        self.analysis_report = None
        self.analysis_identity = None
        self.selected_answers = None
        self.analysis_approved = False
        self.analysis_folder = None
        if hasattr(self, 'analysis_note'):
            self.analysis_note.setText('Chưa phân tích quy tắc. Hãy bấm “Phân tích quy tắc”.')
        if hasattr(self, 'review_btn'):
            self.review_btn.setEnabled(False)
            self.review_btn.setText('Xem / sửa tùy chọn')

    def reset_project(self):
        if self._running() or (self.analysis_worker and self.analysis_worker.isRunning()):
            return self.warn('Đang xử lý API. Không thể tạo dự án mới.')
        self._detach_project()
        self.source_paths.clear()
        self.rule_paths.clear()
        self.clear_analysis()
        self.inp_info.setText('Chưa có file nguồn')
        self.rule_info.setText('Chưa có file quy tắc')
        self.progress.setValue(0)
        self.details.clear()
        self.status.setText('Dự án mới. Hãy chọn tài liệu.')

    def choose_inputs(self):
        if self._running() or (self.analysis_worker and self.analysis_worker.isRunning()): return
        paths, _ = QFileDialog.getOpenFileNames(self, 'Chọn tài liệu nguồn', '',
            'Văn bản (*.txt *.md *.srt *.json *.yaml *.yml)')
        if paths:
            if self.studio:
                self._detach_project()
                self.clear_analysis()
            self.source_paths = [Path(p) for p in paths]
            self.inp_info.setText(f'{len(paths)} file: ' + ', '.join(p.name for p in self.source_paths)[:130])

    def choose_rules(self):
        if self._running() or (self.analysis_worker and self.analysis_worker.isRunning()): return
        paths, _ = QFileDialog.getOpenFileNames(self, 'Chọn quy trình, hướng dẫn, quy tắc', '',
            'Quy tắc (*.zip *.txt *.md *.json *.yaml *.yml)')
        if paths:
            if self.studio: self._detach_project()
            self.clear_analysis()
            self.rule_paths = [Path(p) for p in paths]
            self.rule_info.setText(f'{len(paths)} file: ' + ', '.join(p.name for p in self.rule_paths)[:130])

    def choose_project_root(self):
        if self._running() or (self.analysis_worker and self.analysis_worker.isRunning()): return
        if self.analysis_folder:
            return self.warn('Đã bắt đầu phân tích tại nơi lưu hiện tại. Hãy chọn nơi lưu trước khi phân tích bộ quy tắc mới.')
        folder = QFileDialog.getExistingDirectory(self, 'Chọn nơi lưu dự án', str(self.project_root))
        if folder:
            self.project_root = Path(folder)
            self.status.setText('Dự án mới sẽ được lưu tại: ' + folder)

    def open_project(self):
        if self._running() or (self.analysis_worker and self.analysis_worker.isRunning()):
            return self.warn('Đang xử lý API. Không thể mở dự án khác.')
        folder = QFileDialog.getExistingDirectory(self, 'Chọn thư mục dự án đã lưu', str(self.project_root))
        if not folder: return
        new = None
        try:
            location = Path(folder)
            if not (location / '.ai_film_studio_v6').is_file():
                raise ContractError('Đây chưa phải thư mục dự án AI Film Studio hợp lệ.')
            new = Studio(location)
            source_count = len(new.store.source_hashes())
            rule_files = new.rule_files()
            saved_report = new.folder / 'PHAN_TICH_QUY_TAC.json'
            saved_answers = new.folder / 'TUY_CHON_DA_CHON.json'
            report = None
            answers = None
            if saved_report.exists() != saved_answers.exists():
                raise ContractError('Bộ hồ sơ tùy chọn dự án không đầy đủ.')
            if saved_report.exists():
                report = json.loads(saved_report.read_text(encoding='utf-8'))
                answers = json.loads(saved_answers.read_text(encoding='utf-8'))
                if report.get('schema_version', 0) < 2 or report.get('constraint_engine_version') != 2:
                    raise ContractError('Báo cáo phân tích phiên bản cũ chưa xác minh lựa chọn số/chẵn-lẻ. Hãy tạo dự án mới và phân tích lại quy tắc.')
                source_set = {k: v for k, v in rule_files.items()
                              if k != '00_TUY_CHON_NGUOI_DUNG.txt'}
                if not report.get('reviewed') or report.get('rules_digest') != rules_digest(source_set):
                    raise ContractError('Báo cáo tùy chọn không còn khớp với quy tắc gốc.')
                verify_report_constraints(report, source_set)
                checked = validate_answers(report, answers)
                frozen = confirmed_choices_text(report, checked)
                if frozen != new._confirmed_options():
                    raise ContractError('Báo cáo hoặc tùy chọn đã bị sửa sau khi khóa dự án.')
                answers = checked
            # Validation is complete: only now detach the previous project.
            self._detach_project()
            self.studio = new
            new = None
            self.loaded_project = True
            self.clear_analysis()
            self.source_paths = []
            self.rule_paths = []
            self.inp_info.setText(f'Đã nạp {source_count} nguồn từ dự án')
            self.rule_info.setText(f'Đã nạp {len(rule_files)} file quy tắc từ dự án')
            if report is not None:
                self.analysis_report = report
                self.selected_answers = answers
                self.analysis_approved = True
                self.review_btn.setEnabled(False)
                self.analysis_note.setText('Đã có báo cáo phân tích và tùy chọn được duyệt trong dự án.')
            else:
                self.analysis_note.setText('Dự án cũ chưa có bước phân tích tùy chọn; muốn áp dụng hãy tạo dự án mới từ file quy tắc.')
            self.status.setText('Đã mở: ' + location.name)
        except Exception as exc:
            if new is not None:
                try: new.close()
                except Exception: pass
            self.warn(str(exc))

    def _api_values(self):
        key = self.key.text().strip()
        model = self.model.currentText().strip()
        if not key:
            raise ValueError('Hãy nhập API key.')
        if not model:
            raise ValueError('Hãy chọn hoặc nhập mã model.')
        return {
            'provider': self.provider.currentData(), 'api_key': key, 'model': model,
            'budget': self.budget.value(), 'max_calls': self.max_calls.value(),
            'parallel': min(self.parallel.value(), 2 if self.provider.currentData() == 'tuansu' else 3),
        }

    def analyze_selected_rules(self):
        if self._running() or (self.analysis_worker and self.analysis_worker.isRunning()):
            return
        try:
            if self.studio and self.loaded_project:
                raise ValueError('Để thay lựa chọn của dự án đã khóa, hãy tạo DỰ ÁN MỚI rồi nạp các file quy tắc gốc.')
            if not self.rule_paths:
                raise ValueError('Hãy chọn file quy trình / quy tắc trước.')
            values = self._api_values()
            files = read_rules(self.rule_paths)
            if self.analysis_report and (self.analysis_identity !=
                    (values['provider'], values['model'])):
                self.clear_analysis()  # A new provider/model requires fresh rule analysis.
            if self.analysis_report and self.analysis_report.get('rules_digest') == rules_digest(files):
                return self.review_options()
            plan = analysis_plan(files)
            identity = values['provider'] + ':' + values['model']
            old_audit = analysis_budget_dir(self.analysis_folder) if self.analysis_folder else None
            remaining = pending_analysis_chunks(files, old_audit, identity,
                                                shared_cache_dir=shared_rule_cache_dir())
            if remaining > values['max_calls']:
                raise ValueError(f'Cần tối thiểu {remaining} lượt API để đọc đủ tài liệu, '
                                 f'nhưng Tùy chọn chỉ cho {values["max_calls"]} lượt. '
                                 'Hãy tăng giới hạn trước khi phân tích.')
            notice = (
                f'Bộ quy tắc: {plan["characters"]:,} ký tự, {plan["files"]} file.\n'
                f'Chia thành {plan["segments"]} phần; còn {remaining} phần cần gọi API.\n'
                f'Phân tích tối đa {values["parallel"]} phần song song (TuanSu tối đa 2).\n\n'
                'AI sẽ kiểm tra TẤT CẢ các phần, không bỏ qua đoạn cuối. '
                'Kết quả mỗi phần được lưu để có thể tiếp tục nếu gián đoạn.\n'
                'Với TuanSu, nếu có phần chưa cache, hệ thống thử model bằng request nhỏ trước (có thể tính phí). '
                'Có thể phát sinh chi phí API cho mỗi phần. '
                'Chi phí thực tế phụ thuộc model, ngôn ngữ và số lượt chạy lại.\n\n'
                'Tiếp tục phân tích?'
            )
            if QMessageBox.question(self, 'Xác nhận phân tích bằng API', notice,
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                return
            if self.analysis_folder is None:
                self.analysis_folder = new_project_folder(self.project_root)
            self.analysis_worker = AnalysisWorker(values, self.rule_paths, self.analysis_folder)
            self.analysis_worker.progress.connect(self.message)
            self.analysis_worker.ready.connect(self.analysis_ready)
            self.analysis_worker.failed.connect(self.analysis_failed)
            self.analyze_btn.setEnabled(False)
            self.start_btn.setEnabled(False)
            self.status.setText('Đang phân tích quy tắc và xác định các câu hỏi...')
            self.analysis_worker.start()
        except Exception as exc:
            self.warn(str(exc))

    def analysis_ready(self, report):
        self.analyze_btn.setEnabled(True)
        self.start_btn.setEnabled(True)
        self.analysis_report = report
        self.analysis_identity = (self.analysis_worker.values['provider'],
                                  self.analysis_worker.values['model'])
        self.selected_answers = None
        self.analysis_approved = False
        self.review_btn.setEnabled(True)
        self.review_btn.setText('Xem phân tích' if not report['questions'] else 'Xem / sửa tùy chọn')
        self.analysis_note.setText(
            f"Đã đọc {report.get('segment_count', 1)} phần, "
            f"tìm {len(report['questions'])} tùy chọn, "
            f"{len(report.get('conflicts', []))} xung đột, "
            f"{len(report.get('review_items', []))} nghi vấn. Hãy xem và xác nhận."
        )
        if not report['questions'] and not report.get('conflicts') and not report.get('blockers') and not report.get('warnings') and not report.get('review_items'):
            try:
                self.selected_answers = validate_answers(report, {})
                confirmed_choices_text(report, self.selected_answers)
                self.analysis_approved = True
                self.status.setText('Phân tích xong: không có tùy chọn cần chọn. Sẵn sàng sản xuất.')
                self.analysis_note.setText(
                    f"Đã đọc {report.get('segment_count', 1)} phần. Không có tùy chọn bắt buộc "
                    'hoặc xung đột được phát hiện. Có thể xem báo cáo hoặc bắt đầu sản xuất.'
                )
                return
            except ContractError as exc:
                self.warn(str(exc))
        self.status.setText('Đã phân tích xong. Xem báo cáo, giải quyết các vấn đề nếu có.')
        self.review_options()

    def analysis_failed(self, err):
        self.analyze_btn.setEnabled(True)
        self.start_btn.setEnabled(True)
        self.status.setText('Phân tích quy tắc chưa hoàn tất.')
        self.warn(err + '\n\nKhông được bắt đầu sản xuất khi chưa duyệt phân tích.')

    def review_options(self):
        if not self.analysis_report:
            self.warn('Bạn chưa phân tích quy tắc.')
            return
        if self._running(): return
        if self.studio is not None:
            self.warn('Tùy chọn đã khóa trong dự án này. Hãy tạo DỰ ÁN MỚI nếu muốn thay đổi. '
                      'Bản phân tích và các lựa chọn được lưu trong thư mục dự án.')
            return
        dlg = RuleOptionsDialog(self.analysis_report, self.selected_answers, self)
        if dlg.exec() == QDialog.Accepted:
            self.selected_answers = dlg.answers
            self.analysis_approved = True
            if self.analysis_report['questions']:
                self.analysis_note.setText(
                    f"Đã duyệt {len(self.analysis_report['questions'])} mục và "
                    f"{len(self.analysis_report.get('conflicts', []))} xung đột. Sẵn sàng sản xuất.")
            else:
                self.analysis_note.setText('Đã duyệt phân tích, không có tùy chọn người dùng. '
                                           'Đã giải quyết các xung đột được phát hiện.')
            self.status.setText('Đã duyệt phân tích. Bấm BẮT ĐẦU SẢN XUẤT khi sẵn sàng.')

    def _ensure_project(self):
        if self.studio: return self.studio
        if not self.rule_paths: raise ValueError('Bạn chưa chọn file quy trình / hướng dẫn / quy tắc.')
        if not self.analysis_approved or self.analysis_report is None or self.selected_answers is None:
            raise ValueError('Bạn phải hoàn thành PHÂN TÍCH QUY TẮC và giải quyết các vấn đề bắt buộc trước khi sản xuất.')
        if self.analysis_identity is not None and self.analysis_identity != (
                self.provider.currentData(), self.model.currentText().strip()):
            self.clear_analysis()
            raise ValueError('Nhà cung cấp/model đã đổi sau phân tích. Hãy phân tích lại với model đã chọn.')
        files = read_rules(self.rule_paths)
        if rules_digest(files) != self.analysis_report['rules_digest']:
            self.clear_analysis()
            raise ValueError('Nội dung quy tắc đã thay đổi sau khi phân tích. Hãy phân tích lại.')
        target = self.analysis_folder or new_project_folder(self.project_root)
        # First validate all answers, then initialize the project without Qt-side effects.
        s = initialize_approved_project(
            target, self.rule_paths, self.analysis_report, self.selected_answers,
            import_sources=(lambda studio: import_inputs(studio, self.source_paths)),
        )
        self.studio = s
        self.review_btn.setEnabled(False)  # Human decisions are immutable after project creation.
        return s

    def start(self):
        if self._running() or (self.analysis_worker and self.analysis_worker.isRunning()): return
        try:
            key = self.key.text().strip()
            model = self.model.currentText().strip()
            if not key: raise ValueError('Chưa nhập API key.')
            if not model: raise ValueError('Chưa chọn hoặc nhập mã model.')
            if self.loaded_project and not self.analysis_approved:
                raise ValueError('Dự án cũ chưa có báo cáo tùy chọn được duyệt. Hãy tạo dự án mới và nhập quy tắc để phân tích.')
            studio = self._ensure_project()
            if not studio.rule_files(): raise ValueError('Chưa có quy tắc.')
            msg = (
                f'Nhà cung cấp: {self.provider.currentText()}\n'
                f'Model: {model}\n'
                f'Dự phòng cục bộ USD (không phải bảng giá TuanSu): ${self.budget.value():.2f}\n'
                f'Tối đa {self.max_calls.value()} lượt API trong phiên.\n\n'
                'AI sẽ thực hiện quy trình văn bản và áp dụng những quyết định đã được xác nhận (nếu có). '
                'Có thể phát sinh phí API; giới hạn cục bộ không đảm bảo mức phí thực tế.\n\n'
                'Bạn muốn bắt đầu sản xuất?'
            )
            if QMessageBox.question(self, 'Xác nhận gọi API có phí', msg,
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes: return
            self.prefs.update({
                'provider': self.provider.currentData(),
                'model_' + self.provider.currentData(): model,
                'budget': self.budget.value(),
                'max_calls': self.max_calls.value(),
                'parallel': self.parallel.value(),
                'project_root': str(self.project_root),
            })
            save_prefs(self.prefs)
            values = {
                'provider': self.provider.currentData(), 'api_key': key, 'model': model,
                'budget': self.budget.value(), 'max_calls': self.max_calls.value(),
                'parallel': min(self.parallel.value(), 2 if self.provider.currentData() == 'tuansu' else 3),
            }
            self.worker = RunWorker(studio, values)
            self.worker.progress.connect(self.message)
            self.worker.done.connect(self.finished)
            self.worker.failed.connect(self.failed)
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)
            self.progress.setRange(0, 0)
            self.status.setText('Đang phân tích quy tắc và sản xuất văn bản...')
            self.details.clear()
            self.worker.start()
        except Exception as exc:
            self.warn(str(exc))

    def message(self, content):
        line = str(content).replace('\n', '  ')[:700]
        self.details.appendPlainText(line)
        self.status.setText(line[:190])

    def finished(self, result):
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.progress.setRange(0, 100)
        self.progress.setValue(100)
        self.latest_output = Path(result)
        self.message('HOÀN THÀNH: ' + result)
        QMessageBox.information(self, 'Hoàn thành',
            'Đã tạo thành phẩm và lưu tại:\n' + result)

    def failed(self, err):
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.message('TẠM DỪNG: ' + err)
        self.warn(err + '\n\nDữ liệu và checkpoint của dự án đã lưu vẫn được giữ lại.')

    def stop(self):
        if self.studio:
            self.studio.stop.set()
            self.status.setText('Đang yêu cầu dừng sau request hiện tại...')

    def toggle_details(self):
        show = not self.details.isVisible()
        self.details.setVisible(show)
        self.detail_btn.setText('Chi tiết ▴' if show else 'Chi tiết ▾')

    def toggle_advanced(self):
        show = not self.advanced.isVisible()
        self.advanced.setVisible(show)
        self.more_btn.setText('Tùy chọn ▴' if show else 'Tùy chọn ▾')

    def open_results(self):
        if not self.studio:
            return self.warn('Chưa có dự án để mở.')
        dest = self.latest_output.parent if self.latest_output and self.latest_output.exists() else self.studio.folder
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(dest)))

    def closeEvent(self, event):
        if self.analysis_worker and self.analysis_worker.isRunning():
            self.warn('Đang phân tích quy tắc. Hãy chờ thao tác hiện tại hoàn tất.')
            event.ignore()
            return
        if self._running():
            self.warn('Hãy bấm Dừng an toàn và đợi request hiện tại kết thúc trước khi đóng.')
            event.ignore()
            return
        if self.model_worker and self.model_worker.isRunning():
            self.warn('Đang lấy danh sách model. Hãy đợi thao tác kết thúc.')
            event.ignore()
            return
        if getattr(self, 'probe_worker', None) and self.probe_worker.isRunning():
            self.warn('Đang kiểm tra model. Hãy đợi yêu cầu hiện tại kết thúc.')
            event.ignore()
            return
        if self.studio: self.studio.close()
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    app.setStyleSheet(THEME)
    window = MainWindow()
    window.show()
    return app.exec()
