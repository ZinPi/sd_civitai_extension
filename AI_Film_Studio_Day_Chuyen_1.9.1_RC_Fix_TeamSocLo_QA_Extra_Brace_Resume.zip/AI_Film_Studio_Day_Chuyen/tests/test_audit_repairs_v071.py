"""Adversarial regressions for the failures independently found in 0.7.0."""
from __future__ import annotations
from types import SimpleNamespace
from pathlib import Path
import json, tempfile, unittest
from studio.engine import Studio, RunBlocked
from studio.contract import ContractError
from studio.one_click import add_story_file,normalize_srt,BudgetedProvider,OneClickService
from studio.rule_context import stage_rules
from studio.qa import validate_content
from studio.rule_outline import build_outline, OutlineSelection
from studio.rule_scope import scope_view
from studio.api import Generation, IncompleteGeneration
from tests.test_acceptance_end_to_end import build_pack,STORY,AUDIO,MockProvider

class AlwaysError:
    is_live=False;model='testing';effort='none'
    def generate(self,**kwargs):raise RuntimeError('mạng lỗi: không biết usage')

class MeteredIncomplete:
    is_live=False;model='testing';effort='none'
    def generate(self,**kwargs):
        raise IncompleteGeneration('incomplete','max_output_tokens',750,420,120)

class OneSemanticFailure(MockProvider):
    def __init__(self,scope):
        super().__init__();self.scope=scope;self.triggered=False
    def generate(self,*,system,user,max_output_tokens):
        if 'Bạn là người kiểm tra ĐỘC LẬP' in system and '"characters"' in user and not self.triggered:
            self.triggered=True
            self.calls.append((system,user))
            return Generation(json.dumps({'verdict':'FAIL','issues':['Sửa lại mô tả đầu ra'],
                                          'repair_scope':self.scope}),90,50,0)
        return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)

class AuditRepairs(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.folder=Path(self.tmp.name)
        self.studio=Studio(self.folder/'project')
    def tearDown(self):
        self.studio.close();self.tmp.cleanup()

    def test_srt_parse_error_has_zero_mutations(self):
        self.studio.import_source_text('SOURCE_STORY','GIỮ TÁC PHẨM CŨ')
        self.studio.import_source_text('SOURCE_AUDIO','001|GIỮ AUDIO CŨ')
        before=self.studio.store.source_hashes().copy()
        srt=self.folder/'broken.srt'
        srt.write_text('1\n00:00:02,000 --> 00:00:01,000\nkhông hợp lệ',encoding='utf8')
        with self.assertRaises(ValueError):add_story_file(self.studio,srt)
        self.assertEqual(before,self.studio.store.source_hashes())
    def test_srt_rejects_overlap_or_invalid_clock(self):
        with self.assertRaises(ValueError):
            normalize_srt('1\n00:00:01,000 --> 00:00:03,000\nA\n\n2\n00:00:02,999 --> 00:00:04,000\nB')
        with self.assertRaises(ValueError):
            normalize_srt('1\n00:65:00,000 --> 00:66:00,000\nA')
    def test_atomic_two_sources(self):
        updated=self.studio.import_sources_atomic({'SOURCE_STORY':('story','test'),'SOURCE_AUDIO':('001|voice','test')})
        self.assertEqual(self.studio.store.source_hashes(),updated)
    def test_existing_project_cost_does_not_block_new_run(self):
        pack=self.folder/'rules.zip';build_pack(pack)
        self.studio.import_pack(pack)
        self.studio.import_source_text('SOURCE_STORY',STORY)
        self.studio.import_source_text('SOURCE_AUDIO',AUDIO)
        run=self.studio.store.begin('PREVIOUS')
        self.studio.store.record_usage(run,'PREVIOUS',1,1,0,3.0)
        self.studio.store.end(run,'DONE')
        provider=MockProvider()
        result=OneClickService(self.studio).run(provider,max_usd=2)
        self.assertIn('TEST_ONLY',result.name)
        self.assertGreater(len(provider.calls),0)
    def test_failed_request_never_reported_as_zero_cost(self):
        provider=BudgetedProvider(AlwaysError(),self.studio.folder,max_usd=2,max_calls=2)
        with self.assertRaises(RuntimeError):provider.generate(system='s',user='u',max_output_tokens=300)
        self.assertEqual(provider.cost,0)
        self.assertGreater(provider.unknown_exposure,0)
        event=json.loads((self.studio.folder/'api_request_ledger.jsonl').read_text(encoding='utf8').splitlines()[-1])
        self.assertEqual(event['status'],'UNKNOWN')
    def test_incomplete_with_usage_is_metered_not_unknown(self):
        provider=BudgetedProvider(MeteredIncomplete(),self.studio.folder,max_usd=2,max_calls=1)
        with self.assertRaises(IncompleteGeneration):
            provider.generate(system='s',user='u',max_output_tokens=12000)
        self.assertGreater(provider.cost,0)
        self.assertEqual(provider.unknown_exposure,0)
        ev=json.loads((self.studio.folder/'api_request_ledger.jsonl').read_text(encoding='utf8').splitlines()[-1])
        self.assertEqual(ev['status'],'INCOMPLETE_METERED')
        self.assertEqual(ev['input_tokens'],750)
    def test_session_lock_protects_import_and_approval(self):
        self.assertTrue(self.studio._session_lock.acquire(blocking=False))
        self.studio._session_owner_ident=-99
        try:
            with self.assertRaises(ContractError):self.studio.import_source_text('SOURCE_STORY','new')
            with self.assertRaises(ContractError):self.studio.approve(self.folder/'whatever')
        finally:
            self.studio._session_owner_ident=None;self.studio._session_lock.release()
    def test_preflight_explicit_required_audio(self):
        with self.assertRaises(RunBlocked):OneClickService._early_preflight({'SOURCE_STORY':'a'},
            {'rules.txt':'ĐẦU VÀO BẮT BUỘC: SOURCE_AUDIO'})
        OneClickService._early_preflight({'SOURCE_STORY':'a'},{'rules.txt':'SOURCE_AUDIO chỉ là ví dụ tham khảo'})
    def test_long_rulefile_retrieves_target_clause_not_unrelated(self):
        rules='\n'.join('' if i%23==0 else f'Đoạn văn thứ {i} cần hiểu.' for i in range(6000))
        lines=rules.splitlines();lines[3200]='CHỐT HƯỚNG TÓC TRÁI PHẢI KHÔNG ĐƯỢC ĐẢO'
        lines[5000]='CHỐT CAMERA 180 ĐỘ'
        rules='\n'.join(lines)
        st=SimpleNamespace(id='A',rules=('LONG.txt',),source_evidence=('LONG.txt:3201',))
        contract=SimpleNamespace(raw={'clause_coverage':[
            {'decision':'ENFORCE','stage_ids':['A'],'file':'LONG.txt','start':5001,'end':5001}]})
        output=stage_rules(st,contract,{'LONG.txt':rules})
        self.assertIn('HƯỚNG TÓC',output)
        self.assertIn('CAMERA 180',output)
        self.assertIn('3201: CHỐT',output)
        self.assertLess(len(output),len(rules))
    def test_large_rule_missing_evidence_blocks(self):
        st=SimpleNamespace(id='A',rules=('LONG.txt',),source_evidence=())
        contract=SimpleNamespace(raw={'clause_coverage':[]})
        with self.assertRaises(ContractError):
            stage_rules(st,contract,{'LONG.txt':'L' * 25000})
    def test_unbroken_text_is_bounded_but_preserves_every_mapped_clause(self):
        lines=[f'text line {i}' for i in range(15000)]
        lines[3000]='PHẢI GIỮ CHAR VÀ BG ĐỒNG BỘ'
        lines[8000]='CẤM ĐẢO HƯỚNG CAMERA'
        st=SimpleNamespace(id='A',rules=('long.txt',),source_evidence=('long.txt:3001',))
        c=SimpleNamespace(raw={'clause_coverage':[
            {'file':'long.txt','start':8001,'end':8001,'decision':'ENFORCE','stage_ids':['A']}]})
        text=stage_rules(st,c,{'long.txt':'\n'.join(lines)})
        self.assertIn('3001: PHẢI GIỮ',text)
        self.assertIn('8001: CẤM ĐẢO',text)
        self.assertLess(len(text),10000)
    def test_alias_collision_and_state_timeline_are_detected(self):
        bad={'entities':[{'id':'CHAR_01','aliases':['An']},
              {'id':'CHAR_02','aliases':['an'],'states':[{'id':'S2','effective_from_line':10},{'id':'S1','effective_from_line':9}]}]}
        fails=validate_content(json.dumps(bad),({'type':'entity_integrity','value':'entities'},),{})
        self.assertTrue(fails)
        bad={'entities':[{'id':'CHAR_01','states':[{'id':'S2','effective_from_line':10},{'id':'S1','effective_from_line':9}]}]}
        self.assertTrue(validate_content(json.dumps(bad),({'type':'entity_integrity','value':'entities'},),{}))
    def test_timeline_reversed_detected(self):
        self.assertTrue(validate_content(json.dumps({'events':[{'line_id':3},{'line_id':2}]}),
                ({'type':'temporal_order','value':'events'},),{}))
        self.assertFalse(validate_content(json.dumps({'events':[{'line_id':2},{'line_id':3}]}),
                ({'type':'temporal_order','value':'events'},),{}))
    def _load_sample(self):
        path=self.folder/'rules_new.zip';build_pack(path)
        self.studio.import_pack(path)
        self.studio.import_source_text('SOURCE_STORY',STORY)
        self.studio.import_source_text('SOURCE_AUDIO',AUDIO)
    def test_output_only_semantic_failure_retries_without_changing_source(self):
        self._load_sample()
        old=self.studio.store.source_hashes().copy()
        fake=OneSemanticFailure('OUTPUT_ONLY')
        output=OneClickService(self.studio).run(fake)
        self.assertTrue(output.is_file())
        self.assertEqual(old,self.studio.store.source_hashes())
        self.assertGreaterEqual(len([r for r in self.studio.store.qa_review_summary() if r['verdict']=='FAIL']),1)
    def test_upstream_failure_never_auto_rewrites_canon(self):
        self._load_sample();before=self.studio.store.source_hashes().copy()
        fake=OneSemanticFailure('UPSTREAM')
        with self.assertRaises(RunBlocked):OneClickService(self.studio).run(fake)
        self.assertEqual(before,self.studio.store.source_hashes())
        self.assertFalse((self.studio.folder/'FINAL').exists())
    def test_unselected_global_lock_is_reported_and_not_sent(self):
        docs={'a.txt':'BƯỚC 01 — TẠO NỘI DUNG\nTạo dữ liệu ABC.\n'
                       'BƯỚC 02 — GLOBAL_LOCK QUY TẮC CHUNG\nPhải QA toàn bộ.\n'}
        nodes=build_outline(docs)
        included={n.key for n in nodes if 'BƯỚC 01' in n.title}
        selection=self.folder/'selection.json'
        OutlineSelection(selection).write('h',included,{n.key for n in nodes})
        view=scope_view(docs,'h',selection)
        self.assertTrue(view.missing_references)
        self.assertNotIn('Phải QA toàn bộ.',view.files['a.txt'])

if __name__=='__main__':unittest.main()
