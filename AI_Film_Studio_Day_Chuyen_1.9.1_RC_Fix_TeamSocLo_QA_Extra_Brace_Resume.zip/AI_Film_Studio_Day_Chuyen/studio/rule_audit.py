"""Generic rulepack clause inventory and coverage gate.

A lexical inventory is not equivalent to fully understanding natural-language
rules. It is a conservative, inspectable preflight step; an approved compiled
contract is required before execution. No media-specific branches.
"""
from __future__ import annotations
import re
from .contract import ContractError

# Deliberately conservative and inspectable; false negatives remain possible.
DIRECTIVE = re.compile(r'(?i)(\bmust\b|\bshall\b|\brequired\b|\bnever\b|'
                       r'\bprohibited\b|\bmandatory\b|\bonly\b|'
                       r'\bbắt buộc\b|\bphải\b|\bcấm\b|\bkhông\b|\bkhông được\b|'
                       r'\btuyệt đối\b|\bluôn\b|\bchỉ được\b|'
                       r'必須|禁止|厳守|してはいけない|しなければならない)')


def collect_candidates(files:dict[str,str], dispositions:dict) -> dict[str,list[int]]:
    result={}
    for name,content in files.items():
        if dispositions[name]['role']!='PRODUCTION':continue
        result[name]=[i for i,line in enumerate(content.splitlines(),1)
                      if line.strip() and DIRECTIVE.search(line)]
    return result


def validate_clause_coverage(raw:dict, files:dict[str,str], stage_ids:set[str]) -> None:
    dispositions=raw.get('file_dispositions',{})
    wanted=collect_candidates(files,dispositions)
    spans=raw.get('clause_coverage')
    if not isinstance(spans,list):
        raise ContractError('Thiếu clause_coverage: chưa đối chiếu các điều khoản bắt buộc trong ZIP')
    covered={fn:set() for fn in wanted}
    decisions={'ENFORCE','NOT_APPLICABLE'}
    for spec in spans:
        if not isinstance(spec,dict) or set(spec)!={'file','start','end','decision','stage_ids','reason'}:
            raise ContractError('clause_coverage phải ghi file/start/end/decision/stage_ids/reason')
        fn=spec['file'];st=spec['stage_ids'];reason=spec['reason'];decision=spec['decision']
        if fn not in wanted:raise ContractError('clause_coverage: file không phải PRODUCTION: '+str(fn))
        start,end=spec['start'],spec['end']
        if type(start)!=int or type(end)!=int or start<1 or end<start or end>len(files[fn].splitlines()):
            raise ContractError('Khoảng dòng điều khoản không hợp lệ: '+str(fn))
        if decision not in decisions:raise ContractError('Quy tắc còn phân loại chưa rõ: '+str(decision))
        if not isinstance(st,list) or any(item not in stage_ids for item in st):
            raise ContractError('clause_coverage tham chiếu công đoạn không tồn tại')
        if decision=='ENFORCE' and not st:
            raise ContractError(f'{fn}:{start}: điều khoản ENFORCE chưa có công đoạn thực hiện')
        if decision=='NOT_APPLICABLE' and (st or not isinstance(reason,str) or len(reason.strip())<12):
            raise ContractError(f'{fn}:{start}: phải giải thích rõ lý do không áp dụng')
        for line in wanted[fn]:
            if start<=line<=end:
                if line in covered[fn]:raise ContractError(f'Điều khoản phân loại lặp: {fn}:{line}')
                covered[fn].add(line)
    missed=[f'{fn}:{line}' for fn,lines in wanted.items() for line in lines if line not in covered[fn]]
    if missed:
        raise ContractError(f'Chưa phân loại {len(missed)} điều khoản có khả năng bắt buộc; ví dụ: '+', '.join(missed[:8]))
