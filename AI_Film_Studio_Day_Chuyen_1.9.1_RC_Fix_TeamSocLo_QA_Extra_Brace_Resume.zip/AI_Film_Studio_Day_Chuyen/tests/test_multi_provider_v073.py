"""Regression checks for the 0.7.3 Claude/OpenAI text-only upgrade."""
from __future__ import annotations
from pathlib import Path
from types import SimpleNamespace as S
import json
import tempfile

import pytest
from studio.api import OpenAIProvider, IncompleteGeneration
from studio.claude_api import ClaudeProvider, fetch_claude_models
from studio.workflow_plan import stage_fingerprint


def fake_claude_client(*args, **kwargs):
    class Messages:
        def __init__(self): self.kwargs = None
        def create(self, **k):
            self.kwargs = k
            return S(stop_reason='end_turn',
                     usage=S(input_tokens=4, cache_read_input_tokens=2,
                             cache_creation_input_tokens=3, output_tokens=7),
                     content=[S(type='text', text='Kết quả văn bản')])
    return S(messages=Messages(), models=S(list=lambda limit: S(data=[S(id='claude-test-model'), S(id='bad-model')])))


def test_claude_text_adapter_uses_messages_and_measures_usage():
    p = ClaudeProvider('not-a-real-key', 'claude-test-model', client_factory=fake_claude_client)
    x = p.generate(system='Quy tắc', user='Văn bản', max_output_tokens=500)
    assert x.text == 'Kết quả văn bản'
    assert (x.input_tokens, x.output_tokens, x.cached_tokens) == (9, 7, 2)
    assert p.client.messages.kwargs['messages'] == [{'role':'user','content':'Văn bản'}]
    assert p.client.messages.kwargs['system'] == 'Quy tắc'
    assert p.client.messages.kwargs['max_tokens'] == 500


def test_claude_refuses_incomplete_response():
    p = ClaudeProvider('key', 'claude-any', client_factory=fake_claude_client)
    p.client.messages.create = lambda **k: S(stop_reason='max_tokens',
        usage=S(input_tokens=10, cache_read_input_tokens=0, cache_creation_input_tokens=0,
                output_tokens=100), content=[S(type='text',text='Không hoàn tất')])
    with pytest.raises(IncompleteGeneration) as exc:
        p.generate(system='s', user='u', max_output_tokens=100)
    assert exc.value.output_tokens == 100


def test_claude_models_can_be_discovered_without_generation():
    assert fetch_claude_models('key', client_factory=fake_claude_client) == ['claude-test-model']


def test_openai_requests_disable_stored_responses():
    class Response:
        def create(self, **kwargs):
            assert kwargs['store'] is False
            return S(status='completed', output_text='OK', usage=S(input_tokens=2,output_tokens=2,input_tokens_details=None))
    p = object.__new__(OpenAIProvider)
    p.model='gpt-test';p.effort='default';p.client=S(responses=Response())
    assert p.generate(system='a', user='b', max_output_tokens=32).text == 'OK'


def test_stage_fingerprints_different_providers():
    contract = S(contract_sha='abc')
    stage = S(id='S1', adapter='api_text', max_output_tokens=150)
    o = S(is_live=True, provider_id='openai', model='model-1', effort='default')
    c = S(is_live=True, provider_id='anthropic', model='model-1', effort='default')
    assert stage_fingerprint(contract, stage, {}, o) != stage_fingerprint(contract, stage, {}, c)


def test_minimal_ui_preferences_do_not_store_api_keys():
    # The GUI stores provider/model/budget only, and never handles keys in preference writes.
    src = (Path(__file__).resolve().parents[1]/'studio'/'minimal_gui.py').read_text(encoding='utf-8')
    assert "'api_key': key" in src  # Key only passed to in-memory worker.
    start = src.index('def save_prefs(')
    end = src.index('def import_inputs(', start)
    assert 'api_key' not in src[start:end]
