"""Adversarial regression tests for v1.3; never use paid APIs."""
import json
from pathlib import Path
import pytest
from studio.api import Generation
from studio.contract import ContractError
from studio.engine import RunBlocked
from studio.guide_flow import GuideFlow
from studio.output_guards import output_specs,validate_deliverables
from studio.one_click import BudgetedProvider


class Dummy:
    effort='default'
    provider_id='fake'
    def __init__(self,responses=None,model='alpha'):
        self.model=model
        self.responses=list(responses or [])
        self.calls=[]
    def generate(self,*,system,user,max_output_tokens):
        self.calls.append((system,user))
        if not self.responses:raise AssertionError('unexpected paid API call')
        item=self.responses.pop(0)
        if isinstance(item,Exception):raise item
        return Generation(item,100,50,0)


def mk(tmp_path,guide,rules,source='Novel'):
    p=tmp_path/'rules';p.mkdir()
    (p/'HUONG_DAN.txt').write_text(guide,encoding='utf8')
    for name,body in rules.items():(p/name).write_text(body,encoding='utf8')
    input=tmp_path/'source.txt';input.write_text(source,encoding='utf8')
    return GuideFlow.create(tmp_path/'project',None,[p],[input])


def video_guide():
    return ('1- TẠO NỘI DUNG YOUTUBE\nĐọc B7.txt.\n'
            '- Tạo 10 prompt ảnh thumbnail bằng CHAR.\n'
            '- Tạo 10 tiêu đề, 1 mô tả đúng 300 từ và 1 bộ tag YouTube.\n')


def video_files(t=10,h=10,w=300):
    def build(n):return '\n'.join(f'{i}. Nội dung số {i}' for i in range(1,n+1))
    return {'THUMBNAIL_PROMPTS.txt':build(t)+'\n','YOUTUBE_TITLES.txt':build(h)+'\n',
            'YOUTUBE_DESCRIPTION.txt':('palabra '*w).strip()+'\n', 'YOUTUBE_TAGS.txt':'a, b, c\n'}


def display(files):
    return ''.join('@@FILE:'+k+'@@\n'+v for k,v in files.items())


def test_qa_false_pass_cannot_lock_one_sentence(tmp_path):
    f=mk(tmp_path,video_guide(),{'B7.txt':'Các thành phẩm phải đủ số lượng.'})
    provider=Dummy(['@@FILE:ANY.txt@@\nMột câu.', '{"verdict":"PASS","issues":[]}'])
    with pytest.raises(ContractError,match='Thiếu thành phẩm'):
        f.run_next(provider)
    assert len(provider.calls)==1
    assert f.status()['completed']==0


def test_qa_false_pass_cannot_lock_missing_title_or_wrong_description(tmp_path):
    f=mk(tmp_path,video_guide(),{'B7.txt':'Tuân thủ mô tả và số prompt.'})
    incomplete=video_files(h=9,w=299)
    with pytest.raises(ContractError,match='10 mục'):
        f.run_next(Dummy([display(incomplete)]))
    assert f.status()['completed']==0
    with pytest.raises(ContractError,match='300 từ'):
        f.run_next(Dummy([display(video_files(w=299))]))
    assert f.status()['completed']==0


def test_all_explicit_counts_are_validated_before_lock(tmp_path):
    f=mk(tmp_path,video_guide(),{'B7.txt':'Đúng các yêu cầu.'})
    p=Dummy([display(video_files()),'{"verdict":"PASS","issues":[]}'])
    record=f.run_next(p)
    assert record['state']=='LOCKED'
    assert len(p.calls)==2
    assert 'ĐỊNH DẠNG BẮT BUỘC' in p.calls[0][0]


def test_unsupported_guide_never_invents_numeric_requirements():
    assert output_specs('Đọc RULE.txt rồi tạo nội dung văn bản.')=={}


def test_single_file_semantic_audit_is_required_in_gui_flow(tmp_path):
    rule='Phải giữ nguyên toàn bộ lời thoại trực tiếp.\nPhải chuyển toàn bộ lời thoại trực tiếp thành gián tiếp.'
    f=mk(tmp_path,'1- VIẾT\nĐọc ONLY.txt. Xuất result.txt.',{'ONLY.txt':rule})
    assert f.needs_semantic_audit('fake','alpha')
    with pytest.raises(ContractError,match='chưa rà'):
        f.run_next(Dummy([]),require_semantic_audit=True)
    audit={'conflicts':[{'reason':'Không thể đồng thời giữ và chuyển toàn bộ',
            'left':{'source_file':'ONLY.txt','source_line':1,'source_quote':rule.splitlines()[0]},
            'right':{'source_file':'ONLY.txt','source_line':2,'source_quote':rule.splitlines()[1]}}]}
    p=Dummy([json.dumps(audit,ensure_ascii=False)])
    found=f.audit_current_conflicts(p)
    assert len(found)==1 and found[0]['kind']=='review'
    assert not f.needs_semantic_audit('fake','alpha')
    with pytest.raises(ContractError,match='mâu thuẫn'):
        f.run_next(Dummy([]),require_semantic_audit=True)
    result=f.run_next(Dummy(['@@FILE:result.txt@@\nText','{"verdict":"PASS","issues":[]}']),
                      conflict_choices={found[0]['id']:'left'},require_semantic_audit=True)
    assert result['state']=='LOCKED'


def test_one_file_forged_quote_rejected(tmp_path):
    f=mk(tmp_path,'1- VIẾT\nĐọc ONLY.txt.',{'ONLY.txt':'Dòng thứ nhất.\nDòng thứ hai.'})
    forged={'conflicts':[{'reason':'Wrong','left':{'source_file':'ONLY.txt','source_line':1,
        'source_quote':'Dòng bịa đặt'},'right':{'source_file':'ONLY.txt','source_line':2,
        'source_quote':'Dòng thứ hai.'}}]}
    with pytest.raises(ContractError,match='trích sai'):
        f.audit_current_conflicts(Dummy([json.dumps(forged,ensure_ascii=False)]))
    assert f.needs_semantic_audit('fake','alpha')


def batch_guide():
    return ('1- TẠO PROMPT\nĐọc RULE.txt.\n'
            '1 DÒNG/CÂU NGUỒN = 1 OUTPUT_SLOT_LINE = 1 IMAGE_PROMPT.\n'
            'NGUỒN VĂN BẢN DÙNG ĐỂ TẠO PROMPT ẢNH LÀ "SOURCE_LINES".\n'
            'Mỗi lượt chỉ phân tích 2 dòng/câu.\nSAU 1 LẦN, TỨC 2 PROMPT, phải QA.\n')


def batch_start(tmp_path):
    f=mk(tmp_path,batch_guide(),{'RULE.txt':'Giữ dữ liệu gốc.'},source='initial')
    # Replace just before create would be better: output first step is a source-line document;
    # creating from a file name that matches source_stem works without moving files.
    return f


def batch_flow(tmp_path):
    p=tmp_path/'rules';p.mkdir()
    (p/'HUONG_DAN.txt').write_text(batch_guide(),encoding='utf8')
    (p/'RULE.txt').write_text('Giữ nguyên nội dung, không thêm.',encoding='utf8')
    src=tmp_path/'SOURCE_LINES.txt';src.write_text('A\nB\n',encoding='utf8')
    return GuideFlow.create(tmp_path/'project',None,[p],[src])


def test_batch_checkpoint_not_reused_after_model_switch(tmp_path):
    f=batch_flow(tmp_path)
    a=Dummy(['IMAGE_PROMPT_000001 | A\nIMAGE_PROMPT_000002 | B',
             '{"verdict":"PASS","issues":[]}', '{"verdict":"FAIL","issues":["global"]}'],model='alpha')
    with pytest.raises(ContractError,match='Full-scope'):
        f.run_next(a)
    b=Dummy(['IMAGE_PROMPT_000001 | AA\nIMAGE_PROMPT_000002 | BB',
             '{"verdict":"PASS","issues":[]}', '{"verdict":"PASS","issues":[]}'],model='beta')
    result=f.run_next(b)
    assert result['state']=='LOCKED'
    assert len(b.calls)==3 and 'CHỈ TẠO ĐÚNG' in b.calls[0][1]
    assert 'AA' in (f.folder/'steps'/'STEP_001'/'IMAGE_PROMPTS.txt').read_text(encoding='utf8')
    assert len(list((f.folder/'candidates'/'STEP_001'/'groups').glob('v2_*')))==2


def test_batch_checkpoint_reused_only_with_exact_model(tmp_path):
    f=batch_flow(tmp_path)
    a=Dummy(['IMAGE_PROMPT_000001 | A\nIMAGE_PROMPT_000002 | B',
             '{"verdict":"PASS","issues":[]}', '{"verdict":"FAIL","issues":["global"]}'],model='same')
    with pytest.raises(ContractError,match='Full-scope'):f.run_next(a)
    b=Dummy(['{"verdict":"PASS","issues":[]}'],model='same')
    result=f.run_next(b)
    assert result['state']=='LOCKED' and len(b.calls)==1


def test_batch_decision_changes_force_regeneration(tmp_path):
    f=batch_flow(tmp_path)
    rules=f._read_current_rules(f.status()['current'])
    inputs=f._sources_and_prior_outputs()
    from studio.guide_batch import run_batched
    a=Dummy(['IMAGE_PROMPT_000001 | A\nIMAGE_PROMPT_000002 | B',
             '{"verdict":"PASS","issues":[]}', '{"verdict":"FAIL","issues":["global"]}'])
    with pytest.raises(ContractError,match='Full-scope'):
        run_batched(f,a,f.status()['current'],rules,inputs,'decision A','',lambda _:None,8000,0,
                    user_decisions={'choice':'A'})
    b=Dummy(['IMAGE_PROMPT_000001 | AA\nIMAGE_PROMPT_000002 | BB',
             '{"verdict":"PASS","issues":[]}', '{"verdict":"PASS","issues":[]}'])
    run_batched(f,b,f.status()['current'],rules,inputs,'decision B','',lambda _:None,8000,0,
                user_decisions={'choice':'B'})
    assert len(b.calls)==3


def test_api_call_limit_is_cumulative_across_sessions(tmp_path):
    p=Dummy(['ok','ok','ok'])
    a=BudgetedProvider(p,tmp_path,max_usd=10,max_calls=2)
    a.generate(system='x',user='y',max_output_tokens=64)
    b=BudgetedProvider(p,tmp_path,max_usd=10,max_calls=2)
    b.generate(system='x',user='y',max_output_tokens=64)
    c=BudgetedProvider(p,tmp_path,max_usd=10,max_calls=2)
    with pytest.raises(RunBlocked,match='toàn dự án'):
        c.generate(system='x',user='y',max_output_tokens=64)
    doc=json.loads((tmp_path/'api_usage_guard.json').read_text(encoding='utf8'))
    assert doc['requests_total']==2


def test_api_failure_consumes_call_and_unknown_exposure_persists(tmp_path):
    p=Dummy([TimeoutError('upstream timeout'),'ok'])
    a=BudgetedProvider(p,tmp_path,max_usd=10,max_calls=1)
    with pytest.raises(TimeoutError):a.generate(system='x',user='y',max_output_tokens=64)
    b=BudgetedProvider(p,tmp_path,max_usd=10,max_calls=1)
    assert b.unknown_exposure>0
    with pytest.raises(RunBlocked):b.generate(system='x',user='y',max_output_tokens=64)
    assert len(p.calls)==1


def test_interrupted_request_reservation_is_not_lost(tmp_path):
    (tmp_path/'api_usage_guard.json').write_text(json.dumps({'requests_total':1,
        'estimated_usd_total':0.01,'unknown_exposure_usd':0.02,'inflight_reserved_usd':0.03}),encoding='utf8')
    guard=BudgetedProvider(Dummy([]),tmp_path,max_usd=10,max_calls=2)
    assert guard.unknown_exposure == pytest.approx(0.05)
    guard2=BudgetedProvider(Dummy([]),tmp_path,max_usd=10,max_calls=2)
    assert guard2.unknown_exposure == pytest.approx(0.05)


def test_large_scene_work_is_blocked_before_paid_call(tmp_path):
    guide=('1- CHUYỂN THỂ\nĐọc B1.txt.\n'
           'QA từng scene và FULL-SCOPE QA toàn tác phẩm; không được bỏ qua.\n')
    f=mk(tmp_path,guide,{'B1.txt':'Giữ nguyên căn cứ toàn bộ source.'},source='Câu chuyện. '*6500)
    p=Dummy([])
    with pytest.raises(ContractError,match='Dừng TRƯỚC'):
        f.run_next(p,max_output_tokens=1000)
    assert not p.calls
    assert f.status()['completed']==0
