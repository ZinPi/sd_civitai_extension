"""Single authoritative catalog, content-addressed immutable file blobs."""
from __future__ import annotations
from pathlib import Path
from contextlib import contextmanager
import sqlite3, os, json, tempfile, time, threading
from .contract import digest, canonical_json, ContractError

SCHEMA='''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sources(name TEXT PRIMARY KEY, sha TEXT NOT NULL, origin TEXT NOT NULL, imported_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS contracts(sha TEXT PRIMARY KEY, json TEXT NOT NULL, rule_sha TEXT NOT NULL, approved_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS artifacts(revision_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, stage TEXT NOT NULL,
 fingerprint TEXT NOT NULL, sha TEXT NOT NULL, qa_status TEXT NOT NULL, qa_details TEXT NOT NULL,
 created_at REAL NOT NULL, UNIQUE(name, fingerprint));
CREATE TABLE IF NOT EXISTS artifact_deps(revision_id INTEGER NOT NULL REFERENCES artifacts(revision_id),
 input_name TEXT NOT NULL, input_sha TEXT NOT NULL, PRIMARY KEY(revision_id,input_name));
CREATE TABLE IF NOT EXISTS external_outputs(name TEXT PRIMARY KEY, sha TEXT NOT NULL, origin TEXT NOT NULL, imported_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS stage_units(stage TEXT NOT NULL, fingerprint TEXT NOT NULL, unit_id TEXT NOT NULL,
 sha TEXT NOT NULL, PRIMARY KEY(stage,fingerprint,unit_id));
CREATE TABLE IF NOT EXISTS runs(run_id INTEGER PRIMARY KEY AUTOINCREMENT, contract_sha TEXT NOT NULL,
 started_at REAL NOT NULL, ended_at REAL, status TEXT NOT NULL, issue TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS usage(id INTEGER PRIMARY KEY AUTOINCREMENT, run_id INTEGER NOT NULL, stage TEXT NOT NULL,
 input_tokens INTEGER NOT NULL, output_tokens INTEGER NOT NULL, cached_tokens INTEGER NOT NULL,
 approx_cost_usd REAL NOT NULL, created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS qa_reviews(review_id INTEGER PRIMARY KEY AUTOINCREMENT,
 run_id INTEGER NOT NULL, stage TEXT NOT NULL, source_sha TEXT NOT NULL,
 rule_sha TEXT NOT NULL, content_sha TEXT NOT NULL, verdict TEXT NOT NULL,
 issues_json TEXT NOT NULL, created_at REAL NOT NULL);
'''

class Store:
    def __init__(self, root:Path):
        self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.blobs=self.root/'objects';self.blobs.mkdir(exist_ok=True)
        self._connections=[];self._connections_lock=threading.RLock()
        self._local=threading.local()
        self.con.executescript(SCHEMA)
        self.con.execute('PRAGMA journal_mode=WAL')
    @property
    def con(self):
        c=getattr(self._local,'connection',None)
        if c is None:
            c=sqlite3.connect(self.root/'studio.sqlite', isolation_level=None,timeout=10)
            c.execute('PRAGMA busy_timeout=10000')
            c.execute('PRAGMA foreign_keys=ON')
            self._local.connection=c
            with self._connections_lock:self._connections.append(c)
        return c
    @contextmanager
    def tx(self):
        self.con.execute('BEGIN IMMEDIATE')
        try:yield
        except Exception:self.con.rollback();raise
        else:self.con.commit()
    def close(self):
        with self._connections_lock:
            for c in self._connections:
                try:c.close()
                except sqlite3.Error:pass
            self._connections.clear()
    def blob(self,data:str|bytes)->str:
        raw=data.encode('utf-8') if isinstance(data,str) else data
        sha=digest(raw);dest=self.blobs/sha[:2]/sha;dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():
            fd,temp=tempfile.mkstemp(dir=str(dest.parent),prefix='.pending_')
            try:
                with os.fdopen(fd,'wb') as f:
                    f.write(raw);f.flush();os.fsync(f.fileno())
                os.replace(temp,dest)
            finally:
                if os.path.exists(temp):os.unlink(temp)
        return sha
    def get_blob(self,sha:str)->bytes:
        data=(self.blobs/sha[:2]/sha).read_bytes()
        if digest(data)!=sha:raise ContractError('Blob bị thay đổi hoặc hỏng: '+sha)
        return data
    def text(self,sha:str)->str:return self.get_blob(sha).decode('utf-8')
    def source(self,name:str,text:str,origin:str):
        return self.sources_atomic({name:(text,origin)})[name]
    def sources_atomic(self, entries:dict[str,tuple[str,str]]) -> dict[str,str]:
        """Validate all inputs before moving any source pointers; commit once.

        Blob files are immutable and may safely remain unreferenced if the transaction
        fails. Readers never observe a partially imported story/audio pair.
        """
        if not entries:raise ContractError('Không có dữ liệu nguồn để nhập')
        for name,(body,origin) in entries.items():
            if not isinstance(name,str) or not name or not isinstance(body,str) or not isinstance(origin,str):
                raise ContractError('Dữ liệu nguồn không hợp lệ')
        hashes={name:self.blob(body) for name,(body,_) in entries.items()}
        with self.tx():
            self.con.executemany('INSERT INTO sources(name,sha,origin,imported_at) VALUES(?,?,?,?) '
                 'ON CONFLICT(name) DO UPDATE SET sha=excluded.sha,origin=excluded.origin,imported_at=excluded.imported_at',
                 [(name,hashes[name],origin,time.time()) for name,(_,origin) in entries.items()])
        return hashes
    def source_hashes(self):
        return dict(self.con.execute('SELECT name,sha FROM sources'))
    def source_text(self,name:str)->str:
        row=self.con.execute('SELECT sha FROM sources WHERE name=?',(name,)).fetchone()
        if not row:raise ContractError('Thiếu nguồn: '+name)
        return self.text(row[0])
    def approve(self,contract,policy_hash:str):
        with self.tx():
            self.con.execute('INSERT OR IGNORE INTO contracts VALUES(?,?,?,?)',
                  (contract.contract_sha,canonical_json(contract.raw),contract.rules_sha,time.time()))
            self.con.execute('INSERT INTO meta(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v',
                             ('approved_contract_sha',contract.contract_sha))
            self.con.execute('INSERT INTO meta(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v',
                             ('approved_delivery_policy_sha',policy_hash))
    def approved_policy_sha(self):
        row=self.con.execute("SELECT v FROM meta WHERE k='approved_delivery_policy_sha'").fetchone()
        return row[0] if row else None
    def approved_sha(self):
        row=self.con.execute("SELECT v FROM meta WHERE k='approved_contract_sha'").fetchone()
        return row[0] if row else None
    def find_artifact(self,name:str,fingerprint:str|None=None):
        if fingerprint:
            row=self.con.execute('SELECT revision_id,sha,qa_status,qa_details FROM artifacts WHERE name=? AND fingerprint=?',(name,fingerprint)).fetchone()
        else:
            row=self.con.execute('SELECT revision_id,sha,qa_status,qa_details FROM artifacts WHERE name=? ORDER BY revision_id DESC LIMIT 1',(name,)).fetchone()
        return row
    def artifact_revision(self, revision_id: int):
        """Immutable selected revision, never latest-by-name at release time."""
        return self.con.execute('SELECT revision_id,name,stage,fingerprint,sha,qa_status,qa_details FROM artifacts WHERE revision_id=?',(revision_id,)).fetchone()
    def artifact_dependencies(self, revision_id: int):
        return dict(self.con.execute('SELECT input_name,input_sha FROM artifact_deps WHERE revision_id=?',(revision_id,)))
    def save_artifact(self,name:str,stage:str,fingerprint:str,content:str,qa_status:str,qa_details:str,input_hashes:dict):
        sha=self.blob(content)
        with self.tx():
            row=self.con.execute('SELECT revision_id,sha FROM artifacts WHERE name=? AND fingerprint=?',(name,fingerprint)).fetchone()
            if row:
                if row[1]!=sha:raise ContractError('Kết quả có cùng đầu vào nhưng khác nội dung; cần tạo phiên bản hợp đồng mới')
                return row[0]
            cur=self.con.execute('INSERT INTO artifacts(name,stage,fingerprint,sha,qa_status,qa_details,created_at) VALUES(?,?,?,?,?,?,?)',
                   (name,stage,fingerprint,sha,qa_status,qa_details,time.time()))
            rid=cur.lastrowid
            self.con.executemany('INSERT INTO artifact_deps VALUES(?,?,?)',[(rid,key,h) for key,h in input_hashes.items()])
        return rid
    def supply_external_output(self,name:str,content:str,origin:str):
        """Imported stage products are QUARANTINED. Never QA PASS just for uploading."""
        sha=self.blob(content)
        with self.tx():
            self.con.execute('INSERT INTO external_outputs(name,sha,origin,imported_at) VALUES(?,?,?,?) '
                  'ON CONFLICT(name) DO UPDATE SET sha=excluded.sha,origin=excluded.origin,imported_at=excluded.imported_at',
                  (name,sha,origin,time.time()))
        return sha
    def external_output(self,name:str):
        return self.con.execute('SELECT sha,origin FROM external_outputs WHERE name=?',(name,)).fetchone()

    def source_or_artifact(self,name:str,active:dict[str,str]):
        if name not in active:raise ContractError('Chưa có đầu vào đã xác minh: '+name)
        return self.text(active[name])
    def save_unit(self,stage:str,fingerprint:str,unit_id:str,text:str):
        sha=self.blob(text)
        with self.tx():
            row=self.con.execute('SELECT sha FROM stage_units WHERE stage=? AND fingerprint=? AND unit_id=?',
                     (stage,fingerprint,unit_id)).fetchone()
            if row and row[0]!=sha: raise ContractError('Checkpoint bị mâu thuẫn')
            if not row:self.con.execute('INSERT INTO stage_units VALUES(?,?,?,?)',(stage,fingerprint,unit_id,sha))
    def get_unit(self,stage:str,fingerprint:str,unit_id:str)->str|None:
        row=self.con.execute('SELECT sha FROM stage_units WHERE stage=? AND fingerprint=? AND unit_id=?',
                     (stage,fingerprint,unit_id)).fetchone()
        return self.text(row[0]) if row else None
    def begin(self,contract_sha:str):
        with self.tx():return self.con.execute('INSERT INTO runs(contract_sha,started_at,status) VALUES(?,?,?)',
            (contract_sha,time.time(),'RUNNING')).lastrowid
    def end(self,run_id:int,status:str,issue:str=''):
        with self.tx():self.con.execute('UPDATE runs SET ended_at=?,status=?,issue=? WHERE run_id=?',
            (time.time(),status,issue[:1500],run_id))
    def record_usage(self,run_id:int,stage:str,in_tok:int,out_tok:int,cached:int,approx_cost:float):
        with self.tx():self.con.execute('INSERT INTO usage(run_id,stage,input_tokens,output_tokens,cached_tokens,approx_cost_usd,created_at) VALUES(?,?,?,?,?,?,?)',
            (run_id,stage,in_tok,out_tok,cached,approx_cost,time.time()))
    def record_qa(self,run_id:int,stage:str,source_sha:str,rule_sha:str,content_sha:str,
                  verdict:str,issues:list):
        with self.tx():
            self.con.execute('INSERT INTO qa_reviews(run_id,stage,source_sha,rule_sha,content_sha,verdict,issues_json,created_at) VALUES(?,?,?,?,?,?,?,?)',
                (run_id,stage,source_sha,rule_sha,content_sha,verdict,json.dumps(issues,ensure_ascii=False),time.time()))
    def qa_review_summary(self):
        rows=self.con.execute('SELECT stage,verdict,COUNT(*) FROM qa_reviews GROUP BY stage,verdict').fetchall()
        return [{'stage':r[0],'verdict':r[1],'count':r[2]} for r in rows]
    def total_cost(self):return self.con.execute('SELECT COALESCE(SUM(approx_cost_usd),0) FROM usage').fetchone()[0]
    def run_cost(self,run_id:int)->float:
        """Billing estimates for THIS executor run, never all past projects/runs."""
        return float(self.con.execute('SELECT COALESCE(SUM(approx_cost_usd),0) FROM usage WHERE run_id=?',
             (run_id,)).fetchone()[0])

    def usage_summary(self):
        row=self.con.execute(
            'SELECT COALESCE(SUM(input_tokens),0),COALESCE(SUM(output_tokens),0),'
            'COALESCE(SUM(cached_tokens),0),COALESCE(SUM(approx_cost_usd),0),COUNT(*) FROM usage').fetchone()
        return {'input_tokens':row[0],'output_tokens':row[1],
                'cached_tokens':row[2],'estimated_usd':round(row[3],6),
                'recorded_api_calls':row[4],'scope':'cumulative_project_recorded_usage'}
    def session_api_guard_summary(self):
        """Includes compilation AND production/QA, unlike the executor usage table.

        The local estimate is deliberately not presented as the provider invoice.
        """
        path=self.root/'api_usage_guard.json'
        if not path.is_file():return None
        try:
            data=json.loads(path.read_text(encoding='utf8'))
            return {key:data.get(key) for key in (
                'model','effort','requests_this_session','estimated_usd_this_session',
                'unknown_exposure_usd','failed_requests_this_session','input_tokens_this_session',
                'output_tokens_this_session','note')}
        except (ValueError,OSError):
            return {'status':'UNAVAILABLE','note':'Không đọc được báo cáo ngân sách phiên'}
