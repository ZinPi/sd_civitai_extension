"""Contract-governed release assurance: no media profile, no file-name heuristics.

A release check is separate from a stage check: completeness of a file does
not establish readiness of the delivery. This gate does NOT certify semantic
truth; model reviews remain probabilistic and must be benchmarked externally.
"""
from __future__ import annotations
import re
from .contract import ContractError
from .qa import validate_content

# These tokens unambiguously describe unfinished generated artifacts. Rules may
# override neither this blocker nor the requirement for independent source data.
UNFINISHED = re.compile(
    r'(?im)(?:\bPLACEHOLDER(?:_CHUA_QA)?\b|\bNOT_VERIFIED\b|'
    r'\bTODO\s*:\s*(?:fill|complete|bổ sung|điền)\b|'
    r'\bHANDOFF_STATUS\s*[:=]\s*PARTIAL\b|\[\[TO_FILL\]\]|\bERROR_NEED_EVIDENCE\b)')

STRONG_CHECKS = {'line_id_coverage', 'json_keys', 'required_sections', 'source_quote', 'json_schema', 'entity_refs', 'evidence_line_refs','entity_integrity','temporal_order','mapping_integrity','nonhuman_scale_lock'}


def lineage(contract, output: str) -> tuple[set[str], set[str]]:
    """Return required source IDs and stage IDs in a product's dependency graph."""
    producers = {stage.output: stage for stage in contract.stages}
    visited: set[str] = set()
    sources: set[str] = set()
    stages: set[str] = set()
    def walk(name: str):
        if name in visited:
            return
        visited.add(name)
        stage = producers.get(name)
        if stage is None:
            if name not in contract.required_inputs:
                raise ContractError(f'Đầu vào không xác định trong chuỗi nguồn: {name}')
            sources.add(name)
            return
        stages.add(stage.id)
        for inp in stage.inputs:
            walk(inp)
    walk(output)
    return sources, stages


def validate_release_contract(raw: dict, contract) -> None:
    checks = raw.get('release_checks')
    if not isinstance(checks, dict) or set(checks) != set(contract.outputs):
        raise ContractError('release_checks phải liệt kê chính xác tất cả required_outputs')
    for output, spec in checks.items():
        if not isinstance(spec, dict) or set(spec) != {'source_inputs', 'validators'}:
            raise ContractError(f'{output}: release_checks thiếu source_inputs hoặc validators')
        requested = spec['source_inputs']
        if not isinstance(requested, list) or not requested or any(not isinstance(x, str) for x in requested):
            raise ContractError(f'{output}: phải khai báo nguồn đối chiếu trước khi FINAL')
        sources, stages = lineage(contract, output)
        if not set(requested).issubset(sources):
            raise ContractError(f'{output}: thiếu liên kết đến các nguồn {sorted(set(requested)-sources)}')
        by_id = contract.stage_by_id
        if not any(by_id[sid].adapter == 'api_text' and by_id[sid].semantic_qa for sid in stages):
            raise ContractError(f'{output}: thiếu công đoạn AI đã QA ngữ nghĩa trong chuỗi nguồn')
        checks_list = spec['validators']
        if not isinstance(checks_list,list) or not checks_list:
            raise ContractError(f'{output}: thiếu kiểm tra bàn giao')
        if not any(isinstance(v,dict) and v.get('type') in STRONG_CHECKS for v in checks_list):
            raise ContractError(f'{output}: chỉ nonempty/required_phrases không đủ để chứng nhận FINAL')
        # Validator schema is validated at the contract layer too; never skip it.


def check_release_content(content: str, validators, source_texts: dict[str,str], output: str) -> None:
    marker = UNFINISHED.search(content)
    if marker:
        raise ContractError(f'{output}: chứa dấu hiệu dữ liệu chưa hoàn thành: {marker.group(0)}')
    issues=validate_content(content, validators, source_texts)
    if issues:
        raise ContractError(f'{output}: QA bàn giao FAIL: '+ '; '.join(issues))
