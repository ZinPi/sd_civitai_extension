"""Deterministic checks for explicitly numbered deliverables in the current guide.

These guards do not claim to replace source/canon/semantic QA. The file layout
is a technical serialization contract for individually countable deliverables.
No B1-B7 filename or fixed filmmaking sequence is assumed.
"""
from __future__ import annotations
import re
from .contract import ContractError


def output_specs(instructions: str) -> dict[str, int]:
    specs = {}
    cases = [
        ('THUMBNAIL_PROMPTS.txt', r'(?i)\b(?:tạo|viết|xuất)\s+(\d+)\s+prompt\s+(?:ảnh\s+)?thumbnail\b'),
        ('YOUTUBE_TITLES.txt', r'(?i)\b(?:tạo|viết|xuất)\s+(\d+)\s+tiêu\s+đề\b'),
        ('YOUTUBE_DESCRIPTION.txt', r'(?i)\b(?:1|một)\s+mô\s+tả\s+(?:đúng|chính\s+xác)\s+(\d+)\s+từ\b'),
    ]
    for filename, pattern in cases:
        found = [int(v) for v in re.findall(pattern, instructions)]
        if found:
            if len(set(found)) != 1 or not 1 <= found[0] <= 10000:
                raise ContractError('Yêu cầu số lượng trong hướng dẫn không nhất quán: '+filename)
            specs[filename] = found[0]
    return specs


def serialization_contract(specs: dict[str, int]) -> str:
    if not specs:
        return ''
    parts=['\n\n### ĐỊNH DẠNG BẮT BUỘC ĐỂ KIỂM ĐẾM THÀNH PHẨM']
    if 'THUMBNAIL_PROMPTS.txt' in specs:
        n=specs['THUMBNAIL_PROMPTS.txt']
        parts.append(f'Xuất @@FILE:THUMBNAIL_PROMPTS.txt@@ với đúng {n} prompt; mỗi prompt là MỘT dòng độc lập, bắt đầu lần lượt 1. đến {n}. Mỗi dòng chứa toàn bộ prompt. Không gộp hoặc dùng nhiều dòng cho một prompt.')
    if 'YOUTUBE_TITLES.txt' in specs:
        n=specs['YOUTUBE_TITLES.txt']
        parts.append(f'Xuất @@FILE:YOUTUBE_TITLES.txt@@ với đúng {n} tiêu đề; mỗi tiêu đề một dòng, đánh số 1. đến {n}.')
    if 'YOUTUBE_DESCRIPTION.txt' in specs:
        n=specs['YOUTUBE_DESCRIPTION.txt']
        parts.append(f'Xuất @@FILE:YOUTUBE_DESCRIPTION.txt@@, CHỈ chứa nội dung mô tả đúng {n} từ, không kèm nhãn, tiêu đề hay hashtag.')
    return '\n'.join(parts)


def _numbered_rows(text: str, count: int, label: str) -> None:
    lines=[x.strip() for x in text.splitlines() if x.strip()]
    if len(lines)!=count:
        raise ContractError(f'{label}: phải có đúng {count} mục riêng biệt, hiện có {len(lines)} dòng; chưa LOCK.')
    for index,line in enumerate(lines,1):
        match=re.match(r'^(\d+)[.)]\s+(\S.*)$',line)
        if not match or int(match.group(1))!=index:
            raise ContractError(f'{label}: mục {index} thiếu, sai số thứ tự hoặc không có nội dung; chưa LOCK.')


def validate_deliverables(specs: dict[str,int], files: dict[str,str]) -> None:
    if not specs:return
    index={n.casefold():text for n,text in files.items()}
    for filename,number in specs.items():
        if filename.casefold() not in index:
            raise ContractError('Thiếu thành phẩm để kiểm đếm: '+filename+'; chưa LOCK.')
        content=index[filename.casefold()].strip()
        if filename=='YOUTUBE_DESCRIPTION.txt':
            words=content.split()
            if len(words)!=number:
                raise ContractError(f'Mô tả yêu cầu đúng {number} từ, hiện có {len(words)} từ; chưa LOCK.')
        else:_numbered_rows(content,number,filename)
