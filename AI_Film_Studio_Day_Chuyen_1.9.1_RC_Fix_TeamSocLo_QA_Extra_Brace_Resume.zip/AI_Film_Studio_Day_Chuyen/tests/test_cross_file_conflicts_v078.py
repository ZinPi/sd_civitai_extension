"""Regression: multiple rule files must not silently choose conflicting instructions."""
import copy
import json
import zipfile
from pathlib import Path

import pytest

from studio.api import Generation
from studio.contract import ContractError
from studio.rule_options import (read_rules, analyze_rules, validate_answers,
                                 confirmed_choices_text, verify_report_constraints)
from studio.rule_conflicts import (extract_fixed_rules, detect_conflicts,
                                   validate_assertions, verify_conflicts)
from studio.project_setup import initialize_approved_project


def fixture_files():
    return {'a.txt': 'Ngôn ngữ đầu ra: tiếng Việt.\nSố cảnh: 10.\nBắt buộc tạo mục lục.\n',
            'b.txt': 'Ngôn ngữ đầu ra: tiếng Anh.\nSố cảnh: 12.\nKhông được tạo mục lục.\n'}


class SourceModel:
    def __init__(self, extras=None):
        self.calls = 0
        self.extras = extras or {}
    def generate(self, *, system, user, max_output_tokens):
        self.calls += 1
        fn = user.split('TÊN FILE QUY TẮC: ')[1].split('\n')[0]
        doc = {'summary': 'Đọc file ' + fn, 'steps': [], 'deliverables': [],
               'questions': [], 'warnings': [], 'blockers': [],
               'assertions': self.extras.get(fn, [])}
        return Generation(json.dumps(doc, ensure_ascii=False))


def test_conflicts_are_cross_file_and_grounded():
    result = detect_conflicts(fixture_files())
    assert len(result) == 3
    assert {c['topic'] for c in result} == {'ngon_ngu', 'so_canh', 'thao_tac:tạo:mục lục'}
    assert all(c['left']['source_file'] == 'a.txt' for c in result)
    assert all(c['right']['source_file'] == 'b.txt' for c in result)
    assert all(c['left']['source_quote'] in fixture_files()['a.txt'] for c in result)


def test_not_conflicts_same_file_or_same_value():
    assert not detect_conflicts({'a.txt': 'Số cảnh: 10\nSố cảnh: 12'})
    assert not detect_conflicts({'a.txt': 'Ngôn ngữ đầu ra: tiếng Việt',
                                 'b.txt': 'Ngôn ngữ đầu ra: tiếng Việt.'})
    assert not detect_conflicts({'a.txt': 'Số cảnh: 3 hoặc 5',
                                 'b.txt': 'Số cảnh: 10 nếu cần'})
    assert not detect_conflicts({'a.txt': 'Số cảnh: 10', 'b.txt': 'Số câu: 10'})


def test_multi_file_report_blocks_when_undecided():
    model = SourceModel()
    report = analyze_rules(fixture_files(), model)
    assert model.calls == 2
    assert report['file_count'] == 2
    assert len(report['conflicts']) == 3
    assert report['conflict_engine_version'] == 4
    with pytest.raises(ContractError, match='chưa quyết định'):
        validate_answers(report, {})
    with pytest.raises(ContractError, match='chưa quyết định'):
        confirmed_choices_text(report, {})


def test_decisions_are_bound_to_exact_pair_and_frozen():
    report = analyze_rules(fixture_files(), SourceModel())
    answers = {'__conflicts__': {c['id']: 'left' for c in report['conflicts']}}
    checked = validate_answers(report, answers)
    result = confirmed_choices_text(report, checked)
    assert result.count('ƯU TIÊN: a.txt:') == 3
    assert result.count('KHÔNG ÁP DỤNG ĐIỀU KHOẢN TRÁI NGƯỢC: b.txt:') == 3
    assert 'MÃ PHÂN TÍCH ĐÃ DUYỆT' in result
    verify_report_constraints(report, fixture_files())
    reject = copy.deepcopy(answers)
    reject['__conflicts__']['garbage'] = 'left'
    with pytest.raises(ContractError, match='không xuất phát'):
        validate_answers(report, reject)
    reject = copy.deepcopy(answers)
    reject['__conflicts__'][report['conflicts'][0]['id']] = 'other'
    with pytest.raises(ContractError, match='Chỉ được chọn'):
        validate_answers(report, reject)


def test_legacy_report_rejected_on_reload():
    report = analyze_rules(fixture_files(), SourceModel())
    altered = copy.deepcopy(report)
    altered.pop('conflict_engine_version')
    with pytest.raises(ContractError, match='Bản phân tích cũ'):
        verify_report_constraints(altered, fixture_files())
    altered = copy.deepcopy(report)
    altered['conflicts'] = []
    with pytest.raises(ContractError, match='không khớp'):
        verify_report_constraints(altered, fixture_files())


def test_synthesized_ai_evidence_must_exist_exactly():
    files = {'a.txt': 'Các tài liệu chỉ dùng tông nghiêm túc.',
             'b.txt': 'Các tài liệu chỉ dùng tông hài hước.'}
    claims = [dict(topic='tông', value='nghiêm túc', source_file='a.txt',
                   source_line=1, source_quote=files['a.txt']),
              dict(topic='tông', value='hài hước', source_file='b.txt',
                   source_line=1, source_quote=files['b.txt'])]
    assert len(detect_conflicts(files, claims)) == 1
    corrupted = copy.deepcopy(claims)
    corrupted[0]['value'] = 'kinh dị'
    with pytest.raises(ContractError, match='không xuất hiện nguyên văn'):
        detect_conflicts(files, corrupted)
    corrupted = copy.deepcopy(claims)
    corrupted[0]['source_line'] = 99
    with pytest.raises(ContractError, match='bằng chứng'):
        detect_conflicts(files, corrupted)


def test_user_chooses_no_conflict_does_not_add_internal_field():
    report = analyze_rules({'a.txt': 'Quy tắc A.', 'b.txt':'Quy tắc B.'}, SourceModel())
    assert not report['conflicts']
    assert validate_answers(report, {}) == {}
    assert 'QUYẾT ĐỊNH ƯU TIÊN' not in confirmed_choices_text(report, {})


def test_project_initialization_persists_decisions(tmp_path):
    files = fixture_files()
    paths = []
    for fn, content in files.items():
        p = tmp_path / fn
        p.write_text(content, encoding='utf8')
        paths.append(p)
    report = analyze_rules(read_rules(paths), SourceModel())
    answers = {'__conflicts__': {c['id']: 'right' for c in report['conflicts']}}
    project = tmp_path / 'project'
    with pytest.raises(ContractError, match='chưa quyết định'):
        initialize_approved_project(project, paths, report, {})
    assert not project.exists()
    studio = initialize_approved_project(project, paths, report, answers)
    try:
        frozen = (project/'user_choices_confirmed.txt').read_text(encoding='utf8')
        assert frozen.count('ƯU TIÊN: b.txt:') == 3
        assert 'CẤM' not in frozen or 'mục lục' in frozen
        assert 'QUYẾT ĐỊNH XUNG ĐỘT' in (project/'PHAN_TICH_QUY_TAC.txt').read_text(encoding='utf8')
        persisted = json.loads((project/'TUY_CHON_DA_CHON.json').read_text(encoding='utf8'))
        assert persisted == answers
        stored_report = json.loads((project/'PHAN_TICH_QUY_TAC.json').read_text(encoding='utf8'))
        verify_report_constraints(stored_report, files)
        assert confirmed_choices_text(stored_report, persisted) == frozen
    finally:
        studio.close()


def test_zip_multi_file_and_line_indices(tmp_path):
    z = tmp_path/'rules.zip'
    with zipfile.ZipFile(z,'w') as archive:
        for fn, content in fixture_files().items():
            archive.writestr(fn, content)
    files = read_rules([z])
    report = analyze_rules(files, SourceModel())
    assert report['file_count'] == 2
    assert len(report['conflicts']) == 3


def test_conflicting_model_claims_with_no_explicit_options():
    files = {'a.txt': 'Bản viết phải dùng tông trang trọng.',
             'b.txt': 'Bản viết phải dùng tông hài hước.'}
    claims = {'a.txt': [dict(topic='tông', value='trang trọng', source_file='a.txt',
                           source_line=1, source_quote=files['a.txt'])],
              'b.txt': [dict(topic='tông', value='hài hước', source_file='b.txt',
                           source_line=1, source_quote=files['b.txt'])]}
    report = analyze_rules(files, SourceModel(claims))
    assert len(report['conflicts']) == 1
    assert report['conflicts'][0]['topic'] == 'tông'


def test_more_malformed_conflict_values_fail_closed():
    report = analyze_rules(fixture_files(), SourceModel())
    complete = {c['id']: 'right' for c in report['conflicts']}
    incomplete = {k:v for k,v in list(complete.items())[1:]}
    with pytest.raises(ContractError, match='chưa quyết định'):
        validate_answers(report, {'__conflicts__': incomplete})
    with pytest.raises(ContractError, match='Chỉ được chọn'):
        validate_answers(report, {'__conflicts__': {k: True for k in complete}})
    with pytest.raises(ContractError, match='không xuất phát'):
        validate_answers(report, {'__conflicts__': complete, 'unexpected': 'a'})


def test_three_rule_files_cannot_form_preference_cycle():
    files = {'a.txt':'Ngôn ngữ đầu ra: tiếng Việt',
             'b.txt':'Ngôn ngữ đầu ra: tiếng Anh',
             'c.txt':'Ngôn ngữ đầu ra: tiếng Nhật'}
    report = analyze_rules(files, SourceModel())
    assert len(report['conflicts']) == 3
    # Pair order is a-b, a-c, b-c. Create A>B, C>A, B>C (cycle).
    choices = {}
    for c in report['conflicts']:
        a = c['left']['source_file']
        b = c['right']['source_file']
        pref = {('a.txt', 'b.txt'):'left', ('a.txt','c.txt'):'right',
                ('b.txt','c.txt'):'left'}[(a,b)]
        choices[c['id']] = pref
    with pytest.raises(ContractError, match='vòng mâu thuẫn'):
        validate_answers(report, {'__conflicts__': choices})
    # A>B>C, consistent.
    choices = {c['id']:'left' for c in report['conflicts']}
    frozen = confirmed_choices_text(report, {'__conflicts__': choices})
    assert 'KẾT LUẬN ƯU TIÊN CHỦ ĐỀ ngon_ngu: a.txt:1' in frozen


def test_same_value_from_two_files_cannot_choose_both_sides():
    files = {'a.txt':'Ngôn ngữ đầu ra: tiếng Việt',
             'b.txt':'Ngôn ngữ đầu ra: tiếng Việt',
             'c.txt':'Ngôn ngữ đầu ra: tiếng Anh'}
    report = analyze_rules(files, SourceModel())
    assert len(report['conflicts']) == 2
    decisions = {c['id']: 'left' if c['left']['source_file'] == 'a.txt' else 'right'
                 for c in report['conflicts']}
    with pytest.raises(ContractError, match='hai giá trị trái nhau'):
        validate_answers(report, {'__conflicts__': decisions})
