"""Offline regression for account model selection and protected settings."""
import json
from types import SimpleNamespace
import pytest

from studio.api_connection import choose_text_models, fetch_account_models, probe_responses_model, ConnectionCheckError
from studio import local_settings as ls


def test_model_filter_no_special_apis():
    result=choose_text_models(['gpt-6.1','gpt-5.1','gpt-4o-mini','o3','gpt-image-1',
                               'text-embedding-3-large','gpt-realtime-mini','gpt-6.1',
                               'gpt-5.1-codex','sora-2','chatgpt-4o','omni-moderation-latest'])
    assert set(result)=={'gpt-6.1','gpt-5.1','gpt-4o-mini','o3'}


def test_api_key_list_models_no_generation():
    class Client:
        def __init__(self,**kwargs):
            assert kwargs['api_key']=='sk-fake'
            self.models=SimpleNamespace(list=lambda:SimpleNamespace(data=[SimpleNamespace(id=x) for x in ['gpt-5','gpt-image-1']]))
    assert fetch_account_models('sk-fake',client_factory=Client)==['gpt-5']


def test_model_list_invalid_key_error_safe():
    class AuthenticationError(Exception):pass
    class Client:
        def __init__(self,**kwargs):
            self.models=SimpleNamespace(list=lambda: (_ for _ in ()).throw(AuthenticationError('sk-secret NEVER LOG')))
    with pytest.raises(ConnectionCheckError) as info:
        fetch_account_models('sk-secret',client_factory=Client)
    assert 'sk-secret' not in str(info.value)
    assert '401' in str(info.value)


def test_model_probe_token_usage_and_inputs():
    calls=[]
    class Client:
        def __init__(self,**kwargs):
            self.responses=SimpleNamespace(create=self.create)
        def create(self,**kwargs):
            calls.append(kwargs)
            return SimpleNamespace(status='completed',usage=SimpleNamespace(input_tokens=12,output_tokens=3))
    assert probe_responses_model('sk-xx','gpt-5','high',client_factory=Client)==(12,3)
    assert calls[0]['reasoning']=={'effort':'high'}
    assert calls[0]['store'] is False
    assert calls[0]['max_output_tokens']<=256


def test_model_probe_bad_request_without_leaking_key():
    class BadRequestError(Exception):pass
    class Client:
        def __init__(self,**kwargs):
            self.responses=SimpleNamespace(create=lambda **opts: (_ for _ in ()).throw(BadRequestError('sk-secret')))
    with pytest.raises(ConnectionCheckError) as info:
        probe_responses_model('sk-secret','gpt-X','xhigh',client_factory=Client)
    assert 'sk-secret' not in str(info.value)


def test_settings_without_key_persist_only_nonsecret(tmp_path):
    path=tmp_path/'settings.json'
    ls.save_settings(model='gpt-test',effort='high',budget=2,api_key='sk-ultrasecret',remember_key=False,path=path)
    raw=path.read_text('utf-8')
    assert 'sk-ultrasecret' not in raw
    data=ls.load_settings(path=path)
    assert data['model']=='gpt-test'
    assert 'api_key' not in data


def test_settings_with_mock_encrypted_dpapi_roundtrip(tmp_path,monkeypatch):
    # Non-Windows CI: test save/load plumbing; Windows smoke must verify real DPAPI.
    def fake_dpapi(data,*,decrypt):
        return data[::-1] if decrypt else data[::-1]
    monkeypatch.setattr(ls,'_dpapi',fake_dpapi)
    path=tmp_path/'private.json'
    ls.save_settings(model='gpt-test',effort='medium',budget=1,api_key='sk-topsecret',remember_key=True,path=path)
    assert 'sk-topsecret' not in path.read_text('utf8')
    loaded=ls.load_settings(path=path)
    assert loaded['api_key']=='sk-topsecret'
    ls.save_settings(model='gpt-test',effort='medium',budget=1,api_key='',remember_key=False,path=path)
    assert 'api_key_dpapi' not in json.loads(path.read_text('utf8'))


def test_setting_corrupt_json_recover(tmp_path):
    f=tmp_path/'settings.json'
    f.write_text('{broken json',encoding='utf8')
    assert 'warning' in ls.load_settings(path=f)
