"""Per-Windows-user settings. Only DPAPI-encrypted API keys may be persisted."""
from __future__ import annotations

import base64
import json
import os
from pathlib import Path


class SettingsError(ValueError):
    pass


def settings_path() -> Path:
    root=os.environ.get('LOCALAPPDATA')
    if not root:
        root=str(Path.home()/'AppData'/'Local') if os.name=='nt' else str(Path.home()/'.config')
    return Path(root)/'AI_Film_Studio'/'settings.json'


def _dpapi(data: bytes, *, decrypt: bool) -> bytes:
    if os.name != 'nt':
        raise SettingsError('Chỉ Windows mới cho phép lưu API key an toàn bằng DPAPI.')
    import ctypes
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_ubyte))]

    buf = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    inside=DATA_BLOB(len(data),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)))
    outside=DATA_BLOB()
    crypt32=ctypes.WinDLL('crypt32',use_last_error=True)
    kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
    fn=crypt32.CryptUnprotectData if decrypt else crypt32.CryptProtectData
    fn.restype=wintypes.BOOL
    if decrypt:
        fn.argtypes=[ctypes.POINTER(DATA_BLOB),ctypes.POINTER(ctypes.c_wchar_p),ctypes.c_void_p,
                     ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(DATA_BLOB)]
        result=fn(ctypes.byref(inside),None,None,None,None,0x1,ctypes.byref(outside))
    else:
        fn.argtypes=[ctypes.POINTER(DATA_BLOB),ctypes.c_wchar_p,ctypes.c_void_p,
                     ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(DATA_BLOB)]
        result=fn(ctypes.byref(inside),'AI Film Studio - API key',None,None,None,0x1,ctypes.byref(outside))
    if not result:
        raise SettingsError('Windows không thể '+('giải mã' if decrypt else 'mã hóa')+' API key bằng DPAPI.')
    try:
        return ctypes.string_at(outside.pbData, outside.cbData)
    finally:
        kernel32.LocalFree.argtypes=[ctypes.c_void_p]
        kernel32.LocalFree.restype=ctypes.c_void_p
        kernel32.LocalFree(ctypes.cast(outside.pbData,ctypes.c_void_p))


def save_settings(*, model: str, effort: str, budget: float, api_key: str,
                  remember_key: bool, path: Path|None=None, calls:int=180) -> Path:
    """Never write a plaintext key. File is atomic and per-user."""
    p=path or settings_path()
    payload={'version':1,'model':model,'effort':effort,'budget':float(budget),
             'remember_key':bool(remember_key),'calls':int(calls)}
    if remember_key:
        if not api_key.strip():
            raise SettingsError('Chưa có API key để lưu.')
        protected=_dpapi(api_key.strip().encode('utf-8'),decrypt=False)
        payload['api_key_dpapi']=base64.b64encode(protected).decode('ascii')
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_name(p.name+'.tmp')
    try:
        tmp.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(tmp,p)
    finally:
        if tmp.exists():tmp.unlink()
    return p


def load_settings(*, path: Path|None=None) -> dict:
    p=path or settings_path()
    if not p.is_file():return {}
    try:
        payload=json.loads(p.read_text(encoding='utf-8'))
        if not isinstance(payload,dict) or payload.get('version') != 1:
            return {}
        result={k:payload[k] for k in ('model','effort','budget','remember_key','calls') if k in payload}
        if payload.get('remember_key') and payload.get('api_key_dpapi'):
            try:
                result['api_key']=_dpapi(base64.b64decode(payload['api_key_dpapi'],validate=True),decrypt=True).decode('utf-8')
            except Exception:
                result['warning']='API key đã lưu không giải mã được trên tài khoản Windows này; hãy nhập lại.'
        return result
    except (OSError,ValueError,TypeError):
        return {'warning':'Không đọc được file cài đặt. Hãy thiết lập lại API.'}
