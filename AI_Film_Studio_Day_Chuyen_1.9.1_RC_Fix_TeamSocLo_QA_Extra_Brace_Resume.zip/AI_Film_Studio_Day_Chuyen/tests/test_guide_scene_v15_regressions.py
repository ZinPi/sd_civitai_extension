"""Previously untested scene QA checkpoint and complete source-comparison failures."""
from __future__ import annotations
import json
from types import SimpleNamespace
import pytest
from studio.contract import ContractError
from studio.guide_flow import GuideFlow
import studio.guide_scene as scene
from tests.test_scene_responsive_v14 import project,SceneProvider


class FullSourceProvider(SceneProvider):
    def __init__(self, *, fail_group=False, omit_group_note=False, **kwargs):
        super().__init__(**kwargs)
        self.fail_group=fail_group
        self.omit_group_note=omit_group_note
    def generate(self, *, system, user, max_output_tokens):
        if 'QA ĐỐI CHIẾU TOÀN VĂN THEO NHÓM CỬA SỔ' in system:
            self.calls.append((system,user,max_output_tokens))
            values={'verdict':'FAIL' if self.fail_group else 'PASS',
                    'issues':['Lỗi so sánh nguồn'] if self.fail_group else []}
            if not self.omit_group_note:values['coverage_note']='Đã đối chiếu trực tiếp từng source và output trong nhóm.'
            return SimpleNamespace(text=json.dumps(values,ensure_ascii=False))
        return super().generate(system=system,user=user,max_output_tokens=max_output_tokens)



def large_project(tmp_path):
    (tmp_path/'HUONG_DAN.txt').write_text(
        '1- CHUYỂN THỂ\nĐỌC B1.txt. OUTPUT CHÍNH THỨC:\nAUDIO_ES_LATAM_MASTER\n'
        'QA từng scene, FULL-SCOPE QA toàn tác phẩm.\n'
        '2- BƯỚC TIẾP\nĐọc B2.txt.\n',encoding='utf8')
    (tmp_path/'B1.txt').write_text('Không bịa canon.',encoding='utf8')
    (tmp_path/'B2.txt').write_text('KHÔNG ĐỌC TRƯỚC.',encoding='utf8')
    (tmp_path/'story.txt').write_text(
        ('Câu chuyện có nguồn nguyên văn và tính liên tục qua từng chương. '
         'Nhân vật không biến mất khỏi diễn biến.\n\n')*350,encoding='utf8')
    return GuideFlow.create(tmp_path/'project',tmp_path/'HUONG_DAN.txt',
                            [tmp_path/'B1.txt',tmp_path/'B2.txt'],[tmp_path/'story.txt'])

def qa_receipt(flow):
    paths=list((flow.folder/'candidates'/'STEP_001'/'scene_windows').glob('*/full_qa.json'))
    assert len(paths)==1
    return paths[0]


def test_full_scope_sends_both_entire_original_and_combined_output(tmp_path):
    flow=project(tmp_path)
    provider=FullSourceProvider()
    rec=flow.run_next(provider,max_output_tokens=1600)
    assert rec['full_qa_mode']=='direct_source_output'
    source=(flow.folder/'source'/'story.txt').read_text(encoding='utf8')
    output=(flow.folder/'steps'/'STEP_001'/'AUDIO_ES_LATAM_MASTER.txt').read_text(encoding='utf8')
    calls=[(s,u) for s,u,_ in provider.calls if 'QA TỔNG THỂ toàn tác phẩm' in s]
    assert len(calls)==1
    assert 'TOÀN BỘ NGUỒN GỐC (NGUYÊN VĂN):\n'+source in calls[0][1]
    assert 'TOÀN BỘ THÀNH PHẨM ĐÃ GHÉP (NGUYÊN VĂN):\n'+output in calls[0][1]


def test_resume_preserves_every_qa_gate_and_no_api_after_final_pass(tmp_path,monkeypatch):
    flow=project(tmp_path)
    # Force the optional hard gates to exercise H_ERROR, Q_TOTAL and quality.
    flow.meta['steps'][0]['instructions'] += ('\nH_ERROR = 0; Q_TOTAL >= 90; '
        'MANDATORY_USER_PASS_GATE; FULL-SCOPE QA; TEXTUAL ORALITY; UG-01.')
    flow._save()
    first=FullSourceProvider()
    original=scene.validate_full_qa_gates
    def interrupted_after_persisting_full_qa(instructions,verdict):
        original(instructions,verdict)
        raise ContractError('SIMULATED_POWER_LOSS_BEFORE_LOCK')
    monkeypatch.setattr(scene,'validate_full_qa_gates',interrupted_after_persisting_full_qa)
    with pytest.raises(ContractError,match='SIMULATED_POWER_LOSS'):
        flow.run_next(first,max_output_tokens=1600)
    path=qa_receipt(flow)
    content=json.loads(path.read_text(encoding='utf8'))
    assert content['H_ERROR']==0 and content['Q_TOTAL']==93.5
    assert content['MANDATORY_USER_PASS_GATE']=='PASS'
    monkeypatch.setattr(scene,'validate_full_qa_gates',original)
    reopened=GuideFlow(flow.folder)
    second=FullSourceProvider()
    record=reopened.run_next(second,max_output_tokens=1600)
    assert record['state']=='LOCKED'
    assert second.calls==[]  # all checkpoints, including QA full gates, were cached


def test_old_note_only_qa_must_be_revalidated_without_rewriting_windows(tmp_path,monkeypatch):
    flow=project(tmp_path)
    original=scene.validate_full_qa_gates
    def stop(*args,**kwargs):raise ContractError('INTERRUPTION')
    monkeypatch.setattr(scene,'validate_full_qa_gates',stop)
    with pytest.raises(ContractError,match='INTERRUPTION'):
        flow.run_next(FullSourceProvider(),max_output_tokens=1600)
    path=qa_receipt(flow)
    old=json.loads(path.read_text(encoding='utf8'))
    old.pop('qa_version');old.pop('evidence_sha256');old.pop('full_scope_mode')
    path.write_text(json.dumps(old),encoding='utf8')
    monkeypatch.setattr(scene,'validate_full_qa_gates',original)
    follow=FullSourceProvider()
    record=GuideFlow(flow.folder).run_next(follow,max_output_tokens=1600)
    assert record['state']=='LOCKED'
    assert sum('QA TỔNG THỂ toàn tác phẩm' in s for s,u,n in follow.calls)==1
    assert not any('QA ĐỘC LẬP CHO SOURCE WINDOW' in s for s,u,n in follow.calls)
    assert json.loads(path.read_text(encoding='utf8'))['qa_version']==2


def test_tampered_qa_evidence_blocks_resuming(tmp_path,monkeypatch):
    flow=project(tmp_path)
    monkeypatch.setattr(scene,'validate_full_qa_gates',lambda *_:(_ for _ in ()).throw(ContractError('INTERRUPTION')))
    with pytest.raises(ContractError,match='INTERRUPTION'):
        flow.run_next(FullSourceProvider(),max_output_tokens=1600)
    receipt=qa_receipt(flow)
    document=json.loads(receipt.read_text(encoding='utf8'))
    document['evidence_sha256']='0000'
    receipt.write_text(json.dumps(document),encoding='utf8')
    with pytest.raises(ContractError,match='Bằng chứng QA tổng thể thay đổi'):
        GuideFlow(flow.folder).run_next(FullSourceProvider(),max_output_tokens=1600)


def test_very_long_scope_uses_full_source_output_group_checks(tmp_path,monkeypatch):
    flow=large_project(tmp_path)
    monkeypatch.setattr(scene,'MAX_ALL_CONTEXT',23000)
    provider=FullSourceProvider()
    rec=flow.run_next(provider,max_output_tokens=1600)
    assert rec['full_qa_mode']=='grouped_source_output'
    group_calls=[(s,u) for s,u,_ in provider.calls if 'QA ĐỐI CHIẾU TOÀN VĂN THEO NHÓM CỬA SỔ' in s]
    assert len(group_calls)>=2
    assert all('SOURCE FULL:' in u and 'OUTPUT FULL:' in u for s,u in group_calls)
    paths=list((flow.folder/'candidates'/'STEP_001'/'scene_windows').glob('*/full_source_group_*.json'))
    indices=sorted(i for p in paths for i in json.loads(p.read_text(encoding='utf8'))['indices'])
    assert indices==list(range(1,rec['scene_window_count']+1))
    assert any('QA TỔNG THỂ toàn tác phẩm' in s for s,u,n in provider.calls)


def test_group_qa_fail_keeps_previous_window_checkpoints(tmp_path,monkeypatch):
    flow=large_project(tmp_path)
    monkeypatch.setattr(scene,'MAX_ALL_CONTEXT',23000)
    with pytest.raises(ContractError,match='QA toàn nguồn nhóm'):
        flow.run_next(FullSourceProvider(fail_group=True),max_output_tokens=1600)
    assert flow.status()['completed']==0
    later=FullSourceProvider()
    rec=GuideFlow(flow.folder).run_next(later,max_output_tokens=1600)
    assert rec['state']=='LOCKED'
    assert not any('QA ĐỘC LẬP CHO SOURCE WINDOW' in s for s,u,n in later.calls)


def test_unsubstantiated_group_qa_pass_cannot_lock(tmp_path,monkeypatch):
    flow=large_project(tmp_path)
    monkeypatch.setattr(scene,'MAX_ALL_CONTEXT',23000)
    with pytest.raises(ContractError,match='thiếu ghi chú kiểm chứng'):
        flow.run_next(FullSourceProvider(omit_group_note=True),max_output_tokens=1600)
    assert flow.status()['completed']==0


def test_after_atomic_publishing_before_metadata_save_recovers(tmp_path,monkeypatch):
    flow=project(tmp_path)
    def lose_power():raise OSError('interrupted metadata write')
    monkeypatch.setattr(flow,'_save',lose_power)
    with pytest.raises(OSError,match='interrupted metadata write'):
        flow.run_next(FullSourceProvider(),max_output_tokens=1600)
    assert (flow.folder/'steps'/'STEP_001'/'AUDIO_ES_LATAM_MASTER.txt').is_file()
    reopened=GuideFlow(flow.folder)
    provider=FullSourceProvider()
    rec=reopened.run_next(provider,max_output_tokens=1600)
    assert rec['state']=='LOCKED' and provider.calls==[]
