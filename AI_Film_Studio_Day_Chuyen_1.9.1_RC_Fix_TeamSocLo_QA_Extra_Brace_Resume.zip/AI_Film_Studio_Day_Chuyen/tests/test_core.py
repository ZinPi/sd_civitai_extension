from pathlib import Path
from tempfile import TemporaryDirectory
import json, zipfile, copy, pytest
from studio.contract import validate_contract, ContractError, digest
from studio.engine import Studio, RunBlocked
from studio.api import Generation

RULE='Điều khoản 1: luôn giữ đúng dữ kiện nguồn.\nĐiều khoản 2: không thêm nhân vật.\n'

class FakeProvider:
    def __init__(self, fail_for=None):self.calls=0;self.fail_for=fail_for;self.text_calls=0
    def generate(self,*,system,user,max_output_tokens):
        self.calls+=1
        if 'JSON {"verdict"' in system:
            return Generation(json.dumps({'verdict':'FAIL' if self.fail_for=='qa' else 'PASS',
                     'issues':['Mâu thuẫn nguồn'] if self.fail_for=='qa' else []}),100,45,0)
        self.text_calls+=1
        if self.fail_for=='interrupt' and self.text_calls==2:
            raise RuntimeError('mô phỏng mất kết nối')
        return Generation('Nhân vật thực hiện hành động số '+str(self.text_calls)+'.',250,75,0)

def contract_template(rule_sha,scope='each_audio_line'):
    return dict(schema_version=1,rulepack_sha256=rule_sha,
        file_dispositions={'guide.txt':{'role':'PRODUCTION','reason':'Quy tắc áp dụng cho ví dụ'}},
        clause_coverage=[
          {'file':'guide.txt','start':1,'end':1,'decision':'ENFORCE','stage_ids':['STEP_ALPHA'],'reason':'Đúng dữ kiện nguồn'},
          {'file':'guide.txt','start':2,'end':2,'decision':'ENFORCE','stage_ids':['STEP_ALPHA'],'reason':'Không thêm nhân vật'}
        ],
        required_inputs=['SOURCE_AUDIO','SOURCE_STORY'],required_outputs=['PROMPTS','HANDOFF'],
        deliverables={'scene_prompts':'PROMPTS','handoff':'HANDOFF'},
        release_checks={
          'PROMPTS':{'source_inputs':['SOURCE_AUDIO','SOURCE_STORY'],
                     'validators':[{'type':'line_id_coverage','source':'SOURCE_AUDIO'}]},
          'HANDOFF':{'source_inputs':['SOURCE_AUDIO'],
                     'validators':[{'type':'required_sections','values':['Bàn giao:','001|']}]}
        },
        export_names={'PROMPTS':'03_SCENE_PROMPTS/SCENE_PROMPT_FINAL.txt','HANDOFF':'04_HANDOFF/HANDOFF.txt'},
        stages=[
        dict(id='STEP_ALPHA', title='Phân cảnh mẫu',adapter='api_text',inputs=['SOURCE_AUDIO','SOURCE_STORY'],
             output='PROMPTS', rules=['guide.txt'],source_evidence=['guide.txt:1'],
             instructions='Dựa vào nguồn tạo đúng một đoạn phân cảnh, không thêm chi tiết.',
             scope=scope, output_type='lines' if scope=='each_audio_line' else 'text',semantic_qa=True,
             chunk_source='SOURCE_AUDIO',validators=[{'type':'nonempty'}]+([{'type':'line_id_coverage','source':'SOURCE_AUDIO'}] if scope=='each_audio_line' else [])),
        dict(id='STEP_BETA',title='Bàn giao mẫu',adapter='template',inputs=['PROMPTS'],output='HANDOFF',
             rules=['guide.txt'],source_evidence=['guide.txt:2'],instructions='Bàn giao:\n{{PROMPTS}}',
             validators=[{'type':'nonempty'},{'type':'required_phrases','values':['Bàn giao:']}])])

@pytest.fixture
def env(tmp_path):
    z=tmp_path/'arbitrary_rules_pack.zip'
    with zipfile.ZipFile(z,'w') as f:f.writestr('guide.txt',RULE)
    proj=tmp_path/'proj';s=Studio(proj)
    (proj/'delivery_policy.json').write_text(json.dumps({'required_roles':['scene_prompts','handoff']}),encoding='utf8')
    sha,_=s.import_pack(z)
    s.import_source_text('SOURCE_AUDIO','001|Nhân vật đi vào.\n002|Nhân vật dừng lại.\n003|Họ nhìn nhau.')
    s.import_source_text('SOURCE_STORY','Một câu chuyện gốc.')
    con=contract_template(sha);f=tmp_path/'contract.json';f.write_text(json.dumps(con),encoding='utf8')
    yield s,con,f,z
    s.close()

def test_dynamic_contract_no_manga_branches(env):
    s,raw,f,z=env
    c=s.approve(f)
    assert c.order==('STEP_ALPHA','STEP_BETA')
    assert not any('BOY' in str(x) or 'GIRL' in str(x) for x in c.stages)

def test_complete_export_and_reuse_no_extra_api(env):
    s,c,f,z=env;s.approve(f);api=FakeProvider()
    out=s.run(api,max_usd=50)
    assert out.exists() and out.name.startswith('PROJECT_TEST_ONLY_')
    with zipfile.ZipFile(out) as a:
        assert a.testzip() is None
        assert '04_HANDOFF/HANDOFF.txt' in a.namelist()
        assert len(a.read('03_SCENE_PROMPTS/SCENE_PROMPT_FINAL.txt').decode().splitlines())==3
    count=api.calls
    s.run(api,max_usd=50)
    assert api.calls==count

def test_qa_fail_must_not_export(env):
    s,c,f,z=env;s.approve(f)
    with pytest.raises(RunBlocked):s.run(FakeProvider(fail_for='qa'),max_usd=50)
    assert not list((s.folder/'FINAL').glob('*zip')) if (s.folder/'FINAL').exists() else True

def test_interrupt_reuse_unit_checkpoint(env):
    s,c,f,z=env;s.approve(f)
    with pytest.raises(RuntimeError):s.run(FakeProvider(fail_for='interrupt'),max_usd=50)
    api=FakeProvider();s.run(api,max_usd=50)
    assert api.text_calls==2  # only two remaining units

def test_source_modified_invalidates(env):
    s,c,f,z=env;s.approve(f);api=FakeProvider();s.run(api,max_usd=50);calls=api.calls
    s.import_source_text('SOURCE_STORY','Câu chuyện đã được cập nhật.')
    s.run(api,max_usd=50)
    assert api.calls>calls

def test_changed_contract_blocked(env):
    s,c,f,z=env;s.approve(f)
    s.folder.joinpath('contract_approved.json').write_text(json.dumps({**c,'metadata':'changed'}),encoding='utf8')
    with pytest.raises(ContractError,match='thay đổi'):
        s.active_contract()

def test_wrong_rulepack_hash(env):
    s,c,f,z=env;raw=copy.deepcopy(c);raw['rulepack_sha256']='0'*64
    with pytest.raises(ContractError,match='SHA-256'):
        validate_contract(raw,s.rule_files(),s.rule_hash())

def test_missing_producer(env):
    s,c,f,z=env;raw=copy.deepcopy(c);raw['required_outputs'].append('EXTRA')
    with pytest.raises(ContractError,match='Không có dữ liệu'):
        validate_contract(raw,s.rule_files(),s.rule_hash())

def test_cycle(env):
    s,c,f,z=env;raw=copy.deepcopy(c);raw['stages'][0]['inputs'].append('HANDOFF')
    with pytest.raises(ContractError,match='chu trình'):
        validate_contract(raw,s.rule_files(),s.rule_hash())

def test_parallel_never_unlocked_by_bool(env):
    s,c,f,z=env;raw=copy.deepcopy(c);raw['stages'][0]['parallel']=True
    with pytest.raises(ContractError,match='song song'):
        validate_contract(raw,s.rule_files(),s.rule_hash())

def test_unsupported_validator_blocked(env):
    s,c,f,z=env;raw=copy.deepcopy(c);raw['stages'][0]['validators']=[{'type':'magically_correct'}]
    with pytest.raises(ContractError,match='QA chưa được hỗ trợ'):
        validate_contract(raw,s.rule_files(),s.rule_hash())

def test_no_qa_stage_blocked(env):
    s,c,f,z=env;raw=copy.deepcopy(c);raw['stages'][0]['semantic_qa']=False
    with pytest.raises(ContractError,match='semantic_qa'):
        validate_contract(raw,s.rule_files(),s.rule_hash())

def test_missing_rule_evidence_blocked(env):
    s,c,f,z=env;raw=copy.deepcopy(c);raw['stages'][0]['source_evidence']=['guide.txt:600']
    with pytest.raises(ContractError,match='dòng quy tắc'):
        validate_contract(raw,s.rule_files(),s.rule_hash())

def test_rules_edit_blocked(env):
    s,c,f,z=env;s.approve(f)
    (s.folder/'rules_source.zip').write_bytes(b'changed')
    with pytest.raises(ContractError,match='thay đổi|hỏng|SHA-256'):
        s.active_contract()

def test_zip_traversal_rejected(tmp_path):
    z=tmp_path/'evil.zip'
    with zipfile.ZipFile(z,'w') as f:f.writestr('../bad.txt','hello')
    s=Studio(tmp_path/'out')
    with pytest.raises(ContractError,match='không an toàn'):s.import_pack(z)
    s.close()

def test_arbitrary_stage_ids_and_artifacts(env):
    s,c,f,z=env;raw=copy.deepcopy(c)
    raw['stages'][0]['id']='ANY_STEP_914';raw['stages'][1]['id']='WHATEVER_NAMED'
    for clause in raw['clause_coverage']:clause['stage_ids']=['ANY_STEP_914']
    raw['required_outputs']=['PROMPTS','HANDOFF']
    c2=validate_contract(raw,s.rule_files(),s.rule_hash())
    assert c2.order==('ANY_STEP_914','WHATEVER_NAMED')

def test_export_is_deterministic_and_has_sha(env):
    s,c,f,z=env;s.approve(f);out=s.run(FakeProvider(),max_usd=50)
    with zipfile.ZipFile(out) as a:
        manifest=json.loads(a.read('PROJECT_MANIFEST.json'))
        for name,sha in manifest['artifacts'].items():
            assert digest(a.read(name))==sha
        assert manifest['rulepack_sha256']==s.rule_hash()
        assert manifest['status']=='TEST_ONLY'

def test_no_provider_blocks_paid_stage(env):
    s,c,f,z=env;s.approve(f)
    with pytest.raises(RunBlocked,match='chưa kết nối provider'):s.run(None,max_usd=50)

def test_budget_estimate_blocks_before_charge(env):
    s,c,f,z=env;s.approve(f);api=FakeProvider()
    with pytest.raises(RunBlocked,match='Ngân sách'):s.run(api,max_usd=.0001)
    assert api.calls==0

def test_rule_index_mutation_blocked(env):
    s,c,f,z=env;s.approve(f)
    path=s.folder/'rule_files.json'
    idx=json.loads(path.read_text(encoding='utf8'))
    idx['guide.txt']='Quy tắc đã bị thay đổi trái phép'
    path.write_text(json.dumps(idx),encoding='utf8')
    with pytest.raises(ContractError,match='khác với ZIP gốc'):
        s.active_contract()

def test_model_change_invalidates_units(env):
    s,c,f,z=env;s.approve(f)
    class ModelFake(FakeProvider):
        def __init__(self,model):super().__init__();self.model=model;self.effort='medium'
    a=ModelFake('model-A');s.run(a,max_usd=50)
    b=ModelFake('model-B');s.run(b,max_usd=50)
    assert b.text_calls==3

def test_no_override_manifest_filename(env):
    s,c,f,z=env;raw=copy.deepcopy(c)
    raw['export_names']['PROMPTS']='PROJECT_MANIFEST.json'
    f.write_text(json.dumps(raw),encoding='utf8');s.approve(f)
    with pytest.raises(ContractError,match='trùng báo cáo'):
        s.run(FakeProvider(),max_usd=50)

def test_three_real_rulepacks_as_generic_samples():
    base=Path('/mnt/data')
    from studio.rulepack import inspect_zip
    samples=['MANGA PROMPT BOY.zip','MANGA PROMPT GIRL.zip','#VIDEO_PROJECT(1).zip']
    if all((base/x).exists() for x in samples):
        for name in samples:
            files,raw=inspect_zip(base/name)
            assert len(files)>=14
            assert all(isinstance(x,str) and x for x in files.values())

def test_default_full_deliverables_required(tmp_path):
    z=tmp_path/'rules.zip'
    with zipfile.ZipFile(z,'w') as out:out.writestr('guide.txt',RULE)
    s=Studio(tmp_path/'project')
    sha,_=s.import_pack(z)
    s.import_source_text('SOURCE_AUDIO','001|Cảnh')
    s.import_source_text('SOURCE_STORY','Truyện gốc')
    contract=contract_template(sha)
    p=tmp_path/'contract.json';p.write_text(json.dumps(contract),encoding='utf8')
    with pytest.raises(ContractError,match='Thiếu vai trò'):
        s.approve(p)
    s.close()

def test_delivery_roles_not_reused_ambiguously(env):
    s,c,f,z=env;raw=copy.deepcopy(c)
    raw['deliverables']['handoff']='PROMPTS'
    with pytest.raises(ContractError,match='cùng dùng'):
        from studio.delivery import validate_delivery_policy
        validate_delivery_policy(s.policy(),validate_contract(raw,s.rule_files(),s.rule_hash()))

def test_no_hidden_batch_field_ignored(env):
    s,c,f,z=env;raw=copy.deepcopy(c)
    raw['stages'][0]['batch_size']=40
    with pytest.raises(ContractError,match='trường chưa hỗ trợ'):
        validate_contract(raw,s.rule_files(),s.rule_hash())

def test_rule_disposition_covers_every_source_file(env):
    s,c,f,z=env;raw=copy.deepcopy(c);raw.pop('file_dispositions')
    with pytest.raises(ContractError,match='ĐỦ mọi file'):
        validate_contract(raw,s.rule_files(),s.rule_hash())

def test_cannot_run_chat_only_rule_as_production(env):
    s,c,f,z=env;raw=copy.deepcopy(c)
    raw['file_dispositions']['guide.txt']['role']='CHAT_ONLY'
    with pytest.raises(ContractError,match='production'):
        validate_contract(raw,s.rule_files(),s.rule_hash())

def test_run_worker_thread_sqlite_safe(env):
    from concurrent.futures import ThreadPoolExecutor
    s,c,f,z=env;s.approve(f)
    with ThreadPoolExecutor(max_workers=1) as ex:
        out=ex.submit(s.run,FakeProvider(),max_usd=50).result(timeout=10)
    assert out.exists()
    assert s.store.total_cost()>=0

def test_import_source_during_run_rejected(env):
    s,c,f,z=env
    s._run_lock.acquire()
    try:
        with pytest.raises(ContractError,match='RUN'):
            s.import_source_text('SOURCE_AUDIO','CHANGED')
        with pytest.raises(ContractError,match='RUN'):
            s.approve(f)
    finally:s._run_lock.release()

def test_stop_reset_for_manual_resume(env):
    s,c,f,z=env;s.approve(f)
    s.stop.set()
    out=s.run(FakeProvider(),max_usd=50)
    assert out.exists()

def test_do_not_mix_previous_project_folders(tmp_path):
    root=tmp_path/'legacy'
    root.mkdir();(root/'old_data.json').write_text('{"version":5}',encoding='utf8')
    with pytest.raises(ContractError,match='không phải dự án V6'):
        Studio(root)

def test_close_blocked_during_run(env):
    s,c,f,z=env
    s._run_lock.acquire()
    try:
        with pytest.raises(ContractError,match='RUN'):
            s.close()
    finally:s._run_lock.release()
