"""User delivery requirements are independent of source rulepacks."""
from __future__ import annotations
from .contract import ContractError, IDENTITY

DEFAULT_ROLES=[
    'character_index', 'background_index', 'character_prompts',
    'background_prompts', 'scene_prompts', 'handoff'
]

def validate_delivery_policy(policy:dict, contract)->None:
    roles=policy.get('required_roles')
    bindings=contract.raw.get('deliverables',{})
    if not isinstance(roles,list) or not roles or len(roles)!=len(set(roles)):
        raise ContractError('Chính sách bàn giao phải có danh sách vai trò duy nhất')
    if not isinstance(bindings,dict):raise ContractError('Hợp đồng thiếu ánh xạ deliverables')
    for role in roles:
        if not isinstance(role,str) or not IDENTITY.fullmatch(role):
            raise ContractError('Vai trò đầu ra không hợp lệ: '+str(role))
        if role not in bindings:raise ContractError('Thiếu vai trò sản phẩm bắt buộc: '+role)
        name=bindings[role]
        if name not in contract.outputs:
            raise ContractError('Vai trò '+role+' tham chiếu sản phẩm không có trong required_outputs: '+str(name))
    if len(set(bindings.values())) != len(bindings):
        raise ContractError('Các vai trò không được cùng dùng một file trừ khi quy tắc và chính sách cho phép rõ ràng')
