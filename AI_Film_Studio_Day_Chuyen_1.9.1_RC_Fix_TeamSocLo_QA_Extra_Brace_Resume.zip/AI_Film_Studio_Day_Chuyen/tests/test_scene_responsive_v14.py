"""Failures missed by the one-call engine, including interrupted runs."""
from __future__ import annotations
import json
from pathlib import Path
from types import SimpleNamespace
import pytest
from studio.contract import ContractError
from studio.guide_flow import GuideFlow
from studio.guide_scene import source_windows


class SceneProvider:
    provider_id='teamsoclo'
    model='model-test'
    def __init__(self,qa_fail_at=0,global_fail=False):
        self.calls=[];self.qa_counter=0;self.qa_fail_at=qa_fail_at;self.global_fail=global_fail
    def generate(self,*,system,user,max_output_tokens):
        self.calls.append((system,user,max_output_tokens))
        if 'QA ĐỘC LẬP CHO SOURCE WINDOW' in system:
            self.qa_counter+=1
            if self.qa_counter==self.qa_fail_at:
                return SimpleNamespace(text=json.dumps({'verdict':'FAIL','issues':['thiếu chi tiết nguồn']}))
            return SimpleNamespace(text=json.dumps({'verdict':'PASS','issues':[],
                                                    'continuity':f'Nguồn phân đoạn {self.qa_counter}; nhân vật và tình tiết giữ nguyên'}))
        if 'QA RANH GIỚI ĐỘC LẬP' in system:
            return SimpleNamespace(text='{"verdict":"PASS","issues":[]}')
        if 'QA TỔNG THỂ toàn tác phẩm' in system:
            values={'verdict':'FAIL' if self.global_fail else 'PASS',
                    'issues':['cần đối chiếu lại'] if self.global_fail else []}
            if 'H_ERROR' in system:
                values.update({'H_ERROR':0,'Q_TOTAL':93.5,'MANDATORY_USER_PASS_GATE':'PASS',
                               'FULL_SOURCE_COMPARISON':'PASS','SCENE_QA':'PASS',
                               'FULL_SCOPE_QA':'PASS','TEXTUAL_ORALITY_SIMULATION':'PASS',
                               'UG_QA':'PASS'})
            return SimpleNamespace(text=json.dumps(values))
        return SimpleNamespace(text='Văn bản chuyển thể dựa trên source. '+str(len(user)))


def project(tmp_path):
    (tmp_path/'HUONG_DAN.txt').write_text(
        '1- CHUYỂN THỂ\nTHỰC TẾ ĐỌC B1.txt. OUTPUT CHÍNH THỨC:\nAUDIO_ES_LATAM_MASTER\n'
        'QA từng scene trước rồi chạy FULL-SCOPE QA toàn tác phẩm.\n'
        '2- BƯỚC TIẾP\nĐọc B2.txt.\n',encoding='utf8')
    (tmp_path/'B1.txt').write_text('Chuyển thể trọn nguồn, không bỏ canon.',encoding='utf8')
    (tmp_path/'B2.txt').write_text('TỪ TƯƠNG LAI KHÔNG ĐƯỢC ĐỌC TRƯỚC.',encoding='utf8')
    (tmp_path/'story.txt').write_text(('Chương truyện có liên kết giữa các nhân vật. '+
                                       'Mỗi hành động nối vào diễn biến tiếp theo.\n\n')*170,encoding='utf8')
    return GuideFlow.create(tmp_path/'project',tmp_path/'HUONG_DAN.txt',
                            [tmp_path/'B1.txt',tmp_path/'B2.txt'],[tmp_path/'story.txt'])


def test_windows_lossless_even_with_a_single_very_long_sentence():
    source='A '*8000+'\n\nChapter two.\n'+('B'*7000)
    windows=source_windows(source,3200)
    assert len(windows)>5
    assert ''.join(t for _,_,t in windows)==source
    assert windows[0][0]==0 and windows[-1][1]==len(source)
    assert all(stop-start==len(t) and len(t)<=3200 for start,stop,t in windows)


def test_scene_step_locks_only_after_all_qa_and_no_future_rules(tmp_path):
    flow=project(tmp_path)
    provider=SceneProvider()
    rec=flow.run_next(provider,max_output_tokens=1600)
    assert rec['state']=='LOCKED' and rec['engine']=='scene_windows'
    assert rec['scene_window_count']>=2
    saved=flow.folder/'steps'/rec['step_id']/'AUDIO_ES_LATAM_MASTER.txt'
    assert saved.exists() and saved.stat().st_size>0
    assert all('TỪ TƯƠNG LAI KHÔNG ĐƯỢC ĐỌC TRƯỚC' not in a+'\n'+b for a,b,_ in provider.calls)
    assert any('QA RANH GIỚI ĐỘC LẬP' in system for system,_,_ in provider.calls)
    assert any('QA TỔNG THỂ toàn tác phẩm' in system for system,_,_ in provider.calls)
    assert flow.status()['completed']==1


def test_global_qa_fail_keeps_scene_checkpoints_and_resume(tmp_path):
    flow=project(tmp_path)
    first=SceneProvider(global_fail=True)
    with pytest.raises(ContractError,match='QA tổng thể FAIL'):
        flow.run_next(first,max_output_tokens=1600)
    assert flow.status()['completed']==0
    assert len(list((flow.folder/'candidates'/'STEP_001'/'scene_windows').glob('*/window_*.json')))>=2
    later=SceneProvider()
    rec=flow.run_next(later,max_output_tokens=1600)
    assert rec['state']=='LOCKED'
    assert not any('QA ĐỘC LẬP CHO SOURCE WINDOW' in system for system,_,_ in later.calls)


def test_scene_qa_fail_blocks_next_and_no_false_checkpoint(tmp_path):
    flow=project(tmp_path)
    provider=SceneProvider(qa_fail_at=2)
    with pytest.raises(ContractError,match='QA chưa PASS'):
        flow.run_next(provider,max_output_tokens=1600,repair_attempts=0)
    assert flow.status()['completed']==0
    later=SceneProvider()
    record=flow.run_next(later,max_output_tokens=1600)
    assert record['state']=='LOCKED'
    assert any('QA ĐỘC LẬP CHO SOURCE WINDOW' in system for system,_,_ in later.calls)


def test_model_change_does_not_reuse_scene_windows(tmp_path):
    flow=project(tmp_path)
    with pytest.raises(ContractError,match='QA tổng thể FAIL'):
        flow.run_next(SceneProvider(global_fail=True),max_output_tokens=1600)
    replacement=SceneProvider();replacement.model='new-model'
    flow.run_next(replacement,max_output_tokens=1600)
    assert any('QA ĐỘC LẬP CHO SOURCE WINDOW' in system for system,_,_ in replacement.calls)


def test_too_small_output_stops_before_api(tmp_path):
    flow=project(tmp_path)
    provider=SceneProvider()
    with pytest.raises(ContractError,match='Dừng TRƯỚC'):
        flow.run_next(provider,max_output_tokens=1100)
    assert provider.calls==[]


def test_gui_source_is_responsive_not_fixed_size():
    content=(Path(__file__).parents[1]/'studio'/'guide_gui.py').read_text(encoding='utf8')
    assert 'def resizeEvent' in content and 'self._reflow()' in content
    assert 'QGridLayout' in content and 'setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)' in content
    assert 'self.model.setMinimumWidth(300)' not in content


def test_guided_output_name_and_hard_qa_gates():
    from studio.guide_scene import _one_text_file,validate_full_qa_gates
    step={'instructions':'1- CHUYỂN ĐỔI\nĐầu ra sau FINAL PASS/LOCK: AUDIO_ES_LATAM_MASTER.'}
    assert _one_text_file(step)=='AUDIO_ES_LATAM_MASTER.txt'
    guide=('FINAL STATUS = PASS khi H_ERROR = 0, Q_TOTAL >= 90/100, '
           'MANDATORY_USER_PASS_GATE PASS, FULL-SCOPE QA, TEXTUAL ORALITY, UG-01')
    with pytest.raises(ContractError,match='H_ERROR'):
        validate_full_qa_gates(guide,{'verdict':'PASS','issues':[]})
    fields={'verdict':'PASS','issues':[],'H_ERROR':0,'Q_TOTAL':89.5,
            'MANDATORY_USER_PASS_GATE':'PASS','FULL_SOURCE_COMPARISON':'PASS',
            'SCENE_QA':'PASS','FULL_SCOPE_QA':'PASS','TEXTUAL_ORALITY_SIMULATION':'PASS','UG_QA':'PASS'}
    with pytest.raises(ContractError,match='Q_TOTAL'):
        validate_full_qa_gates(guide,fields)
    fields['Q_TOTAL']=92
    validate_full_qa_gates(guide,fields)



def test_real_seven_step_guide_runs_long_step1_without_reading_b2(tmp_path):
    root=Path('/mnt/data')
    if not (root/'QUY_TRINH_HUONG_DAN_CHO_TOOL.txt').is_file():
        pytest.skip('User guide is not mounted in this test environment')
    (tmp_path/'source.txt').write_text(
        ('Una historia que continúa entre escenas sin inventar nuevos hechos.\n\n')*850,
        encoding='utf8')
    flow=GuideFlow.create(tmp_path/'project',root/'QUY_TRINH_HUONG_DAN_CHO_TOOL.txt',
                          [root/'B1.txt',root/'B2.txt',root/'B3.txt',root/'B4.txt',
                           root/'B5.txt',root/'B6.txt',root/'B7.txt'],[tmp_path/'source.txt'])
    provider=SceneProvider()
    choices=flow.current_requirements()
    assert not choices, 'These files should not demand artificial human choices.'
    receipt=flow.run_next(provider,max_output_tokens=5000)
    assert receipt['state']=='LOCKED'
    assert 'AUDIO_ES_LATAM_MASTER.txt' in receipt['outputs']
    assert flow.status()['current']['id']=='STEP_002'
    assert not any('QUY TẮC B2.txt' in s for s,u,n in provider.calls)
    assert any('H_ERROR' in system for system,user,n in provider.calls)


def test_budget_preflight_denies_inadequate_remaining_calls(tmp_path):
    flow=project(tmp_path)
    p=SceneProvider()
    p.max_calls=4;p.total_calls=1
    with pytest.raises(ContractError,match='Tăng hạn mức API'):
        flow.run_next(p,max_output_tokens=1600)
    assert not p.calls
