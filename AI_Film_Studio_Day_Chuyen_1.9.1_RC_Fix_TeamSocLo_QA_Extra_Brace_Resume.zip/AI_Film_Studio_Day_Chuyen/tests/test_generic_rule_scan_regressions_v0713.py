"""General-purpose fast analysis against real-world AI over-extraction."""
import json
import threading
from pathlib import Path

from studio.api import Generation
from studio.rule_options import analyze_rules, pending_analysis_chunks, analysis_plan
from studio.fast_analysis import is_human_choice_line


class NaiveOptions:
    def __init__(self, bogus_line, q_count=130):
        self.bogus_line = bogus_line
        self.q_count = q_count
        self.calls = 0
        self.lock = threading.Lock()

    def generate(self, *, system, user, max_output_tokens):
        with self.lock:
            self.calls += 1
        name = user.split('TÊN FILE QUY TẮC: ', 1)[1].splitlines()[0]
        questions = []
        if f'L{self.bogus_line}:' in user:
            for i in range(self.q_count):
                questions.append({
                    'question': f'Chọn tóc {i}?', 'kind': 'single', 'required': True,
                    'choices': ['A', 'B'], 'source_file': name,
                    'source_line': self.bogus_line,
                    'source_quote': 'Hướng tóc phía sau được phép phải ưu tiên một trong các logic sau:'
                })
        return Generation(json.dumps({'summary': name, 'steps': [], 'deliverables': [],
                                      'questions': questions, 'warnings': [],
                                      'blockers': [], 'assertions': []}, ensure_ascii=False))


def test_exact_b4_section_does_not_create_130_human_options():
    # Reproduce the B4 source line without bundling the user's private rules.
    original = Path('/mnt/data/B4.txt')
    line = 'Hướng tóc phía sau được phép phải ưu tiên một trong các logic sau:'
    if original.is_file():
        assert original.read_text('utf8').splitlines()[844] == line
    assert not is_human_choice_line(line)
    synthetic = ['Các quy tắc thiết kế khác.'] * 844 + [line, '* chảy thẳng xuống dưới;', '* tạo bím chéo đi xuống;']
    report = analyze_rules({'ANY_NAME.md': '\n'.join(synthetic)}, NaiveOptions(845), max_workers=3)
    assert report['questions'] == []
    assert report['segment_count'] >= 2


def test_global_shared_cache_only_reanalyzes_modified_file(tmp_path):
    files = {'R1.txt': 'AI chọn chi tiết phù hợp.\n' * 1200,
             'R2.txt': 'Không tạo thêm nhân vật.\n' * 800}
    cache = tmp_path / 'shared'
    first = NaiveOptions(999999)
    rep = analyze_rules(files, first, shared_cache_dir=cache,
                        provider_identity='openai:example', max_workers=3)
    assert rep['cache_hits'] == 0
    assert pending_analysis_chunks(files, None, 'openai:example', shared_cache_dir=cache) == 0
    modified = dict(files, **{'R2.txt': files['R2.txt'] + 'Thêm ràng buộc mới.\n'})
    remaining = pending_analysis_chunks(modified, None, 'openai:example', shared_cache_dir=cache)
    assert 0 < remaining < analysis_plan(modified)['segments']
    second = NaiveOptions(999999)
    changed_report = analyze_rules(modified, second, shared_cache_dir=cache,
                                   provider_identity='openai:example', max_workers=3)
    assert second.calls == remaining
    assert changed_report['cache_hits'] > 0


def test_no_questions_from_another_chunk_even_if_ai_cites_real_user_line():
    rules = 'AI tự làm theo quy tắc.\n' * 1200 + 'Người dùng phải chọn phong cách: A hoặc B.\n'
    class Overeager:
        def generate(self, *, system, user, max_output_tokens):
            question = {'question': 'Chọn phong cách?', 'kind': 'single', 'required': True,
                        'choices': ['A', 'B'], 'source_file': 'R.txt', 'source_line': 1201,
                        'source_quote': 'Người dùng phải chọn phong cách: A hoặc B.'}
            return Generation(json.dumps({'summary': '', 'steps': [], 'deliverables': [],
                                          'questions': [question], 'warnings': [],
                                          'blockers': [], 'assertions': []}, ensure_ascii=False))
    result = analyze_rules({'R.txt': rules}, Overeager())
    assert len(result['questions']) == 1
    assert result['questions'][0]['source_line'] == 1201
