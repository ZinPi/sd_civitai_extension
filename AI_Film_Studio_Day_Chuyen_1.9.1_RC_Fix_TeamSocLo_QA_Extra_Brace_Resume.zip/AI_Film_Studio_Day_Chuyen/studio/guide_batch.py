"""Bounded, guide-declared line batches with per-window QA and checkpoints.

This is not a universal hardcoded B5 engine. Enabled only where the active
instruction explicitly states line-per-prompt, batch size and QA interval.
"""
from __future__ import annotations
import json
import hashlib
import re
import time
from pathlib import Path
from .contract import ContractError
from .guide_preflight import rules_digest


def batch_policy(step:dict)->dict|None:
    text=step['instructions']
    if not re.search(r'(?i)1\s*(?:dòng|dong)\s*/\s*(?:câu|cau).*?1\s*(?:IMAGE_PROMPT|PROMPT)',text):
        return None
    n=re.search(r'(?i)(?:mỗi\s+lần\s+chat|mỗi\s+lượt)\s+chỉ\s+phân\s+tích\s+(\d+)\s*(?:dòng|câu)',text)
    q=re.search(r'(?i)sau\s+(\d+)\s+lần\s*,?\s*tức\s+(\d+)\s*prompt',text)
    if not n or not q:return None
    size, rounds, total=int(n.group(1)),int(q.group(1)),int(q.group(2))
    if not (1<=size<=100 and 1<=rounds<=30 and size*rounds==total):
        raise ContractError('Mốc batch/QA trong hướng dẫn không nhất quán.')
    m=re.search(r'(?i)nguồn\s+văn\s+bản\s+dùng\s+để\s+tạo\s+prompt.{0,80}?["“`]+([A-Z][A-Z0-9_]{5,})',text)
    if not m:
        raise ContractError('Quy trình line-batch chưa nêu rõ tên đầu vào 1-câu/1-dòng để chia batch.')
    return {'batch_size':size,'qa_rounds':rounds,'qa_every':total,'source_stem':m.group(1)}


def source_lines(policy:dict, inputs:dict[str,str])->list[str]:
    key=policy['source_stem'].casefold()
    matched=[(n,b) for n,b in inputs.items() if Path(n).stem.casefold()==key]
    if len(matched)!=1:
        raise ContractError('Cần đúng một thành quả đã LOCK tên '+policy['source_stem']+
                            '.txt làm nguồn 1 dòng = 1 câu (không tự chọn TTS/truyện nguồn). '
                            f'Hiện tìm thấy {len(matched)} file.')
    lines=[line.strip() for line in matched[0][1].splitlines() if line.strip()]
    if not lines:raise ContractError('Nguồn dòng/câu trống.')
    return lines


def parse_batch(text:str,start:int,count:int)->list[str]:
    expected=list(range(start,start+count))
    out=[]
    for line in text.strip().splitlines():
        if not line.strip():continue
        match=re.fullmatch(r'IMAGE_PROMPT_(\d{6})\s*\|\s*(\S.*)',line.strip())
        if match is None:raise ContractError(f'Prompt dòng {start}: sai định dạng IMAGE_PROMPT_000001 | ...')
        out.append((int(match.group(1)),line.strip()))
    if [x[0] for x in out]!=expected:
        raise ContractError(f'Thiếu, thừa, trùng hoặc đảo dòng prompt {start}..{start+count-1}; chưa cho QA PASS.')
    return [x[1] for x in out]


def run_batched(flow,provider,step,rules,inputs,decision_text,resolution,emit,max_tokens,repairs,
                user_decisions=None,conflict_choices=None):
    # Imported lazily to avoid an initialization cycle.
    from .guide_flow import MAX_ALL_CONTEXT,sha,atomic_json,parse_review
    policy=batch_policy(step)
    assert policy is not None
    lines=source_lines(policy,inputs)
    current_digest=rules_digest(rules)
    inputs_digest=rules_digest(inputs)
    all_prompts=[];group_size=policy['qa_every'];batch_size=policy['batch_size']
    # A checkpoint belongs to one exact execution contract, not merely to
    # equivalent source text. Old v1.2 checkpoints have no such binding and
    # are intentionally NOT reused (they are left untouched for inspection).
    contract={'schema':2,'provider_id':str(getattr(provider,'provider_id','unknown')),
              'model':str(getattr(provider,'model','unknown')),
              'rules_digest':current_digest,'inputs_digest':inputs_digest,
              'guide_sha256':flow.meta['guide_sha256'],
              'step_instructions':step['instructions'],'step_id':step['id'],
              'policy':policy,'decisions':user_decisions or {},
              'conflict_decisions':conflict_choices or {},
              'decisions_rendered':decision_text,'conflict_resolution':resolution,
              'max_output_tokens':int(max_tokens)}
    contract_hash=hashlib.sha256(json.dumps(contract,sort_keys=True,ensure_ascii=False).encode('utf8')).hexdigest()
    cand=flow.folder/'candidates'/step['id']/'groups' / ('v2_'+contract_hash[:24])
    cand.mkdir(parents=True,exist_ok=True)
    rule_text='\n\n'.join('FILE '+n+'\n'+r for n,r in rules.items())
    # Exclude the enormous line source from repeated context; the current
    # range is passed explicitly, along with all other upstream continuity.
    aux={n:b for n,b in inputs.items() if Path(n).stem.casefold()!=policy['source_stem'].casefold()}
    auxiliary='\n\n'.join('DỮ LIỆU UPSTREAM '+n+'\n'+b for n,b in aux.items())
    common=('CHỈ THỰC HIỆN BƯỚC '+step['id']+'; TUÂN THỦ QUY TẮC GỐC. '\
            'Không tự tạo CHAR/BG mới, chỉ dùng ID đã LOCK. '\
            'QUY TẮC ĐANG ÁP DỤNG:\n'+rule_text+'\n\nHƯỚNG DẪN BƯỚC:\n'+step['instructions']+
            '\n\nQUYẾT ĐỊNH CON NGƯỜI:\n'+decision_text+'\n'+resolution)
    if len(common)+len(auxiliary)>MAX_ALL_CONTEXT-35000:
        raise ContractError('Quy tắc + dữ liệu upstream quá dài cho batch; không cắt dữ liệu để chạy sai.')
    for group_start in range(1,len(lines)+1,group_size):
        group_end=min(len(lines),group_start+group_size-1)
        group_file=cand/f'group_{group_start:06d}_{group_end:06d}.txt'
        receipt=cand/f'group_{group_start:06d}_{group_end:06d}.json'
        if group_file.exists() and receipt.exists():
            doc=json.loads(receipt.read_text(encoding='utf8'))
            content=group_file.read_text(encoding='utf8')
            if (doc.get('state')=='PASS' and doc.get('rules_digest')==current_digest
                and doc.get('inputs_digest')==inputs_digest
                and doc.get('contract_sha256')==contract_hash
                and doc.get('text_sha256')==sha(content)):
                restored=parse_batch(content,group_start,group_end-group_start+1)
                all_prompts+=restored
                emit(step['id']+f': dùng checkpoint QA PASS {group_start}-{group_end}.')
                continue
            raise ContractError('Checkpoint batch thay đổi/không hợp lệ. Không ghi đè hoặc tái sử dụng sai dữ liệu: '+str(receipt))
        chunk=[]
        for begin in range(group_start,group_end+1,batch_size):
            segment=lines[begin-1:min(begin+batch_size-1,group_end)]
            user=(f'CHỈ TẠO ĐÚNG {len(segment)} PROMPT CHO CÁC DÒNG NGUỒN SAU. '
                  '1 dòng nguồn = 1 IMAGE_PROMPT, đúng thứ tự, không thêm. '
                  'MỖI OUTPUT LÀ MỘT DÒNG KHÔNG XUỐNG HÀNG GIỮA PROMPT, '
                  'cú pháp bắt buộc IMAGE_PROMPT_000001 | nội dung ... (ID đúng số nguồn). '
                  'Không thêm header, lời giải thích hay @@FILE@@.\n\n'+
                  '\n'.join(f'SOURCE_LINE_{i:06d} | {line}' for i,line in enumerate(segment,begin))+
                  '\n\nUPSTREAM ĐÃ KHÓA:\n'+auxiliary)
            if len(common)+len(user)>MAX_ALL_CONTEXT:
                raise ContractError(f'Batch {begin}: vượt context, chưa chạy API.')
            emit(step['id']+f': sinh prompt {begin}-{begin+len(segment)-1}, chưa PASS.')
            result=provider.generate(system=common,user=user,max_output_tokens=max_tokens)
            parsed=parse_batch(result.text,begin,len(segment))
            chunk.extend(parsed)
        group_content='\n'.join(chunk)+'\n'
        group_sources=lines[group_start-1:group_end]
        qa_system=('BỘ QA ĐỘC LẬP CHO CỬA SỔ DÒNG/CÂU. Kiểm tra CHÍNH XÁC 1:1, thứ tự, '
                   'canon, tham chiếu CHAR/BG đã LOCK, đầy đủ quy tắc áp dụng. '
                   'Chỉ trả JSON {"verdict":"PASS"|"FAIL","issues":["... phải ghi IMAGE_PROMPT_000123 nếu lỗi ở dòng đó"]}. '
                   'KHÔNG báo PASS nếu chưa kiểm hết.\n'+common)
        qa_user=('CÁC DÒNG NGUỒN:\n'+'\n'.join(f'SOURCE_LINE_{i:06d} | {v}' for i,v in enumerate(group_sources,group_start))+
                 '\n\nPROMPT CẦN QA:\n'+group_content+'\nUPSTREAM:\n'+auxiliary)
        if len(qa_system)+len(qa_user)>MAX_ALL_CONTEXT:
            raise ContractError('QA batch vượt context, dữ liệu candidate chưa được LOCK.')
        verdict=parse_review(provider.generate(system=qa_system,user=qa_user,max_output_tokens=3000).text)
        for attempt in range(max(0,min(2,int(repairs)))):
            if verdict['verdict']=='PASS':break
            # Only targeted batches with identifiable line IDs may be repaired;
            # never replace a whole 100-line result on an unverifiable guess.
            affected=set()
            for issue in verdict['issues']:
                for match in re.finditer(r'(?:IMAGE_PROMPT_|SOURCE_LINE_)(\d{6})',str(issue)):
                    value=int(match.group(1))
                    if group_start<=value<=group_end:affected.add((value-group_start)//batch_size)
            if not affected:
                break
            emit(step['id']+f': lỗi QA cửa sổ {group_start}-{group_end}; sửa các batch có dẫn ID (vòng {attempt+1}).')
            for batch_index in sorted(affected):
                begin=group_start+batch_index*batch_size
                end=min(begin+batch_size-1,group_end)
                old=chunk[begin-group_start:end-group_start+1]
                repair_user=('SỬA CHỈ CÁC PROMPT Ở BATCH NÀY; vẫn phải trả ĐỦ các dòng cùng ID.\n'
                             'SOURCE:\n'+'\n'.join(f'SOURCE_LINE_{i:06d} | {lines[i-1]}' for i in range(begin,end+1))+
                             '\nPROMPT HIỆN TẠI:\n'+'\n'.join(old)+
                             '\nLỖI QA:\n'+json.dumps(verdict['issues'],ensure_ascii=False))
                if len(common)+len(repair_user)>MAX_ALL_CONTEXT:raise ContractError('REPAIR batch vượt context.')
                edited=provider.generate(system=common+'\nCHẾ ĐỘ REPAIR: KHÔNG ĐỔI ID.',user=repair_user,max_output_tokens=max_tokens)
                chunk[begin-group_start:end-group_start+1]=parse_batch(edited.text,begin,end-begin+1)
            group_content='\n'.join(chunk)+'\n'
            qa_user=('CÁC DÒNG NGUỒN:\n'+'\n'.join(f'SOURCE_LINE_{i:06d} | {v}' for i,v in enumerate(group_sources,group_start))+
                     '\n\nPROMPT CẦN QA:\n'+group_content+'\nUPSTREAM:\n'+auxiliary)
            if len(qa_system)+len(qa_user)>MAX_ALL_CONTEXT:raise ContractError('RE-QA batch vượt context.')
            verdict=parse_review(provider.generate(system=qa_system,user=qa_user,max_output_tokens=3000).text)
        if verdict['verdict']!='PASS':
            (cand/f'failed_{group_start:06d}.txt').write_text(group_content,encoding='utf8')
            atomic_json(cand/f'failed_{group_start:06d}.json',verdict)
            raise ContractError(f'QA batch {group_start}-{group_end} FAIL; dừng tại batch, KHÔNG mở bước sau: '+str(verdict['issues'])[:350])
        # Commit checkpoint ONLY after QA PASS, and verify every ID.
        parse_batch(group_content,group_start,group_end-group_start+1)
        group_file.write_text(group_content,encoding='utf8')
        atomic_json(receipt,{'state':'PASS','rules_digest':current_digest,'inputs_digest':inputs_digest,
                             'text_sha256':sha(group_content),'contract_sha256':contract_hash,'source_start':group_start,'source_end':group_end,
                             'qa_verdict':'PASS'})
        all_prompts+=chunk
        emit(step['id']+f': QA PASS, checkpoint {group_start}-{group_end}.')
    if len(all_prompts)!=len(lines):raise ContractError('Số prompt khác số dòng nguồn, không được LOCK.')
    combined='\n'.join(all_prompts)+'\n'
    parse_batch(combined,1,len(lines))
    # Final full-document semantic QA is mandatory; no silent passing based
    # solely on batch PASS or numerical coverage. Stop safely if too long.
    final_system=('QA TOÀN TÁC PHẨM, đối chiếu toàn bộ nguồn, toàn bộ prompt, quy tắc liên quan và continuity. '
                  'Chỉ PASS khi full-source comparison thật sự thực hiện được. '
                  'Trả JSON {"verdict":"PASS"|"FAIL","issues":["..."]}.\n'+common)
    final_user=('TOÀN BỘ NGUỒN:\n'+'\n'.join(f'SOURCE_LINE_{i:06d} | {line}' for i,line in enumerate(lines,1))+
                '\n\nTOÀN BỘ IMAGE_PROMPT:\n'+combined+'\nUPSTREAM:\n'+auxiliary)
    if len(final_system)+len(final_user)>MAX_ALL_CONTEXT:
        raise ContractError('Full-scope QA vượt context; đã giữ checkpoint các batch QA PASS, '
                            'nhưng CHƯA thể chứng nhận QA tổng thể. Không LOCK bước.')
    final=parse_review(provider.generate(system=final_system,user=final_user,max_output_tokens=4000).text)
    atomic_json(cand/'final_qa.json',final)
    if final['verdict']!='PASS':
        raise ContractError('Full-scope QA FAIL, đã giữ checkpoint batch; chưa LOCK: '+str(final['issues'])[:400])
    target=flow.folder/'steps'/step['id']
    if target.exists():raise ContractError('Không ghi đè bước đã LOCK.')
    target.mkdir(parents=True,exist_ok=False)
    name='IMAGE_PROMPTS.txt'
    (target/name).write_text(combined,encoding='utf8')
    record={'step_id':step['id'],'title':step['title'],'rules':{n:sha(v) for n,v in rules.items()},
            'outputs':{name:sha(combined)},'inputs':{n:sha(v) for n,v in inputs.items()},
            'qa_verdict':'PASS','state':'LOCKED','timestamp':time.time(),
            'provider_id':str(getattr(provider,'provider_id','unknown')),
            'model':str(getattr(provider,'model','unknown')),
            'decisions':user_decisions or {},'conflict_decisions':conflict_choices or {},'batch_policy':policy, 'execution_contract_sha256':contract_hash,'line_count':len(lines),
            'auxiliary_data':{n:sha(inputs[n]) for n in step.get('auxiliary_references',[])
                              if n in inputs and flow._library().has(n)
                              and n.casefold() not in {e['name'].casefold() for e in flow.meta['source_files']}
                              and n.casefold() not in {out.casefold() for prior in flow.meta['locked'] for out in prior['outputs']}}}
    flow.meta['locked'].append(record);flow._save()
    emit(step['id']+f': QA TỔNG THỂ PASS, khóa {len(lines)} IMAGE_PROMPT.')
    return record
