"""Regression for many TXT imports, step preview and fail-closed selective runs."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json,zipfile
import pytest
from studio.engine import Studio,RunBlocked
from studio.contract import ContractError
from studio.workflow_plan import prepare_plan
from tests.test_acceptance_end_to_end import build_pack, MockProvider, STORY, AUDIO

@pytest.fixture
def sample(tmp_path):
    z=tmp_path/'new_rules.zip';build_pack(z)
    studio=Studio(tmp_path/'project')
    studio.import_pack(z)
    studio.import_source_text('SOURCE_STORY',STORY)
    studio.import_source_text('SOURCE_AUDIO',AUDIO)
    studio.approve(studio.propose_contract())
    yield studio
    studio.close()

def test_import_many_txt_and_json_different_filenames(tmp_path):
    z=tmp_path/'reference.zip';build_pack(z)
    with zipfile.ZipFile(z) as pack:
        texts={n:pack.read(n).decode('utf8') for n in pack.namelist()}
    paths=[]
    for n,v in texts.items():
        path=tmp_path/n;path.write_text(v,encoding='utf8');paths.append(path)
    st=Studio(tmp_path/'new_project')
    try:
        sha,n=st.import_rule_inputs(paths)
        assert n==2 and len(sha)==64
        assert st.rule_files()==texts
        assert len(st.active_contract().stages)==6 if False else True  # not approved yet
        draft=st.propose_contract()
        # Contract approved even when project source documents have not been supplied.
        approved=st.approve(draft)
        assert len(approved.stages)==6
        plan=st.preflight(MockProvider())
        assert plan.missing_sources==('SOURCE_AUDIO','SOURCE_STORY') and not plan.ready
    finally:st.close()

def test_import_zip_plus_txt_in_one_batch(tmp_path):
    z=tmp_path/'unknown.zip'
    with zipfile.ZipFile(z,'w') as f:f.writestr('one.txt','Bắt buộc làm gì đó')
    txt=tmp_path/'two.txt';txt.write_text('Phải kiểm tra dữ liệu',encoding='utf8')
    s=Studio(tmp_path/'workspace')
    try:
        h,n=s.import_rule_inputs([z,txt]);assert n==2
        assert set(s.rule_files())=={'one.txt','two.txt'}
        assert s.rule_hash()==h
    finally:s.close()

def test_duplicate_txt_names_are_refused(tmp_path):
    d1=tmp_path/'x';d2=tmp_path/'y';d1.mkdir();d2.mkdir()
    for d in (d1,d2):(d/'R.txt').write_text('Quy tắc',encoding='utf8')
    st=Studio(tmp_path/'proj')
    try:
        with pytest.raises(ContractError,match='Trùng tên'):
            st.import_rule_inputs([d1/'R.txt',d2/'R.txt'])
        assert not (st.folder/'rules_source.zip').exists()
    finally:st.close()

def test_missing_document_blocks_before_any_request(sample):
    sample.store.con.execute('DELETE FROM sources WHERE name=?',('SOURCE_STORY',))
    mock=MockProvider()
    plan=sample.preflight(mock,selected_stage_ids=['step_5'],auto_dependencies=True)
    assert 'SOURCE_STORY' in plan.missing_sources
    with pytest.raises(RunBlocked,match='TRƯỚC RUN'):
        sample.run(mock,selected_stage_ids=['step_5'],auto_dependencies=True)
    assert not mock.calls

def test_selected_no_autodeps_blocks_without_qa_pass_upstream(sample):
    mock=MockProvider()
    plan=sample.preflight(mock,selected_stage_ids=['step_5'],auto_dependencies=False)
    assert 'step_1' in plan.missing_upstream and 'step_2' in plan.missing_upstream
    with pytest.raises(RunBlocked,match='BƯỚC TRƯỚC'):
        sample.run(mock,selected_stage_ids=['step_5'],auto_dependencies=False)
    assert not mock.calls

def test_selected_auto_dependencies_and_no_final(sample):
    mock=MockProvider()
    plan=sample.preflight(mock,selected_stage_ids=['step_5'],auto_dependencies=True)
    assert plan.ready
    assert set(plan.included)=={'step_1','step_2','step_5'}
    outcome=sample.run(mock,selected_stage_ids=['step_5'],auto_dependencies=True)
    assert 'chưa phải FINAL' in outcome
    assert not (sample.folder/'FINAL').exists()
    assert not (sample.folder/'TEST_OUTPUT').exists()
    calls=len(mock.calls)
    plan2=sample.preflight(mock,selected_stage_ids=['step_5'],auto_dependencies=False)
    assert plan2.ready
    assert sample.run(mock,selected_stage_ids=['step_5'],auto_dependencies=False)
    assert len(mock.calls)==calls

def test_selected_then_full_reuses_passed_stages(sample):
    m=MockProvider()
    sample.run(m,selected_stage_ids=['step_5'],auto_dependencies=True)
    calls=len(m.calls)
    result=sample.run(m)
    assert result.exists()
    # step_1, step_2 and step_5 require no new API requests.
    # Remaining 3 stages and QA still run.
    assert len(m.calls)>calls
    assert sample.preflight(m).ready

def test_preflight_changes_when_source_revision_changes(sample):
    m=MockProvider();sample.run(m,selected_stage_ids=['step_5'])
    assert sample.preflight(m,selected_stage_ids=['step_5'],auto_dependencies=False).ready
    sample.import_source_text('SOURCE_STORY',STORY+' phiên bản mới')
    plan=sample.preflight(m,selected_stage_ids=['step_5'],auto_dependencies=False)
    assert not plan.ready
    assert set(plan.missing_upstream)=={'step_1','step_2'}

def test_user_can_upload_intermediate_instead_of_regenerating(sample,tmp_path):
    char=tmp_path/'CHAR_MASTER.txt'
    char.write_text(json.dumps({'characters':[{'id':'CHAR_01','name':'An','evidence_line_ids':['001','003']}]},ensure_ascii=False),encoding='utf8')
    bg=tmp_path/'BG_MASTER.txt'
    bg.write_text(json.dumps({'backgrounds':[{'id':'BG_01','description':'Xưởng có bàn gỗ','evidence_line_ids':['001','002']}]},ensure_ascii=False),encoding='utf8')
    sample.import_stage_output_file('CHAR_MASTER',char)
    sample.import_stage_output_file('BG_MASTER',bg)
    fake=MockProvider()
    plan=sample.preflight(fake,selected_stage_ids=['step_5'],auto_dependencies=False)
    assert plan.ready and plan.missing_upstream==()
    assert [x.action for x in plan.stages]==['VERIFY_EXTERNAL','VERIFY_EXTERNAL','RUN']
    partial=sample.run(fake,selected_stage_ids=['step_5'],auto_dependencies=False)
    assert 'chưa phải FINAL' in partial
    assert sample.store.find_artifact('CHAR_MASTER')
    assert sample.store.find_artifact('BG_MASTER')
    assert len([x for x in fake.calls if 'PHASE=character_index' in x[0]])==0
    assert len([x for x in fake.calls if 'PHASE=background_index' in x[0]])==0
    calls=len(fake.calls)
    sample.run(fake,selected_stage_ids=['step_5'],auto_dependencies=False)
    assert len(fake.calls)==calls, 'Imported content must be QA cached after successful verification'

def test_bad_external_document_never_becomes_pass(sample,tmp_path):
    char=tmp_path/'bad.txt';char.write_text('CHAR_999|bịa nhân vật',encoding='utf8')
    bg=tmp_path/'BG_MASTER.txt';bg.write_text(json.dumps({'backgrounds':[{'id':'BG_01','description':'Xưởng có bàn gỗ','evidence_line_ids':['001']}]},ensure_ascii=False),encoding='utf8')
    sample.import_stage_output_file('CHAR_MASTER',char)
    sample.import_stage_output_file('BG_MASTER',bg)
    provider=MockProvider()
    assert sample.preflight(provider,selected_stage_ids=['step_5'],auto_dependencies=False).ready
    with pytest.raises(RunBlocked,match='chưa đạt QA cấu trúc'):
        sample.run(provider,selected_stage_ids=['step_5'],auto_dependencies=False)
    assert sample.store.find_artifact('CHAR_MASTER') is None
    assert not provider.calls

def test_reject_unknown_external_artifact(sample,tmp_path):
    f=tmp_path/'x.txt';f.write_text('a',encoding='utf8')
    with pytest.raises(ContractError,match='không phải đầu ra'):
        sample.import_stage_output_file('NOT_A_STAGE_OUTPUT',f)
