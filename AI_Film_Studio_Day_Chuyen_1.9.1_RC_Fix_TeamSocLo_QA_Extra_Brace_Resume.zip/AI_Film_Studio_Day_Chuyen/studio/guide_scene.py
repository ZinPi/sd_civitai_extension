"""Resumable scene-window narrative production with sourced QA at each scope.

Unlike a one-call output this workflow partitions *all* original source text,
keeps exact byte-compatible source spans, compares every span with its output,
and audits cross-span continuity.  These are bounded work windows, not an
assertion that automated paragraph boundaries equal literary scenes.
"""
from __future__ import annotations
import json
import os
import re
import time
from pathlib import Path
from .contract import ContractError
from .guide_flow import sha, atomic_json, parse_review, MAX_ALL_CONTEXT

SCENE_ENGINE_VERSION = 2
MAX_SEGMENT_CHARS = 6500
MIN_SEGMENT_CHARS = 1000
# QA semantics only; keep production contract version so previously PASS/LOCK
# windows 1..N remain recoverable after this patch.
WINDOW_QA_SCOPE_VERSION = 4
MAX_TOTAL_WINDOW_REPAIRS = 4  # Across restarts, including legacy repairs.


def source_windows(text: str, limit: int = MAX_SEGMENT_CHARS) -> list[tuple[int,int,str]]:
    """Produce an exact, non-overlapping, lossless partition using paragraph/sentence bounds."""
    if limit < 600:
        raise ContractError('Giới hạn cửa sổ nguồn quá nhỏ.')
    if not text.strip():raise ContractError('Nguồn tác phẩm rỗng.')
    boundaries=[0]
    for m in re.finditer(r'\n\s*\n|(?<=[.!?…。！？])\s+(?=[^\s])', text):
        if m.end()>boundaries[-1]:boundaries.append(m.end())
    if boundaries[-1]!=len(text):boundaries.append(len(text))
    raw=[]
    for i in range(len(boundaries)-1):
        start,end=boundaries[i],boundaries[i+1]
        # Extremely long single paragraph/sentence: cut into bounded work
        # windows while preserving all characters. Always supply overlap.
        while end-start>limit:
            desired=start+limit
            s=text.rfind(' ',start+min(200,limit//3),desired)
            cut=s+1 if s>start else desired
            raw.append((start,cut));start=cut
        if start<end:raw.append((start,end))
    pieces=[];begin=0;end=0
    for start,stop in raw:
        if end>begin and (stop-begin>limit):
            pieces.append((begin,end,text[begin:end]));begin=end
        if begin==end:begin=start
        end=stop
    if end>begin:pieces.append((begin,end,text[begin:end]))
    assert ''.join(part for _,_,part in pieces)==text
    assert all(len(part)<=limit for _,_,part in pieces)
    return pieces


def _one_text_file(step:dict)->str:
    """Resolve declared name from the *current* instruction; never invent a B1 lock."""
    text=step['instructions']
    names=re.findall(r'(?i)(?:OUTPUT\s+CHÍNH\s+THỨC|OUTPUT\s+OFFICIAL|THÀNH\s+PHẨM\s+CHÍNH|Đầu\s+ra\s+sau\s+FINAL\s+PASS/LOCK)\s*:\s*\n?\s*[`“\"]?([A-Z][A-Z0-9_]{3,80})', text)
    if len(set(names))==1:return names[0]+'.txt'
    if names:raise ContractError('Hướng dẫn có nhiều tên OUTPUT CHÍNH THỨC không đồng nhất.')
    outputs=step.get('output_references',[])
    if len(outputs)==1:return outputs[0]
    if outputs:raise ContractError('Bước có nhiều đầu ra, chưa thể chia scene an toàn bằng engine một đầu ra.')
    return step['id']+'_OUTPUT.txt'


def _qa(result: str, stage: str, *, invalid_path: Path | None = None,
        evidence: dict | None = None) -> dict:
    """Parse QA without another paid request; keep malformed evidence locally.

    A malformed model response is a FORMAT failure, not grounds for story
    REPAIR. Save the unmodified reviewer reply in the local project (no keys,
    source prompts or credentials) so the user can diagnose the next incident.
    """
    try:
        return parse_review(result)
    except ContractError as exc:
        if invalid_path is not None:
            atomic_json(invalid_path,{
                'stage':stage,'error':str(exc), 'response_sha256':sha(result),
                'response_length':len(result),'response_text':result[:100_000],
                'response_truncated':len(result)>100_000,
                'evidence':evidence or {},
                'explanation':'QA response cannot be trusted. Original candidate is preserved. '
                              'No story repair or automatic billed retry is authorized.'})
            raise ContractError(stage+': phản hồi QA không đọc được an toàn; chưa PASS. '
                                'Đã lưu nguyên phản hồi tại '+str(invalid_path)+'. '
                                'Không REPAIR truyện vì lỗi định dạng; không tự gọi API lại. '
                                'Chi tiết: '+str(exc)) from None
        raise


def _only_project_level_uncertainty(issues: list) -> bool:
    """Identify only pure global-evidence objections, never local defects.

    A claim about excessive literal detail is a local QA finding even when it
    also mentions the project-wide 40% target. Such issues MUST remain FAIL.
    """
    if not issues or any(not isinstance(item,str) for item in issues):
        return False
    for item in issues:
        line=item.casefold()
        if not any(flag in line for flag in ('40%', 'toàn tác phẩm', 'toàn bộ tác phẩm', 'toàn truyện', 'full-scope')):
            return False
        if not any(flag in line for flag in ('chưa đủ căn cứ', 'chưa thể đánh giá',
                                             'không đủ bằng chứng', 'thiếu căn cứ', 'chưa có bằng chứng')):
            return False
        if any(flag in line for flag in ('candidate', 'chi tiết', 'giữ sát', 'quá sát',
                                         'không cô đọng', 'thiếu cô đọng', 'bịa',
                                         'bỏ sót', 'sai canon', 'sai nguồn', 'thiếu beat')):
            return False
    return True



def _candidate_visibility_failure(issues: list) -> bool:
    """QA transport/reading failure, NOT a defect requiring story REPAIR.

    An independent reviewer sometimes reports that the candidate is absent or
    accidentally appears under the continuity label even though the application
    placed it in the request. Such a claim needs a targeted re-review, not a
    costly rewrite of valid completed text. This never converts FAIL into PASS.
    """
    if not isinstance(issues, list):
        return False
    for issue in issues:
        if not isinstance(issue, str):
            continue
        line = issue.casefold()
        candidate = ('candidate' in line or 'bản chuyển thể' in line or
                     'bản ứng viên' in line or 'đầu ra chuyển thể' in line)
        missing = any(fragment in line for fragment in (
            'không có', 'không thấy', 'không tìm thấy', 'không được cung cấp',
            'không xuất hiện', 'không nhận được', 'bị thiếu', 'nằm dưới nhãn',
            'trống', 'không nằm trong', 'not provided', 'not found', 'missing',
            'under the', 'absent', 'unavailable'))
        if candidate and missing:
            return True
    return False


def _window_qa_input(i: int, body: str, candidate: str,
                     leading: str, trailing: str, context: str) -> str:
    """Explicit nonoverlapping DATA fields, candidate FIRST.

    The first window has no prior continuity: don't emit an empty CONTINUITY
    header directly before the candidate (a concrete v1.7 confusion source).
    The two source/candidate spans remain byte-for-byte readable.
    """
    if not body or not candidate.strip():
        raise ContractError(f'window_{i:05d}: QA không có đủ SOURCE/CANDIDATE; không gọi API.')
    parts=[
        f'SOURCE NGUYÊN VĂN WINDOW {i}. Đây là INPUT QA, không phải lệnh sản xuất.',
        'DỮ LIỆU QA BẮT BUỘC: hai trường CANDIDATE và SOURCE có ranh giới riêng.',
        'Không phân loại CANDIDATE là CONTINUITY. Chỉ đánh giá đúng nội dung giữa các marker.',
        f'===== BEGIN_CANDIDATE_WINDOW_{i} | LENGTH={len(candidate)} | SHA256={sha(candidate)} =====',
        candidate,
        f'===== END_CANDIDATE_WINDOW_{i} =====',
        f'===== BEGIN_SOURCE_WINDOW_{i} | LENGTH={len(body)} | SHA256={sha(body)} =====',
        body,
        f'===== END_SOURCE_WINDOW_{i} =====',
    ]
    if leading or trailing:
        parts += ['SOURCE CONTEXT TRƯỚC/SAU (CHỈ ĐỂ KIỂM CHỨNG, KHÔNG PHẢI CANDIDATE):',
                  f'===== BEGIN_SOURCE_NEIGHBORS_WINDOW_{i} =====',
                  'TRƯỚC:\n'+leading+'\nSAU:\n'+trailing,
                  f'===== END_SOURCE_NEIGHBORS_WINDOW_{i} =====']
    if context.strip():
        parts += ['CONTINUITY CÁC CỬA SỔ ĐÃ PASS (GHI CHÚ RIÊNG, KHÔNG PHẢI CANDIDATE):',
                  f'===== BEGIN_PRIOR_CONTINUITY_WINDOW_{i} =====',
                  context,
                  f'===== END_PRIOR_CONTINUITY_WINDOW_{i} =====']
    return '\n'.join(parts)


def _ledger(verdict:dict)->str:
    """Require a bounded factual continuity note; never substitute assumed facts."""
    value=verdict.get('continuity')
    if not isinstance(value,str) or not value.strip() or len(value)>2500:
        raise ContractError('QA cửa sổ chưa trả continuity có giới hạn; chưa PASS.')
    return value.strip()


def validate_full_qa_gates(instructions: str, verdict: dict) -> None:
    """Hard requirements in a source guide cannot be reduced to model PASS.

    Explicit H/Q/mandatory-user gate requirements need their own checked fields.
    An absent field FAILS, rather than silently accepting a generic verdict.
    """
    if verdict.get('verdict')!='PASS':return
    source=instructions.casefold()
    if ('h_error' not in source or 'q_total' not in source):return
    if type(verdict.get('H_ERROR')) is not int or verdict['H_ERROR']!=0:
        raise ContractError('FULL QA thiếu H_ERROR = 0; không LOCK.')
    score=verdict.get('Q_TOTAL')
    minimum_match=re.search(r'q_total\s*(?:>=|≥|\u2265)\s*(\d+(?:[.,]\d+)?)',source)
    threshold=float(minimum_match.group(1).replace(',','.')) if minimum_match else 90.0
    if type(score) not in (float,int) or score<threshold or score>100:
        raise ContractError(f'FULL QA Q_TOTAL chưa đạt {threshold:g}/100; không LOCK.')
    checks=['MANDATORY_USER_PASS_GATE','FULL_SOURCE_COMPARISON','SCENE_QA','FULL_SCOPE_QA']
    if 'textual orality' in source:checks.append('TEXTUAL_ORALITY_SIMULATION')
    if 'ug-01' in source:checks.append('UG_QA')
    for field in checks:
        if verdict.get(field)!='PASS':
            raise ContractError('FULL QA thiếu hoặc chưa PASS '+field+'; không LOCK.')


def run_scene_windows(flow,provider,step,rules,inputs,decision_text,resolution,emit,
                      max_tokens,repair_attempts=2,user_decisions=None,conflict_choices=None):
    """A full-source, resumable, scene-window workflow for long narrative steps.

    Each source character is examined in a source-window QA. Cross-window QA
    checks overlapping pairs, and a final continuity QA checks ALL scene notes.
    If that last review cannot fit, STOP with checkpoints, never fake PASS.
    """
    if max_tokens<1500:
        raise ContractError('Dừng TRƯỚC khi gọi API: output token/lượt quá thấp cho chuyển thể dài theo cửa sổ và QA; cần từ 1500 token.')
    if len(inputs)!=1:
        raise ContractError('Bước chuyển thể dài yêu cầu một nguồn tác phẩm duy nhất; không đoán thứ tự ghép nhiều tài liệu.')
    source_name,source=next(iter(inputs.items()))
    if not source.strip():raise ContractError('Tác phẩm rỗng.')
    filename=_one_text_file(step)
    # Gateway requests have a stricter practical response-time envelope than
    # direct model providers. Smaller source windows and bounded OUTPUT tokens
    # keep each generation reasonably short, without omitting any B1 rules.
    # No automatic retry follows a timeout: it may already be billed.
    gateway = str(getattr(provider,'provider_id','')).casefold() in ('teamsoclo','tuansu')
    if gateway:
        limit=min(2800,max(MIN_SEGMENT_CHARS, max_tokens))
    else:
        limit=min(MAX_SEGMENT_CHARS,max(MIN_SEGMENT_CHARS,max_tokens*2))
    segments=source_windows(source,limit)
    rule_text='\n\n'.join('QUY TẮC '+n+' (TOÀN BỘ)\n'+t for n,t in rules.items())
    common=('THỰC HIỆN CHỈ '+step['id']+', theo quy tắc nguồn nguyên văn. '
            'KHÔNG tạo dữ liệu ngoài tác phẩm, KHÔNG bỏ cảnh/beat. '
            'Các phần là cửa sổ xử lý liên tiếp, có thể nằm trong cùng một scene; '
            'không được tự cho rằng ranh giới cửa sổ là ranh giới scene. '
            'Giữ nhân vật, lore, tiếng nói, POV, trạng thái, quan hệ, setup/payoff. '
            'Không lặp phần trước và không viết trước phần sau. '\
            '\nHƯỚNG DẪN BƯỚC:\n'+step['instructions']+'\n\n'+rule_text+
            '\nQUYẾT ĐỊNH CỦA NGƯỜI DÙNG:\n'+decision_text+'\n'+resolution)
    if len(common)+max(len(t) for _,_,t in segments)+14000>MAX_ALL_CONTEXT:
        raise ContractError('Quy tắc + cửa sổ nguồn vượt context; chưa được phép lược bớt quy tắc.')
    import hashlib
    execution={'engine':'scene_windows','version':SCENE_ENGINE_VERSION,
               'provider_id':str(getattr(provider,'provider_id','unknown')),
               'model':str(getattr(provider,'model','unknown')),
               'source':sha(source),'source_name':source_name,'rules':{n:sha(t) for n,t in rules.items()},
               'step_instructions':sha(step['instructions']), 'decisions':user_decisions or {},
               'conflicts':conflict_choices or {},'max_output_tokens':max_tokens,
               'source_windows':[(s,e,sha(t)) for s,e,t in segments],
               'gateway_bounded_output':gateway}
    digest=sha(json.dumps(execution,ensure_ascii=False,sort_keys=True))
    directory=flow.folder/'candidates'/step['id']/'scene_windows'/digest[:32]
    directory.mkdir(parents=True,exist_ok=True)
    atomic_json(directory/'contract.json',execution)
    # Estimate only a new step. On resumed projects many calls may already
    # have completed; counting them again would falsely block a zero-API
    # recovery. The provider's persistent budget enforces each new call.
    if not list(directory.glob('window_*.json')):
        minimum_calls=3*len(segments)+1  # generation, local QA, boundaries, final
        if hasattr(provider,'max_calls') and hasattr(provider,'total_calls'):
            available=provider.max_calls-provider.total_calls
            if available<minimum_calls:
                raise ContractError(f'Dừng TRƯỚC khi gọi API: bước này cần ít nhất {minimum_calls} lượt '
                                    f'(chưa kể QA đối chiếu nhóm và REPAIR), hạn mức dự án chỉ còn {available}. '
                                    'Tăng hạn mức API toàn dự án nếu chấp nhận chi phí rồi chạy lại.')
    chunks=[];notes=[]
    emit(step['id']+f': nguồn đã chia thành {len(segments)} cửa sổ nối tiếp, bảo toàn 100% ký tự gốc. Chưa LOCK.')
    for i,(start,end,body) in enumerate(segments,1):
        label=f'window_{i:05d}'
        saved=directory/(label+'.txt'); receipt=directory/(label+'.json')
        if saved.exists() and receipt.exists():
            doc=json.loads(receipt.read_text(encoding='utf8'))
            produced=saved.read_text(encoding='utf8')
            if (doc.get('contract')!=digest or doc.get('source_sha')!=sha(body) or
                doc.get('output_sha')!=sha(produced) or doc.get('qa')!='PASS' or
                not isinstance(doc.get('continuity'),str) or not doc['continuity']):
                raise ContractError(label+': checkpoint bị đổi hoặc không khớp hợp đồng; không dùng lại.')
            chunks.append(produced);notes.append(doc['continuity'])
            emit(step['id']+f': phục hồi QA PASS cửa sổ {i}/{len(segments)} từ checkpoint.')
            continue
        context='\n'.join(f'WINDOW_{j:05d}: {n}' for j,n in enumerate(notes[max(0,len(notes)-20):],max(1,len(notes)-19)))
        if len(context)>15000:
            raise ContractError('Continuity trước đó quá dài; không được cắt ngầm để sinh phần mới.')
        leading=source[max(0,start-450):start]
        trailing=source[end:min(len(source),end+450)]
        prompt=(f'TÁC PHẨM {source_name}; PHẦN {i}/{len(segments)}, SOURCE_OFFSETS={start}:{end}. '
                'HÃY CHUYỂN THỂ NGUYÊN NỘI DUNG PHẦN HIỆN TẠI THEO TOÀN BỘ QUY TẮC, '
                'KHÔNG CHUYỂN THỂ NGỮ CẢNH LÂN CẬN. '
                'Chỉ trả VĂN BẢN TÁC PHẨM CHUYỂN THỂ, không JSON/header/fence.\n'
                'NGỮ CẢNH TRƯỚC (KHÔNG TẠO OUTPUT):\n'+leading+'\n'
                'NGỮ CẢNH SAU (KHÔNG TẠO OUTPUT):\n'+trailing+'\n'
                'CONTINUITY CÁC CỬA SỔ TRƯỚC:\n'+context+'\n'
                'SOURCE PHẢI XỬ LÝ ĐÚNG PHẠM VI:\n'+body)
        if len(common)+len(prompt)>MAX_ALL_CONTEXT:
            raise ContractError(label+': vượt context; chưa gửi API.')
        # Completed generations are checkpointed BEFORE QA, with a source and
        # contract fingerprint. A failed QA network request can be retried
        # later without regenerating an already completed (potentially billed)
        # candidate. A partial stream never generates such a receipt.
        candidate = directory / (label + '_candidate.txt')
        candidate_receipt = directory / (label + '_candidate.json')
        window_output_cap = (min(max_tokens,max(2500,int(len(body)*1.4)))
                             if gateway else max_tokens)
        if candidate.exists() and candidate_receipt.exists():
            saved_candidate = candidate.read_text(encoding='utf8')
            receipt_data = json.loads(candidate_receipt.read_text(encoding='utf8'))
            if (receipt_data.get('contract') != digest or
                receipt_data.get('source_sha') != sha(body) or
                receipt_data.get('candidate_sha') != sha(saved_candidate)):
                raise ContractError(label+': candidate checkpoint không khớp; chưa QA và không dùng lại.')
            produced=saved_candidate.strip()
            emit(step['id']+f': tiếp tục QA cửa sổ {i}/{len(segments)} từ candidate đã hoàn tất.')
        elif candidate.exists() or candidate_receipt.exists():
            raise ContractError(label+': candidate và biên nhận không đồng bộ; không tự dùng lại.')
        else:
            emit(step['id']+f': chuyển thể cửa sổ {i}/{len(segments)} ({start}–{end}), '
                 f'output cap {window_output_cap} token, chưa PASS.')
            produced=provider.generate(system=common,user=prompt,max_output_tokens=window_output_cap).text.strip()
            if produced and not produced.startswith('@@FILE:') and len(produced)<=max_tokens*6:
                partial=candidate.with_suffix('.tmp')
                partial.write_text(produced, encoding='utf8')
                os.replace(partial,candidate)
                atomic_json(candidate_receipt,{'contract':digest,'source_sha':sha(body),
                                               'candidate_sha':sha(produced),'qa':'PENDING'})
        if not produced or produced.startswith('@@FILE:') or len(produced)>max_tokens*6:
            raise ContractError(label+': output trống, sai định dạng hoặc không hợp lý; chưa QA.')
        # A project-level 40% target cannot be proved or disproved by a single
        # processing window. The model must still check local functional
        # compression: literal retention of dispensable beats is a genuine
        # window defect, not a reason to waive this QA gate.
        qa_system=('QA ĐỘC LẬP CHO SOURCE WINDOW. CHỈ TRONG PHẠM VI CỬA SỔ HIỆN TẠI. '
                   'So sánh ĐẦY ĐỦ source đúng offset với candidate; kiểm tra '
                   'canon, speaker, scene beats và chức năng, source coverage, '
                   'omissions, invented details, language, continuity và các '
                   'HARD/QUALITY QA CÓ THỂ KIỂM CHỨNG TẠI CỬA SỔ NÀY. '
                   'QUAN TRỌNG: Nếu MODE B đặt 40% ở cấp TOÀN TÁC PHẨM thì '
                   'KHÔNG yêu cầu đạt tỷ lệ 40% cho cửa sổ, KHÔNG FAIL chỉ vì '
                   'chưa thể chứng minh tỷ lệ toàn truyện khi mới đọc một cửa sổ. '
                   'Chuyển những điều kiện chỉ có thể kiểm chứng ở cấp toàn tác phẩm '
                   '(40% toàn truyện, motif/setup-payoff xuyên truyện, full-scope QA) '
                   'sang bước QA TỔNG THỂ, không cho PASS/FAIL toàn tác phẩm ở đây. '
                   'TUY NHIÊN, nếu candidate giữ gần như toàn bộ chi tiết không cần '
                   'thiết, thiếu cô đọng theo chức năng hoặc giống bản kể lại sát '
                   'nguồn, đây là LỖI CỤC BỘ thật: phải FAIL và nêu rõ ví dụ '
                   'source/candidate cùng nguyên nhân theo quy tắc; không bỏ qua. '
                   'Không tự đánh PASS; chỉ PASS các điều kiện có thể xác nhận '
                   'trên cửa sổ này. Trả JSON: '
                   '{"verdict":"PASS"|"FAIL","issues":["..."],'
                   '"continuity":"ghi chú canon ngắn có căn cứ"}. '
                   'Ghi issues ngắn gọn có căn cứ và continuity không quá 1200 ký tự. '
                   'Không rõ vấn đề CỤC BỘ nào thì FAIL, không suy đoán.\n'+common)
        def review(text):
            message=_window_qa_input(i,body,text,leading,trailing,context)
            if len(qa_system)+len(message)>MAX_ALL_CONTEXT:
                raise ContractError(label+': QA vượt context; giữ ứng viên, chưa PASS.')
            invalid_path=directory/(label+'_qa_invalid.json')
            evidence={'contract':digest,'source_sha':sha(body),'candidate_sha':sha(text),
                      'scope_version':WINDOW_QA_SCOPE_VERSION}
            # A previous RC saved the complete reviewer reply but could not
            # parse a known single-brace grammar error. On upgrade, recover
            # that *same billed response* first, after verifying its byte
            # length, SHA and candidate/contract/scope. Never use stale or
            # truncated evidence as a QA verdict. No extra provider call.
            result=None
            if invalid_path.exists():
                try:
                    old=json.loads(invalid_path.read_text(encoding='utf8'))
                    prior=old.get('response_text')
                    if (old.get('stage')==label and old.get('evidence')==evidence and
                        old.get('response_truncated') is False and
                        isinstance(prior,str) and old.get('response_length')==len(prior) and
                        old.get('response_sha256')==sha(prior)):
                        result=parse_review(prior)
                        emit(step['id']+f': cửa sổ {i} đọc lại QA đã lưu, '
                             'không gọi thêm API. Giữ nguyên verdict '+result['verdict']+'.')
                except (ValueError,TypeError,KeyError,ContractError,OSError):
                    # A prior diagnostic from a different candidate/scope or
                    # irrecoverable JSON does NOT authorize a verdict.
                    result=None
            if result is None:
                result=_qa(provider.generate(system=qa_system,user=message,max_output_tokens=2500).text,
                           label,invalid_path=invalid_path,evidence=evidence)
            if invalid_path.exists():invalid_path.unlink()
            if result['verdict']=='FAIL' and _candidate_visibility_failure(result['issues']):
                emit(step['id']+f': cửa sổ {i} QA nhận nhầm/không thấy CANDIDATE đã gửi; '
                     'chỉ rà lại dữ liệu một lần, KHÔNG REPAIR văn bản.')
                retry=_qa(provider.generate(
                    system=qa_system+'\nKIỂM TRA LẠI NHÃN DỮ LIỆU: CANDIDATE NẰM TRONG '
                           'BEGIN_CANDIDATE_WINDOW/END_CANDIDATE_WINDOW của INPUT. '
                           'SOURCE có marker SOURCE riêng. CONTINUITY chỉ là ghi chú sau cùng '
                           'và có thể KHÔNG CÓ ở cửa sổ 1. '
                           'Trước khi báo candidate thiếu, đọc chính xác hai cặp marker. '
                           'Không PASS chỉ vì thấy marker: vẫn QA nội dung theo quy tắc.',
                    user=message,max_output_tokens=2500).text,label,
                    invalid_path=invalid_path,evidence=evidence)
                if retry['verdict']=='FAIL' and _candidate_visibility_failure(retry['issues']):
                    raise ContractError(label+': model QA liên tục báo thiếu/nhầm CANDIDATE '
                                        'dù ứng viên đã lưu và yêu cầu QA có đủ marker; '
                                        'KHÔNG tự REPAIR, chưa PASS/LOCK. '
                                        'Kiểm tra model/endpoint QA hoặc đổi model QA; '
                                        'giữ nguyên checkpoint và bản ứng viên.')
                if invalid_path.exists():invalid_path.unlink()
                return retry
            if result['verdict']=='FAIL' and _only_project_level_uncertainty(result['issues']):
                # The reviewer missed the scope rule. Re-audit the SAME SOURCE
                # and candidate once, without rewriting or silently passing it.
                # If the model still refuses to assess LOCAL correctness, stop
                # with a scope-specific error instead of buying repair loops.
                emit(step['id']+f': cửa sổ {i} QA chỉ nêu thiếu chứng cứ toàn tác phẩm; rà lại phạm vi cục bộ một lần.')
                retry=_qa(provider.generate(
                    system=qa_system+'\nRÀ LẠI PHẠM VI: QA chỉ xác nhận nguồn và candidate của CỬA SỔ. '
                           'Mục tiêu 40% TOÀN TÁC PHẨM chỉ được đánh giá trong FULL QA. '
                           'Nếu thấy lỗi cô đọng theo CHỨC NĂNG ngay ở cửa sổ, FAIL kèm căn cứ cụ thể; '
                           'nếu không có lỗi cục bộ, PASS với continuity. '
                           'KHÔNG đánh PASS chỉ vì bỏ qua kiểm tra cục bộ.',
                    user=message,max_output_tokens=2500).text,label,
                    invalid_path=invalid_path,evidence=evidence)
                if retry['verdict']=='FAIL' and _only_project_level_uncertainty(retry['issues']):
                    raise ContractError(label+': model QA tiếp tục yêu cầu bằng chứng 40% toàn tác phẩm '
                                        'ở bước cục bộ; chưa PASS, không tự sinh lại/không tự LOCK.')
                if invalid_path.exists():invalid_path.unlink()
                return retry
            return result

        # A previous release saved repair_1/repair_2 text, but retried from
        # the ORIGINAL candidate. Reuse the newest completed revision instead;
        # old unreceipted repairs are ALWAYS re-QA'd, never trusted as PASS.
        qa_path=directory/(label+'_qa.json')
        repair_files=[]
        for path in directory.glob(label+'_repair_*.txt'):
            m=re.fullmatch(re.escape(label)+r'_repair_(\d+)\.txt',path.name)
            if m:repair_files.append((int(m.group(1)),path))
        repair_files.sort()
        if repair_files:
            if [number for number,_ in repair_files]!=list(range(1,repair_files[-1][0]+1)):
                raise ContractError(label+': chuỗi bản sửa bị thiếu; không khôi phục mù.')
            revision,path=repair_files[-1]
            revision_text=path.read_text(encoding='utf8').rstrip('\n')
            if not revision_text.strip():
                raise ContractError(label+': bản sửa gần nhất rỗng.')
            revision_receipt=directory/(label+f'_repair_{revision}.json')
            if revision_receipt.exists():
                record=json.loads(revision_receipt.read_text(encoding='utf8'))
                if (record.get('contract')!=digest or record.get('source_sha')!=sha(body) or
                    record.get('candidate_sha')!=sha(revision_text)):
                    raise ContractError(label+': bản sửa checkpoint không khớp SHA-256; chưa QA.')
            else:
                # Legacy 1.6 repairs had no per-revision receipts. Only accept
                # them as UNVERIFIED candidates if their old final QA exists.
                # Never silently accept a missing receipt for new 1.7 repairs.
                old_doc=json.loads(qa_path.read_text(encoding='utf8')) if qa_path.exists() else {}
                if (old_doc.get('qa_scope_version') is not None or
                    old_doc.get('verdict') not in ('FAIL','PASS')):
                    raise ContractError(label+': bản sửa thiếu biên nhận; không tự dùng lại.')
                emit(step['id']+f': khôi phục bản sửa cũ lần {revision} để QA LẠI; chưa PASS.')
            produced=revision_text
        else:
            revision=0

        def checked_review(text,revision_no):
            # A fully persisted FAIL can be reused to continue REPAIR without
            # wasting a second QA call. PASS requires the same candidate hash.
            if qa_path.exists():
                record=json.loads(qa_path.read_text(encoding='utf8'))
                if record.get('qa_scope_version')==WINDOW_QA_SCOPE_VERSION:
                    if (record.get('contract')!=digest or record.get('source_sha')!=sha(body) or
                        record.get('candidate_sha')!=sha(text) or
                        record.get('revision')!=revision_no):
                        raise ContractError(label+': QA checkpoint không khớp bản sửa mới nhất.')
                    result=parse_review(json.dumps(record,ensure_ascii=False))
                    # With no requested repair, an explicit user retry may
                    # re-evaluate an unedited original after a failed QA.
                    # Completed repaired revisions keep their QA verdict and
                    # are NOT regenerated or re-reviewed needlessly.
                    if not (result['verdict']=='FAIL' and revision_no==0 and int(repair_attempts)==0):
                        emit(step['id']+f': khôi phục QA {result["verdict"]} đã lưu cho bản sửa {revision_no}.')
                        return result
            result=review(text)
            atomic_json(qa_path,{'qa_scope_version':WINDOW_QA_SCOPE_VERSION,
                                 'contract':digest,'source_sha':sha(body),
                                 'candidate_sha':sha(text),'revision':revision_no,**result})
            return result

        verdict=checked_review(produced,revision)
        # At most repair_attempts NEW revisions per run, and never repeat an
        # already persisted revision. A repaired candidate is checkpointed
        # BEFORE its QA request, so a QA timeout will not regenerate it.
        new_repairs=0
        while (verdict['verdict']!='PASS' and
               revision<MAX_TOTAL_WINDOW_REPAIRS and
               new_repairs<max(0,min(int(repair_attempts),3))):
            revision+=1;new_repairs+=1
            emit(step['id']+f': cửa sổ {i} QA FAIL, REPAIR/RE-QA bản sửa {revision}.')
            repair_prompt=prompt+'\nCANDIDATE CẦN SỬA (BẢN MỚI NHẤT):\n'+produced+'\nLỖI CỤC BỘ CẦN SỬA:\n'+json.dumps(verdict['issues'],ensure_ascii=False)
            if len(common)+len(repair_prompt)>MAX_ALL_CONTEXT:
                raise ContractError(label+': REPAIR vượt context; chưa LOCK.')
            produced=provider.generate(system=common+'\nCHỈ SỬA ĐÚNG LỖI QA CỤC BỘ; KHÔNG ÉP % TOÀN TÁC PHẨM VÀO MỘT CỬA SỔ.',
                                       user=repair_prompt,max_output_tokens=window_output_cap).text.strip()
            if not produced or produced.startswith('@@FILE:') or len(produced)>max_tokens*6:
                raise ContractError(label+': bản sửa thiếu hoặc sai định dạng; không lưu.')
            revision_path=directory/(label+f'_repair_{revision}.txt')
            if revision_path.exists() or (directory/(label+f'_repair_{revision}.json')).exists():
                raise ContractError(label+': bản sửa đã tồn tại; không ghi đè.')
            partial=revision_path.with_suffix('.tmp')
            partial.write_text(produced+'\n',encoding='utf8')
            os.replace(partial,revision_path)
            atomic_json(directory/(label+f'_repair_{revision}.json'),
                        {'contract':digest,'source_sha':sha(body),'candidate_sha':sha(produced)})
            # The older QA receipt is for the preceding candidate. Remove it
            # only after saving the new candidate + receipt successfully.
            if qa_path.exists():qa_path.unlink()
            verdict=checked_review(produced,revision)
        if verdict['verdict']!='PASS':
            raise ContractError(label+': QA chưa PASS ở cửa sổ sau bản sửa '+str(revision)+
                                '; giữ nguyên candidate mới nhất và các cửa sổ trước. '
                                'Không tự LOCK: '+str(verdict['issues'])[:350])
        note=_ledger(verdict)
        produced=produced+'\n'
        saved.write_text(produced,encoding='utf8')
        atomic_json(receipt,{'qa':'PASS','contract':digest,'source_sha':sha(body),
                             'output_sha':sha(produced),'continuity':note,
                             'source_start':start,'source_end':end})
        chunks.append(produced);notes.append(note)
        emit(step['id']+f': QA PASS, checkpoint cửa sổ {i}/{len(segments)}.')
    # Cross-window QA: original source AND adjacent outputs. Each window
    # appears in a local QA and at least one pairwise review (where possible).
    for i in range(1,len(segments)):
        cross_path=directory/f'boundary_{i:05d}.json'
        fingerprint=sha(json.dumps([digest,sha(chunks[i-1]),sha(chunks[i]),notes[i-1],notes[i]]))
        if cross_path.exists():
            doc=json.loads(cross_path.read_text(encoding='utf8'))
            if doc.get('fingerprint')==fingerprint and doc.get('verdict')=='PASS':continue
            if doc.get('fingerprint')!=fingerprint:
                raise ContractError('Checkpoint QA ranh giới đã thay đổi; không tự ghi đè.')
            # A prior QA FAIL may be re-evaluated; it never authorizes LOCK.
        cross_user=('KIỂM TRA LIÊN KẾT SCENE/CỬA SỔ LIỀN NHAU, bao gồm tình huống một scene bị chia giữa hai cửa sổ. '
                    'Có thiếu, lặp, sai continuity, lỗi setup/reveal/timeline không?\n'
                    'SOURCE TRƯỚC:\n'+segments[i-1][2]+'\nSOURCE SAU:\n'+segments[i][2]+
                    '\nOUTPUT TRƯỚC:\n'+chunks[i-1]+'\nOUTPUT SAU:\n'+chunks[i])
        cross_system=('QA RANH GIỚI ĐỘC LẬP. Chỉ trả JSON {"verdict":"PASS"|"FAIL","issues":["..."]}. '
                      'Không PASS khi không đủ căn cứ.\n'+common)
        if len(cross_system)+len(cross_user)>MAX_ALL_CONTEXT:
            raise ContractError('QA ranh giới vượt context, đã giữ checkpoint, chưa LOCK.')
        verdict=parse_review(provider.generate(system=cross_system,user=cross_user,max_output_tokens=2500).text)
        atomic_json(cross_path,{'fingerprint':fingerprint,**verdict})
        if verdict['verdict']!='PASS':
            raise ContractError(f'QA liên kết cửa sổ {i}/{i+1} FAIL; chưa LOCK: '+str(verdict['issues'])[:350])
    # Full-scope verification must receive the ACTUAL source and output, not
    # just continuity summaries. When both fit, compare the complete texts in
    # one request. For longer works, audit every exact source/output window in
    # bounded groups and then check cross-work continuity over ALL group
    # findings. Never claim that a note-only audit proves source coverage.
    ledger='\n'.join(f'WINDOW_{i:05d}: {n}' for i,n in enumerate(notes,1))
    full_system=('QA TỔNG THỂ toàn tác phẩm. Kiểm tra thật với văn bản nguồn và '
                 'văn bản thành phẩm được cung cấp, mức độ bao phủ từng đoạn, '
                 'canon, nhân vật, tên, thuật ngữ, thiết lập/payoff, reveal, '
                 'timeline, sự liên kết xuyên đoạn, MODE B 40% ở cấp TOÀN TÁC PHẨM '
                 '(theo chức năng, không ép phần trăm ký tự/từ/câu), và các QA theo quy tắc. '
                 'Nếu thiếu căn cứ cho bất kỳ gate nào, FAIL; không tự báo PASS. '
                 'Trả JSON {"verdict":"PASS"|"FAIL","issues":["..."]}.\n'+common)
    if 'h_error' in step['instructions'].casefold() and 'q_total' in step['instructions'].casefold():
        full_system+=('\nVỚI VERDICT PASS: phải có H_ERROR số nguyên bằng 0, '
                      'Q_TOTAL số chính xác, MANDATORY_USER_PASS_GATE, '
                      'FULL_SOURCE_COMPARISON, SCENE_QA, FULL_SCOPE_QA, '
                      'TEXTUAL_ORALITY_SIMULATION, UG_QA được kiểm tra thực tế. '
                      'Các giá trị gate không được tự suy đoán.')
    combined=''.join(chunks)
    if not combined.strip():raise ContractError('Thành phẩm ghép rỗng.')
    all_text_user=('TOÀN BỘ NGUỒN GỐC (NGUYÊN VĂN):\n'+source+
                   '\nTOÀN BỘ THÀNH PHẨM ĐÃ GHÉP (NGUYÊN VĂN):\n'+combined+
                   '\nHỒ SƠ CONTINUITY CÁC CỬA SỔ:\n'+ledger)
    audit_paths=[]
    if len(full_system)+len(all_text_user)<=MAX_ALL_CONTEXT:
        full_user=all_text_user
        full_scope_mode='direct_source_output'
        emit(step['id']+': QA tổng thể trực tiếp trên toàn bộ nguồn và thành phẩm.')
    else:
        # Each audit sees the full source and output of its assigned contiguous
        # range, with no missing or repeated window IDs. Groups are determined
        # only by the actual context budget, never by a fixed scene count.
        group_system=('QA ĐỐI CHIẾU TOÀN VĂN THEO NHÓM CỬA SỔ. '
                      'Với MỖI cửa sổ trong nhóm hãy đối chiếu nguồn NGUYÊN VĂN '
                      'với thành phẩm NGUYÊN VĂN, kiểm tra thiếu/lặp/bịa và tính '
                      'liên tục giữa các cửa sổ. Nếu không thể xác nhận toàn nhóm, FAIL. '
                      'Trả JSON {"verdict":"PASS"|"FAIL","issues":["..."],'
                      '"coverage_note":"ghi chú có căn cứ ngắn"}.\n'+common)
        def group_part(j:int)->str:
            return ('\nWINDOW_'+str(j+1).zfill(5)+' SOURCE_OFFSETS='+str(segments[j][0])+':'+str(segments[j][1])+
                    '\nSOURCE FULL:\n'+segments[j][2]+'\nOUTPUT FULL:\n'+chunks[j])
        groups=[];current=[];current_size=0
        for j in range(len(segments)):
            part_size=len(group_part(j))
            if len(group_system)+part_size+500>MAX_ALL_CONTEXT:
                raise ContractError('QA đối chiếu nguồn/thành phẩm một cửa sổ vượt context; chưa LOCK.')
            if current and len(group_system)+current_size+part_size+500>MAX_ALL_CONTEXT:
                groups.append(current);current=[];current_size=0
            current.append(j);current_size+=part_size
        if current:groups.append(current)
        evidence=[]
        for gi,indices in enumerate(groups,1):
            evidence_user='ĐỐI CHIẾU NGUỒN/OUTPUT TẤT CẢ CỬA SỔ CỦA NHÓM:\n'+''.join(group_part(j) for j in indices)
            if len(group_system)+len(evidence_user)>MAX_ALL_CONTEXT:
                raise ContractError('QA đối chiếu nhóm vượt context, không gửi API.')
            fingerprint=sha(json.dumps([digest,[(j+1,sha(segments[j][2]),sha(chunks[j])) for j in indices]],sort_keys=True))
            audit_path=directory/f'full_source_group_{gi:05d}.json'
            audit_paths.append(audit_path)
            previous=None
            if audit_path.exists():
                previous=json.loads(audit_path.read_text(encoding='utf8'))
                if previous.get('fingerprint')!=fingerprint or previous.get('qa_version')!=2:
                    raise ContractError('Checkpoint QA đối chiếu toàn nguồn đã thay đổi, không dùng lại.')
            if previous is not None and previous.get('verdict')=='PASS':
                group_result=parse_review(json.dumps(previous,ensure_ascii=False))
            else:
                group_result=parse_review(provider.generate(system=group_system,user=evidence_user,max_output_tokens=2800).text)
                # Do not persist an unsubstantiated PASS: allow a fresh QA
                # request on the next run rather than caching a broken receipt.
                coverage=group_result.get('coverage_note')
                if (group_result['verdict']=='PASS' and
                    (not isinstance(coverage,str) or not coverage.strip())):
                    raise ContractError(f'QA toàn nguồn nhóm {gi} thiếu ghi chú kiểm chứng, chưa LOCK.')
                atomic_json(audit_path,{'qa_version':2,'fingerprint':fingerprint,
                                        'indices':[j+1 for j in indices],**group_result})
            if group_result['verdict']!='PASS':
                raise ContractError(f'QA toàn nguồn nhóm {gi}/{len(groups)} FAIL, chưa LOCK: '+str(group_result['issues'])[:350])
            coverage=group_result.get('coverage_note')
            if not isinstance(coverage,str) or not coverage.strip():
                raise ContractError(f'QA toàn nguồn nhóm {gi} thiếu ghi chú kiểm chứng, chưa LOCK.')
            evidence.append(f'GROUP_{gi:05d}; WINDOWS={indices[0]+1}..{indices[-1]+1}; SOURCE_OUTPUT_VERIFIED=PASS; EVIDENCE='+coverage.strip())
            emit(step['id']+f': QA đối chiếu nguồn/thành phẩm nhóm {gi}/{len(groups)} PASS.')
        if sorted(j for g in groups for j in g)!=list(range(len(segments))):
            raise ContractError('QA tổng thể không bao phủ đầy đủ cửa sổ nguồn.')
        full_scope_mode='grouped_source_output'
        full_user=('BÁO CÁO ĐỐI CHIẾU NGUYÊN VĂN TỪ CÁC NHÓM ĐÃ PASS:\n'+
                   '\n'.join(evidence)+'\nHỒ SƠ CONTINUITY TẤT CẢ CỬA SỔ:\n'+ledger+
                   '\nKiểm tra xuyên nhóm, không coi hồ sơ là bản gốc thay thế.')
        if len(full_system)+len(full_user)>MAX_ALL_CONTEXT:
            raise ContractError('QA continuity tổng thể vượt context; giữ checkpoint các nhóm, chưa LOCK.')
    evidence_hash=sha(json.dumps({'contract':digest,'mode':full_scope_mode,
             'source_sha':sha(source),'output_sha':sha(combined),
             'source_windows':[sha(part) for _,_,part in segments],
             'output_windows':[sha(part) for part in chunks],
             'continuity':sha(ledger),
             'audit_receipts':[sha(path.read_text(encoding='utf8')) for path in audit_paths]},
             ensure_ascii=False,sort_keys=True))
    final_path=directory/'full_qa.json'
    previous=None
    if final_path.exists():
        previous=json.loads(final_path.read_text(encoding='utf8'))
        if previous.get('contract')!=digest:
            raise ContractError('Checkpoint QA tổng thể không hợp lệ.')
        if previous.get('qa_version')==2 and previous.get('evidence_sha256')!=evidence_hash:
            raise ContractError('Bằng chứng QA tổng thể thay đổi; không tái sử dụng checkpoint.')
        # The legacy receipt was summary-only: redo final QA over SOURCE+OUTPUT
        # once, preserving all PASS source-window checkpoints.
        if previous.get('qa_version')!=2:previous=None
    if previous is not None and previous.get('verdict')=='PASS':
        # Read ALL fields (H_ERROR, Q_TOTAL, gates...), never narrow to just
        # verdict/issues. This is the v1.4 resume bug being repaired.
        verdict=parse_review(json.dumps(previous,ensure_ascii=False))
    else:
        verdict=parse_review(provider.generate(system=full_system,user=full_user,max_output_tokens=3000).text)
        atomic_json(final_path,{'contract':digest,'qa_version':2,
                                'evidence_sha256':evidence_hash,
                                'full_scope_mode':full_scope_mode,**verdict})
        if verdict['verdict']!='PASS':
            raise ContractError('QA tổng thể FAIL, giữ checkpoint: '+str(verdict['issues'])[:350])
    validate_full_qa_gates(step['instructions'],verdict)
    combined=''.join(chunks)
    target=flow.folder/'steps'/step['id']
    # Crash-safe file commit: if the app was interrupted after the output was
    # atomically published but before workflow.json was updated, verify the
    # exact expected bytes and finish registration. Never overwrite a mismatch.
    if target.exists():
        existing=target/filename
        if (not existing.is_file() or
            {p.name for p in target.iterdir()}!={filename} or
            sha(existing.read_text(encoding='utf8'))!=sha(combined)):
            raise ContractError('Đã có đầu ra chưa LOCK nhưng không khớp, không ghi đè.')
    else:
        staged=flow.folder/'steps'/('.'+step['id']+'.publishing')
        if staged.exists():
            raise ContractError('Có thư mục xuất tạm chưa hoàn tất, cần kiểm tra trước khi tiếp tục.')
        staged.mkdir(parents=True,exist_ok=False)
        (staged/filename).write_text(combined,encoding='utf8')
        os.replace(staged,target)
    record={'step_id':step['id'],'title':step['title'],
            'rules':{n:sha(v) for n,v in rules.items()},'outputs':{filename:sha(combined)},
            'inputs':{n:sha(v) for n,v in inputs.items()},'qa_verdict':'PASS','state':'LOCKED',
            'timestamp':time.time(), 'provider_id':execution['provider_id'],'model':execution['model'],
            'decisions':user_decisions or {},'conflict_decisions':conflict_choices or {},
            'engine':'scene_windows','scene_window_count':len(segments), 'execution_contract_sha256':digest,
            'full_qa_evidence_sha256':evidence_hash,'full_qa_mode':full_scope_mode}
    flow.meta['locked'].append(record);flow._save()
    emit(step['id']+f': {len(segments)} cửa sổ + QA nguồn + QA ranh giới + QA tổng thể PASS, đã LOCK {filename}.')
    return record
