﻿Option Explicit
' Windows GUI-subsystem startup. This path never launches cmd.exe or a BAT.
Dim fso, shell, base, pyw, scriptPath, command, result
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
base = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = base
scriptPath = fso.BuildPath(base, "KHOI_DONG_KHONG_CMD.pyw")
pyw = fso.BuildPath(base, ".venv\Scripts\pythonw.exe")

If Not fso.FileExists(scriptPath) Then
  MsgBox "Thieu tep khoi dong: " & scriptPath, vbCritical, "AI Film Studio"
  WScript.Quit 2
End If

If fso.FileExists(pyw) Then
  command = Chr(34) & pyw & Chr(34) & " " & Chr(34) & scriptPath & Chr(34)
Else
  ' pyw.exe is the windowless Python Launcher for Windows.
  ' No BAT, cmd.exe, powershell.exe, or console Python is started here.
  command = "pyw.exe -3 " & Chr(34) & scriptPath & Chr(34)
End If

On Error Resume Next
result = shell.Run(command, 1, True)
If Err.Number <> 0 Then
  Dim info
  info = Err.Description
  Err.Clear
  MsgBox "Khong khoi dong duoc Python giao dien. Kiem tra Python 3.11+ va Python Launcher (pyw.exe)." & vbCrLf & _
    "Neu da cai Python, hay xem NHAT_KY_KHOI_DONG.txt trong thu muc tool." & vbCrLf & info, _
    vbCritical, "AI Film Studio - Loi khoi dong"
  WScript.Quit 3
End If
On Error GoTo 0
If result <> 0 Then
  MsgBox "Khong mo duoc AI Film Studio. Xem file NHAT_KY_KHOI_DONG.txt trong cung thu muc." & vbCrLf & _
   "Ma loi: " & CStr(result), vbExclamation, "AI Film Studio"
End If
