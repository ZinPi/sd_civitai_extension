"""TeamSocLo text-only Responses API adapter.

TeamSocLo's Codex configuration documents:
  base_url=https://gpt.teamsoclo.site/v1; wire_api=responses.
We do not run external install scripts, hard-code advertised model IDs, or
silently retry failed/incomplete requests (which may already have been billed).
Streaming only succeeds when an explicit completed event is observed.
"""
from __future__ import annotations

from .api import Generation, IncompleteGeneration
from .contract import ContractError

TEAMSOCLO_BASE_URL = 'https://gpt.teamsoclo.site/v1'


def _field(obj, name, default=None):
    return obj.get(name, default) if isinstance(obj, dict) else getattr(obj, name, default)


def _make_client(api_key: str, *, timeout=180, client_factory=None):
    if client_factory is None:
        from openai import OpenAI
        client_factory = OpenAI
    return client_factory(api_key=api_key.strip(), base_url=TEAMSOCLO_BASE_URL,
                          timeout=timeout, max_retries=0)


def _safe_error(exc: Exception, action: str) -> str:
    """No raw upstream bodies/exception repr; those may contain API credentials."""
    code = _field(exc, 'status_code')
    kind = type(exc).__name__
    if code == 401 or kind == 'AuthenticationError':
        return 'TeamSocLo từ chối API Key (401). Hãy kiểm tra hoặc đổi key.'
    if code == 403 or kind == 'PermissionDeniedError':
        return 'TeamSocLo không cấp quyền sử dụng model/endpoint này (403).'
    if code == 404 or kind == 'NotFoundError':
        return 'Không tìm thấy model hoặc endpoint TeamSocLo (404); chọn model theo gói của key.'
    if code == 429 or kind == 'RateLimitError':
        return 'TeamSocLo báo hết quota hoặc vượt giới hạn request (429).'
    if code in (400, 422) or kind == 'BadRequestError':
        return 'TeamSocLo từ chối tham số Responses hoặc model (400/422).'
    if code in (408, 409, 500, 502, 503, 504, 520, 522, 524):
        return f'TeamSocLo/gateway trả lỗi HTTP {code}; request có thể đã tính phí. Không tự thử lại.'
    if kind in ('APITimeoutError', 'APIConnectionError', 'TimeoutError', 'ConnectError', 'ReadTimeout'):
        return 'TeamSocLo hết thời gian chờ hoặc đứt kết nối; request có thể đã tính phí. Không tự thử lại.'
    return f'{action} không thành công ({kind}, HTTP {code if code is not None else "không rõ"}).'


def _usage(response):
    usage = _field(response, 'usage')
    input_tokens = int(_field(usage, 'input_tokens', 0) or 0)
    output_tokens = int(_field(usage, 'output_tokens', 0) or 0)
    details = _field(usage, 'input_tokens_details')
    cached = int(_field(details, 'cached_tokens', 0) or 0)
    return input_tokens, output_tokens, cached


def _extract_text(response):
    output_text = _field(response, 'output_text')
    if isinstance(output_text, str) and output_text.strip():
        return output_text
    # The gateway may return only standard Responses output[].content[].text.
    texts = []
    for item in _field(response, 'output', []) or []:
        if _field(item, 'type') != 'message':
            continue
        for content in _field(item, 'content', []) or []:
            if _field(content, 'type') == 'output_text':
                value = _field(content, 'text')
                if isinstance(value, str):
                    texts.append(value)
    return '\n'.join(texts)


def _verify_completed(response, *, fallback_text=''):
    status = _field(response, 'status')
    use = _usage(response)
    if status != 'completed':
        detail = _field(response, 'incomplete_details')
        reason = _field(detail, 'reason') or _field(response, 'error') or 'không rõ'
        # Do not include an upstream error object (possibly containing credential).
        raise IncompleteGeneration(status or 'unknown', 'phản hồi chưa hoàn tất', *use)
    text = _extract_text(response) or fallback_text
    if not isinstance(text, str) or not text.strip():
        raise ContractError('TeamSocLo hoàn tất nhưng không có văn bản đầu ra; không LOCK bước.')
    return Generation(text, *use)


class TeamSocLoProvider:
    provider_id = 'teamsoclo'
    is_live = True
    concurrency_limit = 1  # conservative until account-specific rate limit is verified

    def __init__(self, api_key: str, model: str, reasoning_effort='default', *,
                 client_factory=None, stream=True):
        if not api_key or not api_key.strip():
            raise ContractError('Chưa nhập TeamSocLo API Key.')
        if not model or not model.strip():
            raise ContractError('Chưa chọn model TeamSocLo.')
        self.model = model.strip()
        self.effort = 'default'  # gateway/model-dependent, no unverified reasoning flags
        self.client = _make_client(api_key, client_factory=client_factory)
        self.stream = bool(stream)

    def generate(self, *, system: str, user: str, max_output_tokens: int) -> Generation:
        if max_output_tokens <= 0:
            raise ContractError('Giới hạn đầu ra phải > 0.')
        kwargs = dict(model=self.model, instructions=system, input=user,
                      max_output_tokens=int(max_output_tokens), stream=self.stream)
        # Avoid optional parameters which may not be implemented by every gateway.
        try:
            reply = self.client.responses.create(**kwargs)
            if not self.stream:
                return _verify_completed(reply)
            completed = None
            chunks = []
            # The full output is usable ONLY if the stream ends with completed.
            try:
                for event in reply:
                    event_type = _field(event, 'type')
                    if event_type == 'response.output_text.delta':
                        part = _field(event, 'delta')
                        if isinstance(part, str):
                            chunks.append(part)
                    elif event_type == 'response.completed':
                        completed = _field(event, 'response')
                    elif event_type in ('response.incomplete', 'response.failed', 'error'):
                        raise IncompleteGeneration('stream '+str(event_type), 'API chưa hoàn tất')
            finally:
                close = getattr(reply, 'close', None)
                if callable(close):
                    close()
            if completed is None:
                raise IncompleteGeneration('stream interrupted', 'thiếu sự kiện response.completed')
            return _verify_completed(completed, fallback_text=''.join(chunks))
        except (ContractError, IncompleteGeneration):
            raise
        except Exception as exc:
            raise ContractError(_safe_error(exc, 'Gọi TeamSocLo Responses')) from None


def fetch_teamsoclo_models(api_key: str, *, client_factory=None) -> list[str]:
    """Read account model list; listing does not prove Responses compatibility."""
    if not api_key or not api_key.strip():
        raise ValueError('Chưa nhập TeamSocLo API Key.')
    try:
        client = _make_client(api_key, timeout=30, client_factory=client_factory)
        page = client.models.list()
        found = [_field(item, 'id') for item in _field(page, 'data', []) or []]
    except Exception as exc:
        raise ValueError(_safe_error(exc, 'Lấy model TeamSocLo') +
                         ' Nếu không hỗ trợ /models, nhập model từ gói rồi bấm Thử model.') from None
    excluded = ('embedding','tts','audio','video','image','whisper','moderation',
                'realtime','speech','transcription')
    models = sorted({mid.strip() for mid in found if isinstance(mid, str) and mid.strip()
                     and not any(bad in mid.lower() for bad in excluded)}, key=str.casefold)
    if not models:
        raise ValueError('API chưa trả model văn bản. Hãy nhập mã model đúng gói và bấm Thử model.')
    return models


def probe_teamsoclo_model(api_key: str, model: str, *, client_factory=None):
    """Small, potentially billable request using the same Responses streaming path."""
    provider = TeamSocLoProvider(api_key, model, client_factory=client_factory)
    result = provider.generate(system='Trả lời duy nhất một từ.',
                               user='Trả lời: OK', max_output_tokens=128)
    return result.input_tokens, result.output_tokens
