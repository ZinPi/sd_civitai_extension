"""Compile unfamiliar rule ZIPs to DRAFT contracts (never silently approve).

Two paths:
  * Any JSON member containing workflow schema may provide an executable draft.
  * Natural-language rulepacks can be proposed by a real model, subject to
    deterministic validation, evidence coverage and explicit approval.
No title-, gender-, media- or filename-specific workflows are embedded here.
"""
from __future__ import annotations
import json
from pathlib import Path
from .contract import validate_contract, ContractError

COMPILER_SYSTEM = '''Bạn là chuyên gia biên dịch quy tắc sang hợp đồng JSON cho công cụ sản xuất nội dung.
KHÔNG đoán, KHÔNG bỏ ràng buộc, KHÔNG gán mặc định workflow theo tên file hoặc loại truyện.
Trả về duy nhất một object JSON hợp đồng schema_version=1 có các khóa:
rulepack_sha256,required_inputs,required_outputs,deliverables,export_names,
file_dispositions,stages,release_checks,clause_coverage.
Sản phẩm do bộ quy tắc thực tế yêu cầu; KHÔNG mặc định 6 vai trò của một dự án khác.
Chỉ đưa vào required_outputs/deliverables những sản phẩm có cơ sở từ quy tắc đã chọn.
Mỗi vai trò phải ánh xạ một sản phẩm thực sự được tạo ra, không được để placeholder.
Stage: id,title,adapter='api_text',inputs,output,rules,instructions,validators,
source_evidence (tên file:số dòng), semantic_qa=true, output_type='text'|'json'|'lines',
scope='whole'|'each_audio_line'|'chunks', chunk_source, chunk_lines, parallel=false,
max_output_tokens. Đầu vào nguồn thường là SOURCE_STORY,SOURCE_AUDIO; có thể phụ thuộc stage khác.
Nếu người dùng cung cấp tài liệu kế thừa thì nguồn mang tên SOURCE_HANDOFF;
chỉ yêu cầu khi quy tắc cần, không tự tạo giả dữ liệu phần trước.
Mỗi stage phải có validator mạnh, như required_sections/json_schema/line_id_coverage,
entity_integrity,temporal_order,mapping_integrity,nonhuman_scale_lock nếu đầu ra JSON ledger/timeline/Mapping phù hợp,
không chỉ nonempty. release_checks cho mỗi đầu ra có source_inputs thực sự thuộc lineage,
validators có ít nhất một kiểm tra mạnh. Không được tạo dữ liệu không có chứng cứ.
file_dispositions phân loại mọi file PRODUCTION/REFERENCE/CHAT_ONLY/SUPERSEDED kèm reason.
clause_coverage liệt kê các đoạn điều khoản cần được kiểm tra; không đánh ENFORCE nếu không
thật sự có stage phù hợp. Khi không thể giải quyết hợp đồng, trả JSON {"blocked":"lý do"}.
QUAN TRỌNG: Khi có file 00_TUY_CHON_NGUOI_DUNG.txt, phải ưu tiên các quyết định cụ thể đã được người dùng xác nhận về xung đột và nhánh tùy chọn. ĐIỀU KHOẢN đã bị chọn KHÔNG ÁP DỤNG chỉ bị vô hiệu trong đúng chủ đề ghi nhận, không vô hiệu toàn bộ file. Không tự chọn bên thắng.
QUAN TRỌNG: mọi quy tắc người dùng có hiệu lực ưu tiên hơn cấu hình ví dụ.
Chỉ đề xuất hợp đồng, không tự công nhận QA hay quyền phê duyệt.'''

COMPILER_LIMIT = 55000  # Small packs: single-pass. Large packs: source-complete multi-pass compiler.


def _json_contract(rule_files):
    hits=[]
    for name, content in rule_files.items():
        if not name.lower().endswith('.json'):continue
        try: candidate=json.loads(content)
        except ValueError:continue
        if isinstance(candidate,dict) and candidate.get('schema_version')==1 and isinstance(candidate.get('stages'),list):
            hits.append((name,candidate))
    if len(hits)>1:raise ContractError('Nhiều hợp đồng trong ZIP; cần xác định một hợp đồng ưu tiên')
    return hits[0] if hits else (None,None)


PARTIAL_COMPILER_SUFFIX = """
CHỈ lập các công đoạn thật sự được quy tắc đã chọn cho phép.
Đây là PHẠM VI CỤC BỘ, không được tự bịa sáu sản phẩm toàn dự án.
required_outputs, deliverables và release_checks chỉ liên quan tới công đoạn đang chọn.
Nếu thiếu dữ liệu bắt buộc hoặc quy tắc khác thì trả {"blocked":"mô tả file/bước còn thiếu"}.
Một workflow từ phạm vi PARTIAL tuyệt đối không cho phép xuất PROJECT_FINAL.
"""

def draft_contract(rule_files:dict[str,str], rule_hash:str, provider=None, progress=None,
                   checkpoint_path=None, *, partial:bool=False, max_workers:int=1)->dict:
    embedded_file,raw=_json_contract(rule_files)
    if raw is not None:
        raw=json.loads(json.dumps(raw,ensure_ascii=False))
        if raw.get('rulepack_sha256') not in (None,'__CURRENT_RULEPACK__',rule_hash):
            raise ContractError('SHA của hợp đồng đóng gói không phù hợp ZIP hiện tại')
        raw['rulepack_sha256']=rule_hash
        c=validate_contract(raw,rule_files,rule_hash)
        return c.raw
    if provider is None:
        raise ContractError('ZIP không có hợp đồng cấu trúc. Cần kết nối API để đề xuất workflow rồi xác minh.')
    entire='\n\n'.join(f'=== FILE {name} ===\n{content}' for name,content in rule_files.items())
    if len(entire)>COMPILER_LIMIT:
        from .large_rule_compiler import compile_large
        return compile_large(rule_files,rule_hash,provider,progress,checkpoint_path,partial=partial, max_workers=max_workers)
    system='''Bạn là chuyên gia biên dịch quy tắc sang hợp đồng JSON cho công cụ sản xuất nội dung.
KHÔNG đoán, KHÔNG bỏ ràng buộc, KHÔNG gán mặc định workflow theo tên file hoặc loại truyện.
Trả về duy nhất một object JSON hợp đồng schema_version=1 có các khóa:
rulepack_sha256,required_inputs,required_outputs,deliverables,export_names,
file_dispositions,stages,release_checks,clause_coverage.
Sản phẩm do bộ quy tắc thực tế yêu cầu; KHÔNG mặc định 6 vai trò của một dự án khác.
Chỉ đưa vào required_outputs/deliverables những sản phẩm có cơ sở từ quy tắc đã chọn.
Mỗi vai trò phải ánh xạ một sản phẩm thực sự được tạo ra, không được để placeholder.
Stage: id,title,adapter='api_text',inputs,output,rules,instructions,validators,
source_evidence (tên file:số dòng), semantic_qa=true, output_type='text'|'json'|'lines',
scope='whole'|'each_audio_line'|'chunks', chunk_source, chunk_lines, parallel=false,
max_output_tokens. Đầu vào nguồn thường là SOURCE_STORY,SOURCE_AUDIO; có thể phụ thuộc stage khác.
Mỗi stage phải có validator mạnh, như required_sections/json_schema/line_id_coverage,
không chỉ nonempty. release_checks cho mỗi đầu ra có source_inputs thực sự thuộc lineage,
validators có ít nhất một kiểm tra mạnh. Không được tạo dữ liệu không có chứng cứ.
file_dispositions phân loại mọi file PRODUCTION/REFERENCE/CHAT_ONLY/SUPERSEDED kèm reason.
clause_coverage liệt kê các đoạn điều khoản cần được kiểm tra; không đánh ENFORCE nếu không
thật sự có stage phù hợp. Khi không thể giải quyết hợp đồng, trả JSON {"blocked":"lý do"}.
QUAN TRỌNG: Khi có file 00_TUY_CHON_NGUOI_DUNG.txt, phải ưu tiên các quyết định cụ thể đã được người dùng xác nhận về xung đột và nhánh tùy chọn. ĐIỀU KHOẢN đã bị chọn KHÔNG ÁP DỤNG chỉ bị vô hiệu trong đúng chủ đề ghi nhận, không vô hiệu toàn bộ file. Không tự chọn bên thắng.
QUAN TRỌNG: mọi quy tắc người dùng có hiệu lực ưu tiên hơn cấu hình ví dụ.
Chỉ đề xuất hợp đồng, không tự công nhận QA hay quyền phê duyệt.'''
    response=provider.generate(system=system+(PARTIAL_COMPILER_SUFFIX if partial else ''),user='SHA256 quy tắc: '+rule_hash+'\n'+entire,max_output_tokens=30000)
    t=response.text.strip()
    if t.startswith('```'):t=t.split('\n',1)[1].rsplit('```',1)[0].strip()
    try:raw=json.loads(t)
    except ValueError as e:raise ContractError('Trình biên dịch không trả JSON hợp lệ') from e
    if not isinstance(raw,dict):raise ContractError('Hợp đồng đề xuất không phải object')
    if raw.get('blocked'):raise ContractError('Không thể biên dịch quy tắc: '+str(raw['blocked']))
    # The ruleset itself is the authority. Compilation is only a draft until approved.
    return validate_contract(raw,rule_files,rule_hash).raw


def save_draft(draft:dict,path:Path)->Path:
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(draft,ensure_ascii=False,indent=2),encoding='utf8')
    return path
